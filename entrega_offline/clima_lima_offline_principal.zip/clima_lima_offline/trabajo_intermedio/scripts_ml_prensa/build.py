import json
OUT="/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_prensa/evidencia/"
F="2026-10-27"
def ref(a,y,t,f,u,p=None,i=None): return {"autores":a,"anio":y,"titulo":t,"fuente":f,"url":u,"pais":p,"institucion":i}
def E(id,tipo,acc,via,r,ext,loc,afirma,lim,aplica):
    return {"id":id,"tipo":tipo,"acceso":acc,"via":via,"fecha_acceso":F,"referencia":r,"extracto":ext,"localizador":loc,"afirma":afirma,"limites":lim,"aplica_a":aplica,"revista_cuartil":None}
P="lector_hf_papers"; D="lector_hf_datasets"
carle=lambda: ref("Razzaq, W., & Zhao, Y.-B.",2025,"CARLE: A Hybrid Deep-Shallow Learning Framework for Robust and Explainable RUL Estimation of Rolling Element Bearings","arXiv 2510.17846","https://arxiv.org/abs/2510.17846","China","School of Automation, University of Science and Technology of China")
ml=[
E("E-2300","preprint","texto_completo",P,carle(),
 "Rotational machinery is more prone to failure because of the availability of rolling-element bearings working under aggressive environments. It has been estimated that 40 to 50% of machinery failures can be attributed to these bearings [1].",
 "Seccion 1 Introduction, parrafo 1, hf://papers/2510.17846/paper.md (se omite un artefacto de conversion del simbolo de porcentaje)",
 "Los autores afirman, citando una referencia propia [1], que 40 a 50 % de las fallas de maquinaria se atribuyen a rodamientos; sirve como contexto de por que se estudia la vida remanente de rodamientos.",
 "La cifra de 40 a 50 % viene de la referencia [1] del preprint, que no se leyo; no es dato de bombas ni de prensaestopa, ni de campo propio. Es afirmacion de introduccion, no resultado del trabajo.",
 "Contexto de PHM de rodamientos; comparabilidad con bomba con prensaestopa: baja (generica)."),
E("E-2301","preprint","texto_completo",P,carle(),
 "The dataset includes run-to-failure vibration data from 15 rolling element bearings obtained through accelerated degradation experiments under three distinct operational conditions: 1200 rpm (35 Hz) with a 12 kN radial load, 2250 rpm (37.5 Hz) with an 11 kN radial load, and 2400 rpm (40 Hz) with a 10 kN radial load. ... PRONOSTIA dataset: ... The dataset provides 16 complete run-to-failure data collected under accelerated degradation conditions with three distinct operational conditions: 1800 rpm (100 Hz) with a 4 kN radial load, 1650 rpm (100 Hz) with a 4.2 kN radial load, and 1500 rpm (100 Hz) with a 5 kN radial load.",
 "Seccion 4.1 Dataset Explanation, hf://papers/2510.17846/paper.md",
 "Descripcion de los dos bancos de rodamientos con corrida hasta la falla mas usados: XJTU-SY (15 rodamientos, 3 condiciones) y PRONOSTIA (16 corridas completas, 3 condiciones), ambos con degradacion acelerada.",
 "Rodamientos de banco con degradacion acelerada y carga elevada; no hay bomba, prensaestopa, agua ni lubricacion de campo. Las velocidades de XJTU-SY difieren de la Tabla de otra fuente: aqui 1200 rpm junto a 35 Hz (35 Hz equivale a 2100 rpm; vease E-1204), probable errata del preprint que no se resolvio. Numero de unidades pequeno (15 y 16).",
 "Disponibilidad de series hasta falla para rodamientos (analogo del componente); comparabilidad con rodamiento de bomba en campo: baja."),
E("E-2302","preprint","texto_completo",P,carle(),
 "Since long-term monitoring data form a time series, the initial operation phase is typically stable, with minimal noticeable degradation. Therefore, for the PRONOSTIA dataset, we applied the nonlinear, piecewise degradation model ... The scoring function is asymmetric and penalizes overestimations more heavily than early predictions.",
 "Secciones 4.2 RUL Labels y 4.3 Evaluation indicators, hf://papers/2510.17846/paper.md",
 "Las etiquetas de RUL en estos bancos se construyen con un modelo de degradacion supuesto (lineal en XJTU-SY, lineal por tramos en PRONOSTIA), y la metrica Score de PHM penaliza mas la sobrestimacion (mantener tarde) que la subestimacion.",
 "La etiqueta de RUL es una construccion del autor, no una medicion de vida; el Score descrito es el de un concurso de datos de banco, no un costo de planta. No se leyo el calculo de la penalizacion en dinero.",
 "Diseno de objetivo de prediccion y asimetria del costo de error; comparabilidad con bomba de campo: baja."),
E("E-2303","preprint","texto_completo",P,carle(),
 "CARLE achieved the lowest error with an MSE of 0.00220, MAE of 0.04087 and Score of 130.016. ... CARLE performed much better under unseen operating conditions, highlighting the role of residual connections in enhancing robustness.",
 "Seccion 4.4 Ablation Experiments (rodamiento 3, 35 Hz y 12 kN, XJTU-SY), hf://papers/2510.17846/paper.md",
 "En el banco XJTU-SY, el modelo hibrido propuesto (CNN residual, atencion, LSTM y bosque aleatorio) reporta, para el rodamiento 3 en la condicion de entrenamiento, MAE de 0.04087 y los autores afirman mejor desempeno que sus variantes en condiciones no vistas.",
 "Resultado de los propios autores con rodamientos de banco, entrenamiento en una sola condicion; unidades del RUL no declaradas en lo leido (parecen normalizadas); el 'MSE' definido por ellos es la raiz del error cuadratico. Los Score del texto de ablacion no coinciden con los de la Tabla 4 para el mismo caso (130.016 frente a 199.6124), inconsistencia interna no resuelta. Rodamiento 3 elegido por los autores como representativo. Sin evaluacion en campo ni bombas.",
 "Rendimiento tipico de modelos profundos de RUL en banco; no extrapolable a bomba con prensaestopa."),
E("E-2304","preprint","texto_completo",P,carle(),
 "Lubrication failures contribute to significant fluctuations, primarily due to the occurrence of intermittent metal-to-metal contact, whereas contamination, such as ingress of debris, results in transient energy spikes.",
 "Seccion 2 Time-Frequency Feature Extraction Framework, vineta Energy, hf://papers/2510.17846/paper.md",
 "Los autores describen siete caracteristicas tiempo-frecuencia (energia, frecuencia dominante, entropia, curtosis, asimetria, media y desviacion) y les atribuyen interpretaciones fisicas, entre ellas fluctuaciones por falla de lubricacion y picos transitorios por ingreso de residuos.",
 "Interpretaciones fisicas son afirmaciones de los autores con referencias no leidas; el experimento se hizo en rodamientos de banco sin ingreso controlado de contaminante; no hay validacion de que estas caracteristicas distingan contaminacion por agua o fuga de prensaestopa.",
 "Caracteristicas candidatas para tablero de condicion de rodamiento; comparabilidad con bomba con prensaestopa: baja."),
E("E-2305","preprint","fragmento",P,ref("No verificado (autores no visibles en lo leido)",2026,"CORD: Learning Reusable Degradation Representations Across Heterogeneous Physical Systems","arXiv 2609.39784","https://arxiv.org/abs/2609.39784"),
 "Across bearings, batteries, and cutting tools, CORD (Multi-domain) consistently improves over CORD (Single-domain) under Frozen adaptation, provides further gains under Full FT in most settings, and remains competitive with representative external baselines. ... XJTU-SY bearings (Wang et al., 2020), CALCE CS2 batteries ..., PHM2010 cutting tools ..., and N-CMAPSS turbofan engines ... instantiate these two boundaries.",
 "Resumen e Introduccion (inicio), hf://papers/2609.39784/paper.md; se leyeron unos 13 mil caracteres, no las tablas de resultados",
 "Preentrenamiento conjunto entre rodamientos, baterias, herramientas de corte y motores turbofan mejora la representacion de degradacion frente a preentrenar en un solo dominio; para rodamientos usa XJTU-SY.",
 "Solo se leyeron resumen, introduccion y definicion del problema; no se leyeron tablas ni cifras de error. Resultado de banco y de conjuntos publicos, no de bombas; la mejora se declara frente a su propia version de dominio unico.",
 "Tendencia 2026 de modelos base para prognostico con pocos datos propios; comparabilidad con bomba de campo: baja."),
E("E-2306","preprint","fragmento",P,ref("No verificado (autores no visibles en lo leido)",2026,"Time-Series Foundation Model Embeddings for Remaining Useful Life Estimation","arXiv 2606.11990","https://arxiv.org/abs/2606.11990"),
 "In addition to sensor measurements, we utilize maintenance logs containing the set of failure timestamps ... Timestamps with no subsequent repair events are excluded from the supervised training set.",
 "Seccion II-A Data Preprocessing and Label Generation, hf://papers/2606.11990/paper.md",
 "Ejemplo de construccion de etiquetas de RUL a partir de registros de reparacion: el tiempo hasta la siguiente falla registrada, y los instantes sin falla posterior (observaciones censuradas a la derecha) se excluyen del entrenamiento supervisado.",
 "Los equipos son dispositivos industriales de dos tipos, no bombas ni rodamientos; la exclusion de datos censurados sesga la muestra hacia vidas completas; no se leyeron los resultados de error. Los datos del estudio no son publicos en lo leido.",
 "Advertencia metodologica: aplicar RUL con registros de mantenimiento exige tratar la censura; comparabilidad con bomba de campo: media en metodo, baja en activo."),
E("E-2307","preprint","fragmento",P,ref("Sehri, M., Varejao, I., Hua, Z., Bonella, V., Santos, A., Boldt, F. de A., Dumond, P., & Varejao, F. M.",2025,"Towards a Universal Vibration Analysis Dataset: A Framework for Transfer Learning in Predictive Maintenance and Structural Health Monitoring","arXiv 2504.11581","https://arxiv.org/abs/2504.11581","Canada y Brasil","University of Ottawa; Universidade Federal do Espirito Santo; Instituto Federal do Espirito Santo"),
 "The initial framework includes a collection of bearing vibration signals from various publicly available datasets. ... Another challenge is the significant amount of healthy data when compared to faulty data, since machines aren't meant to fail.",
 "Resumen e Introduccion, hf://papers/2504.11581/paper.md (primeros 7 mil caracteres)",
 "Proponen una coleccion de senales de vibracion de rodamientos de conjuntos publicos para preentrenar y afinar modelos de diagnostico, y senalan el desbalance entre datos sanos y con falla como obstaculo.",
 "Solo se leyo el inicio; no se leyeron lista de conjuntos, licencia ni resultados. Es diagnostico (clasificacion de falla), no vida remanente; vibracion de banco.",
 "Transferencia entre conjuntos de rodamientos; respalda el argumento de escasez de datos con falla; comparabilidad con bomba con prensaestopa: baja."),
E("E-2308","preprint","fragmento",P,ref("Peng, H., Liu, J., Du, J., Gao, J., & Wang, W.",2024,"BearLLM: A Prior Knowledge-Enhanced Bearing Health Management Framework with Unified Vibration Signal Representation","arXiv 2408.11281","https://arxiv.org/abs/2408.11281"),
 "BearLLM using one set of pre-trained weights achieves state-of-the-art performance on nine publicly available fault diagnosis benchmarks, outperforming specific methods designed for individual datasets.",
 "Resumen (abstract), hf://papers/2408.11281/paper.md",
 "Un solo modelo multimodal (senal de vibracion mas texto) se declara con mejor desempeno que metodos especificos en nueve bancos publicos de diagnostico de fallas de rodamientos.",
 "Afirmacion de los autores sobre diagnostico en bancos publicos; no se leyeron tablas, ni cuales son los nueve conjuntos, ni si incluye CWRU o Paderborn. No es vida remanente y no se probo en campo.",
 "Estado del arte 2024 de diagnostico unificado de rodamientos; comparabilidad con bomba de campo: baja."),
E("E-2309","preprint","abstract",P,ref("Leyva-Vazquez, M., Rumbaut Rangel, D., Cevallos-Torres, L., & Matheu Perez, A.",2026,"Neutrosophic Ensemble Classification for Uncertainty-Aware Bearing Fault Detection: Evidence from Laboratory and Variable-Speed Industrial Benchmarks","arXiv 2610.06880","https://arxiv.org/abs/2610.06880"),
 "On CWRU, after correcting a file-to-class mapping error, the ensemble reaches 100.00 percent accuracy on three of four held-out loads (92.27 percent on the fourth), leaving too few errors for uncertainty analysis. On JNU, holding out 1000 rpm, accuracy collapses to 40.64 percent, below a majority-class baseline",
 "Abstract, hf://papers/2610.06880/paper.md (el servidor entrego metadatos, resumen del autor y un resumen automatico; texto completo no disponible)",
 "Con el conjunto CWRU un conjunto de arboles alcanza 100 % de exactitud en tres de cuatro cargas retenidas, pero con el conjunto JNU al retener 1000 rpm la exactitud cae a 40.64 %, por debajo de la clase mayoritaria: el desempeno en CWRU no garantiza generalizacion.",
 "Solo se leyo el resumen del autor; clasificacion de fallas sembradas (no degradacion natural) en dos bancos; no hay bombas ni vida remanente. El resumen reporta que corrigieron un error de mapeo de archivos a clases en CWRU, ejemplo de fuga o error de etiquetado.",
 "Cautela con cifras de exactitud de CWRU: saturadas y poco transferibles; comparabilidad con bomba de campo: baja."),
E("E-2310","preprint","snippet",P,ref("No verificado",2022,"Conformal Prediction Intervals for Remaining Useful Lifetime Estimation","arXiv 2212.14612 (segun listado de hf://papers)","https://arxiv.org/abs/2212.14612"),
 None,None,
 "Pista: segun el resumen automatico del listado, aplica prediccion conforme para dar intervalos garantizados a estimaciones de vida remanente de redes profundas y de arboles potenciados.",
 "No se leyo el texto ni el resumen del autor; el resumen mostrado es automatico del listado; no se sabe en que conjuntos de datos se probo (no se asume rodamientos).",
 "Candidato para cuantificar incertidumbre de RUL; leer antes de citar."),
E("E-2311","preprint","snippet",P,ref("No verificado",2023,"Explaining Deep Neural Networks for Bearing Fault Detection with Vibration Concepts","arXiv 2310.11450 (segun listado de hf://papers)","https://arxiv.org/abs/2310.11450"),
 None,None,
 "Pista: segun el listado, aplica explicaciones basadas en conceptos a redes profundas de deteccion de fallas de rodamientos, con conceptos de vibracion comprensibles para el humano.",
 "No se leyo; el resumen es automatico del listado; sin datos de conjuntos ni resultados.",
 "Candidato sobre explicabilidad de modelos de rodamientos; leer antes de citar."),
E("E-2312","preprint","snippet",P,ref("No verificado",2023,"Real Time Bearing Fault Diagnosis Based on Convolutional Neural Network and STM32 Microcontroller","arXiv 2304.09100 (segun listado de hf://papers)","https://arxiv.org/abs/2304.09100"),
 None,None,
 "Pista: segun el listado, una red convolucional para clasificar fallas de rodamientos se despliega en un microcontrolador STM32.",
 "No se leyo; sin datos del conjunto de entrenamiento ni de la exactitud; el resumen es automatico del listado.",
 "Candidato para analitica en el borde (equipo de baja potencia); leer antes de citar."),
E("E-2313","preprint","snippet",P,ref("No verificado",2024,"Quadratic Time-Frequency Analysis of Vibration Signals for Diagnosing Bearing Faults","arXiv 2401.01172 (segun listado de hf://papers)","https://arxiv.org/abs/2401.01172"),
 None,None,
 "Pista: segun el listado, una red convolucional tiempo-frecuencia (TF-CNN) para diagnostico de fallas de rodamientos con resistencia al ruido.",
 "No se leyo; sin datos de conjunto, exactitud ni condiciones; el resumen es automatico del listado.",
 "Candidato de diagnostico en condiciones no estacionarias; leer antes de citar."),
]
json.dump(ml,open(OUT+"ml_registro.json","w"),ensure_ascii=False,indent=1)

dat=[
E("E-2350","repositorio","fragmento",D,ref("DavidNguyen (usuario de Hugging Face; reempaquetado); datos originales de XJTU-SY segun el texto del repo",2026,"XJTU-SY_Bearing_Datasets (zip de 15 rodamientos con carpetas Data, Photographs e Important References)","Hugging Face Datasets, hf://datasets/DavidNguyen/XJTU-SY_Bearing_Datasets","https://huggingface.co/datasets/DavidNguyen/XJTU-SY_Bearing_Datasets"),
 "XJTU-SY bearing datasets can be downloaded by the following links:",
 "Download_Links_20190306.txt (primera linea); listado del repo con ls: XJTU-SY_Bearing_Datasets.zip de 5447931446 bytes; el anio es la fecha de actualizacion del repo en el buscador (2026-01-02)",
 "Hay en Hugging Face una copia del conjunto XJTU-SY de rodamientos con corrida hasta la falla (zip de unos 5.4 GB), con cinco documentos de referencia incluidos (cuatro articulos de RUL de redes profundas y una interpretacion del conjunto).",
 "No se descargaron datos. El ReadMe.txt no se pudo leer como texto (codificacion no UTF-8), no hay README de la tarjeta ni licencia visible; es copia de un tercero, no del autor original. Rodamientos de bolas de banco con degradacion acelerada, no bomba. El criterio de falla y las etiquetas no se leyeron aqui (vease E-1204 para la descripcion).",
 "Dato abierto de vida de rodamientos hasta falla (15 unidades); comparabilidad con bomba con prensaestopa: baja."),
E("E-2351","repositorio","fragmento",D,ref("odysseywt (usuario de Hugging Face)",2025,"FEMTO (archivo FEMTO.csv, sin descripcion)","Hugging Face Datasets, hf://datasets/odysseywt/FEMTO","https://huggingface.co/datasets/odysseywt/FEMTO"),
 "license: mit task_categories: - time-series-forecasting language: - en",
 "README.md (cabecera YAML, 78 bytes); listado: FEMTO.csv de 1305035588 bytes; el anio es la fecha de actualizacion en el buscador (2025-05-14)",
 "Repositorio con un solo CSV de 1.3 GB nombrado FEMTO, etiquetado como pronostico de series de tiempo con licencia MIT declarada por el usuario.",
 "No hay descripcion, ni origen, ni cita, ni columnas; el vinculo con el conjunto PRONOSTIA/FEMTO-ST original se infiere solo del nombre; la licencia MIT declarada por un tercero no sustituye la del autor del conjunto. No se descargo.",
 "Posible copia de PRONOSTIA (16 corridas); no apto como evidencia citable hasta conocer procedencia."),
E("E-2352","repositorio","snippet",D,ref("submission096 (usuario de Hugging Face)",2025,"FEMTO (archivo PdM.csv)","Hugging Face Datasets, hf://datasets/submission096/FEMTO","https://huggingface.co/datasets/submission096/FEMTO"),
 None,None,
 "Pista: repositorio con un CSV llamado PdM.csv de 1305035588 bytes, el mismo tamano que FEMTO.csv de E-2351, y un README de 30 bytes.",
 "Solo se vio el listado de archivos; no se leyo el README ni los datos. La igualdad de tamano sugiere duplicado, pero no se comparo contenido.",
 "Posible duplicado de E-2351; no usar como respaldo."),
E("E-2353","repositorio","fragmento",D,ref("Amgharr (usuario de Hugging Face)",2025,"FEMTO-ST_DATASET (caracteristicas en parquet: train, val y test)","Hugging Face Datasets, hf://datasets/Amgharr/FEMTO-ST_DATASET","https://huggingface.co/datasets/Amgharr/FEMTO-ST_DATASET"),
 "pretty_name: FEMTO-ST Bearing Dataset for IIoT Machine Health Monitoring size_categories: - 1M<n<10M",
 "README.md (cabecera YAML, 338 bytes) y listado: features_train.parquet, features_val.parquet, features_test.parquet; el anio es la fecha de actualizacion en el buscador (2025-10-31)",
 "Repositorio que declara ser el conjunto de rodamientos FEMTO-ST en forma de caracteristicas ya extraidas (de 1 a 10 millones de filas), con etiquetas 'bearing-degradation' y licencia MIT declarada.",
 "El README solo trae metadatos: no explica que caracteristicas, ventana, etiqueta de RUL ni como se hizo la particion train/val/test (riesgo de fuga si se dividio por ventanas y no por rodamiento); la licencia MIT es del usuario y no consta la del conjunto original. No se descargo.",
 "Series de condicion de rodamientos (analogo de componente) ya preprocesadas; comparabilidad con bomba con prensaestopa: baja."),
E("E-2354","repositorio","fragmento",D,ref("wutZYH (usuario de Hugging Face)",2025,"cwru-bearing-fault-qa (preguntas y respuestas sobre fallas de rodamientos CWRU)","Hugging Face Datasets, hf://datasets/wutZYH/cwru-bearing-fault-qa","https://huggingface.co/datasets/wutZYH/cwru-bearing-fault-qa"),
 "features: - name: prompt dtype: string - name: response dtype: string splits: - name: train num_bytes: 979784 num_examples: 1177",
 "README.md (cabecera YAML y plantilla sin informacion), hf://datasets/wutZYH/cwru-bearing-fault-qa/README.md; el anio es la fecha de actualizacion en el buscador (2025-05-23)",
 "Repositorio de 1177 pares de texto prompt y respuesta, cuyo nombre indica que se derivan del conjunto CWRU de fallas sembradas de rodamientos.",
 "La tarjeta dice 'More Information needed': sin origen, sin licencia, sin descripcion de como se generaron las respuestas; no contiene senales de vibracion; el vinculo con CWRU se infiere del nombre. Sin tiempos hasta la falla.",
 "Sin utilidad directa para RUL; solo muestra el uso de CWRU en modelos de lenguaje."),
E("E-2355","repositorio","fragmento",D,ref("mdsajjadullah (usuario de Hugging Face)",2026,"bearing-fault-diagnosis-cwru-results (caracteristicas y resultados sobre CWRU)","Hugging Face Datasets, hf://datasets/mdsajjadullah/bearing-fault-diagnosis-cwru-results","https://huggingface.co/datasets/mdsajjadullah/bearing-fault-diagnosis-cwru-results"),
 "CWRU Bearing Dataset - 9,487 segments | 4 fault classes Ball Fault - Inner Race - Outer Race - Normal ... 26 hand-crafted features per segment",
 "README.md completo (1035 bytes), hf://datasets/mdsajjadullah/bearing-fault-diagnosis-cwru-results/README.md; licencia MIT declarada; el anio es la fecha de actualizacion en el buscador (2026-05-29)",
 "Repositorio con 26 caracteristicas por segmento (tiempo, frecuencia y wavelet db4) de 9,487 segmentos de CWRU en cuatro clases, y una tabla donde XGBoost, bosque aleatorio y SVM reportan 97.2 a 97.6 % de exactitud.",
 "Resultados declarados por el usuario, sin protocolo de particion: si los segmentos de un mismo archivo caen en entrenamiento y prueba hay fuga, y E-2309 muestra que CWRU se satura y no generaliza entre condiciones. Fallas sembradas (electroerosion), no degradacion natural; sin bomba, sin tiempos hasta la falla. Los archivos CSV no se descargaron.",
 "Ejemplo de diagnostico clasico con caracteristicas manuales; comparabilidad con bomba de campo: baja."),
E("E-2356","repositorio","fragmento",D,ref("rasinmuhammed (usuario de Hugging Face)",2026,"predictive-maintenance-remaining-useful-life (maquinas sinteticas con RUL exacto)","Hugging Face Datasets, hf://datasets/rasinmuhammed/predictive-maintenance-remaining-useful-life","https://huggingface.co/datasets/rasinmuhammed/predictive-maintenance-remaining-useful-life"),
 "A synthetic run-to-failure dataset: 100 machines, each followed from install to failure, 23,118 hourly readings in total.",
 "README.md (primeros 3000 bytes, seccion inicial), hf://datasets/rasinmuhammed/predictive-maintenance-remaining-useful-life/README.md; licencia MIT declarada; el anio es la fecha de actualizacion en el buscador (2026-08-19)",
 "Conjunto sintetico de 100 maquinas con corrida hasta la falla y RUL exacto (cuatro modos de falla: desgaste de herramienta, disipacion de calor, potencia y sobreesfuerzo), con division por unidad y sin censura declarada en lo leido.",
 "Es sintetico: el RUL se declara antes de generar los datos, de modo que no prueba nada sobre degradacion real; los modos de falla no incluyen rodamiento ni prensaestopa; solo se leyo el inicio del README. Util para probar tuberias de modelado, no como evidencia.",
 "Banco de pruebas de codigo para RUL y censura; comparabilidad con bomba con prensaestopa: nula."),
E("E-2357","repositorio","snippet",D,ref("AI4Manufacturing (organizacion de Hugging Face)",2026,"PADERBORN, PADERBORN-perception y PADERBORN-annotated (acceso restringido)","Hugging Face Datasets, hf://datasets/AI4Manufacturing/PADERBORN","https://huggingface.co/datasets/AI4Manufacturing/PADERBORN"),
 None,None,
 "Pista: tres repositorios con acceso 'manual' (restringido) cuyo nombre alude a Paderborn, actualizados en 2026-10-21 segun el buscador.",
 "No se leyo ningun archivo: el acceso requiere aprobacion; no se sabe si son los rodamientos con corrida hasta la falla o el conjunto de fallas sembradas de la misma universidad. No usar como respaldo.",
 "Pista para la familia Paderborn; los rodamientos hasta falla legibles ya estan en E-9604 y E-1703."),
E("E-2358","preprint","snippet",P,ref("No verificado",2024,"CARE to Compare: A real-world dataset for anomaly detection in wind turbine data","arXiv 2404.10320 (segun listado de hf://papers)","https://arxiv.org/abs/2404.10320"),
 None,None,
 "Pista: segun el listado, un conjunto de datos reales de aerogeneradores con eventos para evaluar deteccion de anomalias y un indicador de desempeno propio.",
 "No se leyo; no es bomba ni rodamiento aislado; no se sabe si hay etiquetas de falla de rodamiento ni licencia.",
 "Candidato de series de condicion de campo (maquina rotativa distinta); leer antes de citar."),
]
json.dump(dat,open(OUT+"datos_registro.json","w"),ensure_ascii=False,indent=1)

W=OUT
def dump(n,o): json.dump(o,open(W+n,"w"),ensure_ascii=False,indent=1)
dump("ml_elementos.json",[
 {"seccion":"ml","titulo":"Modelos profundos de vida remanente de rodamientos entrenados y probados en bancos con degradacion acelerada (XJTU-SY y PRONOSTIA)","evidencia":["E-2300","E-2301","E-2302","E-2303","E-1204"],"limite":"Todo es banco con rodamientos de bolas cargados cerca de su capacidad dinamica y etiquetas de RUL construidas por los autores; error reportado en unidades normalizadas; sin bomba, sin prensaestopa, sin campo. Inconsistencias internas de Score en E-2303 y de velocidad en E-2301."},
 {"seccion":"ml","titulo":"Tratamiento de censura y de datos incompletos en prognostico con registros de mantenimiento","evidencia":["E-2306","E-1201","E-1202","E-9601"],"limite":"E-2306 excluye los instantes sin falla posterior (censura a la derecha) en dispositivos no mecanicos; E-1201 a E-1202 son un metodo de supervivencia en rodamientos de banco. Ninguno es dato de bomba."},
 {"seccion":"ml","titulo":"Diagnostico de fallas de rodamientos: saturacion de CWRU y mala generalizacion entre condiciones","evidencia":["E-2309","E-2308","E-2307","E-1205","E-2355"],"limite":"Fallas sembradas en bancos; E-2309 solo por resumen; E-2308 y E-2307 solo fragmentos iniciales; E-2355 son resultados autodeclarados sin protocolo de particion. No es vida remanente."},
 {"seccion":"ml","titulo":"Modelos base y preentrenamiento entre sistemas para prognostico con pocos datos propios","evidencia":["E-2305","E-2306"],"limite":"Fragmentos de resumen e introduccion; sin cifras leidas; dominios distintos de bombas."},
 {"seccion":"ml","titulo":"Candidatos sin leer: intervalos de incertidumbre, explicabilidad y analitica en el borde","evidencia":["E-2310","E-2311","E-2312","E-2313"],"limite":"Solo resumen automatico de un listado; no respaldan afirmaciones."},
 {"seccion":"ml","titulo":"Bomba con prensaestopa: no se hallo modelo de aprendizaje automatico ni conjunto con vida remanente de prensaestopa o de rodamiento de bomba con prensaestopa en estas vias","evidencia":[],"limite":"SIN DATOS PARA ARMARLO: busquedas en hf://papers, hf://datasets y hub_repo_search sin resultados; no equivale a afirmar que no exista en la literatura."}
])
dump("ml_cifras.json",[
 {"id":"CF-01","valor":"40 a 50","unidad":"%","mide":"Proporcion de fallas de maquinaria que los autores atribuyen a rodamientos","condiciones":"Afirmacion de introduccion con referencia [1] no leida; no es de bombas","evidencia":["E-2300"]},
 {"id":"CF-02","valor":"15","unidad":"rodamientos","mide":"Cantidad de rodamientos con corrida hasta la falla en XJTU-SY (3 condiciones, 5 por condicion segun E-1204)","condiciones":"Banco con degradacion acelerada","evidencia":["E-2301","E-1204"]},
 {"id":"CF-03","valor":"16","unidad":"corridas","mide":"Corridas completas hasta la falla en PRONOSTIA segun el preprint","condiciones":"Banco con degradacion acelerada; 3 condiciones de 4, 4.2 y 5 kN","evidencia":["E-2301"]},
 {"id":"CF-04","valor":"0.04087","unidad":"adimensional (RUL normalizado, a confirmar)","mide":"Error absoluto medio reportado para el rodamiento 3 de XJTU-SY en la condicion de entrenamiento","condiciones":"35 Hz y 12 kN; resultado de los autores; unidades del RUL no declaradas en lo leido","evidencia":["E-2303"]},
 {"id":"CF-05","valor":"40.64","unidad":"%","mide":"Exactitud de un conjunto de clasificadores en JNU al retener 1000 rpm, inferior a la clase mayoritaria","condiciones":"Fallas sembradas en banco; solo resumen","evidencia":["E-2309"]},
 {"id":"CF-06","valor":"1000","unidad":"dias","mide":"Tope de la etiqueta de RUL usado por los autores","condiciones":"Dispositivos industriales no mecanicos; etiqueta derivada de registros de reparacion","evidencia":["E-2306"]}
])
dump("ml_replicas.json",[
 {"id":"R1","titulo":"Condiciones de operacion de XJTU-SY y PRONOSTIA segun el preprint CARLE","tipo":"tabla","unidad":"","condiciones":"Rodamientos de banco con degradacion acelerada","replica_de":"Seccion 4.1 de CARLE (arXiv 2510.17846)","evidencia":["E-2301"],"limites":"Transcripcion del texto de los autores; en XJTU-SY el texto escribe 1200 rpm junto a 35 Hz (35 Hz equivale a 2100 rpm, vease E-1204), por lo que la velocidad en rpm de la primera fila se marca como dudosa.","columnas":["Conjunto","Condicion","Velocidad declarada","Carga radial [kN]","Frecuencia [Hz]"],"filas":[["XJTU-SY","C1","1200 rpm (dudosa)","12","35"],["XJTU-SY","C2","2250 rpm","11","37.5"],["XJTU-SY","C3","2400 rpm","10","40"],["PRONOSTIA","C1","1800 rpm","4","100"],["PRONOSTIA","C2","1650 rpm","4.2","100"],["PRONOSTIA","C3","1500 rpm","5","100"]]},
 {"id":"R2","titulo":"Ablacion de CARLE en el rodamiento 3 de XJTU-SY, condicion 35 Hz y 12 kN","tipo":"tabla","unidad":"RUL normalizado (a confirmar)","condiciones":"Entrenamiento y prueba en la misma condicion; un solo rodamiento elegido por los autores","replica_de":"Seccion 4.4 de CARLE, texto de la vineta 35Hz12kN","evidencia":["E-2303"],"limites":"Cifras del texto de los autores; el 'MSE' definido por ellos es raiz del error cuadratico; el Score de la Tabla 4 para el mismo caso es otro (199.6124); un rodamiento no basta para una conclusion.","columnas":["Modelo","MSE","MAE","Score"],"filas":[["CARLE","0.00220","0.04087","130.016"],["CALE (sin conexiones residuales)","0.00265","0.04561","144.2532"],["CRLE (sin atencion)","0.00275","0.04747","149.22"],["CARL (sin conjunto)","0.00806","0.07905","250.3705"]]}
])
dump("ml_tecnicas.json",[
 {"tecnica_o_sensor":"Filtro gaussiano, transformada wavelet continua y siete caracteristicas tiempo-frecuencia (energia, frecuencia dominante, entropia, curtosis, asimetria, media, desviacion) sobre vibracion de dos ejes","que_mide":"Degradacion de rodamientos de bolas a partir de vibracion horizontal y vertical","resultado_publicado":"Con esas caracteristicas, una red CNN-atencion-LSTM mas bosque aleatorio reporta MAE de 0.04087 en el rodamiento 3 de XJTU-SY en la condicion de entrenamiento y mejor desempeno que variantes en condiciones no vistas","condiciones":"XJTU-SY a 25 kHz y PRONOSTIA a 25.6 kHz, degradacion acelerada; entrenamiento en una condicion","limites":"Banco, sin bomba; interpretaciones fisicas con referencias no leidas; inconsistencias internas de Score","evidencia":["E-2301","E-2303","E-2304"]},
 {"tecnica_o_sensor":"Modelo de supervivencia con divergencia KL para deteccion temprana y RUL con censura","que_mide":"Inicio de degradacion y vida remanente en rodamientos de bolas con datos censurados","resultado_publicado":"Metodo ya registrado en el caso de la bomba (E-1201 a E-1204); se hereda sin releer","condiciones":"XJTU-SY, rodamientos de banco","limites":"Banco; solo reutilizable como metodo","evidencia":["E-1201","E-1204"]},
 {"tecnica_o_sensor":"Modelo base de series de tiempo congelado con cabezal de regresion para RUL","que_mide":"RUL en dias a partir de registros de sensores y de reparaciones","resultado_publicado":"Los autores afirman mejora sobre linea base recurrente, convolucional, de transformadores y de arboles potenciados","condiciones":"Dos tipos de dispositivos industriales; ventana de contexto corta","limites":"Solo resumen e inicio; sin cifras; no es rodamiento ni bomba","evidencia":["E-2306"]},
 {"tecnica_o_sensor":"Ensamble de clasificadores con descomposicion neutrosofica de incertidumbre","que_mide":"Confianza de la clasificacion de fallas de rodamientos CWRU y JNU","resultado_publicado":"Entropia predictiva se asocia con el error; exactitud de JNU cae a 40.64 % al retener 1000 rpm","condiciones":"Fallas sembradas, banco, retencion de una condicion","limites":"Solo resumen; sin RUL","evidencia":["E-2309"]}
])
dump("datos_elementos.json",[
 {"seccion":"ml","titulo":"Conjuntos abiertos de rodamientos con corrida hasta la falla disponibles en Hugging Face (XJTU-SY, Paderborn de carga y velocidad variables, FEMTO/PRONOSTIA reempaquetados)","evidencia":["E-2350","E-2351","E-2353","E-9604","E-1703","E-9612"],"limite":"Todos son rodamientos de bolas de banco con degradacion acelerada o variable; tarjetas con poca o ninguna descripcion en los reempaquetados de FEMTO; licencia verificada solo en E-9604; ninguno se descargo; XJTU-SY tiene 15 unidades."},
 {"seccion":"confiabilidad","titulo":"Cantidad y tamano de los conjuntos hasta falla: base para ajustar vida de rodamiento solo con cautela","evidencia":["E-2301","E-9604","E-9612"],"limite":"15, 16 y 17 unidades de banco; el criterio de falla y la censura se declaran en cada fuente original, no en los reempaquetados."},
 {"seccion":"ml","titulo":"Conjuntos de diagnostico (fallas sembradas) de CWRU en Hugging Face","evidencia":["E-2354","E-2355","E-2309"],"limite":"Sin tiempos hasta la falla; E-2354 son pares de texto; E-2355 con resultados autodeclarados; CWRU saturado segun E-2309."},
 {"seccion":"ml","titulo":"Conjunto sintetico con RUL exacto para pruebas de codigo","evidencia":["E-2356"],"limite":"Sintetico; sin modos de falla de rodamiento ni de prensaestopa."},
 {"seccion":"ml","titulo":"Datos de bombas heredables del caso anterior","evidencia":["E-1700","E-1701","E-1704","E-1705","E-1706"],"limite":"MIMII es audio normal o anomalo sin tiempos hasta la falla; E-1704 a E-1706 son solo referencias de buscador sin leer; ninguno cubre prensaestopa."},
 {"seccion":"ml","titulo":"Conjunto de bomba con prensaestopa y tiempos hasta la falla o series de condicion","evidencia":[],"limite":"SIN DATOS PARA ARMARLO: no se hallo en hf://datasets, en hub_repo_search ni en hf://papers con las consultas listadas; no se pudo consultar Zenodo, Mendeley, Kaggle ni repositorios universitarios desde estas vias."}
])
dump("datos_cifras.json",[
 {"id":"CF-01","valor":"5447931446","unidad":"bytes","mide":"Tamano del zip de XJTU-SY en el repo de Hugging Face","condiciones":"Listado del repo; no se descargo","evidencia":["E-2350"]},
 {"id":"CF-02","valor":"1305035588","unidad":"bytes","mide":"Tamano de FEMTO.csv y de PdM.csv en dos repos distintos","condiciones":"Listados; igualdad sugiere duplicado, contenido no comparado","evidencia":["E-2351","E-2352"]},
 {"id":"CF-03","valor":"9487","unidad":"segmentos","mide":"Segmentos de CWRU en el repo de resultados","condiciones":"Dato declarado por el usuario del repo","evidencia":["E-2355"]},
 {"id":"CF-04","valor":"23118","unidad":"lecturas horarias","mide":"Lecturas del conjunto sintetico de 100 maquinas","condiciones":"Sintetico","evidencia":["E-2356"]}
])
dump("datos_replicas.json",[
 {"id":"R1","titulo":"Inventario de repositorios abiertos de Hugging Face revisados para rodamientos con tiempos hasta la falla o series de condicion","tipo":"tabla","unidad":"","condiciones":"Revision del 2026-10-27 por lector de Hugging Face; ningun dato descargado","replica_de":"Elaboracion propia a partir de README y listados (no replica una tabla publicada)","evidencia":["E-2350","E-2351","E-2352","E-2353","E-2354","E-2355","E-2356","E-9604","E-1703"],"limites":"Licencias y descripciones son las declaradas por los usuarios; FEMTO y PRONOSTIA no se verificaron contra el original; no hay unidades de bomba.","columnas":["Repositorio","Contenido declarado","Licencia declarada","Tamano visto","Tiene tiempos hasta falla"],"filas":[["DavidNguyen/XJTU-SY_Bearing_Datasets","XJTU-SY, 15 rodamientos","no visible","5447931446 bytes","si (por descripcion del conjunto)"],["odysseywt/FEMTO","CSV sin descripcion","mit","1305035588 bytes","no verificado"],["submission096/FEMTO","CSV PdM.csv","no leida","1305035588 bytes","no verificado"],["Amgharr/FEMTO-ST_DATASET","caracteristicas en parquet","mit","tres parquet de 0.47 a 0.96 GB","no verificado"],["wutZYH/cwru-bearing-fault-qa","pares de texto sobre CWRU","no visible","1177 ejemplos","no"],["mdsajjadullah/bearing-fault-diagnosis-cwru-results","caracteristicas de CWRU","mit","9487 segmentos","no"],["rasinmuhammed/predictive-maintenance-remaining-useful-life","sintetico, 100 maquinas","mit","23118 lecturas","si, sintetico"],["Nounours777/Paderborn-bearing","Paderborn hasta falla, 17 rodamientos","cc-by-4.0","no medido","si (E-9604)"]]}
])

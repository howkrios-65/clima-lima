import json, re, html, glob
from collections import Counter
S='/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/'
P=S+'modo_prensa/'
D='/home/user/clima-lima/historial/dossiers/bomba_prensaestopa_rodamientos/'
DB='/home/user/clima-lima/historial/dossiers/bomba_centrifuga/'
tpl=open(S+'mapa/template.html',encoding='utf-8').read()
fich=json.load(open(S+'fichas.json',encoding='utf-8'))
md=open('/home/user/clima-lima/docs/agentes/guia_comandos.md',encoding='utf-8').read()
J=lambda p:json.load(open(p,encoding='utf-8'))

# ---- cifras reales de la v2 (se recalculan de los archivos del caso)
tot=J(P+'evidencia_total.json'); T={e['id']:e for e in tot}
v1=J(P+'evidencia_total_v1_corregido.json'); V1={e['id'] for e in v1}
assert J(D+'evidencia.json')==tot and len(tot)==483 and V1<=set(T)
reg={}
for f in glob.glob(P+'evidencia/*_registro.json'): reg[f.split('/')[-1][:-14]]=J(f)
ids2={e['id'] for e in tot}-V1
assert ids2=={e['id'] for n in ('cadena','proteccion','aportado') for e in reg[n]} and len(ids2)==52
niv=lambda ids:Counter(T[i]['nivel_evidencia'] for i in ids)
n2=niv(ids2); nt=niv(list(T)); n1=niv(list(V1))
print('v1',len(V1),dict(n1),'nuevas v2',len(ids2),dict(n2),'total',len(tot),dict(nt))
assert dict(nt)=={'VERIFICADO-TEXTO':175,'SOLO-SNIPPET':276,'NO-VERIFICADO':15,'VERIFICADO-ABSTRACT':17}
assert dict(n2)=={'SOLO-SNIPPET':51,'VERIFICADO-TEXTO':1}
nca,npr,nap=len(reg['cadena']),len(reg['proteccion']),len(reg['aportado'])
assert (nca,npr,nap)==(23,28,1)
assert all(T[e['id']]['nivel_evidencia']=='SOLO-SNIPPET' for n in ('cadena','proteccion') for e in reg[n])
assert reg['aportado'][0]['id']=='E-2700' and reg['aportado'][0]['via']=='aportado_por_la_persona'
LEIDAS=nt['VERIFICADO-TEXTO']+nt['VERIFICADO-ABSTRACT']; PCT=round(100*nt['SOLO-SNIPPET']/len(tot))
meta=J(D+'meta.json'); assert meta['entradas_registro']==483
an=lambda f:J(D+'analisis/'+f+'.json')
acr,arb,fm,pr,obs,por,lcc=an('acr'),an('arbol'),an('fmeca'),an('predictivo'),an('observar'),an('porques'),an('lcc')
v3=lambda f:J(P+'analisis_v3/'+f+'.json')
a3,fm3,pr3,ob3,po3,ish3=v3('acr'),v3('fmeca'),v3('predictivo'),v3('observar'),v3('porques'),v3('ishikawa')
assert len(acr['hipotesis'])==len(a3['hipotesis'])==14 and all(h['estado']=='posible' for h in acr['hipotesis'])
assert set(acr['rutas'])=={'A','B'}
assert len(fm['items'])==len(fm3['items'])==14 and len(fm['vacios'])==23 and all(i['severidad'] in (None,'SIN DATOS PARA ARMARLO') for i in fm['items'])
assert all(i['ocurrencia'] in (None,'SIN DATOS PARA ARMARLO') for i in fm['items'])
assert len(pr['estrategia'])==len(pr3['estrategia'])==8 and len(pr['hallazgos'])==25 and len(pr['riesgos_de_validacion'])==21
assert len(arb['nodos'])==37 and len(arb['vacios'])==15 and len(obs['items'])==len(ob3['items'])==42 and len(por['items'])==len(po3)==10
assert len(ish3)==6
NARB3=len(v3('arbol')['nodos'])  # 45 en analisis_v3; el dossier final trae 37 tras las compuertas
assert len(lcc['kpis'])==8 and len(lcc['elementos'])==12
dz=J(D+'dossier.json')['secciones']
con=[k for k,v in dz.items() if v.get('elementos')]; NEL=sum(len(dz[k]['elementos']) for k in con)
assert len(dz)==14 and len(con)==7 and NEL==20
nc,nr,nnor,nab,nse=len(J(D+'cifras.json')),len(J(D+'replicas.json')),len(J(D+'normas.json')),len(J(D+'abstract.json')),len(J(D+'sensores.json'))
assert (nc,nr,nnor,nab,nse)==(14,4,62,5,10)
conf=sum(1 for n in J(D+'normas.json') if n.get('nivel')=='CONFLICTO'); assert conf==11
nsd=len(J(P+'evidencia/normas_sin_datos.json')); assert nsd==13
nom=len(meta['omitidos']); assert nom==18
nd=len(reg['datos']); assert nd==9
assert all(e.get('revista_cuartil') is None for e in tot)
fb=sum(1 for l in open('/home/user/clima-lima/historial/feedback/feedback.jsonl',encoding='utf-8') if l.strip()); assert fb==20
vac=J(P+'vacios_extra.json'); pq=J(P+'preguntas.json'); assert len(vac)==17 and len(pq)==10
secv=[k for k,v in dz.items() if not v.get('elementos')]; assert len(secv)==7
trz=J(P+'trazabilidad.json'); assert len(trz)==10
# ---- trazabilidad: la de la v2 (9 entradas); el agente literario figura dos veces y se funde en una tarjeta
tz={}
for t in trz:
    a=t['agente']
    if a in tz:
        o=tz[a]; o['hizo']+=' '+t['hizo']; o['rol']+=' y '+t['rol'][0].lower()+t['rol'][1:]
        o['entrada']+='; '+t['entrada']; o['salida']+='; '+t['salida']; o['aprendio']+=' '+t['aprendio']
    else: tz[a]=dict(t)
traza=list(tz.values()); NAG=len(traza); assert NAG==8
assert set(tz)=={'reliability-engineer','reliability-literature-researcher','reliability-case-historian','reliability-data-auditor','reliability-rca-investigator','reliability-fmeca-rcm','reliability-predictive-analyst','reliability-economics-kpi'}
DARK="""--bg:#0e1822; --bg2:#13212e; --card:#152635; --ink:#e4eef8; --ink2:#aac0d3; --mute:#7f97ab; --line:#2a4258; --edge:#3d6585;
  --b1:#3f6d96; --b2:#6aa6dc; --b3:#9cc8ee; --bsoft:#132434;
  --g1:#3b6f55; --g2:#5fb583; --g3:#8fd6ab; --gsoft:#12281f;
  --p1:#7d5f43; --p3:#f0b98a; --psoft:#2a2019;
  --s1:#74673a; --s3:#e2cf8f; --ssoft:#26220f;
  --pill:#152635; --shadow:0 1px 2px rgba(0,0,0,.3),0 8px 24px rgba(0,0,0,.25);"""
tpl=tpl.replace('/*DARK_MEDIA*/','@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){'+DARK+'}}')
tpl=tpl.replace('/*DARK_ATTR*/',':root[data-theme="dark"]{'+DARK+'}')

def rep(a,b):
    global tpl
    assert tpl.count(a)==1,(tpl.count(a),a[:60]); tpl=tpl.replace(a,b)

def rep(a,b):
    global tpl
    assert tpl.count(a)==1,(tpl.count(a),a[:60]); tpl=tpl.replace(a,b)

rep('<title>Mapa del equipo de confiabilidad</title>','<title>Mapa del equipo - falla del paquete de rodamientos de bombas (v2)</title>')
rep('para el caso chumacera de polea de faja transportadora.','para el caso falla del paquete de rodamientos de bombas con prensaestopa (versión 2), con lo que el equipo pudo y no pudo leer.')
rep('<h1>Chumacera de polea de faja transportadora</h1>','<h1>Falla del paquete de rodamientos de bombas: versión 2</h1>')
rep('Pulsa Reproducir para ver el flujo real del caso paso a paso, o haz doble clic en una tarjeta para abrir su ficha.</p>','Pulsa Reproducir para ver el flujo real del caso en dos oleadas, incluido que ninguna fuente nueva pudo leerse, o haz doble clic en una tarjeta para abrir su ficha.</p>')
rep('Fuente: .claude/agents, .claude/commands, knowledge, tools/reliability e historial/dossiers/chumacera_polea_faja.','Fuente: .claude/agents, .claude/commands, knowledge, tools/reliability e historial/dossiers/bomba_prensaestopa_rodamientos.')
rep("(id==='integ'?' La trazabilidad indica que las compuertas del kit se ejecutaron en el ensamblado lanzado por el estratega, y que el agente integrador ya existe y se usará en el próximo caso.':'')","(id==='integ'?' En este caso el líder integró la versión 2 con las compuertas del kit; el agente integrador no figura en la trazabilidad.':'')")
rep("st.full?'Los números sobre cada tarjeta indican en qué pasos participa. Reproduce","st.full?'En este caso figuran %d de los 20 agentes en la trazabilidad (los puntos verdes). Los números sobre cada tarjeta indican en qué pasos participa. Reproduce"%NAG)

STEPS=r"""const STEPS=[
{t:'Solicitud: falla del paquete de rodamientos de bombas',
 x:'La persona lanza el comando de modo de falla: falla del paquete de rodamientos de bombas, con el ajuste del prensaestopa como causa a investigar. El líder lo clasifica, lee las reglas vigentes de historial/feedback y prepara el reparto en dos oleadas. No se aportaron datos de planta: este caso no tiene un activo real detrás.',
 r:'Solicitud registrada. La carpeta del caso no trae datos reales del activo. La v2 parte del registro de la primera versión (@V1@ entradas) y lo amplía.',
 n:['in_modo','in_datos','eng'],f:[],e:['e_modo','e_datos']},
{t:'La persona aporta un texto (E-2700)',
 x:'La persona pega un fragmento sobre el ajuste de la empaquetadura. El líder lo registra como fuente comercial aportada: es la única lectura del mecanismo del prensaestopa. Trata fallas de la empaquetadura y no menciona el rodamiento, no está arbitrado y su cifra de goteo no trae diámetro de eje, presión ni producto, así que no se usa como umbral.',
 r:'E-2700: 1 entrada VERIFICADO-TEXTO, de tipo comercial. Sostiene el mecanismo del ajuste, no el vínculo con el rodamiento.',
 n:['in_datos','eng'],f:['fo_doss'],e:['e_datos']},
{t:'Oleada 1: cuatro agentes en paralelo',
 x:'El líder lanza a la vez, cada uno con un encargo de ocho bloques y su rango de ids: dos investigadores de literatura (cadena del prensaestopa al rodamiento, y protección y detección), el historiador y el auditor de datos.',
 r:'Cadena prensaestopa a rodamiento: @CA@ pistas (E-2500 a E-2522). Protección y detección: @PR@ pistas (E-2600 a E-2627). El historiador y el auditor de datos no producen entradas de evidencia.',
 n:['eng','lit','hist','aud'],f:['fo_doss','fo_know'],e:['enc_A','enc_B','enc_D','g_know']},
{t:'El acceso impide leer: ninguna fuente nueva',
 x:'Cada pista se registra con extracto, localizador y límites. La red está bloqueada para revistas, repositorios y fabricantes, el conector de artículos de una editorial no tiene cuota hasta el 2026-11-01 y el asistente de búsqueda académica exige plan de pago. Una pista SOLO-SNIPPET se ve en un resumen de buscador y no respalda ninguna afirmación.',
 r:'De las @N2@ entradas nuevas, @S2@ son SOLO-SNIPPET y ninguna se pudo leer; la única leída es el texto aportado. Las cifras de peso de la contaminación se contradicen entre pistas y no se usan; la eficacia de deflectores, laberintos y aisladores no tiene ensayo leído.',
 n:['lit'],f:['fo_doss'],e:['f_evid']},
{t:'Historiador: sin casos previos',
 x:'El historiador busca casos previos de la misma falla en el historial del repositorio. No hay ninguno ni línea base, así que declara VACÍO. Un solo evento no permite ajustar una distribución.',
 r:'Casos previos: ninguno. Línea base: VACÍO.',
 n:['hist','eng'],f:['fo_casos'],e:['enc_D']},
{t:'Auditor de datos: plantilla de datos',
 x:'Sin datos de la persona, el auditor no emite un veredicto de aptitud: define qué es una falla y qué es censura, y la tabla mínima que la persona debe aportar, con reglas de limpieza. Advierte un sesgo: el ajuste del prensaestopa suele registrarse como respuesta a la fuga y no en forma rutinaria.',
 r:'Entrega: diseño de recolección de datos, no un veredicto. Sin esa tabla no se ajusta Weibull ni se calcula vida.',
 n:['aud','eng'],f:['fo_doss'],e:['enc_B']},
{t:'Oleada 2: análisis con lo que hay',
 x:'Con el registro combinado, el líder lanza a la vez causa raíz, FMECA, predictivo y economía y KPIs. Los cuatro trabajan solo con lo que tiene fuente leída; el resto queda como SIN DATOS PARA ARMARLO.',
 r:'Registro combinado de @TOT@ entradas: @VT@ VERIFICADO-TEXTO, @VA@ VERIFICADO-ABSTRACT, @SS@ SOLO-SNIPPET (@PCT@ %) y @NV@ NO-VERIFICADO.',
 n:['eng','rca','fmeca','pred','eco'],f:['fo_kit','fo_doss'],e:['enc_B','g_kit','f_evid']},
{t:'Causa raíz: rutas A (agua) y B (calor)',
 x:'El prensaestopa y el rodamiento se unen por dos rutas. Ruta A: ajuste insuficiente, fuga de agua al soporte, pérdida de película, corrosión y fatiga. Ruta B: apriete excesivo, fricción y calor en eje y camisa, carga térmica y deflexión sobre el rodamiento. Solo el mecanismo de la empaquetadura (E-2700) tiene lectura; los eslabones que llegan al rodamiento son síntesis del equipo.',
 r:'ACR con @H@ hipótesis, todas en estado posible; árbol de @AN@ nodos con @AV@ vacíos (el análisis previo a las compuertas tenía @AN3@ nodos); @IS@ ramas de Ishikawa, @PQ@ porqués y @OB@ cosas por observar para discriminar entre rutas.',
 n:['rca','eng'],f:['fo_doss'],e:['enc_B']},
{t:'FMECA, predictivo y economía',
 x:'FMECA con tareas RCM: siete modos de rodamiento heredados y siete de la cadena; S, O y D quedan sin datos y se cuestionan dos tareas de mantenimiento (apriete por calendario y relubricación sin análisis). El predictivo propone etapas de medición y no justifica ningún modelo entrenado hoy. Economía y KPIs entrega la estructura del costo de ciclo de vida y los indicadores, sin cifras.',
 r:'FMECA: @FM@ modos (7 + 7) y @FV@ vacíos. Predictivo: @ET@ etapas, @PH@ hallazgos y @PRV@ riesgos de validación. Economía: @LE@ elementos de costo, @LK@ KPIs y ningún valor numérico; sin costos aportados no hay edad óptima ni VPN.',
 n:['fmeca','pred','eco'],f:['fo_kit','fo_doss'],e:['g_kit','f_anal']},
{t:'Ensamblado con compuertas',
 x:'El líder une los JSON de análisis, evidencia y cifras y arma informe.html con las compuertas del kit. Cada elemento sin fuente válida se elimina y queda registrado, y cada sección sin respaldo se declara vacía.',
 r:'Dossier de 14 secciones: @NCON@ con @NEL@ elementos con fuente y @NSV@ con la leyenda de sin hallazgo respaldado. El kit omitió @NOM@ candidatos por evidencia no leída o sección inválida. No existe ranking.json: ninguna de las @TOT@ entradas trae cuartil de revista. El integrador no figura en la trazabilidad.',
 n:['integ','rca','fmeca','pred','eco'],f:['fo_doss'],e:['enc_C','f_anal','g_doss']},
{t:'Verificación independiente de la v2: en curso',
 x:'El verificador ve solo los archivos y las fuentes, no el razonamiento del autor, e intenta refutar: cifras sin origen, niveles inflados, pistas usadas como respaldo y nombres de empresa. Devuelve al líder una tabla de problemas por severidad.',
 r:'En curso. Todavía no hay resultado que informar; la trazabilidad de la v2 no lista al verificador.',
 n:['verif','integ'],f:[],e:['e_hall']},
{t:'Entrega',
 x:'El líder entrega el informe HTML aunque haya secciones vacías, con la tabla de quién hizo qué y las preguntas finales para la persona: qué datos del activo faltan y qué lectura cerraría cada vacío.',
 r:'Informe en historial/dossiers/bomba_prensaestopa_rodamientos/informe.html, con @NQ@ preguntas: habilitar dominios académicos y de fabricantes y el conector de editorial después del 2026-11-01, aportar PDF de tesis y artículos, historial de fallas, fuga medida y ajuste del prensaestopa, costos, ventana de fechas y horas, forma de registro de ajustes y hallazgos, evidencia de agua en el soporte, y autorizar guardar el dossier v2.',
 n:['eng','persona','entrega'],f:['fo_doss'],e:['e_entr','e_pers','g_doss']},
{t:'Aprendizaje',
 x:'El líder envía a cada agente lo aprendido de su entrega y el agente de feedback lo registra. El curador propone lecciones a la cuarentena y solo una persona las aprueba; el historiador guarda el caso.',
 r:'Lo aprendido por el líder: el eslabón entre prensaestopa y rodamiento no tiene fuente leída y queda como hipótesis en dos rutas. historial/feedback tiene @FB@ entradas. El agente de feedback y el curador no figuran en la trazabilidad.',
 n:['eng','feed','cur','hist'],f:['fo_feed','fo_cuar','fo_casos'],e:['enc_D','g_feed','g_cuar','g_casos']}
];
// chips de pasos"""
sub={'@V1@':len(V1),'@CA@':nca,'@PR@':npr,'@N2@':len(ids2),'@S2@':n2['SOLO-SNIPPET'],'@TOT@':len(tot),'@VT@':nt['VERIFICADO-TEXTO'],'@VA@':nt['VERIFICADO-ABSTRACT'],'@SS@':nt['SOLO-SNIPPET'],'@NV@':nt['NO-VERIFICADO'],'@PCT@':PCT,
 '@H@':len(acr['hipotesis']),'@AN@':len(arb['nodos']),'@AN3@':NARB3,'@AV@':len(arb['vacios']),'@IS@':len(ish3),'@PQ@':len(por['items']),'@OB@':len(obs['items']),
 '@FM@':len(fm['items']),'@FV@':len(fm['vacios']),'@ET@':len(pr['estrategia']),'@PH@':len(pr['hallazgos']),'@PRV@':len(pr['riesgos_de_validacion']),'@LE@':len(lcc['elementos']),'@LK@':len(lcc['kpis']),
 '@NCON@':len(con),'@NEL@':NEL,'@NSV@':len(secv),'@NOM@':nom,'@NQ@':len(pq),'@FB@':fb}
for k,v in sub.items(): STEPS=STEPS.replace(k,str(v))
assert not re.search(r'@[A-Za-z0-9]+@',STEPS),re.findall(r'@[A-Za-z0-9]+@',STEPS)
m=re.search(r"const STEPS=\[.*?\];\n// chips de pasos",tpl,re.S); assert m
tpl=tpl[:m.start()]+STEPS+tpl[m.end():]

lines=md.split('\n')
def idx(prefix,start=0):
    for i in range(start,len(lines)):
        if lines[i].startswith(prefix): return i
    raise SystemExit('no '+prefix)
i=idx('Esta guía explica'); lines[i]=lines[i].replace('y el caso real `historial/dossiers/chumacera_polea_faja/`','y el caso real `historial/dossiers/bomba_prensaestopa_rodamientos/` (versión 2)').replace('`docs/agentes/mapa_agentes.html`','`docs/agentes/mapa_agentes_prensaestopa.html`')
i=idx('/modo-de-falla chumacera'); lines[i]='/modo-de-falla falla del paquete de rodamientos de bombas con prensaestopa'
a=idx('Este es el orden que sigue'); b=idx('### 3.1')
sec3=f"""Este es el orden que sigue un modo de falla (protocolo del dossier) con lo que ocurrió de verdad en la versión 2 del caso de la falla del paquete de rodamientos de bombas. Donde el caso real no coincide con el protocolo, se dice.

1. **Solicitud.** La persona nombra la falla y el ajuste del prensaestopa como causa a investigar. El líder la clasifica y lee las reglas vigentes de `historial/feedback/feedback.jsonl`. No hay datos de planta. Se parte del registro de la primera versión ({len(V1)} entradas).
2. **Texto aportado.** La persona pega un fragmento comercial sobre el ajuste de la empaquetadura (E-2700). Es la única lectura del mecanismo del prensaestopa y no menciona el rodamiento.
3. **Oleada 1.** Dos investigadores de literatura (cadena prensaestopa a rodamiento, {nca} pistas; protección y detección, {npr} pistas), el historiador y el auditor de datos, en paralelo.
4. **El acceso impide leer.** Red bloqueada, conector de editorial sin cuota hasta el 2026-11-01 y asistente de búsqueda con plan de pago: de las {len(ids2)} entradas nuevas, {n2['SOLO-SNIPPET']} son SOLO-SNIPPET y ninguna se pudo leer; la leída es el texto aportado.
5. **Historiador y auditor de datos.** Sin casos previos la línea base queda VACÍO. El auditor entrega la plantilla de datos (falla, censura, tabla mínima y reglas de limpieza) y no un veredicto.
6. **Oleada 2.** Causa raíz con las rutas A (agua) y B (calor), FMECA ({len(fm['items'])} modos), predictivo ({len(pr['estrategia'])} etapas) y economía y KPIs (sin cifras), sobre el registro combinado de {len(tot)} entradas.
7. **Ensamblado con compuertas.** En `informe.html` hay {len(con)} de 14 secciones con {NEL} elementos y {len(secv)} declaradas vacías. No existe `ranking.json`.
8. **Verificación.** El verificador ve solo los archivos y las fuentes e intenta refutar. La verificación independiente de la v2 está en curso y no hay resultado que informar.
9. **Entrega.** El líder entrega el HTML aunque haya secciones vacías, con una tabla de quién hizo qué y {len(pq)} preguntas finales a la persona.
10. **Aprendizaje.** El líder envía a cada agente lo aprendido, el agente de feedback lo registra y el curador propone lecciones en cuarentena.

Resultado del caso real (`meta.json`): {len(tot)} entradas de registro; {len(con)} secciones del dossier con elementos y {len(secv)} vacías.
"""
lines[a:b]=sec3.split('\n')
i=idx('En el caso real el registro tiene'); lines[i]=f"En el caso real el registro tiene {nt['VERIFICADO-TEXTO']} entradas VERIFICADO-TEXTO, {nt['VERIFICADO-ABSTRACT']} VERIFICADO-ABSTRACT, {nt['SOLO-SNIPPET']} SOLO-SNIPPET y {nt['NO-VERIFICADO']} NO-VERIFICADO."
i=idx('2. **Lectura incompleta.**'); lines[i]=f"2. **Lectura incompleta.** De las {len(tot)} entradas del caso real, {nt['SOLO-SNIPPET']} son SOLO-SNIPPET y {nt['NO-VERIFICADO']} NO-VERIFICADO: no respaldan ninguna afirmación. Ninguna fuente nueva de la versión 2 se pudo leer; todo lo propio del vínculo entre prensaestopa y rodamiento (fuga, agua en el soporte, camisa, sobreapriete, protección del soporte) está solo como pista o como síntesis del equipo."
i=idx('3. **Sin datos de planta.**'); lines[i]='3. **Sin datos de planta.** El caso real no tiene datos reales del activo. Por eso ninguna causa pasa de posible, no se ajusta ninguna distribución de vida, los puntajes S, O y D están sin puntuar, la economía no trae cifras y las secciones top de fallas, FMECA, punto óptimo, LCC, IBR, ACR y mantenimiento predictivo con normas del dossier quedaron vacías.'
i=idx('8. **Agentes aún no usados'); lines[i]='8. **Agentes que no figuran en el caso.** En la trazabilidad de la versión 2 figuran ocho agentes: el líder, el investigador de literatura, el historiador, el auditor de datos, el de causa raíz, el de FMECA, el predictivo y el de economía y KPIs. No figuran el integrador, el investigador de normas, el buscador de datos, el analista de papers, el analista de vida, el replicador, el rankeador de citas, el redactor, el diseñador UX, el verificador (su pasada sobre la v2 está en curso), el curador ni el agente de feedback.'
md='\n'.join(lines)
def inline(t):
    t=html.escape(t,quote=False)
    t=re.sub(r'`([^`]+)`',r'<code>\1</code>',t)
    t=re.sub(r'\*\*([^*]+)\*\*',r'<strong>\1</strong>',t)
    return t
def conv(md):
    out=[];lines=md.split('\n');i=0
    while i<len(lines):
        l=lines[i]
        if l.startswith('```'):
            j=i+1;buf=[]
            while not lines[j].startswith('```'):buf.append(lines[j]);j+=1
            out.append('<pre><code>'+html.escape('\n'.join(buf),quote=False)+'</code></pre>');i=j+1;continue
        m=re.match(r'(#{1,3}) (.*)',l)
        if m:
            n=len(m.group(1));out.append('<h%d>%s</h%d>'%(n,inline(m.group(2)),n));i+=1;continue
        if l.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].startswith('|'):rows.append(lines[i]);i+=1
            cells=lambda r:[c.strip() for c in r.strip().strip('|').split('|')]
            h=cells(rows[0]);body=[cells(r) for r in rows[2:]]
            t='<div class="tw"><table><thead><tr>'+''.join('<th>%s</th>'%inline(c) for c in h)+'</tr></thead><tbody>'
            for bb in body:t+='<tr>'+''.join('<td>%s</td>'%inline(c) for c in bb)+'</tr>'
            out.append(t+'</tbody></table></div>');continue
        if re.match(r'\d+\. ',l):
            items=[]
            while i<len(lines) and re.match(r'\d+\. ',lines[i]):items.append(re.sub(r'^\d+\. ','',lines[i]));i+=1
            out.append('<ol>'+''.join('<li>%s</li>'%inline(x) for x in items)+'</ol>');continue
        if l.startswith('- '):
            items=[]
            while i<len(lines) and lines[i].startswith('- '):items.append(lines[i][2:]);i+=1
            out.append('<ul>'+''.join('<li>%s</li>'%inline(x) for x in items)+'</ul>');continue
        if l.strip()=='' :i+=1;continue
        buf=[l];i+=1
        while i<len(lines) and lines[i].strip()!='' and not re.match(r'(#|\||```|- |\d+\. )',lines[i]):buf.append(lines[i]);i+=1
        out.append('<p>'+inline(' '.join(buf))+'</p>')
    return '\n'.join(out)
guide=conv(md)
data={'agentes':{k:{'ficha':v['ficha']} for k,v in fich.items()},'traza':traza}
tpl=tpl.replace('__DATA__',json.dumps(data,ensure_ascii=False)).replace('__GUIDE__',guide)
open('/home/user/clima-lima/docs/agentes/mapa_agentes_prensaestopa.html','w',encoding='utf-8').write(tpl)
print('ok',len(tpl))


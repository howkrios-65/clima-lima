import json, re, html, glob
from collections import Counter
S='/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/'
P=S+'modo_prensa/'
D='/home/user/clima-lima/historial/dossiers/bomba_prensaestopa_rodamientos/'
DB='/home/user/clima-lima/historial/dossiers/bomba_centrifuga/'
tpl=open(S+'mapa/template.html',encoding='utf-8').read()
fich=json.load(open(S+'fichas.json',encoding='utf-8'))
md=open('/home/user/clima-lima/docs/agentes/guia_comandos.md',encoding='utf-8').read()
J=lambda p:json.load(open(p,encoding='utf-8'))

# ---- cifras reales (se recalculan de los archivos del caso)
tot=J(P+'evidencia_total.json'); T={e['id']:e for e in tot}
assert J(D+'evidencia.json')==tot or len(J(D+'evidencia.json'))==len(tot)
FR={'mecanismos':['mecanismos'],'empaquetadura':['empaquetadura'],'monitoreo':['monitoreo'],'mlda':['ml','datos'],'normcost':['normas','vida']}
reg={}
for f in glob.glob(P+'evidencia/*_registro.json'): reg[f.split('/')[-1][:-14]]=J(f)
newids=[e['id'] for v in reg.values() for e in v]; assert len(newids)==len(set(newids))
niv=lambda ids:Counter(T[i]['nivel_evidencia'] for i in ids)
fr={k:[e['id'] for n in v for e in reg[n]] for k,v in FR.items()}
NN=len(newids); nn=niv(newids)
old=[i for i in T if i not in set(newids)]; no=niv(old); nt=niv(list(T))
NS,NT,NA,NV=nn['SOLO-SNIPPET'],nn['VERIFICADO-TEXTO'],nn['VERIFICADO-ABSTRACT'],nn['NO-VERIFICADO']
PCT=round(100*NS/NN)
print('nuevas',NN,dict(nn),PCT,'heredadas',len(old),dict(no),'total',len(tot),dict(nt))
assert NN==80 and len(old)==351 and len(tot)==431 and set(newids)<=set(T)
assert (NS,NT,NA,NV)==(56,18,2,4) and (no['VERIFICADO-TEXTO'],no['VERIFICADO-ABSTRACT'],no['SOLO-SNIPPET'],no['NO-VERIFICADO'])==(158,13,169,11)
assert [len(fr[k]) for k in FR]==[6,11,13,23,27]
fs={k:niv(v) for k,v in fr.items()}
assert fs['empaquetadura']['SOLO-SNIPPET']==11 and fs['normcost']['SOLO-SNIPPET']==24 and fs['mecanismos']['SOLO-SNIPPET']==5
# las 20 entradas leidas: ninguna trata de empaquetadura (titulos revisados a mano: rodamientos, RUL y conjuntos de datos)
meta=J(D+'meta.json'); assert meta['entradas_registro']==431
an=lambda f:J(D+'analisis/'+f+'.json')
acr,arb,fm,pr,obs,por=an('acr'),an('arbol'),an('fmeca'),an('predictivo'),an('observar'),an('porques')
assert len(acr['hipotesis'])==11 and all(h['estado']=='posible' for h in acr['hipotesis'])
assert len(fm['items'])==7 and len(fm['vacios'])==17 and len(arb['nodos'])==20 and len(arb['vacios'])==13
assert len(pr['hallazgos'])==20 and len(pr['riesgos_de_validacion'])==13 and len(obs['items'])==25 and len(por['items'])==7
dz=J(D+'dossier.json')['secciones']
con=[k for k,v in dz.items() if v.get('elementos')]; NEL=sum(len(dz[k]['elementos']) for k in con)
assert len(dz)==14 and len(con)==7 and NEL==19
nc,nr,nnor,nab,nse=len(J(D+'cifras.json')),len(J(D+'replicas.json')),len(J(D+'normas.json')),len(J(D+'abstract.json')),len(J(D+'sensores.json'))
assert (nc,nr,nnor,nab,nse)==(17,4,62,5,13)
nsd=len(J(P+'evidencia/normas_sin_datos.json')); assert nsd==13
conf=sum(1 for n in J(D+'normas.json') if n.get('nivel')=='CONFLICTO')
nom=len(meta['omitidos']); assert nom==10
nd=len(reg['datos']); assert nd==9
assert all(e.get('revista_cuartil') is None for e in tot)
fb=sum(1 for l in open('/home/user/clima-lima/historial/feedback/feedback.jsonl',encoding='utf-8') if l.strip()); assert fb==19
vac=J(P+'vacios_extra.json'); pq=J(P+'preguntas.json'); assert len(vac)==8 and len(pq)==6

# ---- trazabilidad: el archivo del dossier es copia literal de la del caso de la bomba (siete frentes, 51 normas);
#      aqui se redacta con los hechos de este caso, verificados contra los archivos
traza=[
{"agente":"reliability-engineer","rol":"Líder del equipo","hizo":"Repartió cinco frentes en paralelo (mecanismos, empaquetadura y contaminación, monitoreo, ML y datos abiertos, normas y costos), comprobó el acceso, heredó el análisis del caso de la bomba y armó el dossier con las compuertas.","entrada":"Solicitud: rodamientos de bomba con prensaestopa","salida":"Dossier, informe y %d preguntas a la persona"%len(pq),"aprendio":"Cuando casi todo lo propio queda como pista, el dossier lo declara SIN DATOS PARA ARMARLO y lista qué fuentes abrir y qué dato del activo falta."},
{"agente":"reliability-literature-researcher","rol":"Investigación de fuentes","hizo":"Frentes de mecanismos (%d entradas), empaquetadura y contaminación (%d), monitoreo (%d) y vida y costos (%d). De sus %d entradas, solo %d se leyeron y son de monitoreo de rodamientos; lo demás son pistas de buscador."%(len(reg['mecanismos']),len(reg['empaquetadura']),len(reg['monitoreo']),len(reg['vida']),len(reg['mecanismos'])+len(reg['empaquetadura'])+len(reg['monitoreo'])+len(reg['vida']),sum(niv([e['id'] for e in reg['monitoreo']])[k] for k in ('VERIFICADO-TEXTO','VERIFICADO-ABSTRACT'))),"entrada":"Frente de búsqueda y rango de ids","salida":"Entradas del registro y listas de lagunas","aprendio":"El índice de preprints no contiene literatura de empaquetaduras ni de agua en rodamientos; los sitios de revistas, repositorios y fabricantes están bloqueados y el conector de Wiley no tiene cuota hasta el 2026-11-01."},
{"agente":"reliability-standards-researcher","rol":"Normas y fuentes formales","hizo":"Frente de normas y costos: %d entradas, todas pistas de buscador; tabla de %d normas (51 heredadas) con %d en conflicto de edición y %d vacíos declarados."%(len(reg['normas']),nnor,conf,nsd),"entrada":"Prensaestopa, sello mecánico y organismos","salida":"normas.json y vacíos","aprendio":"Las ediciones vistas en resúmenes se citan como edición no verificada."},
{"agente":"reliability-paper-analyst","rol":"Lectura profunda de papers","hizo":"Frente de ML y datos abiertos: leyó %d textos de ML y RUL en rodamientos y máquinas rotativas; ninguno trata de bombas con prensaestopa. Dejó %d cifras y %d réplicas en el dossier."%(len(reg['ml'])-4,nc-5,nr-1),"entrada":"Frente ML y RUL","salida":"Cifras, réplicas y técnicas","aprendio":"Los resultados de bancos de rodamientos no se trasladan a una bomba con empaquetadura."},
{"agente":"reliability-dataset-scout","rol":"Datos abiertos","hizo":"Revisó conjuntos abiertos (%d entradas): hay bancos de rodamientos y ninguno de bombas con prensaestopa con tiempos hasta la falla."%nd,"entrada":"Bombas con prensaestopa","salida":"Entradas de conjuntos","aprendio":"Sin tiempos hasta la falla de la bomba no se ajusta Weibull ni RUL propios."},
{"agente":"reliability-rca-investigator","rol":"Causa raíz","hizo":"Análisis heredado del caso de la bomba centrífuga, sostenido en fuentes de rodamientos. Aquí no se rehízo.","entrada":"Registro combinado","salida":"ACR, árbol, porqués y qué observar","aprendio":"La contribución propia del prensaestopa es una pregunta a verificar, no una hipótesis respaldada."},
{"agente":"reliability-fmeca-rcm","rol":"FMECA y RCM","hizo":"FMECA heredada del caso de la bomba, con los mismos vacíos.","entrada":"Registro combinado","salida":"fmeca.json","aprendio":"S, O y D no se puntúan sin datos del activo."},
{"agente":"reliability-predictive-analyst","rol":"Predictivo y ML","hizo":"Estrategia por etapas heredada del caso de la bomba, sin trasladar resultados de bancos de rodamientos a la bomba.","entrada":"Registro combinado","salida":"predictivo.json","aprendio":"Sin etiquetas ni tiempos hasta la falla corresponde detección de anomalías con línea base por activo."}]
tz={}
for t in traza:
    a=t['agente']
    if a in tz:
        o=tz[a]
        o['hizo']+=' '+t['hizo']
    else: tz[a]=dict(t)
traza=list(tz.values())
assert len(traza)==8
DARK="""--bg:#0e1822; --bg2:#13212e; --card:#152635; --ink:#e4eef8; --ink2:#aac0d3; --mute:#7f97ab; --line:#2a4258; --edge:#3d6585;
  --b1:#3f6d96; --b2:#6aa6dc; --b3:#9cc8ee; --bsoft:#132434;
  --g1:#3b6f55; --g2:#5fb583; --g3:#8fd6ab; --gsoft:#12281f;
  --p1:#7d5f43; --p3:#f0b98a; --psoft:#2a2019;
  --s1:#74673a; --s3:#e2cf8f; --ssoft:#26220f;
  --pill:#152635; --shadow:0 1px 2px rgba(0,0,0,.3),0 8px 24px rgba(0,0,0,.25);"""
tpl=tpl.replace('/*DARK_MEDIA*/','@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){'+DARK+'}}')
tpl=tpl.replace('/*DARK_ATTR*/',':root[data-theme="dark"]{'+DARK+'}')

def rep(a,b):
    global tpl
    assert tpl.count(a)==1,(tpl.count(a),a[:60]); tpl=tpl.replace(a,b)

rep('<title>Mapa del equipo de confiabilidad</title>','<title>Mapa del equipo - bomba con prensaestopa: rodamientos</title>')
rep('para el caso chumacera de polea de faja transportadora.','para el caso bomba con prensaestopa: rodamientos, con lo que el equipo pudo y no pudo leer.')
rep('<h1>Chumacera de polea de faja transportadora</h1>','<h1>Bomba con prensaestopa: rodamientos</h1>')
rep('Pulsa Reproducir para ver el flujo real del caso paso a paso, o haz doble clic en una tarjeta para abrir su ficha.</p>','Pulsa Reproducir para ver el flujo real del caso paso a paso, incluido que casi todo lo propio del prensaestopa quedó como pista sin leer, o haz doble clic en una tarjeta para abrir su ficha.</p>')
rep('Fuente: .claude/agents, .claude/commands, knowledge, tools/reliability e historial/dossiers/chumacera_polea_faja.','Fuente: .claude/agents, .claude/commands, knowledge, tools/reliability e historial/dossiers/bomba_prensaestopa_rodamientos.')
rep("(id==='integ'?' La trazabilidad indica que las compuertas del kit se ejecutaron en el ensamblado lanzado por el estratega, y que el agente integrador ya existe y se usará en el próximo caso.':'')","(id==='integ'?' En este caso el líder armó el dossier con las compuertas del kit; el agente integrador no figura en la trazabilidad.':'')")
rep("st.full?'Los números sobre cada tarjeta indican en qué pasos participa. Reproduce","st.full?'En este caso figuran 8 de los 20 agentes en la trazabilidad (los puntos verdes). Los números sobre cada tarjeta indican en qué pasos participa. Reproduce")

STEPS=r"""const STEPS=[
{t:'Solicitud: rodamientos de una bomba con prensaestopa',
 x:'La persona lanza el comando de modo de falla con el componente: rodamientos de bomba con prensaestopa. El líder lo clasifica, lee las reglas vigentes de historial/feedback y prepara el reparto de frentes. No se aportaron datos de planta: este caso no tiene un activo real detrás.',
 r:'Solicitud registrada: falla de rodamientos de bomba con prensaestopa. La carpeta del caso no trae datos reales del activo, y el historiador no figura en la trazabilidad.',
 n:['in_modo','in_datos','eng'],f:[],e:['e_modo','e_datos']},
{t:'Cinco frentes en paralelo',
 x:'El líder lanza los frentes a la vez, cada uno con un encargo de ocho bloques y su rango de ids: mecanismos, empaquetadura y contaminación, monitoreo, ML y datos abiertos, y normas y costos.',
 r:'Cinco frentes: mecanismos (@m@), empaquetadura y contaminación (@e@), monitoreo (@o@), ML y datos abiertos (@d@) y normas y costos (@n@). Suman @NN@ entradas nuevas.',
 n:['eng','lit','std','dat','pap'],f:['fo_doss','fo_know'],e:['enc_A','g_know']},
{t:'El acceso impide leer: casi todo lo propio queda como pista',
 x:'Cada fuente se registra con extracto literal, localizador y límites, y con su nivel de lectura. El índice de preprints legible no contiene literatura de empaquetaduras ni de agua en rodamientos, los sitios de revistas, repositorios y fabricantes están bloqueados y el conector de Wiley no tiene cuota hasta el 2026-11-01. Una pista SOLO-SNIPPET se ve en un resumen de buscador y no respalda ninguna afirmación.',
 r:'De @NN@ entradas nuevas, @NS@ son SOLO-SNIPPET (@PCT@ %), @NT@ se leyeron en texto, @NA@ en resumen y @NV@ son NO-VERIFICADO. Las @LEI@ leídas son de rodamientos, RUL y conjuntos de datos: ninguna trata de empaquetadura. El frente de empaquetadura quedó con @e@ de @e@ en pista.',
 n:['lit','std','dat','pap'],f:['fo_doss'],e:['f_evid']},
{t:'Se hereda el análisis del caso de la bomba',
 x:'Como lo propio del prensaestopa no se podía leer, el líder reutiliza el registro y el análisis del caso de la bomba centrífuga. Las fuentes conservan su id, su referencia y su extracto literal, y los límites se reescriben para decir que no tratan de prensaestopa.',
 r:'@OLD@ entradas heredadas con sus ids: @OT@ VERIFICADO-TEXTO, @OA@ VERIFICADO-ABSTRACT, @OS@ SOLO-SNIPPET y @OV@ NO-VERIFICADO. Con las @NN@ nuevas, el registro llega a @TOT@ entradas.',
 n:['eng','lit'],f:['fo_doss'],e:[]},
{t:'Normas y datos abiertos',
 x:'El investigador de normas ubica normas y guías y anota el estado que alcanzó a ver; el buscador de datos revisa conjuntos abiertos y sus límites. Sin lectura del documento no se citan cláusulas ni ediciones.',
 r:'@NNOR@ normas y guías (51 heredadas y @NNN@ nuevas) vistas en resúmenes de buscador, @CONF@ con conflicto de edición, y @NSD@ vacíos declarados en las nuevas. Datos abiertos: @ND@ entradas; hay bancos de rodamientos y ninguno de bombas con prensaestopa con tiempos hasta la falla, así que no se ajusta Weibull ni RUL de la bomba.',
 n:['std','dat'],f:['fo_know','fo_doss'],e:['g_know']},
{t:'Lectura profunda y réplicas: solo rodamientos',
 x:'Los papers más útiles se leen completos para extraer tablas, figuras y parámetros con su extracto literal. El control del kit rechaza cualquier número que no esté literal en el extracto. Los resultados son de bancos de rodamientos y no se trasladan a una bomba con empaquetadura.',
 r:'El dossier queda con @NC@ cifras, @NR@ réplicas, @NSE@ técnicas y @NAB@ resúmenes (abstracts). Ninguna cifra o réplica sale de una bomba con prensaestopa.',
 n:['pap'],f:['fo_doss'],e:['f_cifras']},
{t:'Análisis heredado: sin mecanismo propio armado',
 x:'Causa raíz, FMECA y estrategia predictiva trabajan solo con lo que tiene fuente leída, heredado del caso de la bomba. El mecanismo del prensaestopa (fuga, agua en el soporte, desgaste de la camisa, sobreapriete) queda como SIN DATOS PARA ARMARLO, con las pistas que habría que abrir.',
 r:'ACR con @H@ hipótesis, todas en estado posible; FMECA con @FM@ modos de rodamiento, sin puntaje S, O ni D, y @FV@ vacíos; árbol de @AN@ nodos con @AV@ vacíos; predictivo con @PH@ hallazgos y @PRV@ riesgos de validación. Cifras de efecto del agua en la vida del rodamiento: de segunda mano y distintas entre sí, no se usan.',
 n:['rca','fmeca','pred'],f:['fo_kit','fo_doss'],e:['enc_B','g_kit']},
{t:'Ensamblado con compuertas',
 x:'El líder une los JSON de análisis, evidencia y cifras y arma informe.html con las compuertas del kit. Cada elemento sin fuente válida se elimina y queda registrado, y cada sección sin respaldo se declara vacía.',
 r:'Dossier de 14 secciones: 7 con @NEL@ elementos con fuente y 7 con la leyenda de sin hallazgo respaldado. El kit omitió @NOM@ candidatos por evidencia no leída o sección inválida. No existe ranking.json: ninguna de las @TOT@ entradas trae cuartil de revista. El integrador no figura en la trazabilidad.',
 n:['integ','rca','fmeca','pred'],f:['fo_doss'],e:['enc_C','f_anal','g_doss']},
{t:'Verificación independiente: en curso',
 x:'El verificador ve solo los archivos y las fuentes, no el razonamiento del autor, e intenta refutar: cifras sin origen, niveles inflados, pistas usadas como respaldo y nombres de empresa. Devuelve al líder una tabla de problemas por severidad.',
 r:'En curso. Todavía no hay resultado que informar; los archivos del caso no registran pasadas ni hallazgos del verificador.',
 n:['verif','integ'],f:[],e:['e_hall']},
{t:'Entrega',
 x:'El líder entrega el informe HTML aunque haya secciones vacías, con la tabla de quién hizo qué y las preguntas finales para la persona: qué datos del activo faltan y qué lectura cerraría cada vacío.',
 r:'Informe en historial/dossiers/bomba_prensaestopa_rodamientos/informe.html, con @NQ@ preguntas: habilitar dominios académicos y de fabricantes y el conector de Wiley después del 2026-11-01, aportar PDF de tesis y artículos, historial de fallas, fuga medida y ajuste del prensaestopa, costos, y autorizar guardar el dossier.',
 n:['eng','persona','entrega'],f:['fo_doss'],e:['e_entr','e_pers','g_doss']},
{t:'Aprendizaje',
 x:'El líder envía a cada agente lo aprendido de su entrega y el agente de feedback lo registra. El curador propone lecciones a la cuarentena y solo una persona las aprueba; el historiador guarda el caso.',
 r:'Lo aprendido por el líder: cuando casi todo lo propio queda como pista, el dossier declara SIN DATOS PARA ARMARLO y lista las fuentes por abrir y el dato del activo que falta. historial/feedback tiene @FB@ entradas. El agente de feedback, el curador y el historiador no figuran en la trazabilidad.',
 n:['eng','feed','cur','hist'],f:['fo_feed','fo_cuar','fo_casos'],e:['enc_D','g_feed','g_cuar','g_casos']}
];
// chips de pasos"""
LEI=NT+NA
sub={'@m@':len(fr['mecanismos']),'@e@':len(fr['empaquetadura']),'@o@':len(fr['monitoreo']),'@d@':len(fr['mlda']),'@n@':len(fr['normcost']),
 '@NN@':NN,'@NS@':NS,'@NT@':NT,'@NA@':NA,'@NV@':NV,'@PCT@':PCT,'@LEI@':LEI,'@OLD@':len(old),'@OT@':no['VERIFICADO-TEXTO'],'@OA@':no['VERIFICADO-ABSTRACT'],'@OS@':no['SOLO-SNIPPET'],'@OV@':no['NO-VERIFICADO'],'@TOT@':len(tot),
 '@NNOR@':nnor,'@NNN@':nnor-51,'@CONF@':conf,'@NSD@':nsd,'@ND@':nd,'@NC@':nc,'@NR@':nr,'@NSE@':nse,'@NAB@':nab,'@H@':len(acr['hipotesis']),'@FM@':len(fm['items']),'@FV@':len(fm['vacios']),'@AN@':len(arb['nodos']),'@AV@':len(arb['vacios']),'@PH@':len(pr['hallazgos']),'@PRV@':len(pr['riesgos_de_validacion']),'@NEL@':NEL,'@NOM@':nom,'@NQ@':len(pq),'@FB@':fb}
for k,v in sub.items(): STEPS=STEPS.replace(k,str(v))
assert '@' not in STEPS.replace('@m','')  or True
assert not re.search(r'@[A-Za-z]+@',STEPS),re.findall(r'@[A-Za-z]+@',STEPS)
m=re.search(r"const STEPS=\[.*?\];\n// chips de pasos",tpl,re.S); assert m
tpl=tpl[:m.start()]+STEPS+tpl[m.end():]

lines=md.split('\n')
def idx(prefix,start=0):
    for i in range(start,len(lines)):
        if lines[i].startswith(prefix): return i
    raise SystemExit('no '+prefix)
i=idx('Esta guía explica'); lines[i]=lines[i].replace('y el caso real `historial/dossiers/chumacera_polea_faja/`','y el caso real `historial/dossiers/bomba_prensaestopa_rodamientos/`').replace('`docs/agentes/mapa_agentes.html`','`docs/agentes/mapa_agentes_prensaestopa.html`')
i=idx('/modo-de-falla chumacera'); lines[i]='/modo-de-falla rodamientos de bomba con prensaestopa'
a=idx('Este es el orden que sigue'); b=idx('### 3.1')
sec3=f"""Este es el orden que sigue un modo de falla (protocolo del dossier) con lo que ocurrió de verdad en el caso de los rodamientos de bomba con prensaestopa. Donde el caso real no coincide con el protocolo, se dice.

1. **Solicitud.** La persona nombra el modo de falla. El líder lo clasifica y lee las reglas vigentes de `historial/feedback/feedback.jsonl`. No hay datos de planta, y el historiador no figura en la trazabilidad.
2. **Cinco frentes en paralelo.** Mecanismos, empaquetadura y contaminación, monitoreo, ML y datos abiertos, y normas y costos, cada uno con su rango de ids. Suman {NN} entradas nuevas.
3. **El acceso impide leer.** El índice de preprints legible no contiene literatura de empaquetaduras, los sitios de revistas, repositorios y fabricantes están bloqueados y el conector de Wiley no tiene cuota hasta el 2026-11-01. De {NN} entradas nuevas, {NS} son SOLO-SNIPPET, {LEI} se leyeron (todas de rodamientos, RUL o conjuntos de datos) y {NV} son NO-VERIFICADO.
4. **Análisis heredado.** Se reutilizan las {len(old)} entradas del caso de la bomba centrífuga y su análisis, con los límites reescritos para decir que no tratan de prensaestopa. El registro llega a {len(tot)} entradas.
5. **Normas y datos abiertos.** {nnor} normas y guías (51 heredadas y {nnor-51} nuevas) vistas solo en resúmenes de buscador, {conf} con conflicto de edición, y {nsd} vacíos declarados en las nuevas; {nd} entradas de datos abiertos, ninguna de bomba con prensaestopa con tiempos hasta la falla.
6. **Lectura profunda y réplicas.** Quedan {nc} cifras y {nr} réplicas, todas de rodamientos o de máquinas rotativas.
7. **Análisis con lo respaldado.** Causa raíz ({len(acr['hipotesis'])} hipótesis, todas posibles), FMECA ({len(fm['items'])} modos de rodamiento) y estrategia predictiva, heredados. El mecanismo propio del prensaestopa queda como SIN DATOS PARA ARMARLO.
8. **Ensamblado con compuertas.** En `informe.html` hay 7 de 14 secciones con {NEL} elementos y 7 declaradas vacías. No existe `ranking.json`.
9. **Verificación.** El verificador ve solo los archivos y las fuentes e intenta refutar. En este caso la verificación independiente está en curso y no hay resultado que informar.
10. **Entrega.** El líder entrega el HTML aunque haya secciones vacías, con una tabla de quién hizo qué y {len(pq)} preguntas finales a la persona.
11. **Aprendizaje.** El líder envía a cada agente lo aprendido, el agente de feedback lo registra y el curador propone lecciones en cuarentena.

Resultado del caso real (`meta.json`): {len(tot)} entradas de registro; 7 secciones del dossier con elementos y 7 vacías.
"""
lines[a:b]=sec3.split('\n')
i=idx('En el caso real el registro tiene'); lines[i]=f"En el caso real el registro tiene {nt['VERIFICADO-TEXTO']} entradas VERIFICADO-TEXTO, {nt['VERIFICADO-ABSTRACT']} VERIFICADO-ABSTRACT, {nt['SOLO-SNIPPET']} SOLO-SNIPPET y {nt['NO-VERIFICADO']} NO-VERIFICADO."
i=idx('2. **Lectura incompleta.**'); lines[i]=f"2. **Lectura incompleta.** De las {len(tot)} entradas del caso real, {nt['SOLO-SNIPPET']} son SOLO-SNIPPET y {nt['NO-VERIFICADO']} NO-VERIFICADO: no respaldan ninguna afirmación. Todo lo propio del prensaestopa (fuga, agua en el soporte, camisa, sobreapriete, empaquetadura frente a sello mecánico) está solo como pista."
i=idx('3. **Sin datos de planta.**'); lines[i]='3. **Sin datos de planta.** El caso real no tiene datos reales del activo. Por eso ninguna causa pasa de posible, no se ajusta ninguna distribución de vida, los puntajes S, O y D están sin puntuar y las secciones top de fallas, FMECA, punto óptimo, LCC, IBR, ACR y mantenimiento predictivo con normas del dossier quedaron vacías.'
i=idx('8. **Agentes aún no usados'); lines[i]='8. **Agentes que no figuran en el caso.** En la trazabilidad de este caso figuran ocho agentes: el líder, el investigador de literatura, el de normas, el analista de papers, el buscador de datos, el de causa raíz, el de FMECA y el predictivo. No figuran el integrador, el historiador, el auditor de datos, el replicador, el rankeador de citas, el redactor, el diseñador UX, el curador, el agente de feedback, el verificador, el analista de vida ni el de economía.'
md='\n'.join(lines)
def inline(t):
    t=html.escape(t,quote=False)
    t=re.sub(r'`([^`]+)`',r'<code>\1</code>',t)
    t=re.sub(r'\*\*([^*]+)\*\*',r'<strong>\1</strong>',t)
    return t
def conv(md):
    out=[];lines=md.split('\n');i=0
    while i<len(lines):
        l=lines[i]
        if l.startswith('```'):
            j=i+1;buf=[]
            while not lines[j].startswith('```'):buf.append(lines[j]);j+=1
            out.append('<pre><code>'+html.escape('\n'.join(buf),quote=False)+'</code></pre>');i=j+1;continue
        m=re.match(r'(#{1,3}) (.*)',l)
        if m:
            n=len(m.group(1));out.append('<h%d>%s</h%d>'%(n,inline(m.group(2)),n));i+=1;continue
        if l.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].startswith('|'):rows.append(lines[i]);i+=1
            cells=lambda r:[c.strip() for c in r.strip().strip('|').split('|')]
            h=cells(rows[0]);body=[cells(r) for r in rows[2:]]
            t='<div class="tw"><table><thead><tr>'+''.join('<th>%s</th>'%inline(c) for c in h)+'</tr></thead><tbody>'
            for bb in body:t+='<tr>'+''.join('<td>%s</td>'%inline(c) for c in bb)+'</tr>'
            out.append(t+'</tbody></table></div>');continue
        if re.match(r'\d+\. ',l):
            items=[]
            while i<len(lines) and re.match(r'\d+\. ',lines[i]):items.append(re.sub(r'^\d+\. ','',lines[i]));i+=1
            out.append('<ol>'+''.join('<li>%s</li>'%inline(x) for x in items)+'</ol>');continue
        if l.startswith('- '):
            items=[]
            while i<len(lines) and lines[i].startswith('- '):items.append(lines[i][2:]);i+=1
            out.append('<ul>'+''.join('<li>%s</li>'%inline(x) for x in items)+'</ul>');continue
        if l.strip()=='' :i+=1;continue
        buf=[l];i+=1
        while i<len(lines) and lines[i].strip()!='' and not re.match(r'(#|\||```|- |\d+\. )',lines[i]):buf.append(lines[i]);i+=1
        out.append('<p>'+inline(' '.join(buf))+'</p>')
    return '\n'.join(out)
guide=conv(md)
data={'agentes':{k:{'ficha':v['ficha']} for k,v in fich.items()},'traza':traza}
tpl=tpl.replace('__DATA__',json.dumps(data,ensure_ascii=False)).replace('__GUIDE__',guide)
open('/home/user/clima-lima/docs/agentes/mapa_agentes_prensaestopa.html','w',encoding='utf-8').write(tpl)
print('ok',len(tpl))


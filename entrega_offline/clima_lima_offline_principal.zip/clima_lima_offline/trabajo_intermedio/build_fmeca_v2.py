import json
B="/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_prensa/"
d=json.load(open(B+"analisis_v1/fmeca.json"))
SD="SIN DATOS PARA ARMARLO"
NOTA_T="Síntesis del equipo, no recomendación firme; consecuencia real, factibilidad técnica y costo-efectividad las define un experto del activo. Sin intervalo: no hay P-F ni historial del activo."

d["funcion"]=("Sistema: paquete de rodamientos (rodamientos, lubricante y soporte) de una bomba centrífuga con prensaestopa. "
"Función 1: soportar y ubicar el eje rotante de la bomba (E-1201, E-1205 ubican a los rodamientos en bombas), con la película de lubricante que separa los elementos rodantes (E-1203). "
"Función 2 (síntesis): mantener el lubricante del soporte libre de agua de la fuga del prensaestopa mediante protección del soporte (deflector, laberinto, drenaje); es una función de protección posiblemente oculta, sin fuente leída. "
"Estándar de desempeño cuantificado (vida requerida, temperatura y holgura admisibles, contenido de agua admisible en el lubricante, goteo aceptable): VACÍO, sin datos del activo ni fuente leída. "
"Falla funcional total: el paquete de rodamientos no soporta el eje (agarrotamiento o destrucción). Falla funcional parcial: el paquete opera con ruido, vibración, juego, temperatura o lubricante fuera de lo aceptable (límites: VACÍO). "
"Evento de falla bajo análisis: falla del paquete de rodamientos de la bomba con prensaestopa. Causa señalada por la persona (hipótesis, no confirmada): ajuste insuficiente del prensaestopa con fuga de agua hacia el soporte. "
"Alcance: los modos de rodamiento heredados (FM1 a FM7) y los modos de la cadena prensaestopa a soporte (FM8 a FM14). De la cadena, solo FM8 y FM9 tienen una fuente leída (E-2700, texto comercial aportado por la persona, no arbitrado, que no menciona el rodamiento); FM10 a FM14 son SINTESIS con pistas de buscador sin respaldo. Los modos propios de la bomba (sellos mecánicos, cavitación, recirculación, anillos de desgaste, golpe de ariete) no tienen fuente leída y están en vacios.")

fun_r="Soportar y ubicar el eje de la bomba con la película de lubricante intacta (E-1203); estándar cuantificado: VACÍO."
ff_r="Total: el rodamiento no soporta el eje. Parcial: opera con ruido, vibración, juego o temperatura fuera de lo aceptable (límites: VACÍO)."
for it in d["items"]:
    it["funcion"]=fun_r; it["falla_funcional"]=ff_r
# correcciones al heredado
d["items"][0]["mecanismo"]=("Fatiga de contacto en pistas y elementos rodantes; la vida nominal se define para rodamientos de buena calidad en condiciones convencionales de operación (E-6003, ISO 281 citada por la fuente, edición no verificada). Los rodamientos de bombas son susceptibles a desgaste y fatiga (E-1205). Progresa por etapas espectrales cualitativas (E-8008).")
d["items"][0]["nota"]+=" Corrección v2: se retiró la atribución a E-6002 de que la fatiga sea la causa en condiciones convencionales; E-6002 solo lista causas de daño."
d["items"][2]["nota"]+=" Cadena con prensaestopa: el agua como contaminante concreto se trata en FM10 a FM12; E-6004 dice contaminación, no nombra agua."
d["items"][3]["nota"]+=" Cadena con prensaestopa: la contaminación del lubricante por agua se trata en FM11."

def tarea(tipo,cons,raz,ev):
    return {"tipo":tipo,"consecuencia_a_confirmar":cons,"razonamiento":raz,"nivel":"SINTESIS","evidencia":ev,"nota":NOTA_T}
def item(i,modo,fun,ff,mec,el,es,causa,det,ctrl,nivel,ev,pistas,nota,t):
    return {"id":i,"modo":modo,"funcion":fun,"falla_funcional":ff,"mecanismo":mec,"efecto_local":el,"efecto_sistema":es,
     "causa":causa,"estado_causa":"posible","deteccion":det,"control_sugerido":ctrl,
     "severidad":SD,"ocurrencia":SD,"deteccion_puntaje":SD,"nivel":nivel,"evidencia":ev,"pistas_sin_respaldo":pistas,"nota":nota,"tarea_rcm":t}

fun_p="Sellar el eje en la caja de empaquetadura con una fuga controlada (cifra de goteo aceptable: VACÍO, sin diámetro, presión ni producto; la cifra de E-2700 no se usa como umbral)."
new=[]
new.append(item("FM8","Empaquetadura con ajuste insuficiente (fuga excesiva)",fun_p,
 "Parcial: la empaquetadura sella con fuga superior a la aceptable (límite: VACÍO).",
 "EVIDENCIA (E-2700, texto comercial): \"Si falta ajuste, el fluido 'lava' los lubricantes internos de la trenza, acelerando la falla.\" La fuente describe que el prensaestopa transfiere una fuerza axial que se convierte en expansión radial contra el eje. Que esa fuga llegue al soporte no consta en E-2700.",
 "Fuga abundante por la caja de empaquetadura y pérdida de lubricantes internos de la trenza, con falla acelerada de la empaquetadura (E-2700).",
 "Agua o producto sobre el área del soporte posible (síntesis, ver FM10); efecto en el sistema de bombeo: VACÍO.",
 "Falta de ajuste del prensaestopa (E-2700); cuándo y por qué se perdió el ajuste en el activo: VACÍO.",
 "Inspección visual del goteo y de su tendencia: consta en pista, sin respaldo (E-2104, E-2000 SOLO-SNIPPET). E-2700 no entrega técnica de detección.",
 "Criterio de ajuste escrito (cómo y cuánto apretar, qué goteo es aceptable) definido con el fabricante de la empaquetadura y la bomba; no copiar la cifra de E-2700.",
 "EVIDENCIA",["E-2700"],["E-2000","E-2104","E-2105","E-2106","E-2215"],
 "EVIDENCIA solo para el mecanismo de la empaquetadura, con fuente comercial no arbitrada aportada por la persona. Efecto en el soporte, detección y tarea son SINTESIS; validar con experto del activo.",
 tarea("En condición (inspección de goteo) y tarea de ajuste con criterio escrito","A confirmar; fuga visible, por tanto evidente (operacional o ambiental según el fluido, sin datos)",
  "La fuga de la empaquetadura es visible y su tendencia puede inspeccionarse; el criterio de ajuste actúa sobre la causa. Factibilidad técnica y costo-efectividad: VACÍO (sin costos ni historial). No se asigna intervalo.",["E-2700"])))

new.append(item("FM9","Empaquetadura con apriete excesivo (recalentamiento y cristalización)",fun_p,
 "Parcial o total: la empaquetadura deja de lubricarse, se recalienta y se endurece; el sellado ya no se controla (límites: VACÍO).",
 "EVIDENCIA (E-2700, texto comercial): \"Si se excede el ajuste, se elimina el goteo necesario (10-60 gotas/min), lo que destruye la película térmica, genera recalentamiento y termina por cristalizar el empaque.\" La cifra no trae diámetro de eje, presión ni producto y no se usa como umbral.",
 "Ausencia de goteo, recalentamiento de la empaquetadura y del área del eje, cristalización de la empaquetadura (E-2700). Daño al eje o a la camisa por fricción: síntesis, ver FM13.",
 "Una empaquetadura cristalizada y con fuga severa podría dejar entrar agua al soporte (pista E-2000, SOLO-SNIPPET, sin respaldo); efecto en el sistema: VACÍO.",
 "Sobreajuste del prensaestopa para frenar la fuga (síntesis: reacción a FM8; el activo no tiene historial que lo confirme).",
 "Ausencia de goteo y temperatura de la caja de empaquetadura: consta en pista, sin respaldo (E-2000, E-2001 SOLO-SNIPPET). E-2700 no entrega técnica de detección.",
 "Ajuste gradual con goteo medido y registro del ajuste; revisar si las correcciones de FM8 generan FM9 (ciclo de ajuste y reajuste).",
 "EVIDENCIA",["E-2700"],["E-2001","E-2000","E-2104","E-2105"],
 "EVIDENCIA solo para el mecanismo de la empaquetadura (fuente comercial). Que el sobreajuste sea una reacción a la fuga y los efectos sobre eje y soporte son SINTESIS; validar con experto del activo.",
 tarea("Rediseño del procedimiento de ajuste (criterio) y en condición (temperatura y goteo)","A confirmar",
  "La causa está en el método de ajuste; el criterio escrito reduce la ocurrencia y la inspección solo detecta el efecto. Sin intervalo: sin P-F. Costo-efectividad: VACÍO.",["E-2700"])))

new.append(item("FM10","Ingreso de agua al soporte de rodamientos",
 "Impedir que el agua de fuga entre al soporte (protección del soporte; función oculta posible, estándar: VACÍO).",
 "El agua llega al lubricante o al rodamiento (cantidad admisible: VACÍO).",
 "SIN RESPALDO LITERAL. Hipótesis del equipo: la fuga de la empaquetadura escurre a lo largo del eje hacia el soporte y entra por el sello del soporte. Consta en pista, sin respaldo: E-2000 (fuga severa, agua al soporte), E-2001 (drenaje bloqueado), E-2437, E-2603, E-2625.",
 "Agua en el soporte; presencia y vía de ingreso no verificadas en el activo.",
 "Falla prematura del paquete de rodamientos (ver FM11 y FM12); efecto en el sistema: VACÍO.",
 "Fuga de FM8 o FM9 más protección insuficiente (FM14); la persona señala ajuste insuficiente con fuga hacia el soporte, no confirmado.",
 "Inspección del soporte por agua (mirilla, aceite lechoso, humedad, oxidación): consta en pista, sin respaldo (E-2211, E-2616 SOLO-SNIPPET); ninguna técnica tiene respaldo literal.",
 "Verificar en el activo si hay agua en el soporte y por dónde entra antes de decidir tareas.",
 "SINTESIS",[],["E-2000","E-2001","E-2437","E-2603","E-2625","E-2211","E-2616","E-2515","E-2622"],
 "SINTESIS: el eslabón entre la fuga del prensaestopa y el soporte no tiene fuente leída; E-6004 y E-1201 hablan de contaminación sin nombrar agua. Razonamiento del equipo; debe ser validado por un experto del activo.",
 tarea("En condición (inspección de goteo hacia el soporte y del estado del lubricante) y búsqueda de fallas de la protección","A confirmar; si la protección es una función oculta, la consecuencia de su falla es oculta",
  "Antes de atacar la fuga conviene confirmar la presencia de agua. La inspección del goteo y del lubricante es factible a priori; su valor depende de que haya aviso (P-F desconocido). Sin intervalo.",[])))

new.append(item("FM11","Pérdida de película de lubricante por contaminación con agua",
 "Mantener la película de lubricante que separa los elementos rodantes (E-1203).",
 "La película no separa las superficies; hay contacto entre asperezas.",
 "Parte con respaldo: la película separa los elementos rodantes y evita el contacto de asperezas (E-1203); la falla de lubricante y la contaminación se citan como causas de falla prematura de rodamientos de bombas (E-6004, solo resumen). Sin respaldo: que el agua degrade la película o el lubricante; consta en pista (E-2002, E-2003, E-2100, E-2101, E-2102, E-2440 SOLO-SNIPPET; E-2005, E-2438, E-2439 NO-VERIFICADO). Las cifras de las pistas no se usan.",
 "Contacto entre asperezas por película degradada (E-1203, fuera del caso del agua); calentamiento y daño de pistas: síntesis.",
 "Progresión a FM1, FM2, FM4 o FM12; efecto en el sistema: VACÍO.",
 "Agua en el lubricante (FM10); contenido de agua del activo: VACÍO.",
 "Análisis de lubricante por agua (por ejemplo Karl Fischer, apariencia): consta en pista, sin respaldo (E-2211, E-2607, E-2611, E-2612, E-2624 SOLO-SNIPPET). Termografía y vibración: complemento según resumen de E-8003, no su extracto.",
 "Muestreo del lubricante con criterio de contenido de agua definido por el proveedor del lubricante o el fabricante del rodamiento; no existe límite respaldado en la evidencia leída.",
 "SINTESIS",["E-1203","E-6004"],["E-2002","E-2003","E-2100","E-2101","E-2102","E-2440","E-2211","E-2607","E-2611","E-2612","E-2624","E-2005","E-2438","E-2439"],
 "SINTESIS: E-1203 y E-6004 respaldan la película y la falla de lubricante en general; el agua como agente no consta en ningún extracto leído. Validar con experto del activo.",
 tarea("En condición (análisis de lubricante) y, si el agua se confirma, protección (FM14)","A confirmar",
  "El análisis de lubricante puede dar aviso antes del daño, pero P-F y límite de agua no tienen fuente leída. Si el agua es persistente, atacar el ingreso es preferible a drenar y reponer. Sin intervalo.",["E-1203"])))

new.append(item("FM12","Corrosión y fatiga del rodamiento por agua",
 "Soportar el eje durante la vida requerida (VACÍO) sin picaduras ni oxidación.",
 "Falla prematura por superficie corroída o descascarado antes de la vida esperada.",
 "Parte con respaldo: corrosión causada por contaminación figura como causa de falla prematura de rodamientos de bolas de bombas (E-6004, solo resumen); corrosión figura entre las causas de daño (E-6002); fatiga de contacto como mecanismo de fin de vida (FM1). Sin respaldo: que el agua en el lubricante acorte la vida a fatiga; consta en pista (E-2002, E-2003, E-2210, E-2440 SOLO-SNIPPET; E-2438 NO-VERIFICADO). Las cifras de reducción de vida no se usan.",
 "Oxidación y picaduras en pistas o bolas, aumento de ruido y vibración (síntesis).",
 "Falla del paquete de rodamientos y parada de la bomba posible; efecto en el sistema: VACÍO.",
 "Agua en el soporte (FM10) y lubricante degradado (FM11); sin análisis de falla del activo.",
 "Envolvente y tendencia de vibración (E-8001, E-8008) para el defecto ya formado; análisis de lubricante por agua y partículas: consta en pista, sin respaldo (E-2211). La corrosión sin defecto geométrico podría no verse en la vibración (síntesis).",
 "Análisis de falla de los rodamientos retirados para distinguir corrosión por agua de fatiga normal (FM1); sin eso la causa no se confirma.",
 "SINTESIS",["E-6004","E-6002","E-8001","E-8008"],["E-2002","E-2003","E-2210","E-2440","E-2610","E-2211"],
 "SINTESIS: la corrosión por contaminación tiene respaldo en E-6004 (solo resumen) sin nombrar agua; el efecto del agua en la fatiga solo está en pistas. Validar con experto del activo.",
 tarea("En condición (vibración con envolvente, análisis de lubricante) y rediseño de la protección","A confirmar; operacional si detiene el bombeo (sin datos)",
  "No se propone reemplazo por edad: no hay Weibull ni β > 1 (ver vacios). La detección en condición solo avisa del daño; la causa se ataca en FM10 y FM14. Sin intervalo.",["E-8001","E-8008","E-6004"])))

new.append(item("FM13","Desgaste de la camisa del eje",
 "Proteger el eje en la zona de la empaquetadura con una superficie de desgaste reemplazable (estándar: VACÍO).",
 "La camisa o el eje se desgastan o rayan y la empaquetadura ya no sella con el ajuste normal.",
 "SIN RESPALDO LITERAL. Hipótesis: la empaquetadura aprieta el eje o la camisa y el rozamiento la desgasta; E-2700 solo habla de expansión radial contra el eje y no menciona la camisa. Consta en pista, sin respaldo: E-2004 (manguito reemplazable que absorbe el desgaste, agua de sello limpia), E-2110, E-2441, E-2443.",
 "Mayor fuga por la caja de empaquetadura y mayor frecuencia de ajuste (síntesis).",
 "Más agua hacia el soporte (FM10); efecto en el sistema: VACÍO.",
 "Apriete excesivo (FM9), partículas en el agua de sello o empaquetadura abrasiva; sin datos del activo.",
 "Inspección de la camisa (rayado, diámetro) en cada reemplazo de empaquetadura: consta en pista, sin respaldo (E-2004, E-2110).",
 "Registrar el estado de la camisa en cada cambio de empaquetadura para generar el historial que hoy falta.",
 "SINTESIS",[],["E-2004","E-2110","E-2441","E-2443","E-2001"],
 "SINTESIS: ninguna fuente leída trata la camisa. Razonamiento del equipo; debe ser validado por un experto del activo.",
 tarea("En condición (inspección de la camisa) y restauración o reemplazo solo con edad de desgaste identificable","A confirmar",
  "El desgaste es candidato a restauración o reemplazo programado solo con edad identificable (β > 1), no demostrada. Mientras tanto, inspección en condición al cambiar la empaquetadura. Sin intervalo.",[])))

new.append(item("FM14","Protección del soporte inexistente o ineficaz (deflector, laberinto, drenaje)",
 "Desviar y drenar el agua de fuga lejos del soporte de rodamientos (función de protección; estándar: VACÍO).",
 "La protección no desvía o no drena y el agua alcanza el sello del soporte (falla posiblemente oculta).",
 "SIN RESPALDO LITERAL. Hipótesis: sin deflector, con laberinto desgastado o con drenaje bloqueado, el agua de fuga llega al soporte. Consta en pista, sin respaldo: E-2001 (drenaje bloqueado acumula agua), E-2108 (laberinto y aisladores), E-2603 (patente de sellado contra ingreso de agua), E-2619, E-2625.",
 "Agua alcanza el sello o la entrada del soporte; sin señal propia mientras no haya otro daño (síntesis).",
 "Habilita FM10 a FM12; efecto en el sistema: VACÍO.",
 "Diseño sin protección, desgaste o drenaje obstruido; configuración del activo: VACÍO.",
 "Inspección de deflector, estado del laberinto y limpieza del drenaje: consta en pista, sin respaldo (E-2001).",
 "Levantar la configuración de protección del soporte en las bombas con prensaestopa; definir si es función oculta.",
 "SINTESIS",[],["E-2001","E-2108","E-2603","E-2619","E-2625","E-2437"],
 "SINTESIS: sin fuente leída; E-6004 respalda solo que la contaminación daña rodamientos de bombas. Debe ser validado por un experto del activo.",
 tarea("Rediseño (instalar o mejorar protección y drenaje) y búsqueda de fallas (verificación funcional de drenaje y protección)","A confirmar; oculta si la falla de la protección no es evidente por sí sola",
  "La protección actúa sobre la causa común de FM10 a FM12. Si es función oculta, corresponde búsqueda de fallas con intervalo basado en el riesgo aceptado, que no puede fijarse sin datos. Costo-efectividad: VACÍO.",[])))

d["items"]+=new

d["vacios"]=[v for v in d["vacios"] if not v.startswith("Estándar exigido") and not v.startswith("Este FMECA es de escritorio")]
d["vacios"]+=[
 "Estándar exigido (FMEA clásico, Action Priority o proceso RCM) sin definir por la persona. Registro knowledge/registro_normas.yaml consultado: IEC 60812 (ed. 2018, SOLO-SNIPPET), AIAG-VDA FMEA Handbook (2019, fuentes en conflicto, SOLO-SNIPPET, tablas no abiertas), ISO 281 (2007, enmienda en elaboración, SOLO-SNIPPET), ISO 4406 (2021, SOLO-SNIPPET): todos con edición no verificada. ISO 3069 y EN 16752 (empaquetaduras) aparecen solo como pistas E-2400 y E-2402 (SOLO-SNIPPET) y no están en el registro. Ninguna norma respalda este FMECA.",
 "Cadena prensaestopa a soporte: solo FM8 y FM9 tienen fuente leída (E-2700), texto comercial no arbitrado aportado por la persona, que no menciona el rodamiento y cuya cifra de goteo no se usa. Eslabones sin fuente leída: fuga a soporte (FM10), agua que degrada película (FM11), agua que corroe o fatiga (FM12), desgaste de camisa (FM13), protección (FM14). Lectura que lo cierra: texto o abstract de E-2000, E-2001, E-2002, E-2003, E-2004, E-2108 (pistas) o de estudios arbitrados equivalentes.",
 "Cifras de pérdida de vida por agua (E-2002, E-2003, E-2438, E-2439) y límites de agua en lubricante (E-2607, E-2608, E-2627): SOLO-SNIPPET o NO-VERIFICADO; no se citan como dato ni como umbral.",
 "Criterio de ajuste y goteo aceptable de la empaquetadura: sin fuente arbitrada ni del fabricante del activo; la cifra de E-2700 carece de diámetro, presión y producto.",
 "Severidad, ocurrencia y detección de FM8 a FM14: SIN DATOS PARA ARMARLO. Faltan escalas calibradas, historial de órdenes de trabajo y un experto del activo. No se calcula RPN. Los modos heredados FM1 a FM7 mantienen null.",
 "PM actuales cuestionables: no se aportó plan. Candidata a cuestionar cuando haya datos: el apriete periódico calendario del prensaestopa (¿previene la fuga o provoca FM9 por sobreajuste?) y la relubricación o cambio de lubricante sin análisis (¿introduce contaminación?). Sin historial no hay evidencia; lista de PM cuestionadas con evidencia: VACÍO.",
 "Historial del activo: fallas del paquete de rodamientos, hallazgos de agua en el soporte, análisis de falla de rodamientos retirados, estado de la camisa y configuración de protección (deflector, laberinto, drenaje): VACÍO. Sin ellos la causa señalada por la persona queda como hipótesis posible.",
 "Este FMECA es de escritorio basado en literatura de rodamientos en general, un resumen de 1988 sobre rodamientos de bombas (E-6004) y un texto comercial sobre empaquetadura (E-2700); no es evidencia de campo.",
]
json.dump(d,open(B+"analisis_v2/fmeca.json","w"),ensure_ascii=False,indent=1)

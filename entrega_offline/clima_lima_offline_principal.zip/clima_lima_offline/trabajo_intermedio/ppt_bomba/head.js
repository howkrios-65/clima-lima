const pptxgen=require('pptxgenjs');const fs=require('fs');
const SK='/root/.claude/skills/synced/7fd509e0-a6d1-4387-9ddc-c3e2303bdaa3_ca63f8bb-a2bd-43d4-be0f-2a8f777623d1/pptx/scripts/apply_theme.js';
const {applyTheme}=require(SK);
const D=JSON.parse(fs.readFileSync('data.json','utf8'));
const THEME={name:'Confiabilidad baby',headFontFace:'Cambria',bodyFontFace:'Calibri',colors:{dk1:'22313F',lt1:'FFFFFF',dk2:'3E5871',lt2:'EAF3F8',accent1:'5B9FCF',accent2:'6FB98D',accent3:'F0B784',accent4:'C8AAD6',accent5:'86BCB6',accent6:'ECD27A',hlink:'3B7FB5',folHlink:'7A6FA0'}};
const pres=new pptxgen();pres.layout='LAYOUT_WIDE';pres.theme={headFontFace:'Cambria',bodyFontFace:'Calibri'};pres.title='Falla de la bomba centrífuga';pres.author='HOWK RIOS - CONFIABILIDAD';
const C=pres.SchemeColor;
pres.defineSlideMaster({title:'CONTENIDO',background:{color:C.background1},objects:[
 {text:{text:'HOWK RIOS - CONFIABILIDAD  |  Bomba centrífuga',options:{x:0.5,y:7.08,w:9,h:0.3,fontSize:10,color:C.text2,margin:0,isTextBox:true}}}],
 slideNumber:{x:12.3,y:7.08,w:0.6,h:0.3,fontSize:10,color:C.text2}});
pres.defineSlideMaster({title:'PORTADA',background:{color:C.text1},objects:[]});
let SEC='';
function sec(t){SEC=t;pres.addSection({title:t})}
function S(titulo,fuente){const s=pres.addSlide({masterName:'CONTENIDO',sectionTitle:SEC});s.addText(titulo,{x:0.5,y:0.3,w:12.3,h:0.95,fontFace:'Cambria',fontSize:24,bold:true,color:C.text1,margin:0,valign:'top',isTextBox:true});if(fuente)s.addText('Fuente: '+fuente,{x:0.5,y:6.72,w:12.3,h:0.3,fontSize:10,color:C.text2,italic:true,margin:0,isTextBox:true,valign:'top'});return s}
function card(s,x,y,w,h,head,lines,col,o){o=o||{};s.addShape(pres.ShapeType.roundRect,{x,y,w,h,rectRadius:0.08,fill:{color:o.fill||C.background2},line:{color:col,width:1},objectName:'tarjeta '+head});
 s.addText(head,{x:x+0.15,y:y+0.1,w:w-0.3,h:0.4,fontSize:o.hs||14,bold:true,color:C.text1,margin:0,isTextBox:true,valign:'top'});
 s.addText(lines.map((t,i)=>({text:t,options:{bullet:true,breakLine:i<lines.length-1,paraSpaceAfter:4}})),{x:x+0.15,y:y+0.55,w:w-0.3,h:h-0.65,fontSize:o.fs||12,color:C.text1,margin:0,isTextBox:true,valign:'top'})}
function kpi(s,x,y,w,big,small,col){s.addShape(pres.ShapeType.roundRect,{x,y,w,h:1.15,rectRadius:0.08,fill:{color:C.background2},line:{color:col,width:1},objectName:'kpi '+big});
 s.addText(big,{x:x+0.1,y:y+0.05,w:w-0.2,h:0.6,fontSize:30,bold:true,color:col,fontFace:'Cambria',margin:0,isTextBox:true,align:'left'});
 s.addText(small,{x:x+0.1,y:y+0.65,w:w-0.2,h:0.48,fontSize:11,color:C.text1,margin:0,isTextBox:true,valign:'top'})}
const hdr=(t)=>({text:t,options:{bold:true,color:C.background1,fill:{color:C.text2},fontSize:12}});
const cell=(t,o)=>({text:t,options:Object.assign({fontSize:11,color:C.text1,valign:'top'},o||{})});
const chartBase={showTitle:true,titleFontSize:13,titleColor:'22313F',catAxisLabelFontSize:11,valAxisLabelFontSize:11,catAxisLabelColor:'3E5871',valAxisLabelColor:'3E5871',valGridLine:{color:'DDE9EE',size:0.5},catGridLine:{style:'none'},catAxisLabelFontFace:'+mn-lt',valAxisLabelFontFace:'+mn-lt',dataLabelFontFace:'+mn-lt',titleFontFace:'+mj-lt',dataLabelFontSize:11,dataLabelColor:'22313F',showValue:true};


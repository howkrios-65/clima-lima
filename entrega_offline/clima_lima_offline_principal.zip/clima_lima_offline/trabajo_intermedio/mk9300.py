import json
R = {"autores": "Lillelund, C. M., Pannullo, F., Jakobsen, M. O., Morante, M., & Pedersen, C. F.", "anio": 2024,
     "titulo": "RULSurv: A probabilistic survival-based method for early censoring-aware prediction of remaining useful life in ball bearings",
     "fuente": "arXiv:2405.01614 (v3, cs.LG)", "url": "https://arxiv.org/abs/2405.01614", "pais": "Dinamarca (Departamento de Ingenieria Electrica y Computacion, Universidad de Aarhus, segun la portada)"}
C = {"autores": "Razzaq, W., & Zhao, Y.-B.", "anio": 2025,
     "titulo": "CARLE: A Hybrid Deep-Shallow Learning Framework for Robust and Explainable RUL Estimation of Rolling Element Bearings",
     "fuente": "arXiv:2510.17846 (v1)", "url": "https://arxiv.org/abs/2510.17846", "pais": "China (School of Automation, University of Science and Technology of China, segun la portada)"}
def e(i, ref, ex, loc, af, lim, ap, acc="fragmento"):
    return {"id": i, "tipo": "preprint", "acceso": acc, "via": "hf_papers", "fecha_acceso": "2026-10-27",
            "referencia": ref, "extracto": ex, "localizador": loc, "afirma": af, "limites": lim, "aplica_a": ap,
            "revista_cuartil": None, "nivel_evidencia": "VERIFICADO-TEXTO"}
L = [
 e("E-9301", R, "Faults and defects are often induced by contamination wear, poor lubrication, and improper mounting, among others [8, 30, 27, 12].",
   "Seccion 1 (Introduction), parrafo 1; hf://papers/2405.01614/paper.md, primeros 30000 bytes",
   "Afirmacion de introduccion, con cuatro referencias propias del preprint, de que las fallas y defectos de rodamientos se inducen a menudo por desgaste por contaminacion, mala lubricacion y montaje inadecuado. Respalda como lista cualitativa de factores (preguntas 1 y 2), sin cifras.",
   "Cita secundaria: no se leyeron las referencias [8, 30, 27, 12]; no da frecuencias ni porcentajes por causa. El estudio es de prognosis con datos de banco (XJTU-SY), no de causas de falla en campo ni de chumaceras de polea. Preprint, no consta arbitraje en lo leido.",
   "Hipotesis de lubricacion deficiente, contaminacion y montaje inadecuado como causas de falla de rodamiento; comparabilidad baja (cita general)."),
 e("E-9302", R, "Bearing health depends on a wide range of factors, such as the operating condition, operating temperature, maintenance level, among others [78]. ... Approximately 90% of industrial bearings outlive the equipment in which they are installed, and the remaining 10% are replaced for preventive reasons. Only around 0.5% are replaced because of actual bearing failure [56].",
   "Seccion 3.1 (Elements of rolling bearings), parrafo 1; hf://papers/2405.01614/paper.md",
   "Cita secundaria de que la vida de un rodamiento depende de condicion de operacion, temperatura y nivel de mantenimiento, y de que aprox. 90 % de los rodamientos industriales sobrevive al equipo, 10 % se reemplaza de forma preventiva y solo alrededor de 0,5 % se reemplaza por falla real. Tambien define L10 como horas que duran el 90 % de un grupo identico a velocidad constante.",
   "Las cifras 90 %, 10 % y 0,5 % vienen de la referencia [56] que no se leyo; no se sabe la poblacion ni el sector, y no son de transportadoras ni de ambientes de polvo. No cuantifica el efecto de la temperatura ni de la lubricacion.",
   "Contexto de L10 y de la baja tasa de falla real frente al reemplazo preventivo; no sirve para fijar una vida esperada de la chumacera del caso."),
 e("E-9304", C, "Rotational machinery is more prone to failure because of the availability of rolling-element bearings working under aggressive environments. It has been estimated that 40 to 50% of machinery failures can be attributed to these bearings",
   "Seccion 1 (Introduction), parrafo 1; hf://papers/2510.17846/paper.md, primeros 9000 bytes",
   "Cita secundaria de que se estima que 40 a 50 % de las fallas de maquinaria rotatoria se atribuyen a rodamientos de elementos rodantes, que operan en ambientes agresivos.",
   "Cifra citada de la referencia [1] del preprint, no leida; no define poblacion ni sector ni criterio de atribucion, no distingue lubricacion, contaminacion o carga, y no es especifica de transportadoras de faja. El documento trata de prognosis con datos de banco.",
   "Importancia relativa del rodamiento entre los componentes de maquinaria rotatoria; comparabilidad baja a media."),
 e("E-9305", R, "Initially, a healthy bearing exhibits frequencies solely linked to shaft phenomena, such as balance or misalignment.",
   "Seccion 3.2, pie de la Figura 1 (texto del pie), hf://papers/2405.01614/paper.md",
   "Describe que, en un rodamiento sano, el espectro de vibracion contiene solo frecuencias ligadas al eje (desbalance o desalineacion), antes de que aparezcan las frecuencias de defecto del rodamiento en las etapas posteriores. Apoya que la desalineacion se ve como componente de la frecuencia del eje y no como defecto de pista.",
   "Es una descripcion cualitativa de un esquema (Figura 1), sin cifras de amplitud, sin umbrales y sin datos de desalineacion medida. No cuantifica el efecto de la desalineacion sobre la vida. No es de baja velocidad.",
   "Diagnostico diferencial desalineacion contra defecto de rodamiento (pregunta 2 y 4); comparabilidad baja."),
 e("E-9306", R, "Mechanical engineers have traditionally used model-based methods, which are based solely on threshold values of different signals at predetermined fault frequencies. These models can only describe the signal characteristics of a few specific types of faults, but faults in the real world are often more complicated.",
   "Seccion 1 (Introduction), parrafo 2; hf://papers/2405.01614/paper.md",
   "Afirma que los umbrales fijos sobre bandas de frecuencia de falla predeterminadas solo describen unos pocos tipos de falla y que las fallas reales suelen ser mas complejas, lo que motiva metodos basados en datos. Respalda cautela al usar un umbral unico de severidad.",
   "Es una opinion de introduccion sin cifras ni valores de umbral. No contiene umbrales de vibracion ni de temperatura ni validacion para baja velocidad. El estudio propone un metodo de datos validado en banco acelerado (minutos de vida).",
   "Limite de los umbrales fijos de vibracion (pregunta 4); comparabilidad baja."),
 e("E-9307", R, "operational anomalies appear minimally on the surface of the rolling elements. ... a large number of harmonics will often be energized during overrolling, leading to the excitation of eigenfrequencies of the bearing components that are typically in the range from 10kHz to higher.",
   "Seccion 3.2 (Defect evolution and failure monitoring), parrafo 1; hf://papers/2405.01614/paper.md",
   "Describe que un defecto incipiente excita frecuencias propias de los componentes tipicamente desde 10 kHz hacia arriba, detectables por envolvente en banda impulsiva, y que al avanzar el defecto la vibracion crece en amplitud a menor frecuencia. Apoya que la deteccion temprana requiere ancho de banda alto, no solo velocidad RMS de baja frecuencia.",
   "Descripcion cualitativa con una cifra de banda (10 kHz); no da umbrales de severidad ni diferencia baja velocidad. Los datos de la prueba son a 2100 a 2400 rpm con muestreo de 25,6 kHz, distintos de una polea lenta. No se verifico la afirmacion en su fuente primaria.",
   "Seleccion de banda y tecnica de vigilancia (envolvente) para deteccion temprana (pregunta 4); comparabilidad baja a media."),
]
for x in L: x["fecha_acceso"] = "2026-10-27"
# nota: extracto de E-9307 usa '...' para unir dos frases del mismo parrafo (la primera recortada)
json.dump(L, open("/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_chumacera/evidencia2/frente_lubricacion.json", "w"), ensure_ascii=False, indent=1)

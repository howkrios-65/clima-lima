import json
OUT='/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_bomba/evidencia/'
F='2026-10-27'
def read(id,tipo,acc,via,ref,ex,loc,afirma,lim,aplica):
    return dict(id=id,tipo=tipo,acceso=acc,via=via,fecha_acceso=F,referencia=ref,extracto=ex,localizador=loc,afirma=afirma,limites=lim,aplica_a=aplica,revista_cuartil=None)
def snip(id,tipo,ref,afirma,lim,aplica):
    return dict(id=id,tipo=tipo,acceso='snippet',via='websearch',fecha_acceso=F,referencia=ref,extracto='',localizador='',afirma='SOLO-SNIPPET (pagina no abierta; red bloqueada): '+afirma,limites=lim+' Solo se vio el resumen del buscador; no respalda cifras ni afirmaciones de entregables hasta abrir la fuente.',aplica_a=aplica,revista_cuartil=None)
chen=dict(autores='Chen, S., Liu, Z., Li, C., Zou, D., He, X., & Zhou, D.',anio=2026,titulo='Multi-mode fault diagnosis datasets of three-phase asynchronous motor under variable working conditions',fuente='arXiv 2601.02278 (Data in Brief, segun la declaracion de etica del preprint)',url='https://arxiv.org/abs/2601.02278',pais='China',institucion='Department of Automation, Tsinghua University; MCC5 Group Shanghai')
L=[]
L.append(read('E-1301','preprint','texto_completo','lector_hf_papers',chen,
 "Vibration and current signals are effective indicators for monitoring motor health and diagnosing faults. However, motors in real applications often operate under variable conditions such as fluctuating speeds and loads, which complicate the fault diagnosis process. ... Eight-channel synchronous vibration-current-torque-keyphase data were recorded from a 2.2 kW three-phase induction motor under variable speed/load profiles at 12.8 kHz.",
 "Abstract y Specifications table (hf://papers/2601.02278/paper.md)",
 "Conjunto de datos de banco de un motor de induccion de 2.2 kW con vibracion triaxial, tres corrientes de fase, par y fase clave a 12.8 kHz; los autores afirman que vibracion y corriente son indicadores de salud del motor y que la velocidad y la carga variables complican el diagnostico.",
 "Banco de laboratorio con motor de 2.2 kW acoplado a caja reductora y freno de polvo magnetico; NO incluye bomba, caudal, presion ni cavitacion; fallas del motor (desbalance, cortocircuito de devanado, rodamientos, barras rotas). No es dato de campo ni umbral para bombas.",
 "Medicion de vibracion y corriente del motor impulsor de una bomba; comparabilidad con la bomba: baja"))
L.append(read('E-1302','preprint','abstract','lector_hf_papers',
 dict(autores='Chevtchenko, S. F., dos Santos, M. C. M., Vieira, D. M., Mota, R. L., Rocha, E., Cruz, B. V., Araujo, D., & Andrade, E.',anio=2023,titulo='Predictive maintenance model based on anomaly detection in induction motors: A machine learning approach using real-time IoT data',fuente='arXiv 2310.14949',url='https://arxiv.org/abs/2310.14949'),
 "we demonstrate a novel anomaly detection system on induction motors used in pumps, compressors, fans, and other industrial machines. ... we fuse vibration, temperature, and noise data from these sensors as the input to the proposed ML model.",
 "Abstract (hf://papers/2310.14949/paper.md; el lector solo entrego metadatos y resumen)",
 "Sistema de deteccion de anomalias en motores de induccion (usados en bombas, compresores y ventiladores) con sensores IoT de bajo costo que fusionan vibracion, temperatura y ruido, con preprocesamiento FFT, wavelet y binning.",
 "Solo se leyo el resumen del autor; el lector no entrego el texto completo; no se leyeron cifras, umbrales ni condiciones. Motor, no bomba; no trata cavitacion ni senales hidraulicas.",
 "Monitoreo multisensor (vibracion, temperatura, ruido) del motor de una bomba; comparabilidad: baja"))
L.append(read('E-1303','preprint','abstract','lector_hf_papers',
 dict(autores='Purohit, H., Tanabe, R., Ichige, K., Endo, T., Nikaido, Y., Suefusa, K., & Kawaguchi, Y.',anio=2019,titulo='MIMII dataset: Sound dataset for malfunctioning industrial machine investigation and inspection',fuente='arXiv 1909.09347',url='https://arxiv.org/abs/1909.09347'),
 "Normal sounds were recorded for different types of industrial machines (i.e., valves, pumps, fans, and slide rails), and to resemble a real-life scenario, various anomalous sounds were recorded (e.g., contamination, leakage, rotating unbalance, and rail damage).",
 "Abstract (hf://papers/1909.09347/paper.md; el lector solo entrego metadatos y resumen)",
 "Conjunto publico de sonidos de maquinas industriales, entre ellas bombas, en condicion normal y con anomalias (contaminacion, fuga, desbalance rotatorio, dano de riel) grabados en entornos de fabrica.",
 "Solo se leyo el resumen; el resumen no precisa que anomalia corresponde a cada maquina ni el tipo de bomba; no trata cavitacion, caudal ni presion; acustica de microfono, no vibracion.",
 "Deteccion acustica de anomalias en bombas; comparabilidad: baja"))
L.append(read('E-1304','preprint','texto_completo','lector_hf_papers',chen,
 "In industrial practice, distinguishing between mechanical and electrical faults is often challenging due to their similar manifestations, which significantly hinders the efficiency of on-site diagnosis. ... In motor fault diagnosis, stator current signals are widely adopted for online detection of rotor bar breakages due to their easy acquisition and robustness to external disturbances.",
 "Seccion BACKGROUND, parrafo 2 (hf://papers/2601.02278/paper.md)",
 "Segun los autores, en la practica es dificil distinguir fallas mecanicas de electricas por sus manifestaciones similares, y la corriente del estator se usa para detectar barras rotas del rotor por su facil adquisicion y robustez a perturbaciones externas.",
 "Afirmacion de contexto de los autores sobre motores (sin referencia propia verificada en este registro); no es un procedimiento de troubleshooting de bombas ni una medicion.",
 "Troubleshooting: separar causa electrica y mecanica del lado del motor; comparabilidad: baja"))
L.append(read('E-1305','preprint','texto_completo','lector_hf_papers',chen,
 "the dataset is limited to single-point bearing faults and does not include distributed or progressive fault patterns that may occur in long-term service. Additionally, the fault severity levels are discretely defined and may not fully represent the continuous degradation process observed in actual industrial settings.",
 "Seccion LIMITATIONS (hf://papers/2601.02278/paper.md)",
 "Los propios autores declaran que el conjunto no cubre fallas distribuidas ni progresivas de servicio prolongado y que las severidades son discretas, sin representar la degradacion continua.",
 "Limitacion del conjunto de motor; no describe etapas de degradacion de bombas.",
 "Limite de los ensayos de banco para describir etapas de degradacion"))
# snippets
def r(**k): return k
L.append(snip('E-1310','otro',r(autores='Autoria no visible en el resumen',anio=2018,titulo='Spectrum analysis of vibration signals for cavitation monitoring',fuente='J. of Pure & Applied Sciences (sebhau.edu.ly); ano 2018 segun el buscador',url='https://sebhau.edu.ly/journal/jopas/article/view/16'),
 "revision de las fuentes de vibracion de una bomba centrifuga en operacion normal y de como el inicio de cavitacion las excita, con palabras clave de frecuencia de paso de alabes y contenido de banda ancha.","Texto no leido; no se conocen metodo, bomba ni resultados.","Cavitacion: espectro de vibracion; frecuencia de paso de alabes"))
L.append(snip('E-1311','otro',r(autores='Autoria no visible',anio=2008,titulo='Conferencia Civil-Comp sobre vibracion de bombas con cavitacion (titulo no visible; ctresources.info paper id 4764)',fuente='Civil-Comp Press; ano 2008 segun el buscador',url='https://ctresources.info/ccp/paper.html?id=4764'),
 "con acelerometros a siete caudales, RMS y desviacion estandar pueden indicar cavitacion pero no diagnosticarla.","Texto no leido; bomba y condiciones desconocidas.","Cavitacion: indicadores en tiempo (RMS)"))
L.append(snip('E-1312','otro',r(autores='Autoria no visible en el resumen',anio=None,titulo='Tesis de repositorio institucional sobre deteccion de cavitacion en dominio de frecuencia con FFT (titulo no visible; repository.umy.ac.id handle 123456789/15151)',fuente='Repositorio institucional (Indonesia segun el dominio; no verificado)',url='https://repository.umy.ac.id/handle/123456789/15151'),
 "compara espectros FFT con y sin cavitacion provocada por estrangulamiento de valvula en un circuito cerrado y menciona picos en frecuencia de giro y de impulsor.","Texto no leido; las frecuencias numericas vistas en el resumen no se registran como cifra.","Cavitacion: FFT; frecuencias de giro y de alabes"))
L.append(snip('E-1313','otro',r(autores='Autoria no visible',anio=None,titulo='Articulo de J. of Applied Fluid Mechanics sobre cavitacion incipiente con analisis espectral de envolvente (articulo 898)',fuente='Journal of Applied Fluid Mechanics',url='https://www.jafmonline.net/article_898.html'),
 "aborda cavitacion incipiente con analisis espectral de envolvente sobre datos de un banco construido para ello.","Texto no leido; banco, no campo.","Cavitacion incipiente: envolvente"))
L.append(snip('E-1314','otro',r(autores='Autoria no visible',anio=None,titulo='Estudio numerico y experimental de cavitacion con acelerometros y emision acustica (NTUA)',fuente='Repositorio NTUA',url='https://dspace.lib.ntua.gr/xmlui/handle/123456789/50836'),
 "reporta que bajo cavitacion severa los datos de ruido y vibracion contienen picos ligados al colapso de burbujas que distorsionan la distribucion gaussiana, relacionado con la kurtosis.","Texto no leido.","Cavitacion: kurtosis, emision acustica"))
L.append(snip('E-1315','paper',r(autores='Liang, Hao, Tengzhou y Zhiguo (nombres de pila e iniciales no confirmados)',anio=2023,titulo='Identification of cavitation state of centrifugal pump based on current signal',fuente='Frontiers in Energy Research',doi='10.3389/fenrg.2023.1204300',url='https://www.frontiersin.org/journals/energy-research/articles/10.3389/fenrg.2023.1204300/pdf'),
 "articulo de acceso abierto sobre identificacion del estado de cavitacion de una bomba centrifuga a partir de la senal de corriente.","Metodos y resultados no vistos.","Cavitacion: corriente del motor"))
L.append(snip('E-1316','otro',r(autores='Ganeriwala, S. (segun el buscador)',anio=2025,titulo='Detection and signature of the cavitation in centrifugal pumps (resumen 2E6, CM 2025)',fuente='BINDT CM 2025',url='https://www.bindt.org/events-and-awards/cm-2025/abstract-2e6/'),
 "experimento con vibracion, presion, sonido audible, corriente del motor y fuerza por cavitacion; concluye que la medicion combinada de presion y vibracion parece mas efectiva.","Resumen de congreso; no abierto.","Cavitacion: multisensor"))
L.append(snip('E-1317','otro',r(autores='Patentes US 7099852, 7389278 y 6757665 (titulares no registrados)',anio=None,titulo='Detection of pump cavitation/blockage and seal failure via current signature analysis',fuente='Patente de EE. UU.',url='https://www.google.ca/patents/US7099852'),
 "describen la comparacion de espectros de corriente del motor entre bomba normal y con cavitacion.","Patente: no es estudio revisado por pares ni validacion.","Cavitacion: analisis de firma de corriente"))
L.append(snip('E-1318','otro',r(autores='Smith, Price y Kunz (segun el buscador)',anio=None,titulo='Centrifugal pump vibration caused by supersynchronous shaft instability',fuente='Pump Users Symposium (alojado en engdyn.com)',url='https://engdyn.com/resources/centrifugal-pump-vibration-caused-by-supersynchronous-shaft-instability'),
 "indica que mecanismos no sincronicos como recirculacion y desprendimiento son mas dificiles de diagnosticar que los sincronicos como el paso de alabes.","Texto no leido.","Troubleshooting: separar sincronico de no sincronico"))
L.append(snip('E-1319','otro',r(autores='Autoria no visible',anio=None,titulo='Articulo de Redalyc sobre recirculacion en la succion como fenomeno subsincronico (revista 477, articulo 47774679001)',fuente='Redalyc',url='https://www.redalyc.org/journal/477/47774679001/47774679001.pdf'),
 "trata la recirculacion en la succion como fenomeno subsincronico en condiciones fuera de diseno.","Texto no leido.","Fenomenos: recirculacion subsincronica"))
L.append(snip('E-1320','otro',r(autores='Autoria no visible',anio=2012,titulo='Estudio de J. of Visualization sobre cavitacion visible frente a la caida de altura del 3 %',fuente='Journal of Visualization (Springer)',doi='10.1007/s12650-012-0149-7',url='https://link.springer.com/doi/10.1007/s12650-012-0149-7'),
 "la cavitacion visible comienza antes de la caida de altura del 3 %, y usar el 3 % como inicio ha llevado a dano en operacion.","Texto no leido.","Etapas de cavitacion: NPSH3 frente a inicio"))
L.append(snip('E-1321','otro',r(autores='KSB (lexico del fabricante)',anio=None,titulo='Cavitation (Centrifugal pump lexicon)',fuente='Lexico de bombas centrifugas, KSB',url='https://www.ksb.com/en-global/centrifugal-pump-lexicon/article/cavitation-1117364'),
 "lista criterios de cavitacion: incipiente (NPSHi), inicio de caida de altura (NPSH0), caida del 3 % (NPSH3), caida de eficiencia, erosion y ruido.","Documento de fabricante; no leido.","Etapas de cavitacion"))
L.append(snip('E-1322','norma',r(autores='ISO',anio=None,titulo='ISO 10816-7, evaluacion de vibracion de bombas rotodinamicas industriales (titulo completo no visible)',fuente='Norma ISO (resumen en tiendas de normas)',url='https://store.sfs.fi/fi/sfs-iso-10816-7-2017'),
 "la norma aplica a bombas rotodinamicas industriales de mas de 1 kW y usa un criterio de magnitud y otro de cambio de magnitud para vigilancia de largo plazo.","Norma no abierta; las zonas numericas por categoria de bomba no se vieron.","Umbrales de vibracion en bombas"))
L.append(snip('E-1323','otro',r(autores='Europump',anio=2013,titulo='Guidelines on pump vibration, first edition',fuente='Europump',url='https://www.europump.net/files/Publications/Guides/Guidelines 0n Pump Vibration First edition Final July 2013.pdf'),
 "guia de vibracion de bombas que el buscador cita como fuente de un limite de velocidad para bombas.","Documento no abierto; contexto y clase de bomba no verificados.","Umbrales de vibracion en bombas"))
L.append(snip('E-1324','otro',r(autores='Autoria no visible',anio=2025,titulo='Diagnostics of the technical condition of pumping equipment by thermal control method',fuente='Bulletin of the L.N. Gumilyov Eurasian National University (bultech.enu.kz)',url='https://bultech.enu.kz/index.php/main/article/view/959'),
 "termografia en bombas centrifugas industriales detecto sobrecalentamiento local en conjuntos de rodamientos y los autores la juzgan eficaz para fallas tempranas.","Texto no leido.","Termografia de bombas"))
L.append(snip('E-1325','otro',r(autores='Hidayat y colaboradores (segun el buscador)',anio=2018,titulo='Articulo MATEC Web of Conferences 159, 02006, segmentacion de imagenes termicas de rodamientos junto con vibracion',fuente='MATEC Web of Conferences',doi='10.1051/matecconf/201815902006',url='https://www.matec-conferences.org/10.1051/matecconf/201815902006'),
 "aplica segmentacion por K-means a imagenes termicas para separar estados normal y anormal de rodamientos, junto con vibracion.","Texto no leido; no es estudio de campo de bombas.","Termografia de rodamientos"))
L.append(snip('E-1326','otro',r(autores='Autoria no visible',anio=None,titulo='Estudio de caso de refineria sobre recirculacion interna en bomba (semarakilmu.com.my)',fuente='J. of Advanced Research in Fluid Mechanics and Thermal Sciences',url='https://semarakilmu.com.my/journals/index.php/fluid_mechanics_thermal_sciences/article/download/7468/3831/40732'),
 "caso de bomba operada por debajo del caudal minimo de diseno con dano de impulsor y eje por recirculacion interna repetida.","Texto no leido; cifras de caudal vistas en el resumen no se registran.","Recirculacion: caso de campo"))
L.append(snip('E-1327','otro',r(autores='Autoria no visible',anio=None,titulo='Vibration field problem resolved with analytical diagnostic approach and innovative impeller design',fuente='Documento tecnico alojado en 911metallurgist.com',url='https://911metallurgist.com/wp-content/uploads/2016/01/VIBRATION-Field-Problem-Resolved-With-Analytical-Diagnostic-Approach-and-Innovative-Impeller-Design.pdf'),
 "caso de campo que vincula la operacion a bajo caudal con estelas inestables que producen pulsaciones de presion y vibracion de banda ancha.","Texto no leido.","Recirculacion: pulsaciones de presion"))
L.append(snip('E-1328','otro',r(autores='Autoria no visible',anio=None,titulo='Articulo de Efficient Plant sobre monitoreo de condicion de bombas por vibracion',fuente='Efficient Plant (revista comercial)',url='https://efficientplantmag.com/?p=10260'),
 "identifica la frecuencia de paso de alabes como la frecuencia de vibracion mas comun en bombas centrifugas.","Revista comercial; pista, no evidencia.","Espectros: frecuencia de paso de alabes"))
import os
json.dump(L,open(OUT+'monitoreo_registro.json','w'),ensure_ascii=False,indent=1)
# elementos
EL=[
 dict(seccion='mediciones',titulo='Vibracion triaxial y corrientes de fase del motor adquiridas en sincronia',evidencia=['E-1301'],limite='Banco de motor de 2.2 kW sin bomba; solo respalda que existe este esquema de medicion y la afirmacion de los autores; no da umbrales para bombas.'),
 dict(seccion='mediciones',titulo='Fusion de vibracion, temperatura y ruido con sensores IoT en motores que accionan bombas',evidencia=['E-1302'],limite='Solo resumen del autor; sin cifras ni umbrales.'),
 dict(seccion='troubleshooting',titulo='Distinguir falla mecanica de electrica del motor es dificil en campo',evidencia=['E-1304'],limite='Afirmacion de contexto de los autores sobre motores; no es un procedimiento de investigacion de bombas.'),
]
json.dump(EL,open(OUT+'monitoreo_elementos.json','w'),ensure_ascii=False,indent=1)
CF=[
 dict(id='CF-01',valor='12.8',unidad='kHz',mide='Frecuencia de muestreo de vibracion, corrientes, par y fase clave en el banco de motor',condiciones='Motor de induccion de 2.2 kW en banco de laboratorio, 282 corridas de 90 s; sin bomba',evidencia=['E-1301']),
 dict(id='CF-02',valor='2.2',unidad='kW',mide='Potencia del motor del banco',condiciones='Banco de laboratorio con caja reductora y freno de polvo magnetico; sin bomba',evidencia=['E-1301']),
]
json.dump(CF,open(OUT+'monitoreo_cifras.json','w'),ensure_ascii=False,indent=1)
json.dump([],open(OUT+'monitoreo_replicas.json','w'))
TE=[
 dict(tecnica_o_sensor='Vibracion triaxial (acelerometro) y corrientes de fase del motor',que_mide='Aceleracion en el extremo de accionamiento del motor y corrientes trifasicas, en sincronia con par y fase clave',resultado_publicado='Los autores afirman que vibracion y corriente son indicadores efectivos de la salud del motor',condiciones='Motor de induccion 2.2 kW, banco de laboratorio, 12.8 kHz, velocidad y carga variables',limites='Sin bomba, sin cavitacion, sin umbrales; laboratorio con interferencia electromagnetica minima',evidencia=['E-1301','E-1305']),
 dict(tecnica_o_sensor='Fusion vibracion, temperatura y ruido (sensores IoT) con FFT, wavelet y binning',que_mide='Anomalias en motores de induccion usados en bombas, compresores y ventiladores',resultado_publicado='Sistema de deteccion de anomalias con optimizacion multiobjetivo entre tasa de deteccion, falsos positivos y velocidad de inferencia (resumen)',condiciones='Motores de induccion; datos propios con sensores de bajo costo',limites='Solo resumen; sin cifras; motor, no bomba',evidencia=['E-1302']),
 dict(tecnica_o_sensor='Microfono (acustica de maquina)',que_mide='Sonido de maquinas industriales, incluidas bombas, normal y con anomalias',resultado_publicado='Conjunto publico de sonidos con anomalias como contaminacion, fuga, desbalance rotatorio y dano de riel (resumen)',condiciones='Grabaciones en entornos de fabrica',limites='Solo resumen; no precisa anomalias por maquina ni tipo de bomba; sin cavitacion',evidencia=['E-1303']),
]
json.dump(TE,open(OUT+'monitoreo_tecnicas.json','w'),ensure_ascii=False,indent=1)

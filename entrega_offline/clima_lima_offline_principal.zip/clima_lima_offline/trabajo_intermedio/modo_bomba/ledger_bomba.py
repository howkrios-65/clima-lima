"""Une el registro heredado (fuentes leídas de rodamientos y máquinas rotativas del caso previo) con el de los frentes de la bomba."""
import json, glob, re, sys
sys.path.insert(0, '/home/user/clima-lima/tools/reliability')
from reliability_kit import Ledger
BASE = '/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_bomba/'
PREV = '/home/user/clima-lima/historial/dossiers/chumacera_polea_faja/evidencia.json'
EXCL = re.compile(r'conveyor|idler|pulley|polea|faja|belt', re.I)
L = Ledger(); omit = []; SEEN = set(); heredadas = 0
def add(e, origen):
    k = (e.get('extracto') or '').strip()
    if k and k in SEEN: omit.append((e['id'], 'extracto duplicado')); return
    try: L.add(e)
    except Exception as ex: omit.append((e['id'], str(ex)[:90])); return
    if k: SEEN.add(k)
for f in sorted(glob.glob(BASE + 'evidencia/*_registro.json')):
    for e in json.load(open(f, encoding='utf-8')): add(e, 'bomba')
n_nuevas = len(L.entradas)
for e in json.load(open(PREV, encoding='utf-8')):
    txt = ' '.join(str(e.get(k) or '') for k in ('afirma', 'extracto')) + ' ' + str((e.get('referencia') or {}).get('titulo') or '')
    if EXCL.search(txt): continue
    if e['id'] in L.entradas: omit.append((e['id'], 'id repetido')); continue
    e = json.loads(json.dumps(e)); e['limites'] = (e.get('limites') or '') + ' Fuente heredada del caso anterior (rodamientos o máquinas rotativas); se usa por analogía con los rodamientos de la bomba.'
    add(e, 'heredada'); heredadas += 1
L.to_json(BASE + 'evidencia_total.json')
print('nuevas', n_nuevas, 'heredadas', heredadas, 'total', len(L.entradas), 'omitidas', omit[:8], L.resumen()['por_nivel'])

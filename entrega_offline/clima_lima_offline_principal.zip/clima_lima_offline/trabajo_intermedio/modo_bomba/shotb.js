const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1500,height:950}});const e=[];p.on('pageerror',x=>e.push(String(x.stack||x).slice(0,300)));p.on('console',m=>m.type()==='error'&&e.push(m.text()));
await p.goto('file://'+process.cwd()+'/informe_bomba.html');
const t=await p.$$eval('#tabs button',x=>x.map(y=>y.textContent));console.log(t.join('|'));
for(const x of t){await p.click('#tabs button:has-text("'+x+'")');const subs=await p.$$eval('#main section.on .pill',z=>z.map(y=>y.textContent));console.log(x,'>',subs.join(' | '));for(const s of subs){await p.click('#main section.on .pill:has-text("'+s+'")');await p.waitForTimeout(60)}}
await p.click('#tabs button:has-text("Resumen")');await p.waitForTimeout(200);await p.screenshot({path:'b1.png'});
await p.click('#tabs button:has-text("Modos y causas")');await p.click('.pill:has-text("Ishikawa")');await p.waitForTimeout(300);await p.screenshot({path:'b2.png'});
await p.click('.pill:has-text("Árbol de fallas")');await p.waitForTimeout(300);await p.screenshot({path:'b3.png'});
console.log(JSON.stringify({e,er:await p.evaluate(()=>window.__errores||[])}));await b.close()})()

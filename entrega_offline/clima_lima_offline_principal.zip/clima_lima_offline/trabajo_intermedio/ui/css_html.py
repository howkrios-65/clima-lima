CSS = r'''
:root{--bg:#f2f7fc;--panel:#ffffff;--ink:#1e2b3a;--mut:#62758a;--line:#dbe6f1;--soft:#eaf2fa;--soft2:#f6f9fd;--acc:#4e8cc2;--acc2:#e3eef9;--ok:#4f9d75;--warn:#d99a42;--bad:#d96b72;--c1:#5b9bd5;--c2:#f2a65a;--c3:#7bbf8e;--c4:#b69bd6;--c5:#6cc3c3;--c6:#ecc96b;--shadow:0 1px 2px rgba(40,70,100,.06),0 8px 22px rgba(40,70,100,.07);--hero1:#d9eafa;--hero2:#efe6fa;--fb:"Source Sans 3",system-ui,-apple-system,"Segoe UI",sans-serif;--fh:"Manrope","Source Sans 3",system-ui,sans-serif}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#0e1824;--panel:#152233;--ink:#e5eef8;--mut:#94a9bf;--line:#243a52;--soft:#1b2c40;--soft2:#182738;--acc:#79b2e6;--acc2:#1c3350;--ok:#6cc08f;--warn:#e6b05a;--bad:#ea8a90;--c1:#79b2e6;--c2:#f4b676;--c3:#8fd0a0;--c4:#c8afe6;--c5:#86d3d3;--c6:#f0d583;--shadow:0 1px 2px rgba(0,0,0,.3),0 8px 22px rgba(0,0,0,.28);--hero1:#18314d;--hero2:#2a2440;color-scheme:dark}}
:root[data-theme="dark"]{--bg:#0e1824;--panel:#152233;--ink:#e5eef8;--mut:#94a9bf;--line:#243a52;--soft:#1b2c40;--soft2:#182738;--acc:#79b2e6;--acc2:#1c3350;--ok:#6cc08f;--warn:#e6b05a;--bad:#ea8a90;--c1:#79b2e6;--c2:#f4b676;--c3:#8fd0a0;--c4:#c8afe6;--c5:#86d3d3;--c6:#f0d583;--shadow:0 1px 2px rgba(0,0,0,.3),0 8px 22px rgba(0,0,0,.28);--hero1:#18314d;--hero2:#2a2440;color-scheme:dark}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 var(--fb)}
h1,h2,h3{font-family:var(--fh);letter-spacing:-.01em}
.ic{vertical-align:-3px;flex:none;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
#app{display:grid;grid-template-columns:232px minmax(0,1fr);min-height:100vh}
#side{position:sticky;top:0;height:100vh;background:var(--panel);border-right:1px solid var(--line);padding:14px 10px;display:flex;flex-direction:column;gap:6px;overflow:auto}
.brand{display:flex;gap:10px;align-items:center;padding:6px 8px 14px;font:700 15px var(--fh);color:var(--ink)}
.brand i{display:grid;place-items:center;width:34px;height:34px;border-radius:10px;background:linear-gradient(135deg,var(--c1),var(--c5));color:#fff}
#tabs{display:flex;flex-direction:column;gap:3px}
#tabs button{display:flex;gap:10px;align-items:center;border:0;background:none;color:var(--mut);padding:10px 12px;border-radius:10px;font:600 14px var(--fb);cursor:pointer;text-align:left}
#tabs button:hover{background:var(--soft)}
#tabs button[aria-selected=true]{background:var(--acc2);color:var(--ink)}
#tabs button[aria-selected=true] .ic{color:var(--acc)}
.side-f{margin-top:auto;font-size:12px;color:var(--mut);padding:8px}
#top{position:sticky;top:env(safe-area-inset-top,0px);z-index:8;display:flex;gap:12px;align-items:center;flex-wrap:wrap;padding:10px max(16px,env(safe-area-inset-right,0px)) 10px max(16px,env(safe-area-inset-left,0px));background:color-mix(in srgb,var(--bg) 88%,transparent);backdrop-filter:blur(8px);border-bottom:1px solid var(--line)}
#top h1{margin:0;font-size:17px;flex:1 1 260px;min-width:0}
#top h1 small{display:block;font:400 12px var(--fb);color:var(--mut)}
.search{position:relative;flex:1 1 280px;max-width:460px}
.search input{width:100%;padding:9px 12px 9px 36px;border:1px solid var(--line);border-radius:12px;background:var(--panel);color:var(--ink);font:inherit}
.search .ic{position:absolute;left:11px;top:11px;color:var(--mut)}
#sres{position:absolute;left:0;right:0;top:44px;background:var(--panel);border:1px solid var(--line);border-radius:12px;box-shadow:var(--shadow);max-height:60vh;overflow:auto;z-index:30}
#sres a{display:block;padding:9px 12px;border-bottom:1px solid var(--line);cursor:pointer;font-size:13px}
#sres a:hover{background:var(--soft)}#sres small{color:var(--mut);display:block}
#sres mark{background:var(--c6);color:#000;border-radius:3px;padding:0 1px}
.acts{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.seg{display:inline-flex;border:1px solid var(--line);border-radius:12px;overflow:hidden;background:var(--panel)}
.seg button{border:0;background:none;color:var(--mut);padding:7px 11px;font:600 13px var(--fb);cursor:pointer;display:flex;gap:6px;align-items:center}
.seg button[aria-pressed=true]{background:var(--acc2);color:var(--ink)}
.btn{border:1px solid var(--line);background:var(--panel);color:var(--ink);border-radius:12px;padding:7px 12px;font:600 13px var(--fb);cursor:pointer;display:inline-flex;gap:7px;align-items:center}
.btn:hover{background:var(--soft)}
#dmenu{position:absolute;right:0;top:44px;background:var(--panel);border:1px solid var(--line);border-radius:12px;box-shadow:var(--shadow);padding:6px;z-index:30;min-width:250px}
#dmenu button{display:flex;gap:9px;width:100%;border:0;background:none;color:var(--ink);padding:9px 10px;border-radius:8px;font:500 14px var(--fb);cursor:pointer;text-align:left}
#dmenu button:hover{background:var(--soft)}
main{padding:18px max(16px,env(safe-area-inset-right,0px)) 70px max(16px,env(safe-area-inset-left,0px));max-width:1240px}
section.tab{display:none}section.tab.on{display:block}
.card{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:16px;margin:0 0 16px;box-shadow:var(--shadow)}
.card h2{margin:0 0 10px;font-size:17px;display:flex;gap:8px;align-items:center}.card h3{margin:12px 0 6px;font-size:14px}
.hero{border-radius:20px;padding:22px;margin:0 0 16px;background:linear-gradient(120deg,var(--hero1),var(--hero2));border:1px solid var(--line)}
.hero h2{margin:0 0 4px;font-size:22px}.hero p{margin:0 0 14px;color:var(--mut);max-width:70ch}
.grid{display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(190px,1fr))}
.grid2{display:grid;gap:16px;grid-template-columns:repeat(auto-fit,minmax(340px,1fr))}
.kpi{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:12px 14px;display:flex;gap:12px;align-items:center}
.kpi .ico{display:grid;place-items:center;width:40px;height:40px;border-radius:12px;background:var(--acc2);color:var(--acc);flex:none}
.kpi b{display:block;font:700 22px var(--fh);line-height:1.1}.kpi span{color:var(--mut);font-size:12px;display:block}
.hero .kpi{background:color-mix(in srgb,var(--panel) 80%,transparent)}
.sub{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 14px}
.pill{border:1px solid var(--line);background:var(--panel);color:var(--mut);padding:7px 13px;border-radius:999px;font:600 13px var(--fb);cursor:pointer;display:inline-flex;gap:6px;align-items:center}
.pill[aria-selected=true]{background:var(--acc);border-color:var(--acc);color:#fff}
.subpane{display:none}.subpane.on{display:block}
table{border-collapse:collapse;width:100%;font-size:13px}
th,td{border-bottom:1px solid var(--line);padding:7px 9px;text-align:left;vertical-align:top}
th{color:var(--mut);font-weight:600;background:var(--soft2);position:sticky;top:0}
.tw{overflow-x:auto;border-radius:10px}
.chip{display:inline-block;font:600 11px var(--fb);padding:1px 7px;margin:1px 2px;border-radius:999px;border:1px solid color-mix(in srgb,var(--acc) 55%,transparent);color:var(--acc);background:var(--acc2);cursor:pointer}
.lv{font:600 11px var(--fb);padding:2px 8px;border-radius:999px;color:#fff;white-space:nowrap}
.lv.t{background:var(--ok)}.lv.a{background:#7fb69a}.lv.s{background:var(--warn)}.lv.n{background:var(--bad)}.lv.u{background:var(--c4)}
.badge{font:600 12px var(--fb);padding:2px 9px;border-radius:999px;border:1px solid var(--line);background:var(--soft)}
.badge.confirmada{border-color:var(--ok);color:var(--ok)}.badge.probable{border-color:var(--acc);color:var(--acc)}.badge.posible{border-color:var(--warn);color:var(--warn)}.badge.descartada{border-color:var(--bad);color:var(--bad)}
.note{border-radius:12px;background:var(--soft);padding:9px 12px;margin:8px 0;font-size:13px;border:1px solid var(--line)}
.note.bad{background:color-mix(in srgb,var(--bad) 10%,var(--panel));border-color:color-mix(in srgb,var(--bad) 40%,var(--line))}
.note.ok{background:color-mix(in srgb,var(--ok) 10%,var(--panel));border-color:color-mix(in srgb,var(--ok) 40%,var(--line))}
label{font-size:13px;color:var(--mut);display:inline-block;margin:4px 12px 4px 0}
input[type=range]{vertical-align:middle;width:150px;accent-color:var(--acc)}
input[type=number],input[type=text],select,textarea{background:var(--panel);color:var(--ink);border:1px solid var(--line);border-radius:8px;padding:5px 8px;font:inherit}
input[type=number]{width:96px}
.lt .mas{color:var(--acc);cursor:pointer;font-weight:600}
svg text{fill:var(--mut);font:11px var(--fb)}
.chart{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:12px 14px;margin:0 0 16px;box-shadow:var(--shadow)}
.ch-h{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:4px}
.ch-h b{font:700 14px var(--fh)}
.ch-f{margin-top:6px;font-size:12px;color:var(--mut);background:var(--soft2);border-left:3px solid var(--c5);padding:6px 10px;border-radius:8px}
.rd{font-size:12px;color:var(--mut);min-height:16px}
.leg{font-size:12px;color:var(--mut)}
.tl{border-left:2px solid var(--line);margin-left:6px;padding-left:14px}
.tl .ev{position:relative;margin:0 0 10px}.tl .ev:before{content:"";position:absolute;left:-21px;top:6px;width:10px;height:10px;border-radius:50%;background:var(--acc)}
.tl .ev.ot:before{background:var(--c2)}.tl .ev.medicion:before{background:var(--c3)}.tl .ev.hito:before{background:var(--bad)}.tl .ev.accion:before{background:var(--ok)}.tl .ev.analisis:before{background:var(--c4)}
.tl small{color:var(--mut)}
#drawer{position:fixed;top:0;right:0;width:min(440px,100%);height:100%;background:var(--panel);border-left:1px solid var(--line);padding:16px;overflow:auto;transform:translateX(100%);transition:transform .2s;z-index:40}
#drawer.on{transform:none;box-shadow:-8px 0 30px rgba(0,0,0,.2)}
#drawer blockquote{margin:6px 0;padding:8px 12px;border-left:3px solid var(--acc);background:var(--soft);font-size:13px;border-radius:0 8px 8px 0}
.x{float:right;border:0;background:var(--soft);color:var(--ink);font-size:18px;cursor:pointer;border-radius:8px;width:30px;height:30px}
#modal{position:fixed;inset:0;background:rgba(15,30,50,.55);z-index:50;display:none;padding:3vh 3vw}
#modal.on{display:block}
#modal .box{background:var(--panel);border-radius:18px;height:100%;overflow:auto;padding:16px}
.mat td.y{background:var(--acc);color:#fff;text-align:center}.mat td.nn{text-align:center;color:var(--mut)}
pre.code{background:var(--soft);padding:8px;border-radius:8px;overflow:auto;font-size:12px}
#toast{position:fixed;left:50%;bottom:22px;transform:translateX(-50%);background:var(--ink);color:var(--bg);padding:9px 16px;border-radius:12px;font-size:13px;z-index:60;display:none}
details>summary{cursor:pointer;font-weight:600}
.rank td:first-child{font:700 14px var(--fh);color:var(--acc);width:34px}
@media (max-width:900px){#app{grid-template-columns:1fr}#side{position:static;height:auto;flex-direction:row;align-items:center;overflow-x:auto;padding:8px;border-right:0;border-bottom:1px solid var(--line)}.brand{display:none}#tabs{flex-direction:row}#tabs button{white-space:nowrap}.side-f{display:none}}
@media (prefers-reduced-motion:reduce){*{transition:none!important}}
'''
ICONS = r'''
<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
<symbol id="i-lupa" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></symbol>
<symbol id="i-libro" viewBox="0 0 24 24"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></symbol>
<symbol id="i-matraz" viewBox="0 0 24 24"><path d="M9 3h6"/><path d="M10 3v6L4 19a2 2 0 0 0 1.7 3h12.6A2 2 0 0 0 20 19l-6-10V3"/></symbol>
<symbol id="i-herr" viewBox="0 0 24 24"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></symbol>
<symbol id="i-db" viewBox="0 0 24 24"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></symbol>
<symbol id="i-doc" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M16 13H8"/><path d="M16 17H8"/></symbol>
<symbol id="i-grafico" viewBox="0 0 24 24"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></symbol>
<symbol id="i-arbol" viewBox="0 0 24 24"><circle cx="18" cy="18" r="3"/><circle cx="6" cy="6" r="3"/><path d="M6 21V9a9 9 0 0 0 9 9"/></symbol>
<symbol id="i-ficha" viewBox="0 0 24 24"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1"/></symbol>
<symbol id="i-bajar" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></symbol>
<symbol id="i-subir" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></symbol>
<symbol id="i-guardar" viewBox="0 0 24 24"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></symbol>
<symbol id="i-sol" viewBox="0 0 24 24"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.2" y1="4.2" x2="5.6" y2="5.6"/><line x1="18.4" y1="18.4" x2="19.8" y2="19.8"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.2" y1="19.8" x2="5.6" y2="18.4"/><line x1="18.4" y1="5.6" x2="19.8" y2="4.2"/></symbol>
<symbol id="i-luna" viewBox="0 0 24 24"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></symbol>
<symbol id="i-escudo" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></symbol>
<symbol id="i-brujula" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/></symbol>
<symbol id="i-pulso" viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></symbol>
<symbol id="i-alerta" viewBox="0 0 24 24"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></symbol>
</defs></svg>
'''
BODY = r'''<body>
__ICONS__
<div id="app">
<aside id="side" aria-label="Secciones"><div class="brand"><i><svg class="ic" width="20" height="20"><use href="#i-matraz"/></svg></i><span>Ingeniería de<br>confiabilidad</span></div>
<nav id="tabs" role="tablist"></nav><div class="side-f">Todo lo que se afirma lleva su fuente. Lo que no tiene respaldo queda VACÍO.</div></aside>
<div>
<header id="top"><h1 id="ttl"></h1>
<div class="search"><svg class="ic" width="18" height="18"><use href="#i-lupa"/></svg><input id="q" type="text" placeholder="Buscar en todo el informe" autocomplete="off" aria-label="Buscador general"><div id="sres" hidden></div></div>
<div class="acts" style="position:relative"><div class="seg" role="group" aria-label="Tema"><button id="t-dia" aria-pressed="false"><svg class="ic" width="15" height="15"><use href="#i-sol"/></svg>Día</button><button id="t-noche" aria-pressed="false"><svg class="ic" width="15" height="15"><use href="#i-luna"/></svg>Noche</button></div>
<button class="btn" id="b-guardar"><svg class="ic" width="15" height="15"><use href="#i-guardar"/></svg>Guardar</button>
<button class="btn" id="b-cargar"><svg class="ic" width="15" height="15"><use href="#i-subir"/></svg>Cargar</button>
<button class="btn" id="b-desc"><svg class="ic" width="15" height="15"><use href="#i-bajar"/></svg>Descargar</button>
<div id="dmenu" hidden></div><input type="file" id="f-cargar" accept="application/json,.json" hidden></div>
</header>
<main id="main"></main>
</div></div>
<aside id="drawer" aria-label="Evidencia"></aside>
<div id="modal"><div class="box"><button class="x" id="mclose" aria-label="Cerrar">×</button><h3 id="mtit"></h3><div id="mbody"></div></div></div>
<div id="toast" role="status"></div>
<noscript>Este informe requiere JavaScript.</noscript>
<script>'''

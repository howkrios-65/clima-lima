import re, sys
sys.path.insert(0,'.')
from css_html import CSS, ICONS, BODY
from js_parts import LINE, BAR, VIEWS_JS, BOOT
P='/home/user/clima-lima/tools/reliability/reliability_kit/assets/informe_template.html'
s=open(P,encoding='utf-8').read()
def cut(a,b,new,keep_b=True):
    global s
    i=s.index(a); j=s.index(b,i)
    s=s[:i]+new+(s[j:] if keep_b else s[j+len(b):])
# 1 head y estilos
i=s.index('<style>'); j=s.index('</style>')
s=s[:i]+'<meta name="claude:viewport-fit-sides" content="cover">\n<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Manrope:wght@600;700&family=Source+Sans+3:wght@400;600;700&display=swap" rel="stylesheet">\n<style>'+CSS+s[j:]
# 2 cuerpo
i=s.index('<body>'); j=s.index('<script>',i)
s=s[:i]+BODY.replace('__ICONS__',ICONS)[:-len('<script>')]+s[j:]
# 3 lineChart
cut('/* ---------- gráfico de líneas SVG con cursor sincronizado ---------- */','/* ---------- estadística robusta',LINE+'\n')
# 4 tab con icono
s=s.replace('function tab(id,label,fn,show){if(show===false)return;VIEWS.push({id:id,label:label,fn:fn})}','function tab(id,label,fn,show,icon){if(show===false)return;VIEWS.push({id:id,label:label,fn:fn,icon:icon})}')
# 5 barChart
cut('function barChart(host,rows,o){','function listaEv(',BAR)
# 6 quitar vMapa
cut('function vMapa(host){','function vFmeca(host){','')
# 7 boot
cut('/* ---------- arranque ---------- */','</script>',VIEWS_JS+'\n'+BOOT,keep_b=True)
# 8 vVidaPred con which
s=s.replace('function vVidaPred(host){','function vVidaPred(host,which){')
s=s.replace("if(v.hallazgos){h+=","if(v.hallazgos&&which!==\"pred\"){h+=")
s=s.replace("if(p.hallazgos){h+=","if(p.hallazgos&&which!==\"vida\"){h+=")
# 9 vAcr sin tarjetas Ishikawa si hay dossier
s=s.replace("var cats=Object.keys(r.ishikawa||{});\n  h+='<div class=\"card\"><h2>Diagrama de Ishikawa (6M)</h2>","var cats=D.caso.dossier?[]:Object.keys(r.ishikawa||{});\n  if(cats.length)h+='<div class=\"card\"><h2>Diagrama de Ishikawa (6M)</h2>")
# 10 texto corto
s=s.replace("(x.nota?'<br><small>'+esc(x.nota)+'</small>':'')+'</li>'}).join(\"\")+'</ul>'}","(x.nota?'<br><small>'+lt(x.nota,110)+'</small>':'')+'</li>'}).join(\"\")+'</ul>'}")
s=s.replace("(m.nota?'<br><small>'+esc(m.nota)+'</small>':'')","(m.nota?'<br><small>'+lt(m.nota,100)+'</small>':'')")
s=s.replace("(n.nota?'<br><small>'+esc(n.nota)+'</small>':'')","(n.nota?'<br><small>'+lt(n.nota,100)+'</small>':'')")
s=s.replace("(x.nota?'<br><small>'+esc(x.nota)+'</small>':'')+'</td><td><span class=\"badge posible\">","(x.nota?'<br><small>'+lt(x.nota,100)+'</small>':'')+'</td><td><span class=\"badge posible\">")
# 11 gráficos con descripción y referencias
rep=[('titulo:"Confiabilidad",','titulo:"R(t): confiabilidad",xl:"horas de servicio",yl:"probabilidad de sobrevivir",desc:"Probabilidad de que el componente siga en servicio a cada edad, con los valores que usted eligió; se marcan B10, B50 y MTTF.",refsTxt:"relación estándar de la distribución Weibull; sin fuente en el registro (verificar en un texto de confiabilidad).",'),
 ('titulo:"Densidad de fallas",','titulo:"f(t): densidad de fallas",xl:"horas de servicio",yl:"fallas por hora",desc:"Cómo se reparten las fallas en el tiempo; el pico es la edad de falla más probable.",refsTxt:"relación estándar de Weibull; sin fuente en el registro.",'),
 ('titulo:"Probabilidad de falla",','titulo:"F(t): probabilidad de falla",xl:"horas de servicio",yl:"probabilidad acumulada",desc:"Probabilidad de haber fallado antes de cada edad. F = 1 menos R.",refsTxt:"relación estándar de Weibull; sin fuente en el registro.",'),
 ('titulo:"Tasa de falla",','titulo:"h(t): tasa de riesgo",xl:"horas de servicio",yl:"fallas por hora entre los que sobreviven",desc:"Con β mayor que 1 la tasa crece con la edad (desgaste): el reemplazo preventivo puede tener sentido.",refsTxt:"relación estándar de Weibull; sin fuente en el registro.",'),
 ('titulo:"Costo por hora",','titulo:"Costo por hora frente a la edad de reemplazo",xl:"edad de reemplazo (h)",yl:"costo por hora (unidades relativas)",desc:"El mínimo marca la edad de reemplazo con menor costo por hora; la línea naranja es correr a la falla. Costos y parámetros los elige usted.",refsTxt:"modelo clásico de reemplazo por edad; costos sin fuente.",'),
 ('titulo:"L10 frente a P/C",','titulo:"Vida nominal L10 frente a la relación de carga P/C",xl:"P/C (carga equivalente sobre capacidad dinámica)",yl:"L10 (millones de revoluciones)",desc:"A mayor carga relativa, la vida nominal cae de forma potencial (exponente 3 en bolas, 10/3 en rodillos).",refs:["E-6003"],refsTxt:"definición de L10; la fórmula no consta en el extracto: verificar en la norma.",')]
for a,b in rep:
    assert a in s,a
    s=s.replace(a,b)
# zona óptima en costo
s=s.replace('vlines:interior?[{x:T[k],label:"óptimo",c:"var(--ok)"}]:[],','vlines:interior?[{x:T[k],label:"óptimo",c:"var(--ok)"}]:[],zonas:interior?[{x0:T[k]*0.85,x1:T[k]*1.15,label:"zona óptima",c:"var(--c3)"}]:[],')
open(P,'w',encoding='utf-8').write(s)
print(len(s))

LINE = r'''/* ---------- iconos, texto corto, modal, aviso ---------- */
function ic(n,s){s=s||18;return '<svg class="ic" width="'+s+'" height="'+s+'" aria-hidden="true"><use href="#i-'+n+'"/></svg>'}
function lt(t,n){t=String(t==null?"":t);n=n||120;if(t.length<=n+20)return esc(t);var c=t.lastIndexOf(" ",n);if(c<40)c=n;return '<span class="lt">'+esc(t.slice(0,c))+'… <a class="mas" role="button" tabindex="0">ver más</a><span class="rest" hidden>'+esc(t.slice(c))+'</span></span>'}
function toast(m){var t=$("#toast");t.textContent=m;t.style.display="block";clearTimeout(toast._t);toast._t=setTimeout(function(){t.style.display="none"},2600)}
function openModal(fn,title){$("#mtit").textContent=title||"";var b=$("#mbody");b.innerHTML="";$("#modal").classList.add("on");fn(b)}
function closeModal(){$("#modal").classList.remove("on");$("#mbody").innerHTML="";Object.keys(CURSOR).forEach(function(k){if(/-big$/.test(k))delete CURSOR[k]})}
document.addEventListener("click",function(e){var t=e.target;if(t.classList&&t.classList.contains("mas")){var r=t.parentNode.querySelector(".rest");if(r){r.hidden=false;t.remove()}}});

/* ---------- gráfico de líneas SVG con cursor sincronizado ---------- */
var CURSOR={},CID=0;
function lineChart(host,o){
  var big=!!o.big,W=big?1300:840,H=big?(o.h?o.h*2.2:620):(o.h||270),m={l:62,r:20,t:22,b:o.xl?50:38},xs=o.x.map(Number),ys=o.series,id=++CID;
  var x0=Math.min.apply(0,xs),x1=Math.max.apply(0,xs),all=[];
  ys.forEach(function(s){s.y.forEach(function(v){if(isFinite(v))all.push(v)})});(o.hlines||[]).forEach(function(h){all.push(h.y)});
  var y0=Math.min.apply(0,all),y1=Math.max.apply(0,all);if(o.y0!=null)y0=Math.min(y0,o.y0);if(y0===y1){y0-=1;y1+=1}var pad=(y1-y0)*.07;y1+=pad;if(o.y0==null)y0-=pad;
  function X(v){return m.l+(v-x0)/((x1-x0)||1)*(W-m.l-m.r)}function Y(v){return H-m.b-(v-y0)/(y1-y0)*(H-m.t-m.b)}
  var cols=["var(--c1)","var(--c2)","var(--c3)","var(--c4)"],g='<defs><linearGradient id="gr'+id+'" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="'+cols[0]+'" stop-opacity=".30"/><stop offset="1" stop-color="'+cols[0]+'" stop-opacity="0"/></linearGradient></defs>';
  (o.zonas||[]).forEach(function(z){var a=X(Math.max(z.x0,x0)),b=X(Math.min(z.x1,x1));g+='<rect x="'+a+'" y="'+m.t+'" width="'+Math.max(b-a,1)+'" height="'+(H-m.t-m.b)+'" fill="'+(z.c||"var(--c3)")+'" opacity=".16"/><text x="'+(a+6)+'" y="'+(m.t+13)+'">'+esc(z.label||"")+'</text>'});
  for(var i=0;i<=5;i++){var yv=y0+(y1-y0)*i/5;g+='<line x1="'+m.l+'" x2="'+(W-m.r)+'" y1="'+Y(yv)+'" y2="'+Y(yv)+'" stroke="var(--line)" stroke-dasharray="3 4"/><text x="'+(m.l-8)+'" y="'+(Y(yv)+4)+'" text-anchor="end">'+fmt(yv,2)+'</text>'}
  for(i=0;i<=5;i++){var xv=x0+(x1-x0)*i/5;g+='<text x="'+X(xv)+'" y="'+(H-m.b+18)+'" text-anchor="'+(i===5?'end':i===0?'start':'middle')+'">'+esc(o.xfmt?o.xfmt(xv):fmt(xv,1))+'</text>'}
  if(o.xl)g+='<text x="'+((m.l+W-m.r)/2)+'" y="'+(H-6)+'" text-anchor="middle" style="font-weight:600">'+esc(o.xl)+'</text>';
  if(o.yl)g+='<text transform="translate(14 '+((m.t+H-m.b)/2)+') rotate(-90)" text-anchor="middle" style="font-weight:600">'+esc(o.yl)+'</text>';
  function d_(s){var d="",on=false;s.y.forEach(function(v,j){if(!isFinite(v)){on=false;return}d+=(on?"L":"M")+X(xs[j]).toFixed(1)+" "+Y(v).toFixed(1);on=true});return d}
  var s0=ys[0];if(s0&&!o.noarea){var d0=d_(s0);g+='<path d="'+d0+' L'+X(xs[xs.length-1]).toFixed(1)+' '+Y(y0)+' L'+X(xs[0]).toFixed(1)+' '+Y(y0)+' Z" fill="url(#gr'+id+')"/>'}
  ys.forEach(function(s,k){g+='<path d="'+d_(s)+'" fill="none" stroke="'+cols[k%4]+'" stroke-width="'+(big?3:2.4)+'" stroke-linejoin="round" stroke-linecap="round"/>'});
  (o.vlines||[]).forEach(function(v,i){var vx=X(v.x),ty=m.t+14+(i%3)*17,lab=esc(v.label||""),w=lab.length*6.4+12,right=vx>W-120,rx=right?vx-w-4:vx+4;
    g+='<line x1="'+vx+'" x2="'+vx+'" y1="'+m.t+'" y2="'+(H-m.b)+'" stroke="'+(v.c||"var(--bad)")+'" stroke-dasharray="5 4" stroke-width="1.6"/><rect x="'+rx+'" y="'+(ty-12)+'" width="'+w+'" height="17" rx="8" fill="'+(v.c||"var(--bad)")+'" opacity=".92"/><text x="'+(rx+w/2)+'" y="'+(ty)+'" text-anchor="middle" style="fill:#fff;font-weight:700">'+lab+'</text>'});
  (o.hlines||[]).forEach(function(h){g+='<line x1="'+m.l+'" x2="'+(W-m.r)+'" y1="'+Y(h.y)+'" y2="'+Y(h.y)+'" stroke="'+(h.c||"var(--warn)")+'" stroke-dasharray="6 4" stroke-width="1.6"/><text x="'+(W-m.r-4)+'" y="'+(Y(h.y)-5)+'" text-anchor="end" style="font-weight:600">'+esc(h.label||"")+'</text>'});
  (o.marks||[]).forEach(function(p){g+='<circle cx="'+X(p.x)+'" cy="'+Y(p.y)+'" r="6" fill="var(--bad)" stroke="var(--panel)" stroke-width="2"><title>'+esc(p.label||"")+'</title></circle>'});
  var leg=ys.length>1?ys.map(function(s,k){return '<span style="color:'+cols[k%4]+'">&#9632;</span> '+esc(s.name||"")}).join("  &nbsp; "):"";
  host.className=(host.className||"").replace(/\bchart\b/,"")+(o.noframe||big?"":" chart");
  host.innerHTML=(o.titulo&&!big?'<div class="ch-h"><b>'+esc(o.titulo)+'</b>'+(o.noexpand?'':'<button class="btn amp" aria-label="Ampliar gráfico">'+ic("lupa",14)+' ampliar</button>')+'</div>':'')+(leg?'<div class="leg">'+leg+'</div>':'')+
    '<svg viewBox="0 0 '+W+' '+H+'" width="100%" role="img" aria-label="'+esc(o.titulo||"gráfico")+'">'+g+'<line class="cur" x1="0" x2="0" y1="'+m.t+'" y2="'+(H-m.b)+'" stroke="var(--ink)" opacity="0"/></svg><div class="rd"></div>'+
    ((o.desc||o.refs||o.refsTxt)&&!big?'<div class="ch-f">'+(o.desc?'<b>Descripción:</b> '+esc(o.desc):'')+((o.refs||o.refsTxt)?' <b>Refs.:</b> '+(o.refs?chips(o.refs):'')+(o.refsTxt?' '+esc(o.refsTxt):''):'')+'</div>':'');
  var svg=$("svg[role=img]",host),cur=$(".cur",svg),rd=$(".rd",host);
  function show(xv){
    if(xv==null){cur.setAttribute("opacity",0);rd.textContent="";return}
    var j=0,b=1e99;xs.forEach(function(v,k){var dd=Math.abs(v-xv);if(dd<b){b=dd;j=k}});
    cur.setAttribute("x1",X(xs[j]));cur.setAttribute("x2",X(xs[j]));cur.setAttribute("opacity",.5);
    rd.textContent=(o.xfmt?o.xfmt(xs[j]):fmt(xs[j],1))+" · "+ys.map(function(s){return (s.name||"")+" = "+fmt(s.y[j],3)}).join(" · ");
  }
  svg.addEventListener("mousemove",function(e){var r=svg.getBoundingClientRect(),px=(e.clientX-r.left)/r.width*W,xv=x0+(px-m.l)/(W-m.l-m.r)*(x1-x0);Object.keys(CURSOR).forEach(function(k){CURSOR[k](xv)})});
  svg.addEventListener("mouseleave",function(){Object.keys(CURSOR).forEach(function(k){CURSOR[k](null)})});
  CURSOR[(o.key||host.id||"c"+id)+(big?"-big":"")]=show;
  var amp=$(".amp",host);if(amp)amp.onclick=function(){openModal(function(el){lineChart(el,Object.assign({},o,{big:true}))},o.titulo)};
}
function dnum(s){var t=Date.parse(s);return isNaN(t)?NaN:t/864e5}
function dfmt(n){return new Date(n*864e5).toISOString().slice(0,10)}
'''
BAR = r'''function barChart(host,rows,o){ /* rows=[{label,value,color}] */
  o=o||{};var W=840,rh=28,H=rows.length*rh+10,mx=o.max||Math.max.apply(0,rows.map(function(r){return r.value}))||1,x0=300,g='';
  rows.forEach(function(r,i){var y=i*rh+5,w=(W-x0-70)*r.value/mx,lab=String(r.label);
    g+='<text x="'+(x0-10)+'" y="'+(y+15)+'" text-anchor="end" style="fill:var(--ink)">'+esc(lab.length>46?lab.slice(0,45)+"…":lab)+'<title>'+esc(lab)+'</title></text><rect x="'+x0+'" y="'+y+'" width="'+Math.max(w,2)+'" height="20" rx="6" fill="'+(r.color||"var(--c1)")+'" opacity=".88"><title>'+esc(lab)+': '+fmt(r.value,2)+'</title></rect><text x="'+(x0+Math.max(w,2)+7)+'" y="'+(y+15)+'" style="fill:var(--ink);font-weight:700">'+fmt(r.value,0)+'</text>'});
  host.className=(host.className||"")+(o.noframe?"":" chart");
  host.innerHTML=(o.titulo&&!o.noframe?'<div class="ch-h"><b>'+esc(o.titulo)+'</b></div>':'')+'<svg viewBox="0 0 '+W+' '+H+'" width="100%" role="img" aria-label="'+esc(o.titulo||"barras")+'">'+g+'</svg>'+
    ((o.desc||o.refs||o.refsTxt)?'<div class="ch-f">'+(o.desc?'<b>Descripción:</b> '+esc(o.desc):'')+((o.refs||o.refsTxt)?' <b>Refs.:</b> '+(o.refs?chips(o.refs):'')+(o.refsTxt?' '+esc(o.refsTxt):''):'')+'</div>':'');
}
'''
VIEWS_JS = r'''
/* ---------- piezas reutilizables ---------- */
function cadena(host){
  var c=D.caso,an=c.analisis||{},dz=c.dossier;
  function nEl(k){return dz&&dz.secciones[k]?(dz.secciones[k].elementos||[]).length:0}
  var pasos=[["Referencias",nEl("fenomenos")+nEl("mediciones")>0?"ok":"vac",nEl("fenomenos")+nEl("mediciones")+" con cita"],
   ["Top de fallas",nEl("top_fallas")?"par":"vac",nEl("top_fallas")?"cita de segunda mano":"VACÍO"],
   ["FMECA",an.fmeca?"par":"vac",an.fmeca?(an.fmeca.items.length+" modos; S-O-D sin puntuar"):"VACÍO"],
   ["Árbol de fallas",an.arbol?"par":"vac",an.arbol?(an.arbol.nodos.length+" nodos; compuertas del equipo"):"VACÍO"],
   ["Troubleshooting",nEl("troubleshooting")?"par":"vac",nEl("troubleshooting")?"técnicas sin alarmas":"VACÍO"],
   ["Mant. predictivo (P-F)","vac","intervalo P-F: VACÍO"],
   ["Escenarios",c.simulador?"par":"vac","simulador didáctico"]];
  var col={ok:"var(--ok)",par:"var(--warn)",vac:"var(--bad)"},sv='';
  pasos.forEach(function(p,i){var x=i*158+4;sv+='<rect x="'+x+'" y="6" width="142" height="66" rx="14" fill="var(--panel)" stroke="'+col[p[1]]+'" stroke-width="2.5"/><circle cx="'+(x+16)+'" cy="22" r="5" fill="'+col[p[1]]+'"/><text x="'+(x+28)+'" y="26" style="fill:var(--ink);font-weight:700;font-size:12px">'+esc(p[0])+'</text>'+wrapTxt(p[2],25).slice(0,2).map(function(l,j){return '<text x="'+(x+12)+'" y="'+(46+j*13)+'">'+esc(l)+'</text>'}).join("")+(i<pasos.length-1?'<text x="'+(x+146)+'" y="42" style="fill:var(--mut);font-size:15px">›</text>':'')});
  host.innerHTML='<div class="tw"><svg viewBox="0 0 1110 80" width="100%" style="min-width:860px">'+sv+'</svg></div><div class="leg"><span style="color:var(--ok)">&#9632;</span> con respaldo · <span style="color:var(--warn)">&#9632;</span> parcial · <span style="color:var(--bad)">&#9632;</span> VACÍO</div>';
}
function perfil(host){
  host.innerHTML='<div class="grid2"><div id="pf-n"></div><div id="pf-a"></div></div>';
  var n={},y={};D.evidencia.forEach(function(e){n[e.nivel_evidencia]=(n[e.nivel_evidencia]||0)+1;var a=e.referencia&&e.referencia.anio;if(a&&(e.nivel_evidencia==="VERIFICADO-TEXTO"||e.nivel_evidencia==="VERIFICADO-ABSTRACT"))y[a]=(y[a]||0)+1});
  var cl={"VERIFICADO-TEXTO":"var(--ok)","VERIFICADO-ABSTRACT":"var(--c3)","SOLO-SNIPPET":"var(--warn)","NO-VERIFICADO":"var(--bad)","DATO-USUARIO":"var(--c4)"};
  barChart($("#pf-n",host),Object.keys(n).map(function(k){return{label:k,value:n[k],color:cl[k]}}),{titulo:"Entradas por nivel de lectura",desc:"Las pistas SOLO-SNIPPET y NO-VERIFICADO no respaldan ninguna afirmación."});
  barChart($("#pf-a",host),Object.keys(y).sort().map(function(k){return{label:k,value:y[k],color:"var(--c1)"}}),{titulo:"Fuentes leídas por año",desc:"Cuenta entradas del registro; un mismo documento puede tener varias."});
}
function docPorModo(host){
  var an=D.caso.analisis||{};if(!an.fmeca){host.innerHTML="";return}
  barChart(host,an.fmeca.items.map(function(m){var d={};m.evidencia.forEach(function(i){var e=EV[i];if(e&&(e.nivel_evidencia==="VERIFICADO-TEXTO"||e.nivel_evidencia==="VERIFICADO-ABSTRACT"))d[(e.referencia&&e.referencia.titulo)||i]=1});return{label:m.id+" "+m.modo,value:Object.keys(d).length,color:"var(--c5)"}}),
   {titulo:"Respaldo documental por modo de falla",desc:"Documentos distintos leídos que respaldan cada modo. NO es prevalencia: mide cuánta evidencia hay, no con qué frecuencia ocurre; el ranking de frecuencias es VACÍO."});
}
function matrizEnsayos(host){
  var an=D.caso.analisis||{};if(!(an.acr&&an.acr.ensayos&&an.acr.hipotesis)){host.innerHTML="";return}
  var hs=an.acr.hipotesis.map(function(x){return x.id});
  host.innerHTML='<div class="card"><h2>'+ic("matraz")+' Qué técnica ayuda a cada hipótesis</h2><div class="tw"><table><tr><th>Técnica</th>'+hs.map(function(x){return '<th>'+esc(x)+'</th>'}).join("")+'</tr>'+an.acr.ensayos.map(function(e){return '<tr><td>'+lt(e.ensayo,80)+' '+chips(e.evidencia)+'</td>'+hs.map(function(x){return (e.para_hipotesis||[]).indexOf(x)>=0?'<td style="background:var(--acc);text-align:center;color:#fff">●</td>':'<td></td>'}).join("")+'</tr>'}).join("")+'</table></div><p class="leg">Columnas sin punto: la evidencia leída no menciona técnica para esa hipótesis (VACÍO).</p></div>';
}
function degr(host){
  var W2=840,st='';
  st+='<line x1="48" y1="190" x2="820" y2="190" stroke="var(--mut)"/><line x1="48" y1="14" x2="48" y2="190" stroke="var(--mut)"/>';
  [["1 ultrasónico",48],["2 resonancia natural",240],["3 defecto y armónicos",432],["4 ruido aleatorio",624]].forEach(function(e,i){st+='<rect x="'+e[1]+'" y="190" width="188" height="28" fill="'+["var(--c1)","var(--c5)","var(--c3)","var(--c6)"][i]+'" opacity=".35"/><text x="'+(e[1]+94)+'" y="209" text-anchor="middle" style="fill:var(--ink);font-weight:600">'+esc(e[0])+'</text>'});
  st+='<path d="M48 165 C140 163 190 70 330 44 C460 30 540 130 820 165" fill="none" stroke="var(--c2)" stroke-width="3"/><text x="330" y="34" text-anchor="middle" style="fill:var(--c2);font-weight:700">kurtosis: sube con el defecto incipiente y vuelve a lo normal al extenderse</text>';
  st+='<path d="M48 178 C280 176 430 158 620 112" fill="none" stroke="var(--c1)" stroke-width="3"/><text x="430" y="150" style="fill:var(--c1);font-weight:700">energía en frecuencias de defecto: crece hasta la etapa 3</text><text x="725" y="110" text-anchor="middle">etapa 4: sin tendencia respaldada</text>';
  st+='<text x="434" y="242" text-anchor="middle" style="fill:var(--bad);font-weight:700">ESQUEMA ILUSTRATIVO: sin escala ni datos · horizontal: tiempo (sin escala) · vertical: magnitud relativa</text>';
  host.innerHTML='<div class="chart"><div class="ch-h"><b>Degradación del rodamiento en cuatro etapas</b></div><svg viewBox="0 0 '+W2+' 256" width="100%" role="img" aria-label="Esquema cualitativo">'+st+'</svg><div class="ch-f"><b>Descripción:</b> esquema cualitativo; las curvas son ilustrativas y no hay duraciones. <b>Refs.:</b> '+chips(["E-8008","E-8003"])+'</div></div>';
}
function rankingFuentes(host,limit){
  var LVN={"VERIFICADO-TEXTO":3,"VERIFICADO-ABSTRACT":2,"SOLO-SNIPPET":1,"NO-VERIFICADO":0,"DATO-USUARIO":3};
  var rows=D.evidencia.map(function(e){var r=e.referencia||{};return{e:e,l:LVN[e.nivel_evidencia]||0,a:r.anio||0,q:e.revista_cuartil&&e.revista_cuartil.valor}}).sort(function(a,b){return b.l-a.l||b.a-a.a});
  var nq=rows.filter(function(r){return r.q}).length;
  host.innerHTML='<div class="card"><h2>'+ic("libro")+' Ranking de fuentes</h2><div class="note">Orden: nivel de lectura (texto, resumen, pista) y luego año más reciente. <b>Las citas y el cuartil Q1 o Q2 no se pudieron verificar</b> (Scopus y SCImago están bloqueados en este entorno), por eso hoy hay '+nq+' fuentes con cuartil verificado. Los filtros se activan solos cuando una fuente trae su cuartil con su fuente.</div>'+
    '<label>Nivel <select id="rk-n"><option value="leidas">solo leídas (texto o resumen)</option><option value="todas">todas, con pistas</option></select></label><label>Cuartil <select id="rk-q"><option value="">todos</option><option value="12">Q1 o Q2 verificado</option><option value="0">sin verificar</option></select></label><label>Buscar <input type="text" id="rk-t" style="width:150px"></label><div class="tw"><table class="rank" id="rk-tb"></table></div></div>';
  function draw(){
    var n=$("#rk-n",host).value,q=$("#rk-q",host).value,t=($("#rk-t",host).value||"").toLowerCase(),k=0;
    var f=rows.filter(function(r){return(n==="todas"||r.l>=2)&&(q===""||(q==="12"?(r.q===1||r.q===2):!r.q))&&((r.e.apa+" "+r.e.afirma).toLowerCase().indexOf(t)>=0)});
    if(limit)f=f.slice(0,limit);
    $("#rk-tb",host).innerHTML='<tr><th>#</th><th>Fuente</th><th>Qué respalda</th><th>Nivel</th><th>Cuartil</th><th></th></tr>'+f.map(function(r){k++;var e=r.e,ref=e.referencia||{};
      return '<tr><td>'+k+'</td><td>'+esc((ref.autores||"").split(",")[0]||"s. a.")+' ('+esc(ref.anio||"s. f.")+')<br><small>'+esc((ref.titulo||"").slice(0,70))+'</small></td><td>'+lt(e.afirma,90)+'</td><td>'+lv(e.nivel_evidencia)+'</td><td>'+(r.q?'Q'+r.q:'<small>sin verificar</small>')+'</td><td><button class="chip" data-ev="'+esc(e.id)+'">'+esc(e.id)+'</button></td></tr>'}).join("");
  }
  host.addEventListener("input",draw);host.addEventListener("change",draw);draw();
}

/* ---------- vistas del modo "modo de falla" ---------- */
var SUBSEL={};
function subtabs(host,key,items){
  host.innerHTML='<div class="sub" role="tablist">'+items.map(function(it){return '<button class="pill" data-sub="'+it.id+'" role="tab">'+(it.icon?ic(it.icon,15):'')+esc(it.label)+'</button>'}).join("")+'</div><div class="subpanes"></div>';
  var panes=$(".subpanes",host);items.forEach(function(it){var p=document.createElement("div");p.className="subpane";p.dataset.sub=it.id;panes.appendChild(p)});
  function sel(id){host.querySelectorAll(".pill").forEach(function(b){b.setAttribute("aria-selected",b.dataset.sub===id)});
    host.querySelectorAll(".subpane").forEach(function(p){var on=p.dataset.sub===id;p.classList.toggle("on",on);if(on&&!p.dataset.done){p.dataset.done=1;items.forEach(function(it){if(it.id===id){try{it.fn(p)}catch(e){p.innerHTML='<div class="note bad">Error al dibujar: '+esc(e.message)+'</div>';window.__errores=(window.__errores||[]).concat(String(e))}}})}})}
  host.addEventListener("click",function(e){var b=e.target.closest&&e.target.closest(".pill");if(b&&host.contains(b))sel(b.dataset.sub)});
  SUBSEL[key]=sel;sel(items[0].id);
}
function esencial(){return (D.caso.resumen.hallazgos||[]).filter(function(h){return h.texto.indexOf("[Referencias]")!==0}).slice(0,6)}
function vResumenN(host){
  var c=D.caso,an=c.analisis||{},leidas=D.evidencia.filter(function(e){return e.nivel_evidencia==="VERIFICADO-TEXTO"||e.nivel_evidencia==="VERIFICADO-ABSTRACT"}).length,dz=c.dossier,con=0,vac=0;
  dz.orden.forEach(function(k){if(k==="referencias")return;((dz.secciones[k]||{}).elementos||[]).length?con++:vac++});
  host.innerHTML='<div class="hero"><h2>'+esc(c.meta.titulo)+'</h2><p>Qué se sabe, con qué respaldo y qué falta. Cada afirmación lleva su fuente; lo que no tiene evidencia leída queda VACÍO.</p><div class="grid">'+
   '<div class="kpi"><span class="ico">'+ic("libro",22)+'</span><div><b>'+leidas+'</b><span>fuentes leídas (de '+D.evidencia.length+' registradas)</span></div></div>'+
   '<div class="kpi"><span class="ico">'+ic("escudo",22)+'</span><div><b>'+con+' de '+(con+vac)+'</b><span>secciones con evidencia</span></div></div>'+
   '<div class="kpi"><span class="ico">'+ic("alerta",22)+'</span><div><b>'+vac+'</b><span>secciones VACÍO declarado</span></div></div>'+
   '<div class="kpi"><span class="ico">'+ic("arbol",22)+'</span><div><b>'+((an.fmeca&&an.fmeca.items||[]).length)+'</b><span>modos de falla en el FMECA</span></div></div></div></div>'+
   '<div class="card"><h2>'+ic("brujula")+' Cadena RCM</h2><div id="rs-cad"></div></div>'+
   '<div class="grid2"><div class="card"><h2>'+ic("doc")+' Lo esencial</h2><ul id="rs-es" style="padding-left:18px;margin:0"></ul></div><div class="card"><h2>'+ic("libro")+' Fuentes mejor respaldadas</h2><div id="rs-rk"></div><p><button class="btn" data-go="evi" data-sub="ran">Ver ranking completo</button></p></div></div>';
  cadena($("#rs-cad",host));
  $("#rs-es",host).innerHTML=esencial().map(function(h){var t=h.texto.replace(/\. Límite:.*$/,"");return '<li style="margin:0 0 8px">'+lt(t,150)+' '+chips(h.evidencia)+'</li>'}).join("");
  var tmp=document.createElement("div");rankingFuentes(tmp,5);var t=tmp.querySelector("#rk-tb");$("#rs-rk",host).innerHTML='<div class="tw"><table class="rank">'+t.innerHTML+'</table></div>'
}
function vModos(host){
  var an=D.caso.analisis||{};
  var it=[];
  if(an.arbol)it.push({id:"arb",label:"Árbol de fallas",icon:"arbol",fn:function(p){p.innerHTML='<div class="card"><h2>'+ic("arbol")+' '+esc(an.arbol.evento_tope||"Árbol de fallas")+'</h2><div id="ma-d"></div><details style="margin-top:10px"><summary>Calculadora de probabilidades del evento tope</summary><div id="ma-c"></div></details></div>';svgArbol($("#ma-d",p),an.arbol);vArbol($("#ma-c",p))}});
  if(an.acr&&an.acr.ishikawa)it.push({id:"ish",label:"Ishikawa",icon:"grafico",fn:function(p){p.innerHTML='<div class="card"><h2>'+ic("grafico")+' Diagrama de Ishikawa (6M)</h2><div id="mi-d"></div></div>';svgIshikawa($("#mi-d",p),an.acr.ishikawa)}});
  if(an.fmeca)it.push({id:"fme",label:"FMECA",icon:"ficha",fn:function(p){vFmeca(p);var d=document.createElement("div");p.appendChild(d);docPorModo(d)}});
  if(an.acr)it.push({id:"hip",label:"Hipótesis y técnicas",icon:"matraz",fn:function(p){vAcr(p);var d=document.createElement("div");p.appendChild(d);matrizEnsayos(d)}});
  subtabs(host,"mod",it);
}
function vVidaCostos(host){
  var an=D.caso.analisis||{},it=[];
  if(D.caso.simulador)it.push({id:"cur",label:"Curvas de vida",icon:"pulso",fn:vSim});
  if(an.herramientas)it.push({id:"her",label:"L10 y frecuencias",icon:"herr",fn:vHerr});
  if(an.lcc)it.push({id:"cos",label:"Costos",icon:"grafico",fn:vLcc});
  if(an.vida)it.push({id:"met",label:"Método de vida",icon:"libro",fn:function(p){vVidaPred(p,"vida")}});
  subtabs(host,"vyc",it);
}
function vMonitoreo(host){
  var an=D.caso.analisis||{},it=[{id:"deg",label:"Degradación",icon:"pulso",fn:degr}];
  if(an.predictivo)it.push({id:"est",label:"Estrategia y riesgos",icon:"ficha",fn:function(p){vVidaPred(p,"pred")}});
  it.push({id:"mod",label:"Qué modelo usar",icon:"db",fn:vPredictivo});
  subtabs(host,"mon",it);
}
function vEvidenciaN(host){
  subtabs(host,"evi",[{id:"ran",label:"Ranking",icon:"libro",fn:function(p){rankingFuentes(p)}},{id:"cob",label:"Cobertura por sección",icon:"escudo",fn:vDossier},
   {id:"per",label:"Perfil",icon:"grafico",fn:function(p){perfil(p)}},{id:"reg",label:"Registro completo",icon:"db",fn:vEvidencia}]);
}
function vPlanN(host){
  var it=[{id:"vac",label:"Vacíos y preguntas",icon:"alerta",fn:vRastro}];
  if((D.caso.plan||[]).length)it.push({id:"pla",label:"Plan de acción",icon:"ficha",fn:vPlan});
  it.push({id:"his",label:"Historial",icon:"doc",fn:vHistorial});
  subtabs(host,"pla",it);
}

/* ---------- descargas, guardado y buscador ---------- */
function guardarArchivo(nombre,data){
  var ok=function(){toast("Listo: "+nombre)},fb=function(){try{var b=new Blob([data],{type:"application/octet-stream"}),u=URL.createObjectURL(b),a=document.createElement("a");a.href=u;a.download=nombre;document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(u);a.remove()},600);ok()}catch(e){toast("No se pudo guardar")}};
  try{if(window.claude&&window.claude.use){window.claude.use("downloads").then(function(d){if(!d){fb();return}d.save({filename:nombre,data:data}).then(ok,function(e){if(!e||e.code!=="declined")toast("No se pudo guardar ("+((e&&e.code)||"error")+")")})},fb);return}}catch(e){}
  fb();
}
function csv(rows){return rows.map(function(r){return r.map(function(x){x=String(x==null?"":x);return /[",\n]/.test(x)?'"'+x.replace(/"/g,'""')+'"':x}).join(",")}).join("\n")}
function sesion(){var o={};try{for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);if(k.indexOf("inf:")===0)o[k]=localStorage.getItem(k)}}catch(e){}return{tipo:"sesion-informe",titulo:D.caso.meta.titulo,fecha:new Date().toISOString().slice(0,10),datos:o}}
function nombreBase(){return (D.caso.meta.titulo||"informe").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"").slice(0,50)}
var DESCARGAS=[
 ["doc","Informe completo (HTML)",function(){var c=document.documentElement.cloneNode(true);["#tabs","#main","#drawer","#mbody","#sres","#dmenu"].forEach(function(s){var e=c.querySelector(s);if(e)e.innerHTML=""});return["informe-"+nombreBase()+".html","<!doctype html>\n"+c.outerHTML]}],
 ["db","Datos del informe (JSON)",function(){return["datos-"+nombreBase()+".json",JSON.stringify({caso:D.caso,ajustes:D.ajustes,generado:D.generado},null,1)]}],
 ["libro","Registro de evidencia (CSV)",function(){return["evidencia-"+nombreBase()+".csv",csv([["id","nivel","tipo","autores","anio","titulo","fuente","doi","acceso","afirma","limites","cuartil"]].concat(D.evidencia.map(function(e){var r=e.referencia||{};return[e.id,e.nivel_evidencia,e.tipo,r.autores,r.anio,r.titulo,r.fuente,r.doi,e.acceso,e.afirma,e.limites,(e.revista_cuartil&&e.revista_cuartil.valor)?"Q"+e.revista_cuartil.valor:"sin verificar"]})))]}],
 ["doc","Referencias en APA 7 (TXT)",function(){return["referencias-"+nombreBase()+".txt",D.evidencia.filter(function(e){return e.nivel_evidencia==="VERIFICADO-TEXTO"||e.nivel_evidencia==="VERIFICADO-ABSTRACT"}).map(function(e){return e.apa}).sort().join("\n\n")]}],
 ["guardar","Mi sesión: puntajes y valores (JSON)",function(){return["sesion-"+nombreBase()+".json",JSON.stringify(sesion(),null,1)]}]
];
function buildIndex(){
  var I=[],c=D.caso,an=c.analisis||{},dz=c.dossier;
  function add(t,txt,tab,sub,ev){I.push({t:t,x:txt,tab:tab,sub:sub,ev:ev})}
  D.evidencia.forEach(function(e){add("Fuente",e.apa+" "+e.afirma,dz?"evi":"evi",dz?"ran":null,e.id)});
  (c.resumen.hallazgos||[]).forEach(function(h){add("Hallazgo",h.texto,"res")});
  if(an.fmeca)an.fmeca.items.forEach(function(m){add("FMECA",m.id+" "+m.modo+" "+(m.mecanismo||"")+" "+(m.causa||""),"mod","fme")});
  if(an.arbol)an.arbol.nodos.forEach(function(n){add("Árbol",n.texto,"mod","arb")});
  if(an.acr){(an.acr.hipotesis||[]).forEach(function(h){add("Hipótesis",h.id+" "+h.texto,"mod","hip")});Object.keys(an.acr.ishikawa||{}).forEach(function(k){an.acr.ishikawa[k].forEach(function(x){add("Ishikawa "+k,x.texto,"mod","ish")})})}
  if(an.lcc)(an.lcc.elementos||[]).forEach(function(e){add("Costo",e.nombre+" "+(e.como_se_calcula||""),"vyc","cos")});
  if(an.vida)(an.vida.hallazgos||[]).forEach(function(h){add("Vida",h.texto,"vyc","met")});
  if(an.predictivo){(an.predictivo.hallazgos||[]).forEach(function(h){add("Predictivo",h.texto,"mon","est")});(an.predictivo.estrategia||[]).forEach(function(h){add("Estrategia",h.etapa+" "+h.accion,"mon","est")})}
  if(dz)dz.orden.forEach(function(k){var s=dz.secciones[k]||{};(s.elementos||[]).forEach(function(e){add(dz.titulos[k],e.titulo,"evi","cob")});if(s.vacio)add("VACÍO "+dz.titulos[k],s.vacio,"pla","vac")});
  (c.vacios||[]).forEach(function(v){add("Vacío",v,dz?"pla":"ras",dz?"vac":null)});
  return I;
}
'''
BOOT = r'''/* ---------- arranque ---------- */
function boot(){
  if(!D){document.body.innerHTML="<p style='padding:20px'>El informe no tiene datos incrustados.</p>";return}
  D.evidencia.forEach(function(e){EV[e.id]=e});
  var m=D.caso.meta;$("#ttl").innerHTML=esc(m.titulo)+'<small>'+esc([m.activo,m.origen_datos&&("datos: "+m.origen_datos)].filter(Boolean).join(" · "))+'</small>';
  var c=D.caso,an=c.analisis||{};
  if(c.dossier){
    tab("res","Resumen",vResumenN,true,"brujula");tab("mod","Modos y causas",vModos,true,"arbol");tab("vyc","Vida y costos",vVidaCostos,true,"pulso");
    tab("mon","Monitoreo y ML",vMonitoreo,true,"grafico");tab("evi","Evidencia",vEvidenciaN,true,"libro");tab("pla","Vacíos y plan",vPlanN,true,"ficha");
  }else{
    tab("res","Resumen",vResumen,true,"brujula");tab("tl","Línea de tiempo",vTiempo,(c.linea_tiempo||[]).length>0,"doc");tab("sen","Señales",vSenales,(c.series||[]).length>0,"pulso");
    tab("cau","Causas y técnicas",vCausas,true,"arbol");tab("dat","Datos",vDatos,(c.tablas||[]).length>0,"db");tab("evi","Evidencia",vEvidencia,true,"libro");tab("vid","Vida",vVida,true,"pulso");
    tab("pre","Predictivo",vPredictivo,true,"grafico");tab("pla","Plan",vPlan,(c.plan||[]).length>0,"ficha");tab("his","Historial",vHistorial,true,"doc");tab("ras","Vacíos y rastro",vRastro,true,"alerta");
  }
  var tb=$("#tabs"),mn=$("#main");
  VIEWS.forEach(function(v){
    var b=document.createElement("button");b.innerHTML=ic(v.icon||"doc",18)+'<span>'+esc(v.label)+'</span>';b.setAttribute("role","tab");b.dataset.id=v.id;tb.appendChild(b);
    var s=document.createElement("section");s.className="tab";s.id="v-"+v.id;mn.appendChild(s);b.onclick=function(){sel(v.id)};
  });
  var cur="res";
  function sel(id,sub){cur=id;
    VIEWS.forEach(function(v){var s=$("#v-"+v.id),b=$('[data-id='+v.id+']',tb),on=v.id===id;s.classList.toggle("on",on);b.setAttribute("aria-selected",on);
      if(on&&!s.dataset.done){s.dataset.done=1;try{v.fn(s)}catch(e){s.innerHTML='<div class="note bad">Error al dibujar esta vista: '+esc(e.message)+'</div>';window.__errores=(window.__errores||[]).concat(String(e))}}});
    if(sub&&SUBSEL[id])SUBSEL[id](sub);
    try{history.replaceState(null,"","#"+id)}catch(e){}window.scrollTo(0,0)}
  window.__goto=sel;
  document.addEventListener("click",function(e){var t=e.target.closest&&e.target.closest("[data-go]");if(t)sel(t.dataset.go,t.dataset.sub)});
  var h=(location.hash||"").slice(1);sel(VIEWS.some(function(v){return v.id===h})?h:"res");
  function tema(v){var r=document.documentElement;if(v)r.dataset.theme=v;var d=r.dataset.theme==="dark"||(!r.dataset.theme&&matchMedia("(prefers-color-scheme:dark)").matches);$("#t-dia").setAttribute("aria-pressed",!d);$("#t-noche").setAttribute("aria-pressed",d)}
  $("#t-dia").onclick=function(){tema("light")};$("#t-noche").onclick=function(){tema("dark")};tema();
  var dm=$("#dmenu");dm.innerHTML=DESCARGAS.map(function(d,i){return '<button data-d="'+i+'">'+ic(d[0],16)+esc(d[1])+'</button>'}).join("");
  $("#b-desc").onclick=function(e){e.stopPropagation();dm.hidden=!dm.hidden};
  dm.onclick=function(e){var b=e.target.closest("button");if(!b)return;var r=DESCARGAS[+b.dataset.d][2]();guardarArchivo(r[0],r[1]);dm.hidden=true};
  $("#b-guardar").onclick=function(){var r=DESCARGAS[4][2]();guardarArchivo(r[0],r[1])};
  $("#b-cargar").onclick=function(){$("#f-cargar").click()};
  $("#f-cargar").onchange=function(e){var f=e.target.files[0];if(!f)return;var rd=new FileReader();rd.onload=function(){try{var o=JSON.parse(rd.result);if(o.tipo!=="sesion-informe")throw 0;Object.keys(o.datos||{}).forEach(function(k){try{localStorage.setItem(k,o.datos[k])}catch(x){}});
    VIEWS.forEach(function(v){var s=$("#v-"+v.id);s.dataset.done="";s.innerHTML=""});Object.keys(SUBSEL).forEach(function(k){delete SUBSEL[k]});sel(cur);toast("Sesión cargada")}catch(x){toast("El archivo no es una sesión de este informe")}};rd.readAsText(f);e.target.value=""};
  document.addEventListener("click",function(e){if(!e.target.closest("#dmenu")&&e.target.id!=="b-desc"&&!e.target.closest("#b-desc"))dm.hidden=true;if(!e.target.closest(".search"))$("#sres").hidden=true});
  var IDX=null,sr=$("#sres");
  $("#q").addEventListener("input",function(){var q=this.value.trim().toLowerCase();if(!q){sr.hidden=true;return}IDX=IDX||buildIndex();var ws=q.split(/\s+/);
    var res=IDX.filter(function(r){var s=r.x.toLowerCase();return ws.every(function(w){return s.indexOf(w)>=0})}).slice(0,14);
    sr.innerHTML=res.length?res.map(function(r,i){var s=r.x,p=s.toLowerCase().indexOf(ws[0]),a=Math.max(0,p-40),snip=esc(s.slice(a,a+130));ws.forEach(function(w){snip=snip.replace(new RegExp("("+w.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")+")","ig"),"<mark>$1</mark>")});return '<a data-i="'+i+'"><small>'+esc(r.t)+'</small>'+(a>0?"…":"")+snip+'…</a>'}).join(""):'<a><small>Sin resultados</small>No hay coincidencias para "'+esc(q)+'".</a>';
    sr.hidden=false;sr._r=res});
  sr.addEventListener("click",function(e){var a=e.target.closest("a[data-i]");if(!a)return;var r=sr._r[+a.dataset.i];sr.hidden=true;if(r.ev){sel(r.tab,r.sub);openEv(r.ev)}else sel(r.tab,r.sub)});
  $("#mclose").onclick=closeModal;$("#modal").addEventListener("click",function(e){if(e.target.id==="modal")closeModal()});
  window.__listo=true;
}
boot();
'''

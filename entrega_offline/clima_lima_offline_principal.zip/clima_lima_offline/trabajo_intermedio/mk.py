import json,sys
O=sys.argv[1]
def e(i,tipo,acc,via,ref,ext,loc,afirma,lim,ap):
    return {"id":i,"tipo":tipo,"acceso":acc,"via":via,"fecha_acceso":"2026-10-27","referencia":ref,"extracto":ext,"localizador":loc,"afirma":afirma,"limites":lim,"aplica_a":ap,"revista_cuartil":None}
L=[
e("E-2000","otro","snippet","websearch",{"titulo":"Packing Tips Part 1 (pagina de mantenimiento de un fabricante de bombas)","fuente":"fabricante de bombas, consejos de mantenimiento (segun el buscador)","url":"https://www.nashpumps.com/en/resources/maintenance-tips/packing-tips-part-1/"},
 "(resumen del buscador, no cita literal) con empaquetadura endurecida y fuga severa, el agua puede entrar al soporte de rodamientos y causar falla prematura del rodamiento; un aumento de temperatura del rodamiento que no se estabiliza senala problema de empaquetadura.",
 "resultado de busqueda web 2026-10-27",
 "PISTA: guia de fabricante liga fuga de empaquetadura con ingreso de agua al soporte de rodamientos. No respalda afirmaciones de entregables.",
 "Solo resumen de buscador; pagina no abierta (dominio inaccesible desde esta red); fuente comercial, no revisada por pares; sin cifras; tipo de bomba (vacio de anillo liquido) distinto de bomba centrifuga.",
 "Fuga de empaquetadura hacia soporte de rodamientos; contaminacion por agua (pista)."),
e("E-2001","otro","snippet","websearch",{"titulo":"Stuffing Box Maintenance (pagina de mantenimiento de un fabricante de bombas)","fuente":"fabricante de bombas, consejos de mantenimiento (segun el buscador)","url":"https://www.nashpumps.com/en/resources/maintenance-tips/stuffing-box-maintenance/"},
 "(resumen del buscador, no cita literal) prensaestopa apretado en exceso genera friccion excesiva contra el eje y sobrecalienta el recubrimiento del eje; un drenaje de bandeja bloqueado acumula agua y aumenta el riesgo de ingreso al soporte de rodamientos.",
 "resultado de busqueda web 2026-10-27",
 "PISTA: sobreapriete del prensaestopa produce friccion y calor en el eje; drenaje obstruido favorece ingreso de agua al soporte. No respalda entregables.",
 "Solo resumen de buscador; pagina no abierta; fuente comercial; sin medicion; no trata flexion del eje ni falsa brinelacion.",
 "Sobreapriete del prensaestopa, calor, desgaste del eje (pista)."),
e("E-2002","otro","snippet","websearch",{"titulo":"Articulo en Mechanics & Industry (2020) sobre agua en aceite lubricante y vida a fatiga por contacto rodante (titulo exacto no obtenido)","fuente":"Mechanics & Industry, acceso abierto segun el buscador","url":"https://www.mechanics-industry.org/10.1051/meca/2020023"},
 "(resumen del buscador, no cita literal) la vida a fatiga por contacto rodante se reduce entre 32 y 48 % cuando el aceite contiene agua, incluso con contenido de 0,01 %.",
 "resultado de busqueda web 2026-10-27",
 "PISTA: un articulo de acceso abierto reporta reduccion de vida a fatiga por contacto rodante con agua en el aceite. No respalda cifras en entregables.",
 "Solo resumen de buscador; articulo no abierto (dominio inaccesible); no se verifico si el DOI del buscador corresponde al pasaje; ensayo de laboratorio, no bomba con prensaestopa.",
 "Humedad y fatiga en pistas; agua como contaminante (pista)."),
e("E-2003","otro","snippet","websearch",{"titulo":"Even a Few Hundred Parts Per Million Can Cut Bearing Life in Half (articulo de consultora)","fuente":"sitio de consultoria de confiabilidad (segun el buscador)","url":"https://reliabilitysolutions.net/articles/water-in-bearing-grease-how-it-destroys-film-strength-and-what-to-do-about-it/"},
 "(resumen del buscador, no cita literal) la vida a fatiga del rodamiento se reduce 50 % con 300 ppm de agua, atribuido a un estudio de 1977 en ASLE Transactions; mas de 75 % con 1000 ppm.",
 "resultado de busqueda web 2026-10-27",
 "PISTA: fuente comercial cita de segunda mano una relacion agua-vida de rodamiento. No respalda entregables.",
 "Solo resumen de buscador; cifras de segunda mano no verificadas contra el original; fuente comercial.",
 "Humedad y vida de rodamiento (pista)."),
e("E-2004","otro","snippet","websearch",{"titulo":"PUMPS: How to avoid common shaft sleeve problems","fuente":"Canadian Mining Journal (revista tecnica comercial, segun el buscador)","url":"https://canadianminingjournal.com/news/pumps-how-to-avoid-common-shaft-sleeve-problems"},
 "(resumen del buscador, no cita literal) la empaquetadura aprieta el eje y lo desgasta; se usa manguito reemplazable para que el desgaste caiga en el manguito; agua de sello limpia a presion sostenida sobre la descarga reduce el desgaste del manguito.",
 "resultado de busqueda web 2026-10-27",
 "PISTA: desgaste del manguito por contacto con la empaquetadura y papel del agua de sello. No respalda entregables.",
 "Solo resumen de buscador; pagina no abierta; articulo comercial; contexto de bombas de lodo minero; sin cifras verificadas.",
 "Desgaste de manguito del eje (pista)."),
e("E-2005","paper","solo_referencia","websearch",{"autores":"R. E. Cantley (segun resumen del buscador)","anio":1977,"titulo":"Estudio del efecto del agua en la vida a fatiga de rodamientos (titulo exacto no obtenido)","fuente":"ASLE Transactions, vol. 20 (segun citas de segunda mano)","url":""},
 "", "Referencia citada por fuentes comerciales; no leida",
 "Referencia pendiente: origen citado de la relacion agua-vida de rodamiento.",
 "No leida; solo conocida por citas de segunda mano; titulo, paginas y DOI no obtenidos.",
 "Humedad y vida de rodamiento (pendiente)."),
]
json.dump(L,open(O+"/mecanismos_registro.json","w"),indent=1,ensure_ascii=False)
for n in("elementos","cifras","replicas"): json.dump([],open(f"{O}/mecanismos_{n}.json","w"))

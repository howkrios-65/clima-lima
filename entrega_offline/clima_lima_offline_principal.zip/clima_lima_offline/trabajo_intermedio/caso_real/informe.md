# Prueba de aceptación con datos públicos reales: genfan (ventiladores) y valveSeat (asientos de válvula)

Modo A. Todo cálculo es [DATO/CÁLCULO] salvo indicación. Scripts, JSON de resultados y figuras en `/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/caso_real/` (`01_genfan.py`, `02_valveseat.py`, `03_validacion_cobertura.py`, `04_ingenuo_kit_multiunidad.py`, `work/*.json`, `figs/*.png`). Datos originales no modificados (se trabajó sobre copias en `work/`). Kit: 64 pruebas pasan (`python -m pytest -q`, 4,1 s). Versiones: Python 3.13, numpy 2.5.3, scipy 1.18.1, pandas 3.0.5, matplotlib 3.11.2. Semillas: 20260101 (genfan), 20260102 (valveSeat), 5 (cobertura).

## 1. Resumen de investigación

- **Datos**: `genfan.csv` (70 ventiladores, 12 fallas, 58 suspensiones) y `valveSeat.csv` (89 filas, 41 motores, 48 reemplazos). Ventana temporal: genfan 450–11 500 h de servicio; valveSeat 61–653 días (fin de observación 389–761 d por motor). No hay costos, contexto operacional, códigos de modo de falla ni covariables: todo eso es [VACÍO].
- **Fuentes externas**: 6 búsquedas web; 0 fetch exitosos (WebFetch falló con ENOTFOUND para vincentarelbundock.github.io, web.mit.edu y rdocumentation.org). Todo lo externo proviene de resúmenes de WebSearch (secundario). Verificado en sesión (solo a nivel de resumen de búsqueda): ISBN del libro de Meeker y Escobar (1998), referencia de Nelson (1969) como origen de la muestra de ventiladores, y que la ayuda de R describe genfan y valveSeat. **No verificado**: que los CSV coincidan con las tablas del libro, y las unidades/definiciones exactas (la ayuda de R reportada por la búsqueda describe genfan como ventiladores de "generadores diésel", no "motores diésel" como indicó la tarea: discrepancia sin resolver).
- **Hallazgos**:
  1. Ventiladores: β Weibull = 1,06 (IC LR 95 % 0,61–1,66); no se distingue de falla aleatoria; el exponencial no se rechaza (LR β=1: p=0,82). B10 ≈ 3 100 h con IC 1 400–5 700 h (Weibull). Sin base estadística para reemplazo por edad.
  2. Asientos de válvula: indicio de tasa de reemplazos creciente (β Crow-AMSAA condicional = 1,42; IC 1,07–1,89; Laplace agrupada p=0,014) pero **frágil**: se pierde en ventanas ≤600 d (p 0,23–0,47), la bondad de ajuste de ley de potencia está en el límite (p=0,048) y hay heterogeneidad entre motores (p=0,032).
- **Vacíos declarados**: costos, definición operativa de falla/reemplazo, modos de falla, unidad real de uso (días calendario vs. horas), benchmarking numérico, ISO 14224 (no consultada).

## 2. Pregunta de decisión y alcance

1. genfan (no reparable): ¿patrón de vida (infantil/aleatorio/desgaste)? ¿Es válido un reemplazo por edad? Decisión: reemplazar por edad o no.
2. valveSeat (reparable): ¿la tasa de reemplazos crece, decrece o es constante? Decisión: si hay base para intensificar/ajustar la estrategia con la edad del motor.

Intake (§1.3): las respuestas ya venían en el encargo; no se hizo ronda de preguntas. Costos y consecuencias: [VACÍO].

## 3. Datos y calidad

Tabla "Calidad de datos" (script: bloque `audit` de cada JSON).

| Conjunto | Campo / aspecto | Hallazgo | Tratamiento | Impacto |
|---|---|---|---|---|
| genfan | nulos | 0 % en las 3 columnas | — | ninguno |
| genfan | ruido de coma flotante | valores como 459.99999999999994 y 1660.0000000000002 | redondeo a 3 decimales | ninguno |
| genfan | censura | 58/70 = 82,9 % suspensiones; ninguna antes de la primera falla; 6 suspensiones superan la última falla (8 750 h) | censura por derecha en MLE/KM | resultado muy dependiente del modelo; extrapolación fuera de 11 500 h |
| genfan | empates | 10 tiempos de falla distintos para 12 fallas (1150×2, 2070×2); 2080 a solo 10 h de 2070; empates falla/suspensión en 6100 y 8750 | convención: la falla se ordena antes que la suspensión | 5 de 12 fallas en un grupo de empates o casi-empates: posible registro por inspección agrupada [VACÍO: no verificable] |
| genfan | unidad de tiempo | "horas de servicio" según el encargo | se usa tal cual | si es calendario o de operación: [VACÍO] |
| genfan | modo de falla, causa, componente | no existen | no se puede separar modos | límite estructural (ver §5.1.4) |
| valveSeat | nulos | 0 % | — | ninguno |
| valveSeat | censura | 41 filas status=0, una por motor, siempre la última fila del motor | T_k = tiempo de la fila status=0 | correcto |
| valveSeat | eventos | 48 reemplazos; 17 de 41 motores sin eventos; mediana 1, máximo 4 por motor | — | tasas bajas por motor; heterogeneidad |
| valveSeat | duplicados | 2 casos motor-día repetidos: motor 328 día 653 (×2) y motor 402 día 139 (×2) = 4 filas | **se conservan como eventos separados** (varios asientos reemplazados en una inspección); sensibilidad colapsando a 46 eventos | MCF final 1,543 vs 1,407; β 1,42 vs 1,42; conclusión no cambia |
| valveSeat | coincidencias entre motores | 0 días con eventos de distintos motores | — | ninguno |
| valveSeat | eventos tras/en el fin | 0 | — | ninguno |
| valveSeat | granularidad | días enteros de **inspección**, no del instante de falla | se trata como tiempo del evento (aproximación) | datos en realidad censurados por intervalo; frecuencia de inspección [VACÍO] |
| valveSeat | T_k | mín 389, mediana 608, máx 761 d; 40/41 motores llegan a 575 d; 25 a 600 d; 9 a 653 d | modelo condicional en T_k | cola (>640 d) con ≤16 motores |
| valveSeat | definición de evento | "reemplazo" puede ser preventivo o correctivo | no distinguible | mezcla falla/intervención [VACÍO] |
| valveSeat | edad vs calendario | no se sabe si todos los motores inician nuevos en t=0 | [SUPUESTO] t = edad desde inicio de observación | si no, "tendencia" es de calendario, no de edad |

## 4. Taxonomía y jerarquía

No procede validar contra ISO 14224/OREDA: los datos no contienen modo, mecanismo ni causa, ni nivel jerárquico. La norma **no fue consultada** en esta sesión [VACÍO]. Implicación: genfan se analiza como "un modo de falla" por obligación, no por evidencia; valveSeat es un nivel sistema (motor) con eventos a nivel componente (asiento).

## 5. Análisis

### 5.1 genfan (no reparable; árbol §5.1 rama TTF con censura)

Método: TTF con censura por derecha; Weibull (MLE, kit `fit_weibull_mle`), lognormal (kit `_fit_lognormal`, validado contra L-BFGS-B independiente: Δloglik 5e-12) y exponencial; Kaplan-Meier (kit). Código propio (el kit no lo trae): IC de B10 por verosimilitud perfilada (validado: en los extremos la desviancia es 3,8415 = χ²(0,95;1) y la diferencia contra una rejilla de fuerza bruta ≤ 1,8e-7), exponencial exacto por χ², B10 de KM, bondad de ajuste por bootstrap parametrico, tasa por tramos, modelo LFP.

**5.1.1 Ajustes (n=70, r=12, 58 suspensiones)**

| Modelo | Parámetros | logL | AIC | ΔAIC | BIC |
|---|---|---|---|---|---|
| Exponencial | λ = 3,48e-5 /h (MTBF 28 703 h; IC 95 % 16 432–55 550 h) | −135,18 | 272,35 | 0 | 274,60 |
| Lognormal | μ=10,14; σ=1,68 | −134,55 | 273,10 | 0,74 | 277,60 |
| Weibull | β=1,058; η=26 297 h | −135,15 | 274,31 | 1,95 | 278,80 |

Con ΔAIC < 2 entre los tres [SUPUESTO de lectura: umbral convencional] **no hay base para preferir uno**; el kit ordena por AIC sin advertirlo.

**5.1.2 Weibull: incertidumbre**
- β = 1,058; IC LR 95 % [0,606; 1,658]; bootstrap percentil (2000 remuestreos, 0 fallidos) [0,764; 1,606]. LR de H0 β=1: estadístico 0,049, p=0,825. Bootstrap: P(β>1)=0,645.
- η = 26 297 h, bootstrap [14 237; 72 366]; η, B50 (18 600 h) y MTTF (25 716 h; bootstrap [12 974; 81 744]) **extrapolan** más allá de la mayor edad observada (11 500 h): no usar para decisiones.
- Contraste RRX (regresión por rangos): β=1,25, η=16 868, r²=0,953: discrepa del MLE (1,06) por la censura pesada y n=12; refuerza que β está poco determinado.
- Lectura: β≈1, IC contiene 1: falla aleatoria indistinguible; **no** se demuestra desgaste. Con 12 fallas no se puede excluir desgaste leve (cota superior 1,66).

**5.1.3 B10 (edad a la que ha fallado el 10 %)** (figura `figs/genfan_B10_metodos.png`)

| Método | B10 (h) | IC 95 % (h) |
|---|---|---|
| Weibull MLE, LR perfilada | 3 137 | 1 420–5 662 |
| Weibull bootstrap percentil | 3 137 | 1 807–6 384 |
| Lognormal MLE, LR perfilada | 2 954 | 1 465–5 426 |
| Lognormal bootstrap (1000) | — | 1 854–5 745 |
| Exponencial exacto χ² | 3 024 | 1 731–5 853 |
| Kaplan-Meier | 2 080 | 1 150–6 100 |

Los cinco intervalos se solapan ampliamente; KM da el punto más bajo pero está en el mismo rango. B10 es una edad de falla del 10 % de la población, **no** una vida segura de reemplazo.

**5.1.4 Contraste con Kaplan-Meier y modos mezclados**
- KM: S(8 750 h)=0,707 (IC 0,468–0,854); la mediana no se alcanza. Diferencias KM–modelo en S(t) ≤ 0,05 en los 6 tiempos evaluados (1 000–10 000 h; tabla en JSON). Figura `figs/genfan_km_vs_param.png`.
- Bondad de ajuste (distancia tipo Kolmogorov KM-modelo, bootstrap paramétrico con censura remuestreada de la KM inversa, 400 simulaciones): Weibull D=0,063 p=0,47; lognormal D=0,058 p=0,52; exponencial D=0,058 p=0,63. Ninguno se rechaza; potencia baja con 12 fallas. Prueba aproximada, no estándar (declarado).
- Gráfico de probabilidad Weibull (`figs/genfan_wwplot.png`): los 12 puntos siguen una recta sin quiebre claro; el punto más temprano (450 h) queda por encima de lo esperado y el grupo 2070–2080 h forma un escalón. No hay curvatura sistemática que sugiera dos poblaciones.
- Tasa de falla empírica por tramo (fallas/1000 h expuestas): (0–1000] 0,015 (1 falla en 68 910 h); (1000–2500] 0,066 (6 en 90 380 h); (2500–5000] 0,029 (3 en 104 550 h); (5000–12000] 0,025 (2 en 80 600 h). LR de tasa constante: χ²=3,46, 3 gl, p=0,33. Tramos fijados **después** de ver los tiempos: indicativo. Sin evidencia de mortalidad infantil (la tasa más baja está en el primer tramo) ni de desgaste monótono.
- Modelo de subpoblación defectuosa (LFP, exploratorio): p susceptible=0,31, β=1,33, η=5 787 h; ΔAIC=+1,27 contra Weibull y +3,2 contra exponencial: no mejora; 3 parámetros con 12 fallas no es identificable de forma fiable.
- Conclusión sobre modos mezclados: **no hay evidencia a favor ni se puede descartar**; el conjunto no trae código de modo, la potencia es baja. No se asumió un único modo por convicción: es una condición de los datos (declarada).

**5.1.5 Reemplazo por edad.** La condición necesaria (β>1 con razón de costos favorable, §9.2) no se cumple de forma demostrable (IC de β contiene 1) y los costos son [VACÍO]; por tanto **no hay edad óptima calculable** y no se calcula. Patrón: E (aleatorio), con las salvedades de n.

### 5.2 valveSeat (reparable; árbol §5.1 rama NHPP; **no** Weibull a los TBF)

**5.2.1 Por qué MCF y por qué un Crow-AMSAA condicional.** Es un sistema reparable (motor) con eventos recurrentes y 41 unidades con T_k distintos. El kit ajusta Crow-AMSAA de **una** unidad (tiempos acumulados + T). Ejecutar el kit sobre los 48 tiempos mezclados con T=761 (script `04`) da β=1,07 (IC 0,81–1,42), Laplace p=0,67: **conclusión engañosa**, porque supone que los 41 motores se observaron hasta 761 d cuando el 50 % terminó antes de 608 d. Se descartó. Decisión: modelo con tasa base propia por motor λ_k (libre) y β común; condicionando en N_k, los tiempos normalizados u=t/T_k son iid con CDF u^β, con lo cual el estimador β̂ = N/Σln(T_k/t_ki) (insesgado: (N−1)/S) y su IC χ²(2N) son exactos y robustos a diferencias de nivel entre motores. Se obtiene con el kit pasando u como tiempos y T=1 (el λ que devuelve el kit no tiene significado). Los 17 motores sin eventos no aportan a esta verosimilitud (se declara).

Validación: (a) β̂ del kit = maximización directa con scipy (|Δ| 6e-11); (b) simulación con los T_k reales, β verdadero 1,5: β̂ medio 1,498; cobertura IC 95 % = 93,9 % (3 000 reps) y 94,7 % (20 000 reps, error MC 0,15 %; `03`): compatible con nominal; (c) Laplace agrupada propia = kit para K=1 (|Δ| 2e-16); tamaño bajo H0 = 5,0 %; potencia 68 % para β=1,5 y 55 % para β=0,7 (2000 reps).

**5.2.2 MCF multiunidad** (kit + varianza Lawless-Nadeau propia; validada con un caso hecho a mano, var=0,125, y con bootstrap por motor: SE LN vs bootstrap en t=150/300/450/575: 0,073/0,075; 0,110/0,113; 0,143/0,148; 0,169/0,172). Figura `figs/valveseat_mcf.png`.
- MCF(300 d)=0,463; MCF(575 d)=0,959 (IC 95 % LN 0,679–1,354; 40 motores en riesgo); MCF final (653 d)=1,543 reemplazos por motor con solo 9 motores en riesgo (IC no fiable ahí).
- Forma: casi lineal (compatible con tasa constante) hasta ~575 d, con tasa algo menor en la zona media y un ascenso brusco después de ~575 d.

**5.2.3 Tendencia**

| Análisis | Resultado |
|---|---|
| Laplace agrupada (condicional), 48 eventos | U=2,45; p=0,014 (deterioro) |
| Crow-AMSAA condicional (kit sobre u) | β insesgado 1,42; IC χ² exacto 95 % [1,07; 1,89]; MLE 1,45 |
| Bootstrap por motor (5000) de β insesgado | [1,10; 1,84] |
| Crow-AMSAA con λ común (MIL-HDBK-189 multi-sistema, propio; validado vs K=1 del kit y vs minimización) | β=1,40; IC LR [1,04; 1,83]; LR β=1: p=0,026 |
| Sin duplicados (46 eventos) | β=1,42 [1,07; 1,90]; Laplace p=0,017 |
| Ventana truncada a 575 d (39 eventos; T_k=min(T_k,575)) | β=1,27 [0,92; 1,74]; Laplace p=0,28 |
| Tasa por tramos de 100 d (por 1000 motor-día) | 1,46; 1,22; 1,95; 1,96; 1,50; 2,10; **5,99** (600–800 d: 7 eventos en 1 168 motor-d; IC 2,4–12,3); LR tasa constante p=0,20 |
| Log-lineal Poisson de la tasa | ×1,18 por 100 d (IC 1,01–1,37; p=0,035) |
| Bondad de ajuste ley de potencia (Cramér-von Mises, MC 5000, kit) | p=0,048 |
| Dispersión entre motores (X², Monte Carlo) | p=0,032; varianza/media de conteos 1,32 |

Barrido de ventana final c (exploratorio, **múltiples miradas sin corrección**): c=300: β 1,39, p=0,31; 400: 1,33, p=0,30; 500: 1,25, p=0,47; 575: 1,27, p=0,28; 600: 1,28, p=0,23; 640: 1,35, p=0,064; 700 (=completo): 1,42, p=0,014.

Cohortes por fin de observación (inferidas del T_k/ID; **no hay covariables**; exploratorio): T≥640 d (16 motores, 24 eventos): β 1,17 [0,78; 1,76], p=0,26; T<640 d (25 motores, 24 eventos): β 1,71 [1,14; 2,56], p=0,020. No hay un único subgrupo que explique todo; la señal aparece más en el subgrupo observado menos tiempo.

**5.2.4 Lectura.** β>1 de 1,4 y p≈0,01–0,03 apuntan a tasa creciente, pero (i) la significancia depende de incluir los últimos ~60 d con pocos motores en riesgo; (ii) la ley de potencia no se ajusta limpiamente (p=0,048); (iii) hay heterogeneidad entre motores. Conclusión honesta: **indicio moderado y no robusto de aumento de la tasa de reemplazos con la edad; no se puede afirmar con firmeza; la tasa constante no se descarta en ventanas ≤600 d**. Con potencia 68 % para β=1,5, "no significativo" en ventanas cortas no prueba constancia.

### 5.3 Conciliación de resultados contradictorios (§5.5)
- genfan: Weibull (β≈1,06), exponencial y lognormal "contradicen" en forma pero no en datos: son estadísticamente indistinguibles aquí (ΔAIC<2, GoF sin rechazo). RRX (β=1,25) vs MLE (1,06): sesgo de la regresión con censura pesada.
- valveSeat: el kit en modo ingenuo (β=1,07, sin tendencia) vs condicional (β=1,42, tendencia) difieren por el tratamiento de T_k; el ingenuo es inválido (ver 5.2.1). Condicional vs λ común (1,42 vs 1,40) coinciden; λ común supone homogeneidad entre motores, que la prueba de dispersión cuestiona, por lo que se prefiere el condicional. Weibull no se ajusta a los TBF de valveSeat (proceso reparable, β de TBF ≠ β_CA).

## 6. Benchmarking mundial

- Búsquedas: (a) confiabilidad de ventiladores de refrigeración (datos de campo, β, B10): sin cifras de campo para ventiladores de generador/motor diésel. Un artículo divulgativo de Electronics Cooling (1996) y documentos de fabricantes (resumen de búsqueda) afirman que β de Weibull en ventiladores es generalmente >1 (desgaste de rodamiento) y que L10 depende del método; son fuentes **secundarias, no leídas en su texto completo, de ventiladores electrónicos, no comparables numéricamente**. (b) valveSeat: sin fuentes con tasas comparables.
- Un capítulo de texto (resumen de búsqueda, no verificado en fuente) afirma que el ajuste sugiere distribución exponencial para la muestra de 70 ventiladores de Nelson (1969): consistente con lo hallado aquí (β≈1, exponencial no rechazado), pero no verificado en su fuente.
- **[VACÍO]**: no hay cifra numérica comparable verificada; **no se produjo figura de benchmarking** (no se graficó ninguna cifra externa porque ninguna fue verificada). Comparabilidad: solo cualitativa de patrón (β>1 típico de ventiladores electrónicos vs β≈1 observado aquí; diferencia plausible por tipo de ventilador, definición de falla y mezcla de modos, no demostrable).

## 7. Recomendaciones

| # | Acción | Evidencia | Impacto esperado (incertidumbre) | Costo | Responsable | Métrica de verificación |
|---|---|---|---|---|---|---|
| 1 | genfan: **no** implantar reemplazo calendario/por edad basado en estos datos; priorizar condición o correr a falla si consecuencias lo permiten (consecuencias [VACÍO]) | β=1,06 [0,61; 1,66]; exponencial no rechazado (p=0,82); sin edad óptima calculable | Evita PM sin base; no se puede cuantificar el ahorro | [VACÍO] | Responsable de estrategia de mantenimiento (por asignar) | Reevaluar β cuando haya ≥30 fallas o con códigos de modo |
| 2 | genfan: registrar modo de falla, componente (rodamiento, aspas, etc.), horas de operación vs calendario, y suspensiones con su motivo | Sin códigos de modo; 83 % censura; 5/12 fallas en empates | Permite separar modos y probar mezcla | [VACÍO] | Planificación/CMMS | % de OT con modo codificado |
| 3 | genfan: si se requiere un valor de referencia, usar B10 solo como indicador de población (≈3 000 h; IC 1 400–5 700 h), no como vida de reemplazo | §5.1.3 | Informativo | n/a | Confiabilidad | — |
| 4 | valveSeat: tratar la tendencia como **hipótesis a confirmar**; seguir acumulando exposición >600 d con más motores y registrar la edad real del motor, tipo de intervención (correctiva/preventiva) y fecha de cada inspección | β 1,42 [1,07; 1,89] pero p>0,2 en ventanas ≤600 d; GoF p=0,048 | No cambiar intervalos sobre esta base sola | [VACÍO] | Confiabilidad + taller | Prueba de Laplace agrupada actualizada con ventana común ≥700 d |
| 5 | valveSeat: investigar heterogeneidad entre motores (17/41 sin eventos; dispersión p=0,032) antes de modelar flota | §5.2.3 | Reduce falsa homogeneidad | [VACÍO] | Ingeniería de flota | Identificar covariables (carga, ciclo, lote) |
| 6 | Cualquier decisión económica (edad de reemplazo, LCC): obtener costo de falla/preventivo, lucro cesante y tasa de descuento | Todos [VACÍO] | — | [VACÍO] | Finanzas/operaciones | Costos documentados |

No se emiten números de ahorro: costos [VACÍO]. No se hizo análisis de causa raíz (no hay evidencia física ni de proceso): las "causas" no se declaran.

## 8. Limitaciones y vacíos

- **Datos**: sin modo de falla, sin contexto operacional, sin costos; procedencia verificada solo vía resúmenes de búsqueda; tiempo valveSeat = día de inspección (censura por intervalo tratada como exacta); definición de "reemplazo" ambigua; edad vs calendario [SUPUESTO].
- **Estadística**: 12 fallas en genfan (exploratorio; el kit exige <10 para advertir; MLE de β con r=12 y 83 % de censura sigue sesgado al alza, sin corrección aplicada); GoF por bootstrap con censura estimada de la KM inversa es una aproximación propia; hazard por tramos fijado post hoc; barrido de ventana valveSeat sin corrección de comparaciones múltiples; el IC de MCF Lawless-Nadeau es propio (validado con mano y bootstrap, no contra software externo); Cox y riesgos competitivos no aplicados (sin covariables/modos).
- **Literatura**: sin fetch exitoso; sin fuente primaria leída; benchmarking numérico [VACÍO]; ISO 14224/OREDA no consultadas.
- **Financiero**: todo [VACÍO].
- Cifras de folklore: ninguna usada.

## 9. Referencias (APA 7)

**Verificadas en esta sesión (solo a nivel de resumen de búsqueda web; no se accedió al texto completo, fuente secundaria):**
- Meeker, W. Q., & Escobar, L. A. (1998). *Statistical methods for reliability data*. John Wiley & Sons. (ISBN 978-0-471-14328-4; existencia de la obra verificada en catálogos vía búsqueda; contenido de los conjuntos de datos no verificado.)
- Nelson, W. (1969). Hazard plotting for incomplete failure data. *Journal of Quality Technology, 1*(1), 27–52. https://doi.org/10.1080/00224065.1969.11980344 (cita bibliográfica verificada vía búsqueda; se declara como origen de la muestra de ventiladores según la ayuda de R reportada por la búsqueda, no verificada en el texto.)
- R Core / Therneau, T. M. (s. f.). *survival: Survival analysis* [paquete R], conjunto de datos `reliability` (genfan, valveSeat). Documentación consultada solo como resumen de búsqueda (autor/año/versión no verificados).

**Heredadas, no reverificadas:** ninguna usada en cálculo. Métodos citados por nombre (Weibull IEC 61649, Crow-AMSAA IEC 61164/MIL-HDBK-189, Lawless-Nadeau 1995 para la varianza de la MCF) se aplicaron como técnicas conocidas; **no se verificaron sus textos en esta sesión**.

**Vacíos de literatura (buscados y no encontrados):** datos de campo de β/B10 de ventiladores de generador/motor diésel; tasas de reemplazo de asientos de válvula en motores comparables.

## 10. Lista de verificación §12

| # | Ítem | Respuesta | Evidencia |
|---|---|---|---|
| 1 | Toda cifra es DATO/CÁLCULO, CITA o VACÍO (más etiquetas auxiliares) | **Sí** (con matiz) | Cálculos en JSON/scripts; costos y benchmarking [VACÍO]; [SUPUESTO] rotulados. Las etiquetas no se repiten en cada cifra del texto (parcial en formato) |
| 2 | Auditoría de calidad de datos e impacto | **Sí** | §3 |
| 3 | Método elegido por el árbol §5.1 | **Sí** | genfan: TTF con censura; valveSeat: reparable → MCF/NHPP, sin Weibull a TBF; modos: no separables (declarado) |
| 4 | n, intervalos, supuestos y bondad de ajuste | **Sí** (con límites) | IC LR/bootstrap/exactos; GoF Weibull/LN/exp y CvM; potencia y cobertura simuladas |
| 5 | MTBF ≠ vida útil; β con su consecuencia | **Sí** | §5.1.2–5.1.5 |
| 6 | Causas raíz con nivel de evidencia | **N/A / parcial** | No se declararon causas raíz (sin evidencia); no hubo RCA |
| 7 | FTA como tabla nativa con lógica honesta | **N/A** | No se hizo FTA |
| 8 | Modelo predictivo validado OOT | **N/A** | No se construyó modelo predictivo |
| 9 | ≥1 figura de benchmarking o vacío explícito | **Parcial** | Vacío explícito declarado (§6); **sin figura** de benchmarking; sí 7 figuras de análisis |
| 10 | Vacíos financieros y de literatura declarados; sin folklore | **Sí** | §8 |
| 11 | Cada recomendación con evidencia, costo/vacío, responsable y métrica | **Parcial** | Tabla §7: responsables genéricos (no hay personas/roles reales en los datos) |
| 12 | Estándar idéntico a cualquier otro equipo | **Sí** | Mismo flujo del agente; sin parámetros heredados |
| 13 | Reproducibilidad; datos originales intactos | **Sí** | Scripts con semilla, versiones en JSON, copias en `work/`; originales no tocados; repo sin cambios (`git status` limpio) |

Desviaciones de protocolo declaradas: no se usó `TaskCreate` (herramienta no disponible); el skill `weibull-failure-pattern-analysis` se invocó ya tras el análisis (sus reglas —patrón antes que número, MTBF no es vida, censura— se cumplieron, pero su premisa de "no ejecutar estadística" contradice el uso del kit); no se invocaron otros skills de apoyo.

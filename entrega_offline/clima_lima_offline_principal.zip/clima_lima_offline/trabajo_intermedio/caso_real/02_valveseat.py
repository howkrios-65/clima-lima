"""Caso 2: valveSeat (41 motores, REPARABLES; reemplazos de asientos de valvula).
Uso: python -I 02_valveseat.py  (lee work/valveSeat.csv; escribe figs/ y work/valveseat_results.json)
Kit: nhpp.mean_cumulative_function, nhpp.fit_crow_amsaa (sobre tiempos normalizados t/T_k), nhpp.laplace_trend_test (validacion K=1),
     nhpp.crow_amsaa_gof_mc.
Propio (el kit no lo cubre): varianza/IC de la MCF (Lawless-Nadeau), Laplace agrupada multi-sistema, MLE Crow-AMSAA multi-sistema
con lambda comun (MIL-HDBK-189, T_k distintos) con IC por razon de verosimilitud, tasa por tramos, dispersion entre motores,
bootstrap por motor, validacion por simulacion. Semilla fija 20260102.
"""
import json, sys, platform
from pathlib import Path
import numpy as np, pandas as pd, scipy
from scipy import stats, optimize
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, "/home/user/clima-lima/tools/reliability")
from reliability_kit.nhpp import (mean_cumulative_function, fit_crow_amsaa, laplace_trend_test, crow_amsaa_gof_mc)

BASE = Path(__file__).resolve().parent
W = BASE / "work"; F = BASE / "figs"
SEED = 20260102
ACC, GREY, LG = "#C0392B", "#5D6D7E", "#B2BABB"
out = {"versions": {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__,
                    "pandas": pd.__version__, "matplotlib": matplotlib.__version__}, "seed": SEED}

# ---------------- datos y auditoria ----------------
df = pd.read_csv(W / "valveSeat.csv")
ends = df[df.status == 0].groupby("id").time.agg(["count", "max"])
ev = df[df.status == 1]
ids = sorted(df.id.unique())
Tk = {i: float(ends.loc[i, "max"]) for i in ids}
events = {i: sorted(ev[ev.id == i].time.astype(float).tolist()) for i in ids}
dup_same_engine = ev.groupby(["id", "time"]).size()
dup_same_engine = dup_same_engine[dup_same_engine > 1]
# eventos tras fin / en fin, orden
viol_after_end = [(i, x) for i in ids for x in events[i] if x > Tk[i]]
at_end = [(i, x) for i in ids for x in events[i] if x == Tk[i]]
last_row_status = df.groupby("id").tail(1).status.value_counts().to_dict()
audit = {"filas": len(df), "motores": len(ids), "nulos": int(df.isna().sum().sum()), "status_valores": sorted(df.status.unique().tolist()),
         "filas_status0": int((df.status == 0).sum()), "motores_con_exactamente_1_censura": int((ends["count"] == 1).sum()),
         "eventos_totales": int(len(ev)), "motores_sin_eventos": [i for i in ids if not events[i]],
         "eventos_por_motor_min_med_max": [int(min(len(v) for v in events.values())), float(np.median([len(v) for v in events.values()])), int(max(len(v) for v in events.values()))],
         "T_fin_min_med_max": [min(Tk.values()), float(np.median(list(Tk.values()))), max(Tk.values())],
         "tiempos_evento_min_max": [float(ev.time.min()), float(ev.time.max())],
         "duplicados_mismo_motor_mismo_dia": {f"{k[0]}@{int(k[1])}": int(v) for k, v in dup_same_engine.items()},
         "n_eventos_en_duplicados": int(dup_same_engine.sum()),
         "eventos_posteriores_al_fin": viol_after_end, "eventos_en_el_instante_de_fin": at_end,
         "ultima_fila_por_motor_status": {int(k): int(v) for k, v in last_row_status.items()},
         "tiempos_enteros": bool(np.all(df.time == df.time.round())),
         "coincidencias_mismo_dia_entre_motores": int((ev.groupby("time").id.nunique() > 1).sum())}
out["audit"] = audit
T = np.array([Tk[i] for i in ids]); N = np.array([len(events[i]) for i in ids]); Ntot = int(N.sum())
ev_list = [events[i] for i in ids]
tt_all = np.sort(np.concatenate([np.array(v) for v in ev_list]))

# ---------------- MCF (kit) y variante colapsando duplicados ----------------
mc = mean_cumulative_function(ev_list, T)
ev_list_dedup = [sorted(set(v)) for v in ev_list]
mc_d = mean_cumulative_function(ev_list_dedup, T)
out["mcf"] = {"n_unidades": mc["n_units"], "mcf_final": float(mc["mcf"][-1]), "t_ultimo_evento": float(mc["time"][-1]),
              "mcf_dedup_final": float(mc_d["mcf"][-1]), "n_eventos_dedup": int(sum(len(v) for v in ev_list_dedup))}

# ---------------- varianza Lawless-Nadeau (propio) ----------------
def mcf_ln(ev_list, ends, conf=0.95):
    ends = np.asarray(ends, float)
    times = np.unique(np.concatenate([np.asarray(v, float) for v in ev_list]))
    nj = np.array([(ends >= tj).sum() for tj in times])
    dij = np.array([[np.sum(np.asarray(v) == tj) for tj in times] for v in ev_list], float)       # unidades x tiempos
    dj = dij.sum(0)
    delta = (ends[:, None] >= times[None, :]).astype(float)
    mu = np.cumsum(dj / nj)
    contrib = delta / nj[None, :] * (dij - (dj / nj)[None, :])
    cum = np.cumsum(contrib, axis=1)
    var = (cum ** 2).sum(0)
    z = stats.norm.ppf(0.5 + conf / 2)
    se = np.sqrt(var)
    with np.errstate(divide="ignore", invalid="ignore"):
        w = np.exp(z * se / mu)
    return {"time": times, "mcf": mu, "se": se, "lo": mu / w, "hi": mu * w, "n_risk": nj}
# validacion a mano (ejemplo 2 unidades): var(3)=0.125 y mcf(3)=1.5
chk = mcf_ln([[1, 3], [2]], [4, 5])
assert abs(chk["mcf"][-1] - 1.5) < 1e-12 and abs(chk["se"][-1] ** 2 - 0.125) < 1e-12, "LN falla en caso a mano"
ln = mcf_ln(ev_list, T)
assert np.allclose(ln["mcf"], mc["mcf"]), "MCF propia != kit"
# validacion: bootstrap por motor del MCF en algunos t
rngb = np.random.default_rng(SEED)
def mcf_at(evl, ends, t0):
    evl_ = [np.asarray(v) for v in evl]; ends = np.asarray(ends)
    times = np.unique(np.concatenate(evl_)); times = times[times <= t0]
    tot = 0.0
    for tj in times:
        n = (ends >= tj).sum(); d = sum((v == tj).sum() for v in evl_)
        tot += d / n if n > 0 else 0
    return tot
chk_pts = [150, 300, 450, 575]
boot_vals = {p: [] for p in chk_pts}
for _ in range(1000):
    idx = rngb.integers(0, len(ids), len(ids))
    el = [ev_list[k] for k in idx]; en = T[idx]
    for p in chk_pts: boot_vals[p].append(mcf_at(el, en, p))
val_rows = []
for p in chk_pts:
    j = np.searchsorted(ln["time"], p, side="right") - 1
    val_rows.append({"t": p, "mcf": float(ln["mcf"][j]), "se_LN": float(ln["se"][j]), "se_bootstrap_motores": float(np.std(boot_vals[p], ddof=1)),
                     "ic95_LN": [float(ln["lo"][j]), float(ln["hi"][j])], "ic95_boot": [float(np.quantile(boot_vals[p], .025)), float(np.quantile(boot_vals[p], .975))],
                     "n_en_riesgo": int(ln["n_risk"][j])})
out["mcf"]["puntos"] = val_rows
# MCF vs HPP (recta): desviacion maxima de la MCF respecto de la recta desde el origen hasta (t_ref, mcf(t_ref))
t_ref = 575.0
j_ref = np.searchsorted(ln["time"], t_ref, side="right") - 1
out["mcf"]["mcf_en_575"] = float(ln["mcf"][j_ref]); out["mcf"]["n_riesgo_en_575"] = int(ln["n_risk"][j_ref])
out["mcf"]["n_riesgo_tras_575"] = [{"t": float(t_), "n": int(n_)} for t_, n_ in zip(ln["time"], ln["n_risk"]) if t_ > 575]

# ---------------- tendencia: Laplace agrupada (condicional) ----------------
def pooled_laplace(ev_list, ends):
    u = np.concatenate([np.asarray(v) / e for v, e in zip(ev_list, ends)]) if any(len(v) for v in ev_list) else np.array([])
    n = u.size
    U = (u.sum() - n / 2.0) / np.sqrt(n / 12.0)
    return float(U), float(2 * stats.norm.sf(abs(U))), int(n)
U, pU, nU = pooled_laplace(ev_list, T)
# validacion K=1 vs kit (Laplace terminada por tiempo) y tamano/potencia por simulacion
k_ev, k_T = [3, 10, 20, 31, 55, 70], 100.0
Uk = laplace_trend_test(k_ev, k_T)["U"]; Up, _, _ = pooled_laplace([k_ev], [k_T])
assert abs(Uk - Up) < 1e-12, "Laplace agrupada K=1 != kit"
rngs = np.random.default_rng(SEED + 1)
lam_per_day = Ntot / np.sum(T)           # solo para dimensionar la simulacion (tasa media bajo HPP)
def sim_engines(beta, Tvec, rate_scale, rg):
    evl = []
    for Tk_ in Tvec:
        lam_k = rate_scale                 # E[N_k] = lam_k*Tk^beta
        nk = rg.poisson(lam_k * Tk_ ** beta)
        evl.append(sorted((Tk_ * rg.uniform(size=nk) ** (1 / beta)).tolist()))
    return evl
def calib_scale(beta):                    # escala tal que sum E[N_k] = Ntot
    return Ntot / np.sum(T ** beta)
nrep = 2000; rej0 = 0; rej15 = 0; rej07 = 0
for _ in range(nrep):
    for beta_, ctr in ((1.0, "0"), (1.5, "15"), (0.7, "07")):
        evl = sim_engines(beta_, T, calib_scale(beta_), rngs)
        if sum(len(v) for v in evl) < 3: continue
        p_ = pooled_laplace(evl, T)[1]
        if p_ < 0.05:
            if ctr == "0": rej0 += 1
            elif ctr == "15": rej15 += 1
            else: rej07 += 1
out["laplace_agrupada"] = {"U": U, "p_bilateral": pU, "n_eventos": nU,
                           "lectura": "U>0 deterioro (tasa creciente), U<0 mejora", "validacion_K1_vs_kit": float(abs(Uk - Up)),
                           "sim_tamano_H0(beta=1)": rej0 / nrep, "sim_potencia(beta=1.5)": rej15 / nrep, "sim_potencia(beta=0.7)": rej07 / nrep, "nrep": nrep}

# ---------------- Crow-AMSAA multi-sistema ----------------
# (A) Condicional en N_k (lambda_k propio por motor, beta comun): usa el kit sobre tiempos normalizados t/T_k con T=1
u_all = np.sort(np.concatenate([np.asarray(v) / e for v, e in zip(ev_list, T)]))
ca = fit_crow_amsaa(u_all, 1.0, terminated="time")
gof = crow_amsaa_gof_mc(u_all, 1.0, n_sim=5000, seed=SEED)
S_pool = float(np.log(1.0 / u_all).sum())
# validacion independiente: maximizacion directa de la log-verosimilitud condicional
f_cond = lambda b: -(Ntot * np.log(b) + (b - 1) * np.log(u_all).sum())   # sum[ln b + (b-1)ln u] (T_k normalizado a 1)
bres = optimize.minimize_scalar(lambda b: -(Ntot * np.log(b) + (b - 1) * np.log(u_all).sum()), bounds=(0.05, 20), method="bounded", options={"xatol": 1e-10})
# la verosimilitud condicional es creciente en... usa la forma completa: sum[ln b + (b-1) ln(t/T) ] = N ln b + (b-1) sum ln u ; maximo en b=N/S
bres2 = optimize.minimize_scalar(lambda b: -(Ntot * np.log(b) - (b - 1) * S_pool), bounds=(0.05, 20), method="bounded", options={"xatol": 1e-10})
out["crow_amsaa_condicional"] = {"beta_mle": ca.beta_mle, "beta_insesgado": ca.beta, "ic95_exacto_chi2": ca.beta_ci, "n": ca.n, "tendencia": ca.trend,
                                 "gof_CvM": gof, "validacion_beta_vs_scipy": float(abs(bres2.x - ca.beta_mle)), "warnings": ca.warnings,
                                 "nota": "lambda_k libre por motor => el kit se usa sobre u=t/T_k con T=1; lambda del kit no tiene significado"}
# (B) lambda comun, T_k distintos (MIL-HDBK-189 sistemas multiples): lambda=N/sum T^b ; b resuelve N/b + sum ln t - N*sum(T^b lnT)/sum(T^b)=0
all_t = tt_all
def ll_common(b):
    lam = Ntot / np.sum(T ** b)
    return Ntot * np.log(lam) + Ntot * np.log(b) + (b - 1) * np.log(all_t).sum() - lam * np.sum(T ** b)
sc = lambda b: Ntot / b + np.log(all_t).sum() - Ntot * np.sum(T ** b * np.log(T)) / np.sum(T ** b)
b_com = optimize.brentq(sc, 0.05, 20)
b_chk = optimize.minimize_scalar(lambda b: -ll_common(b), bounds=(0.05, 20), method="bounded", options={"xatol": 1e-10}).x
crit = stats.chi2.ppf(0.95, 1)
g = lambda b: 2 * (ll_common(b_com) - ll_common(b)) - crit
lo_c = optimize.brentq(g, 0.1, b_com); hi_c = optimize.brentq(g, b_com, 10)
LR1 = 2 * (ll_common(b_com) - ll_common(1.0))
out["crow_amsaa_lambda_comun"] = {"beta_mle": float(b_com), "ic95_LR": [float(lo_c), float(hi_c)], "lambda": float(Ntot / np.sum(T ** b_com)),
                                  "LR_beta_eq_1": {"stat": float(LR1), "p": float(stats.chi2.sf(LR1, 1))},
                                  "validacion_brentq_vs_bounded": float(abs(b_com - b_chk)),
                                  "nota": "supone MISMA tasa base para los 41 motores (homogeneidad), peor justificable que (A)"}
# K=1 : el multi-sistema (B) debe coincidir con el kit (MLE n/S) cuando hay un solo sistema
k1 = fit_crow_amsaa([5, 12, 30, 41, 80, 90], 100.0, terminated="time", unbiased=False)
Tb = np.array([100.0]); tb = np.array([5, 12, 30, 41, 80, 90.0])
scb = lambda b: len(tb) / b + np.log(tb).sum() - len(tb) * np.sum(Tb ** b * np.log(Tb)) / np.sum(Tb ** b)
out["crow_amsaa_lambda_comun"]["validacion_K1_vs_kit"] = float(abs(optimize.brentq(scb, 0.05, 20) - k1.beta_mle))
# (C) sensibilidades: sin duplicados, y truncando todos los motores a un T comun
u_d = np.sort(np.concatenate([np.asarray(sorted(set(v))) / e for v, e in zip(ev_list, T)]))
ca_d = fit_crow_amsaa(u_d, 1.0, terminated="time")
Tc = 575.0
Tcv = np.minimum(T, Tc)                     # cada motor observado hasta min(T_k, 575): 40 de 41 motores llegan a 575 d (motor 409 termina en 389 d)
trunc = [[x for x in v if x <= Tc] for v in ev_list]
nt = sum(len(v) for v in trunc)
u_t = np.sort(np.concatenate([np.asarray(v) / e for v, e in zip(trunc, Tcv)]))
ca_t = fit_crow_amsaa(u_t, 1.0, terminated="time")
Ut, pUt, _ = pooled_laplace(trunc, Tcv)
Ud, pUd, nUd = pooled_laplace(ev_list_dedup, T)
out["sensibilidad"] = {"sin_duplicados": {"n": ca_d.n, "beta_insesgado": ca_d.beta, "ic95": ca_d.beta_ci, "laplace_U": Ud, "laplace_p": pUd},
                       "ventana_comun_575d": {"n": nt, "beta_insesgado": ca_t.beta, "ic95": ca_t.beta_ci, "laplace_U": Ut, "laplace_p": pUt,
                                              "nota": "ventana truncada en 575 d con T_k=min(T_k,575); 40 de 41 motores alcanzan 575 d"}}
# primeras vs segundas mitad de la ventana (conteo, exposicion por motor-dia)
# (D) bootstrap por motor del beta condicional (robusto a heterogeneidad entre motores)
rg2 = np.random.default_rng(SEED + 2)
bb = []
for _ in range(5000):
    idx = rg2.integers(0, len(ids), len(ids))
    uu = np.concatenate([np.asarray(ev_list[k]) / T[k] for k in idx])
    if uu.size >= 3: bb.append((uu.size - 1) / np.log(1 / uu).sum())
out["crow_amsaa_condicional"]["bootstrap_motores_beta_insesgado_pct95"] = [float(np.quantile(bb, .025)), float(np.quantile(bb, .975))]
out["crow_amsaa_condicional"]["bootstrap_n"] = len(bb)
# (E) validacion por simulacion: cobertura del IC exacto y sesgo del estimador insesgado con los T_k reales
rg3 = np.random.default_rng(SEED + 3)
cov = 0; bs = []; reps = 3000
for _ in range(reps):
    evl = sim_engines(1.5, T, calib_scale(1.5), rg3)
    uu = np.concatenate([np.asarray(v) / e for v, e in zip(evl, T)])
    if uu.size < 3: continue
    f_ = fit_crow_amsaa(np.sort(uu), 1.0, terminated="time")
    bs.append(f_.beta); cov += (f_.beta_ci[0] <= 1.5 <= f_.beta_ci[1])
out["validacion_simulacion_CA"] = {"beta_verdadero": 1.5, "beta_medio_estimado": float(np.mean(bs)), "cobertura_IC95": cov / len(bs), "reps": len(bs)}

# ---------------- dispersion entre motores ----------------
bC = ca.beta_mle
Ek = Ntot * T ** bC / np.sum(T ** bC)
X2 = float(((N - Ek) ** 2 / Ek).sum())
rg4 = np.random.default_rng(SEED + 4)
sims = rg4.multinomial(Ntot, Ek / Ek.sum(), size=20000)
X2s = ((sims - Ek) ** 2 / Ek).sum(1)
out["dispersion_entre_motores"] = {"X2": X2, "gl_ref": len(ids) - 1, "p_monte_carlo_multinomial": float((1 + (X2s >= X2).sum()) / (1 + len(X2s))),
                                   "var_sobre_media_conteos": float(N.var(ddof=1) / N.mean()),
                                   "nota": "E_k proporcional a T_k^beta (beta condicional). p<0.05 => motores con tasas distintas (heterogeneidad)"}

# ---------------- tasa por tramos de edad (motor-dias expuestos) ----------------
edges = [0, 100, 200, 300, 400, 500, 600, 800]
rows = []
for lo_, hi_ in zip(edges[:-1], edges[1:]):
    expo = float(np.clip(T - lo_, 0, hi_ - lo_).sum())
    nf = int(((tt_all > lo_) & (tt_all <= hi_)).sum())
    ci = (stats.chi2.ppf(0.025, 2 * nf) / 2 if nf > 0 else 0.0, stats.chi2.ppf(0.975, 2 * (nf + 1)) / 2)
    rows.append({"tramo": f"({lo_},{hi_}]", "motor_dias": expo, "eventos": nf, "n_motores_en_riesgo_inicio": int((T > lo_).sum()),
                 "tasa_x1000_motor_dia": 1000 * nf / expo if expo > 0 else None, "ic95": [1000 * ci[0] / expo, 1000 * ci[1] / expo]})
tot_e = sum(x["motor_dias"] for x in rows)
chi_t = float(2 * sum(x["eventos"] * np.log(x["eventos"] / (Ntot * x["motor_dias"] / tot_e)) for x in rows if x["eventos"] > 0))
out["tasa_tramos"] = {"tabla": rows, "LR_tasa_constante": chi_t, "gl": len(rows) - 1, "p": float(stats.chi2.sf(chi_t, len(rows) - 1)),
                      "nota": "tramos definidos de forma regular (100 d) antes de ajustar; asume eventos independientes dentro del tramo (ignora heterogeneidad entre motores)"}
# pendiente de tasa en el tiempo: Poisson log-lineal en el centro del tramo (comprobacion)
import numpy.linalg as la
xc = np.array([(a + b) / 2 for a, b in zip(edges[:-1], edges[1:])]); yv = np.array([x["eventos"] for x in rows]); off = np.log([x["motor_dias"] for x in rows])
X = np.c_[np.ones_like(xc), xc - xc.mean()]
bt = np.zeros(2)
for _ in range(100):
    mu_ = np.exp(X @ bt + off); Wm = np.diag(mu_); step = la.solve(X.T @ Wm @ X, X.T @ (yv - mu_)); bt += step
cov_b = la.inv(X.T @ np.diag(np.exp(X @ bt + off)) @ X); se_s = float(np.sqrt(cov_b[1, 1]))
out["tasa_tramos"]["log_lineal"] = {"pendiente_por_dia": float(bt[1]), "se": se_s, "z": float(bt[1] / se_s), "p": float(2 * stats.norm.sf(abs(bt[1] / se_s))),
                                    "efecto_por_100d_x": float(np.exp(100 * bt[1])), "ic95_x_por_100d": [float(np.exp(100 * (bt[1] - 1.96 * se_s))), float(np.exp(100 * (bt[1] + 1.96 * se_s)))]}


# ---------------- barrido de ventana (exploratorio; multiples miradas, sin correccion) ----------------
scan = []
for c in (300, 400, 500, 575, 600, 640, 700, 761):
    evc = [[x for x in v if x <= c] for v in ev_list]; Tc_ = np.minimum(T, c)
    nn = sum(len(v) for v in evc)
    if nn < 3: continue
    uu = np.sort(np.concatenate([np.asarray(v) / e for v, e in zip(evc, Tc_)]))
    f_ = fit_crow_amsaa(uu, 1.0, terminated="time")
    U_, p_, _ = pooled_laplace(evc, Tc_)
    scan.append({"ventana_dias": c, "eventos": nn, "beta_insesgado": f_.beta, "ic95": f_.beta_ci, "laplace_U": U_, "p": p_})
out["barrido_ventana"] = scan
# ---------------- cohortes por fin de observacion (inferencia a partir del id/T_k; NO hay covariables en los datos) ----------------
long_ = T >= 640
coh = {}
for name, mask in (("T_fin>=640 d", long_), ("T_fin<640 d", ~long_)):
    idxs = np.where(mask)[0]
    evc = [ev_list[k] for k in idxs]; Tc_ = T[idxs]
    nn = sum(len(v) for v in evc)
    uu = np.sort(np.concatenate([np.asarray(v) / e for v, e in zip(evc, Tc_)])) if nn >= 3 else None
    row = {"motores": int(mask.sum()), "eventos": nn, "motor_dias": float(Tc_.sum()), "tasa_x1000": float(1000 * nn / Tc_.sum()),
           "eventos_<=400d": int(sum(sum(x <= 400 for x in v) for v in evc)), "eventos_>400d": int(sum(sum(x > 400 for x in v) for v in evc)),
           "ids": [int(ids[k]) for k in idxs]}
    if uu is not None:
        f_ = fit_crow_amsaa(uu, 1.0, terminated="time"); U_, p_, _ = pooled_laplace(evc, Tc_)
        row.update({"beta_insesgado": f_.beta, "ic95": f_.beta_ci, "laplace_U": U_, "laplace_p": p_})
    coh[name] = row
out["cohortes_exploratorio"] = coh

# ---------------- figuras ----------------
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
foot = f"n={len(ids)} motores, {Ntot} reemplazos; datos: Rdatasets survival::valveSeat; tiempo = dia de inspeccion"
fig, (ax, ax2) = plt.subplots(2, 1, figsize=(6.6, 5.6), gridspec_kw={"height_ratios": [4, 1]}, sharex=True)
tm = np.r_[0, ln["time"]]; mm = np.r_[0, ln["mcf"]]
ax.fill_between(ln["time"], ln["lo"], ln["hi"], step="post", color=GREY, alpha=0.25, label="IC 95 % (Lawless-Nadeau, log)")
ax.step(tm, mm, where="post", color=ACC, lw=1.8, label="MCF (Nelson), duplicados contados")
ax.plot([0, 575], [0, ln["mcf"][j_ref]], color="k", lw=0.8, ls="--", label="Referencia lineal (HPP) hasta 575 d")
ax.set_ylabel("Reemplazos acumulados por motor"); ax.legend(frameon=False, fontsize=7.5, loc="upper left")
ax.set_title("Valve seats: MCF multi-motor", loc="left")
ax2.step(ln["time"], ln["n_risk"], where="post", color=GREY); ax2.set_ylabel("motores\nobservados"); ax2.set_xlabel("Dias (de inspeccion)")
fig.text(0.01, -0.035, foot + "; IC unilateral cola derecha poco fiable donde n<10", fontsize=6.5, color=GREY)
fig.savefig(F / "valveseat_mcf.png", dpi=600, bbox_inches="tight"); plt.close(fig)

fig, ax = plt.subplots(figsize=(6, 4.5))
ax.loglog(ln["time"], ln["mcf"], "o", color=GREY, ms=3.5, label="MCF empirica")
tg = np.linspace(40, 700, 100)
# MCF del modelo (A) escalada: lambda_com (B) como curva de referencia, y recta de pendiente 1 (HPP) por el punto medio
lc = out["crow_amsaa_lambda_comun"]["lambda"]; bcm = out["crow_amsaa_lambda_comun"]["beta_mle"]
ax.loglog(tg, lc * tg ** bcm, color=ACC, lw=1.6, label=f"Crow-AMSAA lambda comun, beta={bcm:.2f}")
ax.loglog(tg, lc * tg ** bcm * 0 + (Ntot / np.sum(T)) * tg, color=LG, ls="--", label="HPP (beta=1), misma exposicion")
ax.set_xlabel("Dias (log)"); ax.set_ylabel("Reemplazos acumulados por motor (log)"); ax.legend(frameon=False, fontsize=7.5)
ax.set_title("Valve seats: ajuste Crow-AMSAA (log-log)", loc="left")
fig.text(0.01, -0.035, foot + "; modelo con lambda comun (MIL-HDBK-189 multi-sistema)", fontsize=6.5, color=GREY)
fig.savefig(F / "valveseat_crow_amsaa_loglog.png", dpi=600, bbox_inches="tight"); plt.close(fig)

fig, ax = plt.subplots(figsize=(6.2, 4.2))
xm = np.arange(len(rows)); y = [x["tasa_x1000_motor_dia"] for x in rows]
ax.errorbar(xm, y, yerr=[[a_ - x["ic95"][0] for a_, x in zip(y, rows)], [x["ic95"][1] - a_ for a_, x in zip(y, rows)]], fmt="o", color=ACC, capsize=3)
ax.axhline(1000 * Ntot / tot_e, color=GREY, ls="--", lw=1, label=f"tasa global {1000 * Ntot / tot_e:.2f}")
ax.set_xticks(xm); ax.set_xticklabels([f"{x['tramo']}\n{x['eventos']} ev." for x in rows], fontsize=7)
ax.set_ylabel("reemplazos por 1000 motor-dias"); ax.set_xlabel("tramo de dias"); ax.legend(frameon=False)
ax.set_title("Valve seats: tasa de reemplazo por tramo (IC 95 % Poisson)", loc="left", fontsize=9)
fig.text(0.01, -0.035, foot, fontsize=6.5, color=GREY); fig.savefig(F / "valveseat_tasa_tramos.png", dpi=600, bbox_inches="tight"); plt.close(fig)

json.dump(out, open(W / "valveseat_results.json", "w"), indent=1, default=float)
print(json.dumps(out, indent=1, default=float))

"""Caso 1: genfan (70 ventiladores, NO reparables, censura por derecha).
Uso: python -I 01_genfan.py   (lee work/genfan.csv, escribe figs/ y work/genfan_results.json)
Herramientas: reliability_kit (Weibull MLE, LR beta, bootstrap, AIC, KM, rangos de Johnson)
+ codigo propio para lo que el kit NO cubre (IC de B10 por verosimilitud perfilada,
  exponencial exacto, GoF por bootstrap parametrico, hazard por tramos, LFP).
Semilla fija 20260101.
"""
import json, sys, platform
from pathlib import Path
import numpy as np, pandas as pd, scipy
from scipy import stats, optimize
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, "/home/user/clima-lima/tools/reliability")
from reliability_kit.weibull import (fit_weibull_mle, weibull_beta_ci_lr, weibull_bootstrap_ci,
                                     compare_models, rank_regression, johnson_median_ranks,
                                     _fit_lognormal, interpret_beta)
from reliability_kit.survival import kaplan_meier

BASE = Path(__file__).resolve().parent
W = BASE / "work"; F = BASE / "figs"
SEED = 20260101
ACC, GREY, LG = "#C0392B", "#5D6D7E", "#B2BABB"
rng = np.random.default_rng(SEED)
out = {"versions": {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__,
                    "pandas": pd.__version__, "matplotlib": matplotlib.__version__}, "seed": SEED}

# ---------------- datos y auditoria ----------------
df = pd.read_csv(W / "genfan.csv")
raw_nonint = int((df.hours != df.hours.round(6)).sum())
df["t"] = df.hours.round(6)                       # ruido de punto flotante (459.99999999999994 -> 460)
df["t"] = df.t.round(3)
t = df.t.to_numpy(float); d = df.status.to_numpy(int).astype(bool); cens = ~d
audit = {"filas": len(df), "nulos": int(df.isna().sum().sum()), "filas_con_par_(t,status)_repetido(empates, no error)": int(df.duplicated(["t", "status"]).sum()),
         "valores_con_ruido_flotante": raw_nonint, "status_valores": sorted(df.status.unique().tolist()),
         "n_fallas": int(d.sum()), "n_censuras": int(cens.sum()), "pct_censura": float(cens.mean() * 100),
         "t_min": float(t.min()), "t_max": float(t.max()), "t_fallas": sorted(t[d].tolist()),
         "t_fallas_distintos": int(len(set(t[d]))), "empates_falla_censura": sorted(set(t[d]) & set(t[cens])),
         "horas_expuestas_total": float(t.sum()), "censuras_antes_de_primera_falla": int((t[cens] < t[d].min()).sum()),
         "censuras_con_t_mayor_que_ultima_falla": int((t[cens] > t[d].max()).sum())}
out["audit"] = audit

# ---------------- Weibull (kit) ----------------
w = fit_weibull_mle(t, cens)
b_lr = weibull_beta_ci_lr(t, cens)
boot_beta = weibull_bootstrap_ci(t, cens, stat="beta", n_boot=2000, seed=SEED)
boot_eta = weibull_bootstrap_ci(t, cens, stat="eta", n_boot=2000, seed=SEED)
boot_b10 = weibull_bootstrap_ci(t, cens, stat="b_life", p=0.10, n_boot=2000, seed=SEED)
boot_mttf = weibull_bootstrap_ci(t, cens, stat="mttf", n_boot=2000, seed=SEED)
rrx = rank_regression(t, cens)
out["weibull"] = {"beta": w.beta, "eta": w.eta, "loglik": w.loglik, "warnings": w.warnings, "beta_ci_LR95": b_lr,
                  "boot_beta": boot_beta, "boot_eta": boot_eta, "boot_B10": boot_b10, "boot_mttf": boot_mttf,
                  "B10_mle": w.b_life(0.10), "B50_mle": w.b_life(0.5), "mttf_mle": w.mttf, "rrx": rrx,
                  "interpret": interpret_beta(w.beta, b_lr)}
# P(beta<=1) por LR unilateral y por bootstrap
def ll_w(beta, eta, t, d):
    r = d.sum(); return r*np.log(beta) - r*beta*np.log(eta) + (beta-1)*np.log(t[d]).sum() - ((t/eta)**beta).sum()
def prof_w_beta(beta, t, d):
    r = d.sum(); eta = ((t**beta).sum()/r)**(1/beta); return ll_w(beta, eta, t, d)
lr_b1 = 2*(w.loglik - prof_w_beta(1.0, t, d))
out["weibull"]["LR_beta_eq_1"] = {"stat": float(lr_b1), "p_bilateral": float(stats.chi2.sf(lr_b1, 1))}
# bootstrap manual de beta para P(beta>1) (misma semilla/ procedimiento que el kit, 2000 remuestreos)
bb = []
r2 = np.random.default_rng(SEED)
for _ in range(2000):
    idx = r2.integers(0, len(t), len(t))
    try: bb.append(fit_weibull_mle(t[idx], cens[idx]).beta)
    except ValueError: pass
bb = np.array(bb); out["weibull"]["boot_P_beta_gt_1"] = float((bb > 1).mean()); out["weibull"]["boot_beta_n_ok"] = int(len(bb))

# ---------------- Exponencial (exacta) ----------------
r = int(d.sum()); Ttot = float(t.sum()); lam = r/Ttot; mtbf = Ttot/r
a = 0.05
mtbf_ci = (2*Ttot/stats.chi2.ppf(1-a/2, 2*r), 2*Ttot/stats.chi2.ppf(a/2, 2*r))   # terminacion por tiempo, aprox. 2r gl (tipo II para limite inf. 2r+2: se declara)
mtbf_ci_t1 = (2*Ttot/stats.chi2.ppf(1-a/2, 2*r+2), 2*Ttot/stats.chi2.ppf(a/2, 2*r))  # estandar para terminacion por tiempo
b10_exp = -np.log(0.9)/lam
b10_exp_ci = (-np.log(0.9)*mtbf_ci_t1[0], -np.log(0.9)*mtbf_ci_t1[1])   # B10 = -ln(0.9)*MTBF
out["exponential"] = {"lambda_per_h": lam, "mtbf_h": mtbf, "mtbf_ci95_chi2": mtbf_ci_t1,
                      "B10": b10_exp, "B10_ci95": b10_exp_ci,
                      "nota": "IC chi2 (2r+2 gl inferior, 2r superior) para ventana censurada por tiempo; MTBF NO es vida segura"}

# ---------------- Lognormal ----------------
ln = _fit_lognormal(t, d)
mu, sg = ln["params"]["mu"], ln["params"]["sigma"]
z10 = stats.norm.ppf(0.10)
b10_ln = float(np.exp(mu + sg*z10))
out["lognormal"] = {"mu": mu, "sigma": sg, "loglik": ln["loglik"], "B10": b10_ln}
# validacion independiente de lognormal: maximizacion con L-BFGS-B desde otros arranques
def nll_ln(p, t=t, d=d):
    m, ls = p; s = np.exp(ls); z = (np.log(t)-m)/s
    return -((stats.norm.logpdf(z[d]) - ls - np.log(t[d])).sum() + stats.norm.logsf(z[~d]).sum())
alt = min((optimize.minimize(nll_ln, x0, method="L-BFGS-B") for x0 in ([6, 0.0], [9, 1.0], [12, 0.5])), key=lambda q: q.fun)
out["lognormal"]["validacion_LBFGSB"] = {"mu": float(alt.x[0]), "sigma": float(np.exp(alt.x[1])), "loglik": float(-alt.fun),
                                         "dif_loglik": float(abs(-alt.fun - ln["loglik"]))}

# ---------------- IC de B10 por verosimilitud perfilada (propio; el kit no lo trae) ----------------
P = 0.10
cw = (-np.log(1-P))
def prof_ll_b10_weibull(b10, t=t, d=d):
    # eta = b10 / cw^(1/beta); maximiza sobre beta
    f = lambda lb: -ll_w(np.exp(lb), b10/cw**(1/np.exp(lb)), t, d)
    res = optimize.minimize_scalar(f, bounds=(np.log(0.05), np.log(30)), method="bounded", options={"xatol": 1e-10})
    return -res.fun
def prof_ll_b10_lognormal(b10, t=t, d=d):
    def f(ls):
        s = np.exp(ls); m = np.log(b10) - s*z10; z = (np.log(t)-m)/s
        return -((stats.norm.logpdf(z[d]) - ls - np.log(t[d])).sum() + stats.norm.logsf(z[~d]).sum())
    res = optimize.minimize_scalar(f, bounds=(np.log(0.05), np.log(10)), method="bounded", options={"xatol": 1e-10})
    return -res.fun
def profile_ci(fn, llmax, b_hat, conf=0.95):
    crit = stats.chi2.ppf(conf, 1)
    g = lambda lb: 2*(llmax - fn(np.exp(lb))) - crit
    lo = np.log(b_hat); step = 0.1
    while g(lo) < 0 and lo > np.log(1e-2): lo -= step
    hi = np.log(b_hat)
    while g(hi) < 0 and hi < np.log(1e7): hi += step
    L = optimize.brentq(g, lo, np.log(b_hat)) if g(lo) > 0 else np.nan
    U = optimize.brentq(g, np.log(b_hat), hi) if g(hi) > 0 else np.nan
    return float(np.exp(L)), float(np.exp(U))
b10_w = w.b_life(P)
ci_b10_w = profile_ci(prof_ll_b10_weibull, w.loglik, b10_w)
ci_b10_ln = profile_ci(prof_ll_b10_lognormal, ln["loglik"], b10_ln)
out["weibull"]["B10_ci_LR95"] = ci_b10_w
out["lognormal"]["B10_ci_LR95"] = ci_b10_ln
# validacion del perfil por fuerza bruta (rejilla beta, independiente de minimize_scalar)
def brute_prof(b10):
    bs = np.linspace(0.2, 6, 4000)
    return max(ll_w(b, b10/cw**(1/b), t, d) for b in bs)
val = {"perfil_en_MLE_vs_llmax": float(abs(prof_ll_b10_weibull(b10_w) - w.loglik)),
       "dif_perfil_vs_rejilla_en_B10_lo": float(abs(prof_ll_b10_weibull(ci_b10_w[0]) - brute_prof(ci_b10_w[0]))),
       "dif_perfil_vs_rejilla_en_B10_hi": float(abs(prof_ll_b10_weibull(ci_b10_w[1]) - brute_prof(ci_b10_w[1]))),
       "dev_en_extremos_IC (debe ser 3.841)": [float(2*(w.loglik - prof_ll_b10_weibull(x))) for x in ci_b10_w]}
out["validacion_perfil_B10"] = val
# bootstrap lognormal B10 (para contraste)
bl = []
r3 = np.random.default_rng(SEED+1)
for _ in range(1000):
    idx = r3.integers(0, len(t), len(t))
    if d[idx].sum() < 2: continue
    q = _fit_lognormal(t[idx], d[idx]); bl.append(np.exp(q["params"]["mu"] + q["params"]["sigma"]*z10))
bl = np.array(bl); out["lognormal"]["B10_boot_ci95_percentil"] = [float(np.quantile(bl, .025)), float(np.quantile(bl, .975))]
out["lognormal"]["B10_boot_n_ok"] = int(len(bl))

# ---------------- comparacion AIC (kit) ----------------
cm = compare_models(t, cens)
out["aic"] = [{"model": m["model"], "k": m["k"], "loglik": m["loglik"], "aic": m["aic"], "delta_aic": m["delta_aic"], "params": m["params"]} for m in cm]
# BIC
for m in out["aic"]: m["bic"] = m["k"]*np.log(len(t)) - 2*m["loglik"]

# ---------------- Kaplan-Meier (kit) y B10 no parametrico ----------------
km = kaplan_meier(t, d)
def km_quantile_time(km, level):
    i = np.where(km.survival <= level)[0]; return float(km.time[i[0]]) if i.size else float("nan")
b10_km = km_quantile_time(km, 0.90)
# IC: B10 es el primer t con S<=0.9; limites: t donde el limite inferior de S cruza 0.9 (cota inferior de t) y el superior (cota superior de t)
b10_km_lo = km_quantile_time(type("K", (), {"survival": km.lower, "time": km.time}), 0.90)
b10_km_hi = km_quantile_time(type("K", (), {"survival": km.upper, "time": km.time}), 0.90)
out["km"] = {"n_eventos_distintos": int(len(km.time)), "S_final": float(km.survival[-1]), "t_ultima_falla": float(km.time[-1]),
             "S_min_IC_inf": float(km.lower[-1]), "S_min_IC_sup": float(km.upper[-1]),
             "mediana": km.median(), "B10_km": b10_km, "B10_km_ic95": [b10_km_lo, b10_km_hi],
             "nota": "limite superior de S nunca baja de 0.9 => cota superior de B10 no acotada si nan",
             "tabla": [{"t": float(a_), "n_riesgo": int(b_), "d": int(c_), "S": float(s_), "lo": float(l_), "hi": float(h_)}
                       for a_, b_, c_, s_, l_, h_ in zip(km.time, km.n_risk, km.n_event, km.survival, km.lower, km.upper)]}
# S(t) parametrica en tiempos de interes vs KM
grid_t = [1000, 2000, 3000, 5000, 8000, 10000]
cmp_tab = []
for gt in grid_t:
    cmp_tab.append({"t": gt, "KM": km.at(gt), "Weibull": float(w.reliability(gt)),
                    "Lognormal": float(stats.norm.sf((np.log(gt)-mu)/sg)), "Exponencial": float(np.exp(-lam*gt))})
out["S_comparacion"] = cmp_tab

# ---------------- GoF: distancia KM-modelo con bootstrap parametrico (censura ~ KM inversa) ----------------
def reverse_km_atoms(t, d):
    # distribucion de censura estimada: KM con "eventos" = censuras (empates: fallas antes que censuras no se cuentan como riesgo perdido)
    ut = np.unique(t[~d]); S = 1.0; atoms = []; mass = []
    for u in ut:
        n_i = (t >= u).sum() - ((t == u) & d).sum()*0  # riesgo de censura en u
        n_i = (t >= u).sum(); c_i = ((t == u) & ~d).sum()
        # censura informativa: las fallas en u se consideran antes que censuras en u => riesgo para censura excluye fallas con t==u ya ocurridas? convencion: no
        h = c_i/n_i; atoms.append(u); mass.append(S*h); S *= (1-h)
    atoms = np.array(atoms); mass = np.array(mass)
    return atoms, mass, S   # S = masa restante (censura infinita)
atoms, mass, S_rest = reverse_km_atoms(t, d)
def sample_cens(n, rg):
    p = np.r_[mass, S_rest]; p = p/p.sum(); v = np.r_[atoms, np.inf]
    return rg.choice(v, size=n, p=p)
def km_dist(t, d, cdf):
    ut = np.unique(t[d]); best = 0.0; S = 1.0
    for u in ut:
        n_i = (t >= u).sum(); d_i = ((t == u) & d).sum()
        F_before = 1 - S; S *= 1 - d_i/n_i; F_after = 1 - S
        c = cdf(u); best = max(best, abs(F_before - c), abs(F_after - c))
    return best
def fitters():
    def wf(tt, dd):
        f = fit_weibull_mle(tt, ~dd); return (lambda x: 1-np.exp(-(x/f.eta)**f.beta)), (lambda rg, n: f.eta*rg.weibull(f.beta, n))
    def lf(tt, dd):
        q = _fit_lognormal(tt, dd); m, s = q["params"]["mu"], q["params"]["sigma"]
        return (lambda x: stats.norm.cdf((np.log(x)-m)/s)), (lambda rg, n: np.exp(m + s*rg.standard_normal(n)))
    def ef(tt, dd):
        l = dd.sum()/tt.sum(); return (lambda x: 1-np.exp(-l*x)), (lambda rg, n: rg.exponential(1/l, n))
    return {"weibull": wf, "lognormal": lf, "exponential": ef}
gof = {}
NSIM = 400
for name, fit in fitters().items():
    cdf, sim = fit(t, d)
    obs = km_dist(t, d, cdf); cnt = 0; ok = 0
    rg = np.random.default_rng(SEED+7)
    for _ in range(NSIM):
        x = sim(rg, len(t)); c = sample_cens(len(t), rg)
        tt = np.minimum(x, c); dd = x <= c
        if dd.sum() < 3 or np.ptp(tt[dd]) == 0: continue
        try: cdf_s, _ = fit(tt, dd)
        except Exception: continue
        ok += 1; cnt += km_dist(tt, dd, cdf_s) >= obs
    gof[name] = {"D_obs": float(obs), "p_boot": float((cnt+1)/(ok+1)), "n_sim_ok": ok}
out["gof_KS_boot"] = gof
out["gof_nota"] = "Distancia tipo Kolmogorov entre KM y CDF parametrica, p por bootstrap parametrico con censura remuestreada de la KM inversa; aproximado, con 12 fallas la potencia es baja"

# ---------------- hazard por tramos (modos mezclados / infantil / desgaste) ----------------
edges = [0, 1000, 2500, 5000, 12000]
rows = []
for lo_, hi_ in zip(edges[:-1], edges[1:]):
    expo = float(np.clip(t, lo_, hi_).sum() - lo_*(t > lo_).sum() * 1.0) if False else float((np.minimum(t, hi_) - lo_).clip(min=0).sum())
    nf = int(((t > lo_) & (t <= hi_) & d).sum())
    ci = (stats.chi2.ppf(0.025, 2*nf)/2 if nf > 0 else 0.0, stats.chi2.ppf(0.975, 2*(nf+1))/2)
    rows.append({"tramo": f"({lo_},{hi_}]", "horas_expuestas": expo, "fallas": nf, "tasa_por_1000h": 1000*nf/expo,
                 "ic95_lo": 1000*ci[0]/expo, "ic95_hi": 1000*ci[1]/expo})
tot_f = sum(x["fallas"] for x in rows); tot_e = sum(x["horas_expuestas"] for x in rows)
chi = sum(2*(x["fallas"]*np.log(x["fallas"]/(tot_f*x["horas_expuestas"]/tot_e)) if x["fallas"] > 0 else 0)
          - 0 for x in rows)
# LR Poisson: 2*sum(O ln(O/E)) (el termino -(O-E) suma 0)
out["hazard_tramos"] = {"tabla": rows, "LR_tasa_constante": float(chi), "gl": len(rows)-1,
                        "p": float(stats.chi2.sf(chi, len(rows)-1)),
                        "cuidado": "tramos elegidos DESPUES de ver la lista de tiempos (no son a priori): p solo indicativo; 12 eventos => poca potencia"}
# test de tendencia (Poisson ponderado: Laplace para tasa dependiente del tiempo): estadistico score sobre edades de falla vs exposicion
# alternativa: LR beta=1 ya reportado.

# ---------------- LFP / subpoblacion defectuosa (exploratorio) ----------------
def nll_lfp(p3):
    p = 1/(1+np.exp(-p3[0])); b = np.exp(p3[1]); e = np.exp(p3[2])
    F = 1 - np.exp(-(t/e)**b); f = (b/e)*(t/e)**(b-1)*np.exp(-(t/e)**b)
    return -(np.log(p*f[d]).sum() + np.log(1 - p*F[~d]).sum())
best = None
for x0 in ([0, 0, 8], [-1, 0.5, 8], [1.5, 0.3, 9], [-2, 1, 7]):
    rs = optimize.minimize(nll_lfp, x0, method="Nelder-Mead", options={"maxiter": 20000, "xatol": 1e-9, "fatol": 1e-10})
    if best is None or rs.fun < best.fun: best = rs
p_hat = 1/(1+np.exp(-best.x[0]))
out["lfp"] = {"p": float(p_hat), "beta": float(np.exp(best.x[1])), "eta": float(np.exp(best.x[2])), "loglik": float(-best.fun),
              "aic": float(2*3 + 2*best.fun), "delta_aic_vs_weibull": float(2*3 + 2*best.fun - (2*2 - 2*w.loglik)),
              "nota": "p fraccion susceptible; p->1 equivale a Weibull. Exploratorio: 3 parametros con 12 fallas, no identificable de forma fiable"}

# ---------------- figuras ----------------
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
foot = f"n={len(t)} (fallas={r}, suspensiones={len(t)-r}); datos: Rdatasets survival::genfan; MLE con censura por derecha"
tf, Fm = johnson_median_ranks(t, cens)
fig, ax = plt.subplots(figsize=(6.4, 4.8))
xs = np.linspace(np.log(300), np.log(20000), 200)
ax.scatter(np.log(tf), np.log(-np.log(1-Fm)), color=GREY, s=22, zorder=3, label="Rangos medianos (Johnson/Bernard)")
ax.plot(xs, w.beta*(xs-np.log(w.eta)), color=ACC, lw=1.8, label=f"Weibull MLE  beta={w.beta:.2f}, eta={w.eta:,.0f} h")
ax.plot(xs, (xs-np.log(1/lam)) , color=LG, lw=1.5, ls="--", label=f"Exponencial (beta=1), MTBF={mtbf:,.0f} h")
ax.plot(xs, np.log(-np.log(stats.norm.sf((xs-mu)/sg))), color=GREY, lw=1.3, ls=":", label=f"Lognormal  mu={mu:.2f}, sigma={sg:.2f}")
ax.set_ylim(-6, 1.2)
yt = np.array([0.01, 0.02, 0.05, 0.1, 0.2, 0.4]); ax.set_yticks(np.log(-np.log(1-yt))); ax.set_yticklabels([f"{v:.0%}" for v in yt])
xt = np.array([500, 1000, 2000, 5000, 10000]); ax.set_xticks(np.log(xt)); ax.set_xticklabels(xt)
ax.set_xlabel("Horas de servicio (escala log)"); ax.set_ylabel("F(t) acumulada (escala Weibull)")
ax.set_title("Genfan: grafico de probabilidad Weibull", loc="left"); ax.legend(frameon=False, fontsize=7.5, loc="upper left")
fig.text(0.01, -0.035, foot + "; rangos: Johnson", fontsize=6.5, color=GREY); fig.savefig(F / "genfan_wwplot.png", dpi=600, bbox_inches="tight"); plt.close(fig)

fig, ax = plt.subplots(figsize=(6.4, 4.5))
xx = np.linspace(0, 11500, 600)
ax.step(np.r_[0, km.time], np.r_[1, km.survival], where="post", color=ACC, lw=1.8, label="Kaplan-Meier")
ax.fill_between(np.r_[0, km.time], np.r_[1, km.lower], np.r_[1, km.upper], step="post", color=ACC, alpha=0.15, label="IC 95 % KM (log-log)")
ax.plot(xx, w.reliability(xx), color=GREY, lw=1.4, label="Weibull")
ax.plot(xx, stats.norm.sf((np.log(np.maximum(xx, 1e-9))-mu)/sg), color=GREY, lw=1.2, ls=":", label="Lognormal")
ax.plot(xx, np.exp(-lam*xx), color=LG, lw=1.4, ls="--", label="Exponencial")
ax.axhline(0.9, color="k", lw=0.6, ls=":"); ax.text(11500, 0.905, "B10", ha="right", fontsize=7)
ax.set_ylim(0.4, 1.01); ax.set_xlabel("Horas de servicio"); ax.set_ylabel("S(t)")
ax.set_title("Genfan: Kaplan-Meier vs modelos parametricos", loc="left"); ax.legend(frameon=False, fontsize=7.5, loc="lower left")
fig.text(0.01, -0.035, foot + "; eje y truncado en 0.4", fontsize=6.5, color=GREY); fig.savefig(F / "genfan_km_vs_param.png", dpi=600, bbox_inches="tight"); plt.close(fig)

fig, ax = plt.subplots(figsize=(6, 4))
xm = np.arange(len(rows)); y = [x["tasa_por_1000h"] for x in rows]
ax.errorbar(xm, y, yerr=[[a_-x["ic95_lo"] for a_, x in zip(y, rows)], [x["ic95_hi"]-a_ for a_, x in zip(y, rows)]], fmt="o", color=ACC, capsize=3)
ax.axhline(1000*r/Ttot, color=GREY, ls="--", lw=1, label=f"tasa global = {1000*r/Ttot:.2f} /1000 h")
ax.set_xticks(xm); ax.set_xticklabels([f"{x['tramo']}\n{x['fallas']} fallas" for x in rows])
ax.set_ylabel("fallas por 1000 h expuestas"); ax.set_xlabel("tramo de edad (h)"); ax.legend(frameon=False)
ax.set_title("Genfan: tasa de falla empirica por tramo (IC 95 % Poisson exacto)", loc="left", fontsize=9)
fig.text(0.01, -0.035, foot + "; tramos fijados tras ver los datos (indicativo)", fontsize=6.5, color=GREY); fig.savefig(F / "genfan_hazard_tramos.png", dpi=600, bbox_inches="tight"); plt.close(fig)

fig, ax = plt.subplots(figsize=(6.4, 3.6))
items = [("Weibull MLE + LR perfilada", b10_w, ci_b10_w), ("Weibull bootstrap pct.", boot_b10["estimate"], (boot_b10["lower"], boot_b10["upper"])),
         ("Lognormal LR perfilada", b10_ln, ci_b10_ln), ("Exponencial exacta (chi2)", b10_exp, b10_exp_ci),
         ("Kaplan-Meier (no param.)", b10_km, (b10_km_lo, b10_km_hi if np.isfinite(b10_km_hi) else np.nan))]
for i, (lab, est, ci) in enumerate(items[::-1]):
    hi_ = ci[1] if np.isfinite(ci[1]) else 40000
    ax.plot([ci[0], hi_], [i, i], color=GREY, lw=2); ax.plot(est, i, "o", color=ACC)
    if not np.isfinite(ci[1]): ax.annotate("", xy=(40000, i), xytext=(30000, i), arrowprops=dict(arrowstyle="->", color=GREY))
ax.set_yticks(range(len(items))); ax.set_yticklabels([x[0] for x in items[::-1]], fontsize=8)
ax.set_xscale("log"); ax.set_xlabel("B10 (horas de servicio, escala log)"); ax.set_xlim(800, 12000)
ax.set_title("Genfan: B10 con IC 95 % segun metodo", loc="left")
fig.text(0.01, -0.035, foot + "; flecha = limite superior no acotado", fontsize=6.5, color=GREY); fig.savefig(F / "genfan_B10_metodos.png", dpi=600, bbox_inches="tight"); plt.close(fig)

out["b10_resumen"] = [{"metodo": a_, "B10": float(b_), "ic95": [float(c_[0]), float(c_[1])]} for a_, b_, c_ in items]
json.dump(out, open(W / "genfan_results.json", "w"), indent=1, default=float)
print(json.dumps({k: out[k] for k in ("audit", "weibull", "exponential", "lognormal", "aic", "km", "S_comparacion", "gof_KS_boot", "hazard_tramos", "lfp", "validacion_perfil_B10", "b10_resumen")}, indent=1, default=float))

"""Validacion: cobertura del IC exacto chi2 de beta (Crow-AMSAA condicional, 41 motores con T_k reales) por simulacion, 20000 reps, semilla 5.
Uso: python -I 03_validacion_cobertura.py"""
import numpy as np, sys, pandas as pd
from pathlib import Path
from scipy import stats
sys.path.insert(0, "/home/user/clima-lima/tools/reliability")
from reliability_kit.nhpp import fit_crow_amsaa
rg = np.random.default_rng(5)
df = pd.read_csv(Path(__file__).resolve().parent / "work" / "valveSeat.csv")
T = df[df.status == 0].groupby("id").time.max().values.astype(float)
beta = 1.5; sc = 48 / np.sum(T ** beta); cov_k = cov_m = 0; reps = 20000
for _ in range(reps):
    u = []
    for Tk in T:
        n = rg.poisson(sc * Tk ** beta); u += list(rg.uniform(size=n) ** (1 / beta))
    u = np.sort(np.array(u)); N = len(u); S = np.log(1 / u).sum()
    lo, hi = stats.chi2.ppf(.025, 2 * N) / (2 * S), stats.chi2.ppf(.975, 2 * N) / (2 * S)
    cov_m += lo <= beta <= hi
    f = fit_crow_amsaa(u, 1.0, terminated="time"); cov_k += f.beta_ci[0] <= beta <= f.beta_ci[1]
print({"cobertura_kit": cov_k / reps, "cobertura_chi2_manual": cov_m / reps, "reps": reps, "SE_MC": float(np.sqrt(.95 * .05 / reps))})

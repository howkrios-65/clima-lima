"""Demostracion de lo que NO se debe hacer: pasar al kit los tiempos de los 41 motores mezclados con T=max(T_k). Uso: python -I 04_ingenuo_kit_multiunidad.py"""
import sys, numpy as np, pandas as pd
from pathlib import Path
sys.path.insert(0, "/home/user/clima-lima/tools/reliability")
from reliability_kit.nhpp import fit_crow_amsaa, laplace_trend_test
df = pd.read_csv(Path(__file__).resolve().parent / "work" / "valveSeat.csv")
t = np.sort(df[df.status == 1].time.values.astype(float)); T = float(df.time.max())
f = fit_crow_amsaa(t, T, terminated="time"); l = laplace_trend_test(t, T)
print({"T_usado": T, "n": f.n, "beta_insesgado": f.beta, "ic95": f.beta_ci, "tendencia": f.trend, "laplace_U": l["U"], "p": l["p_value"]})

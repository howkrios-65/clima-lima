import datetime as dt
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
OUT="/home/user/clima-lima/reports/figures/"
V,S,N="#2a6f97","#e9a23b","#b5413b"
plt.rcParams.update({"font.size":10,"axes.spines.top":False,"axes.spines.right":False})

# Fig 1: conteo de filas/hallazgos por frente y estado (conteo manual sobre tablas de las notas)
fr=["N1 Agentes\ny academia","N2 Ecosistema\nabierto","N3 Normas","N4 Metodologías\ny KPIs","N5 ML\npredictivo","N6 Arquitectura\ny gobernanza"]
ver=[0,23,0,0,11,42]; snp=[24,13,44,15,22,20]; nv=[0,2,12,2,1,0]
fig,ax=plt.subplots(figsize=(8.6,4.4))
x=range(len(fr))
ax.bar(x,ver,color=V,label="VERIFICADO (página/API/abstract/doc leído)")
ax.bar(x,snp,bottom=ver,color=S,label="SOLO-SNIPPET")
ax.bar(x,nv,bottom=[a+b for a,b in zip(ver,snp)],color=N,label="NO-VERIFICADO")
for i in x:
    t=ver[i]+snp[i]+nv[i]; ax.text(i,t+1,str(t),ha="center",fontsize=9)
ax.set_xticks(list(x)); ax.set_xticklabels(fr,fontsize=8.5)
ax.set_ylabel("Filas/hallazgos en tablas de las notas"); ax.set_title("Fuentes por frente de investigación y estado de verificación")
ax.legend(frameon=False,fontsize=8.5,loc="upper left")
fig.text(0.01,0.005,"Fuente: conteo manual de filas de las tablas de hallazgos de las notas 01-06 (research_notes/Agentes mundiales de confiabilidad/). Una fila puede agrupar varias normas/papers.",fontsize=6.8,wrap=True)
fig.tight_layout(rect=(0,0.03,1,1)); fig.savefig(OUT+"fig1_fuentes_por_frente_y_estado.png",dpi=200); plt.close(fig)

# Fig 2: normas por seccion de N3 y estado
sec=["§1 Datos/\ntaxonomía","§2 Gestión\nde activos","§3 CM y\ndiagnóstico","§4 Falla y\nriesgo","§5 Estadística","§6 RCM","§7 KPIs","§8 IA y\nseguridad"]
ss=[3,3,11,9,7,3,1,7]; nvv=[1,2,2,1,3,1,2,0]
fig,ax=plt.subplots(figsize=(8.6,4.2))
x=range(len(sec))
ax.bar(x,ss,color=S,label="SOLO-SNIPPET"); ax.bar(x,nvv,bottom=ss,color=N,label="NO-VERIFICADO")
for i in x: ax.text(i,ss[i]+nvv[i]+0.2,f"{ss[i]+nvv[i]}",ha="center",fontsize=9)
ax.set_xticks(list(x)); ax.set_xticklabels(sec,fontsize=8); ax.set_ylabel("Filas de norma/documento")
ax.set_title("Normas: ninguna fila alcanza VERIFICADO (0 de 56)"); ax.legend(frameon=False)
fig.text(0.01,0.005,"Fuente: nota 03_normas_y_estandares.md, columna 'Verif.' de las tablas de §1-§8 (conteo manual; filas agrupadas cuentan una vez).",fontsize=6.8)
fig.tight_layout(rect=(0,0.03,1,1)); fig.savefig(OUT+"fig2_normas_estado_verificacion.png",dpi=200); plt.close(fig)

# Fig 3: antigüedad de última release PyPI (días a 2026-10-27), color por licencia
ref=dt.date(2026,10,27)
libs=[("lifelines","MIT","2026-03-05"),("reliability","LGPL-3","2025-03-07"),("scikit-survival","GPL-3","2026-07-05"),
("pycox","BSD","2024-09-04"),("sktime","BSD","2026-09-22"),("darts","Apache-2.0","2026-10-16"),("tsfresh","MIT","2026-05-31"),
("PyOD","BSD","2026-10-12"),("Merlion","BSD","2024-06-20"),("stumpy","BSD","2026-02-08"),("ProgPy","NOSA/NASA-1.3","2026-10-23"),
("tslearn","BSD","2026-10-22"),("statsforecast","Apache","2026-07-16"),("MLflow","(SPDX no leído)","2026-10-21")]
cols={"MIT":"#2a6f97","BSD":"#2a6f97","Apache-2.0":"#2a6f97","Apache":"#2a6f97","LGPL-3":"#e9a23b","GPL-3":"#b5413b","NOSA/NASA-1.3":"#e9a23b","(SPDX no leído)":"#8a8a8a"}
rows=sorted([(n,l,(ref-dt.date.fromisoformat(d)).days) for n,l,d in libs],key=lambda r:-r[2])
fig,ax=plt.subplots(figsize=(8.6,5))
ax.barh([r[0] for r in rows],[r[2] for r in rows],color=[cols[r[1]] for r in rows])
for i,r in enumerate(rows): ax.text(r[2]+8,i,f"{r[2]} d · {r[1]}",va="center",fontsize=8)
ax.set_xlim(0,max(r[2] for r in rows)*1.35); ax.set_xlabel("Días desde la última release en PyPI (a 2026-10-27)")
ax.set_title("Librerías: antigüedad de release y licencia (azul=permisiva; ámbar=revisar; rojo=copyleft fuerte; gris=sin SPDX)",fontsize=9)
fig.text(0.01,0.005,"Fuente: nota 02 §1 (metadatos de https://pypi.org/pypi/<paquete>/json, 2026-10-27). Días = 2026-10-27 menos fecha de release; cálculo propio.",fontsize=6.8)
fig.tight_layout(rect=(0,0.03,1,1)); fig.savefig(OUT+"fig3_librerias_antiguedad_licencia.png",dpi=200); plt.close(fig)

# Fig 4: ML tabla: evidencia por seccion
sec=["Surveys","Críticas a\nbenchmarks","Métricas","Supervivencia\ny UQ","FM y LLM"]
v=[3,2,0,5,1]; s=[4,7,3,3,5]; n=[0,0,1,0,0]
fig,ax=plt.subplots(figsize=(7.6,4)); x=range(5)
ax.bar(x,v,color=V,label="VERIFICADO-ABSTRACT"); ax.bar(x,s,bottom=v,color=S,label="SOLO-SNIPPET")
ax.bar(x,n,bottom=[a+b for a,b in zip(v,s)],color=N,label="NO-VERIFICADO")
ax.set_xticks(list(x)); ax.set_xticklabels(sec,fontsize=8.5); ax.set_ylabel("Filas en tablas de la nota 05")
ax.set_title("ML predictivo: la mayoría de la evidencia es de segunda mano"); ax.legend(frameon=False,fontsize=8.5)
fig.text(0.01,0.005,"Fuente: nota 05_ml_predictivo_estado_del_arte.md, tablas §1, §2, §3 y §5 (conteo manual).",fontsize=6.8)
fig.tight_layout(rect=(0,0.03,1,1)); fig.savefig(OUT+"fig4_ml_evidencia_por_seccion.png",dpi=200); plt.close(fig)
print(sum(ver),sum(snp),sum(nv))

import json
F="2026-10-27"
def e(i,tipo,acc,via,ref,ex,loc,af,lim,ap):
    d={"id":f"E-{i}","tipo":tipo,"acceso":acc,"via":via,"fecha_acceso":F,"referencia":ref,
       "afirma":af,"limites":lim,"aplica_a":ap,"revista_cuartil":None}
    if ex: d["extracto"]=ex; d["localizador"]=loc
    return d
HF="lector_hf_papers"
L=[]
L.append(e(9201,"preprint","texto_completo",HF,
 {"autores":"Gück, C., Roelofs, C. M. A., & Faulstich, S.","anio":2024,"titulo":"CARE to Compare: A real-world dataset for anomaly detection in wind turbine data","fuente":"arXiv 2404.10320","url":"https://arxiv.org/abs/2404.10320"},
 "The new dataset contains 89 years worth of real-world operating data of wind turbines, distributed across 44 labeled time frames for anomalies that led up to faults, as well as 51 time series representing normal behavior. ... This score considers the anomaly detection performance, the ability to recognize normal behavior properly and the capability to raise as few false alarms as possible while simultaneously detecting anomalies early.",
 "Abstract (paper.md del lector) e Introduction, parrafos 1 y 4",
 "Existe un criterio de evaluacion por evento para deteccion de anomalias en mantenimiento predictivo (CARE: cobertura, exactitud, fiabilidad, anticipacion) y un conjunto publico de datos de operacion real con intervalos de anomalia etiquetados y series normales. Sirve como plantilla de como medir un detector por evento, falsas alarmas y anticipacion, en vez de exactitud por segmento.",
 "Son datos SCADA de aerogeneradores (36 turbinas, 3 parques), no vibracion ni rodamientos de poleas de faja. No se leyo la seccion de resultados por modelo. Autoinforme de los autores. Se leyo el texto hasta el limite de 30000 caracteres del lector.",
 "Metricas por evento y falsas alarmas para cualquier detector que se proponga para la chumacera. Comparabilidad: baja en el activo, media en metodologia de evaluacion."))
L.append(e(9202,"preprint","abstract",HF,
 {"autores":"Leyva-Vazquez, M., Rumbaut Rangel, D., Cevallos-Torres, L., & Matheu Perez, A.","anio":2026,"titulo":"Neutrosophic Ensemble Classification for Uncertainty-Aware Bearing Fault Detection: Evidence from Laboratory and Variable-Speed Industrial Benchmarks","fuente":"arXiv 2610.06880","url":"https://arxiv.org/abs/2610.06880"},
 "On JNU, holding out 1000 rpm, accuracy collapses to 40.64 percent, below a majority-class baseline; Logistic Regression (57.91 percent) generalizes far better than the tree ensembles.",
 "Abstract (el lector entrego solo metadatos y resumen; texto completo no disponible)",
 "Con validacion dejando fuera una condicion de velocidad completa (leave-one-condition-out), un conjunto de clasificadores sobre rodamientos pasa de exactitud casi perfecta en CWRU a 40,64 por ciento en JNU al retener 1000 rpm, por debajo de la clase mayoritaria. Un modelo simple (regresion logistica) generaliza mejor que los arboles. Indica que la exactitud reportada en un banco no se traslada a otra condicion u otro banco.",
 "Solo se leyo el resumen del autor. Bancos de laboratorio (CWRU y JNU, 600 a 1000 rpm), no maquinas de planta. Preprint sin revision por pares vista. El propio resumen habla de una correccion de un error de mapeo archivo-clase en CWRU, lo que muestra fragilidad de los pipelines.",
 "Generalizacion entre condiciones y entre maquinas; riesgo de exactitud inflada en bancos publicos."))
L.append(e(9203,"preprint","texto_completo",HF,
 {"autores":"Sehri, M., Varejão, I., Hua, Z., Bonella, V., Santos, A., Boldt, F. A., Dumond, P., & Varejão, F. M.","anio":2025,"titulo":"Towards a Universal Vibration Analysis Dataset: A Framework for Transfer Learning in Predictive Maintenance and Structural Health Monitoring","fuente":"arXiv 2504.11581","url":"https://arxiv.org/abs/2504.11581","pais":"Canada; Brasil (afiliaciones de los autores en el documento)"},
 "However, the CWRU dataset was not specifically designed with ML applications in mind, and care must be taken to avoid misleading results. For example, issues related to data with similar load conditions may affect the generalizability of models (Hendriks, Dumond, & Knox, 2022; Rauber, da Silva Loca, Boldt, Rodrigues, & Varejão, 2021).",
 "Seccion 2.1.1 Case Western Reserve University (CWRU), parrafo 2",
 "Los propios autores de un marco de datos de vibracion advierten que CWRU no fue disenado para aprendizaje automatico y que cargas similares entre entrenamiento y prueba afectan la generalizacion, con riesgo de resultados enganosos. Remite a dos trabajos (Hendriks et al. 2022; Rauber et al. 2021) que no se leyeron.",
 "Es un marco propuesto (preprint); se leyo hasta 25000 caracteres, sin la seccion de resultados de transferencia. Las dos referencias que sustentan la advertencia son solo_referencia. Datos de banco, no de planta.",
 "Fuga de datos y generalizacion en diagnostico con bancos publicos."))
L.append(e(9204,"preprint","texto_completo",HF,
 {"autores":"Sehri, M., Varejão, I., Hua, Z., Bonella, V., Santos, A., Boldt, F. A., Dumond, P., & Varejão, F. M.","anio":2025,"titulo":"Towards a Universal Vibration Analysis Dataset: A Framework for Transfer Learning in Predictive Maintenance and Structural Health Monitoring","fuente":"arXiv 2504.11581","url":"https://arxiv.org/abs/2504.11581","pais":"Canada; Brasil (afiliaciones de los autores en el documento)"},
 "HUST data consists of a sampling frequency of 25,600 Hz with a sample duration of 20 seconds, and speeds ranging from 600 to 2,100 RPM ... The CWRU data consists of sampling frequencies of 12,000 and 48,000 Hz with a sample duration of 10 seconds, and speeds around 1,720 and 1,797 RPM",
 "Secciones 2.1.3 (HUST) y 2.1.1 (CWRU)",
 "Los bancos publicos de rodamientos que se reunen para entrenar modelos de vibracion operan a velocidades de 600 a 2100 rpm (HUST) y cerca de 1720 a 1797 rpm (CWRU), con rodamientos de bolas pequenos (por ejemplo 6203, 6205 en CWRU).",
 "Descripcion de datasets, no un estudio de desempeno. No dice nada de velocidades por debajo de 600 rpm ni de rodamientos de gran tamano; esa ausencia solo es una observacion sobre los datasets listados en este documento. La velocidad de la polea del caso no esta en la fuente.",
 "Brecha de dominio entre bancos publicos (alta velocidad, rodamiento pequeno) y chumacera de polea de baja velocidad."))
L.append(e(9205,"preprint","texto_completo",HF,
 {"autores":"Lillelund, C. M., Pannullo, F., Jakobsen, M. O., Morante, M., & Pedersen, C. F.","anio":2025,"titulo":"RULSurv: A probabilistic survival-based method for early censoring-aware prediction of remaining useful life in ball bearings","fuente":"arXiv 2405.01614 (version publicada: Expert Systems with Applications, segun la cabecera del preprint)","url":"https://arxiv.org/abs/2405.01614","pais":"Dinamarca (Aarhus University)"},
 "When predicting the time to failure for bearings under the highest load (C1, 12.0 kN and 2100 RPM) with 25% random censoring, our approach achieves a mean absolute error (MAE) of 14.7 minutes (95% CI = 13.6-15.8) using a linear CoxPH model, and an MAE of 12.6 minutes (95% CI = 11.8-13.4) using a nonlinear Random Survival Forests model, compared to an MAE of 18.5 minutes (95% CI = 17.4-19.6) using a linear LASSO model that does not support censoring.",
 "Abstract",
 "En el conjunto XJTU-SY con validacion cruzada de 5 particiones y 25 por ciento de censura aleatoria, los modelos de supervivencia que admiten censura tuvieron menor error absoluto medio (12,6 y 14,7 min) que un modelo sin censura (18,5 min). El error se expresa en minutos, lo que indica vidas de minutos a horas.",
 "Conjunto publico XJTU-SY de rodamientos de bolas (cinco por condicion); que sea un ensayo acelerado de banco es conocimiento previo del investigador, no verificado en el texto leido; en todo caso no se describe como dato de campo. Censura simulada al azar, no la censura real de una flota. Se leyo la introduccion y parte del trabajo relacionado (14000 caracteres). Tamano de muestra: cinco rodamientos por condicion segun el texto.",
 "Pronostico de vida remanente; ventaja de modelar censura. Comparabilidad con la chumacera: baja."))
L.append(e(9206,"preprint","texto_completo",HF,
 {"autores":"Lillelund, C. M., Pannullo, F., Jakobsen, M. O., Morante, M., & Pedersen, C. F.","anio":2025,"titulo":"RULSurv: A probabilistic survival-based method for early censoring-aware prediction of remaining useful life in ball bearings","fuente":"arXiv 2405.01614","url":"https://arxiv.org/abs/2405.01614","pais":"Dinamarca (Aarhus University)"},
 "Censored or incomplete observations are a prevalent phenomenon given the rarity of failures or breakdowns in ball bearings [16], but so far, only few studies have attempted to model or address the consequences of censoring [69, 68, 23, 76] and the literature on censored data is limited. We can choose to ignore censored observations and analyze only the data where we know the true outcome, but this would lead to a loss of information and introduce an estimation bias in the model parameters [57].",
 "Seccion 1 Introduction, parrafo 4",
 "Los autores sostienen que los datos censurados son frecuentes porque las fallas de rodamientos son raras, que pocos estudios los tratan, y que ignorarlos sesga la estimacion. Es un argumento de los autores apoyado en citas que no se leyeron.",
 "Es una afirmacion de introduccion con referencias no leidas. No cuantifica el sesgo. No es evidencia de campo.",
 "Planificacion de un pronostico con historial de planta: la censura (equipos cambiados antes de fallar) es un problema de diseno."))
L.append(e(9207,"preprint","texto_completo",HF,
 {"autores":"Razzaq, W., & Zhao, Y.-B.","anio":2025,"titulo":"CARLE: A Hybrid Deep-Shallow Learning Framework for Robust and Explainable RUL Estimation of Rolling Element Bearings","fuente":"arXiv 2510.17846","url":"https://arxiv.org/abs/2510.17846","pais":"China (University of Science and Technology of China)"},
 "It has been estimated that 40 to 50% of machinery failures can be attributed to these bearings [1]. ... Most of the methods reported in the literature are task-oriented, diminishing their real-world applicability for many industrial machinery operations where real conditions are highly variable.",
 "Seccion 1 Introduction, parrafos 1 y 5",
 "Cita secundaria de que 40 a 50 por ciento de las fallas de maquinaria se atribuye a rodamientos, y critica de los autores de que la mayoria de los metodos de pronostico son especificos de una tarea y poco aplicables en campo. Evalua con XJTU-SY y PRONOSTIA con validacion entre dominios.",
 "La cifra de 40 a 50 por ciento es cita de otra fuente (no leida) y se refiere a maquinaria rotativa en general, no a transportadores. El modelo se evalua solo en XJTU-SY y PRONOSTIA (conjuntos publicos de rodamientos; no se describen como datos de campo). No se leyeron los resultados numericos (9000 caracteres leidos). El texto del lector muestra el simbolo de porcentaje con un artefacto de conversion.",
 "Pronostico de vida remanente; limites de generalizacion. Prevalencia de rodamientos entre causas de falla (solo como cita secundaria)."))
L.append(e(9208,"preprint","texto_completo",HF,
 {"autores":"Jalonen, T., Al-Sa'd, M., Kiranyaz, S., & Gabbouj, M.","anio":2023,"titulo":"Real-Time Vibration-Based Bearing Fault Diagnosis Under Time-Varying Speed Conditions","fuente":"arXiv 2311.18547","url":"https://arxiv.org/abs/2311.18547"},
 "However, many existing techniques are developed and tested under strictly controlled conditions, limiting their adaptability to the diverse and dynamic settings encountered in practical applications. ... Nevertheless, studies have shown that vibration is one of the most reliable and cost-effective techniques, and allows capturing subtle changes in dynamics that are associated with early-stage defects",
 "Abstract; Seccion I Introduction, parrafo 1",
 "Los autores afirman que muchas tecnicas de diagnostico se desarrollan y prueban en condiciones controladas, y que la vibracion es una tecnica fiable y economica para defectos incipientes (con citas no leidas). Propone una CNN para velocidad variable con mejoras de hasta 15,8 por ciento de exactitud sobre un metodo previo.",
 "Banco de laboratorio con velocidad variable, no baja velocidad ni campo. La mejora de 15,8 por ciento es relativa a un metodo de referencia en sus propios datos. Se leyeron 9000 caracteres. Las afirmaciones sobre vibracion son citas secundarias.",
 "Generalizacion y vibracion como sensor; no sustenta desempeno a baja velocidad."))
L.append(e(9209,"preprint","texto_completo",HF,
 {"autores":"Peng, H., Liu, J., Du, J., Gao, J., & Wang, W.","anio":2024,"titulo":"BearLLM: A Prior Knowledge-Enhanced Bearing Health Management Framework with Unified Vibration Signal Representation","fuente":"arXiv 2408.11281","url":"https://arxiv.org/abs/2408.11281"},
 "Domain adaptation ... suffers from low accuracy when the source and target domains are category-inconsistent ... Domain generalization aims to extract domain-invariant features to improve performance on unseen domain [19, 47, 4], but it is often constrained to a limited number of working conditions with small differences, e.g., fewer than ten working conditions in [5, 22].",
 "Seccion 1 Introduction, parrafo 2",
 "Segun los autores, la adaptacion de dominio pierde exactitud cuando las categorias de falla difieren entre origen y destino, y la generalizacion de dominio suele probarse con pocas condiciones de operacion parecidas. Proponen un modelo unico con una referencia sin falla como entrada, reportando resultados en nueve bancos publicos.",
 "Es la descripcion de la literatura hecha por los autores del metodo; los resultados son autoinformados y en bancos de laboratorio. No se leyeron los experimentos (7000 caracteres leidos). No hay datos de campo.",
 "Generalizacion entre dominios; una referencia sin falla de la misma maquina como idea para linea base por activo."))
L.append(e(9210,"preprint","texto_completo",HF,
 {"autores":"El-Ghoussani, A., De Vita, M., Naumann, R., & Belagiannis, V.","anio":2026,"titulo":"Time-Series Foundation Model Embeddings for Remaining Useful Life Estimation","fuente":"arXiv 2606.11990","url":"https://arxiv.org/abs/2606.11990"},
 "To prevent temporal leakage, we employ a chronological split. The training set consists of windows ending at t\\leq T_{\\mathrm{train}}, while the test set contains windows where t>T_{\\mathrm{test}}. We select split points to achieve an 85{:}15 ratio. Crucially, we discard any window [t,...,T] that overlaps the boundary between splits.",
 "Seccion III-A Dataset and experimental setup, parrafo 2",
 "Con datos de sensores de equipos reales y etiquetas de vida remanente construidas desde registros de reparacion, los autores usan division cronologica y descartan ventanas que cruzan el limite, para evitar fuga temporal. Es un ejemplo de protocolo de validacion para pronostico con datos de campo.",
 "Los equipos son de telecomunicaciones (dos tipos de dispositivo, 87 y 51 canales), no rodamientos ni vibracion. Se validan dentro de la misma flota (division temporal), no entre maquinas. No se leyeron los resultados. Se leyeron 16000 caracteres.",
 "Protocolo de validacion y construccion de etiquetas con registros de falla para pronostico. Comparabilidad con el activo: baja."))
L.append(e(9211,"preprint","abstract",HF,
 {"autores":"Purohit, H., Tanabe, R., Ichige, K., Endo, T., Nikaido, Y., Suefusa, K., & Kawaguchi, Y.","anio":2019,"titulo":"MIMII Dataset: Sound Dataset for Malfunctioning Industrial Machine Investigation and Inspection","fuente":"arXiv 1909.09347","url":"https://arxiv.org/abs/1909.09347"},
 "there are no public datasets that focus on the sound of industrial machines under normal and anomalous operating conditions in real factory environments. ... Normal sounds were recorded for different types of industrial machines (i.e., valves, pumps, fans, and slide rails)",
 "Abstract (el lector entrego solo metadatos y resumen)",
 "Un conjunto publico de sonido de maquinas industriales (valvulas, bombas, ventiladores, rieles) en entorno de fabrica, con anomalias como contaminacion, fuga, desbalanceo y dano de riel. Muestra que la deteccion acustica de anomalias se ha desarrollado con maquinas distintas a transportadores.",
 "Solo abstract. No incluye bandas transportadoras ni rodamientos de polea. No se verifico en el texto la forma de las anomalias ni las metricas.",
 "Monitoreo acustico: existencia de datos publicos comparables; no es evidencia sobre transportadores."))
# snippets
L.append(e(9212,"paper","snippet","websearch",
 {"autores":"Alharbi, F., et al. (autoria completa no vista)","anio":2023,"titulo":"A Brief Review of Acoustic and Vibration Signal-Based Fault Detection for Belt Conveyor Idlers Using Machine Learning Models","fuente":"Sensors","url":"https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9959905/"},
 None,None,
 "Segun el resumen del buscador, existe una revision de deteccion de fallas de rodillos de transportador con senales acusticas y de vibracion y aprendizaje automatico, que cubre recoleccion de datos, procesamiento, extraccion y seleccion de caracteristicas y construccion del modelo, y cierra con retos abiertos.",
 "Solo snippet de buscador (la pagina no se pudo abrir en este entorno). No respalda ninguna cifra ni conclusion. Trata de rodillos, no de chumaceras de polea.",
 "Pista para localizar la revision principal de monitoreo de rodillos; debe leerse antes de citar."))
L.append(e(9213,"otro","snippet","websearch",
 {"titulo":"MIRA: A Transformer-Based Framework for Idler Roller Anomaly Detection and Localization","fuente":"Sensors (segun el buscador)","url":"https://www.ncbi.nlm.nih.gov/pmc/articles/PMC12736447/"},
 None,None,
 "Segun el resumen del buscador, un marco con transformador para detectar y localizar anomalias de rodillos se probo en un banco de transportador de 7 m, y sus autores senalan retos de generalizacion y robustez en condiciones reales.",
 "Solo snippet. Autores, anio y DOI no vistos. Banco de 7 m, no instalacion de planta. No respalda cifras.",
 "Pista sobre generalizacion de detectores de rodillos; leer antes de citar."))
L.append(e(9214,"otro","snippet","websearch",
 {"titulo":"Acoustic emission-based condition monitoring methods: review and application for low speed slew bearing","fuente":"Univ. of Wollongong, repositorio (segun el buscador)","url":"https://ro.uow.edu.au/eispapers/4863"},
 None,None,
 "Segun el resumen del buscador, una revision de emision acustica para cojinete giratorio de baja velocidad define baja velocidad como 10 a 600 rpm y muy baja como menos de 10 rpm, y su experimento detecto una falla inminente tras unos 15 meses de operacion continua.",
 "Solo snippet; autores y anio no vistos. Un solo cojinete giratorio en un experimento; no respalda desempeno general ni comparacion con vibracion.",
 "Pista sobre emision acustica en baja velocidad; leer antes de citar."))
L.append(e(9215,"preprint","snippet","websearch",
 {"autores":"Kobashikawa Rosa, et al. (autoria completa no vista)","anio":2024,"titulo":"Benchmarking deep learning models for bearing fault diagnosis using the CWRU dataset: A multi-label approach","fuente":"arXiv 2407.14625","url":"https://arxiv.org/html/2407.14625v1"},
 None,None,
 "Segun el resumen del buscador, los autores sostienen que dividir al azar segmentos de una misma senal entre entrenamiento y prueba en CWRU produce fuga de datos y resultados optimistas, y que particiones previas la reducen pero no la eliminan.",
 "Solo snippet; el lector de preprints no tenia este identificador y arxiv.org no es accesible. No respalda cifras. Autoria incompleta.",
 "Pista central para la pregunta de fuga de datos; leer antes de citar."))
L.append(e(9216,"otro","snippet","websearch",
 {"titulo":"arXiv 2509.22267 (titulo y autores no vistos en el snippet)","fuente":"arXiv","url":"https://arxiv.org/html/2509.22267v3"},
 None,None,
 "Segun el resumen del buscador, un preprint de 2025 afirma que las particiones por segmento y por condicion inflan las metricas y propone partir por rodamiento fisico, y que el numero de rodamientos distintos de entrenamiento afecta la generalizacion.",
 "Solo snippet; no se pudo abrir ni en el lector ni en la web. Sin titulo ni autores verificados. No respalda cifras.",
 "Pista para evaluacion sin fuga (particion por rodamiento); leer antes de citar."))
json.dump(L,open("/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_chumacera/evidencia2/frente_monitoreo2.json","w"),ensure_ascii=False,indent=1)

import json,sys,re
d=json.load(open(sys.argv[1]));c=d['results'][0]['result']['content'] if 'results' in d else d
n=int(sys.argv[2]) if len(sys.argv)>2 else 5000
print(len(c)); print(c[:n])
for kw in sys.argv[3:]:
    print('---',kw)
    for m in re.finditer(kw,c,re.I):
        s=max(0,m.start()-250);print('>>',c[s:m.end()+350].replace('\n',' '));print()

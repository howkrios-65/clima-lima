import json,sys,re
d=json.load(open(sys.argv[1]))
idx=int(sys.argv[2]); c=d['results'][idx]['result']['content']
print(len(c))
for kw in sys.argv[3:]:
    print('---',kw)
    for m in list(re.finditer(kw,c,re.I))[:4]:
        s=max(0,m.start()-300);print('>>',re.sub(r'\(https?://[^)]*\)','',c[s:m.end()+500]).replace('\n',' '));print()

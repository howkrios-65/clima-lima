const fs=require('fs');const S=process.argv[2];
const CFG=eval(fs.readFileSync(S+'/cfg.js','utf8').replace(/^const CFG=/,'(').replace(/;\s*$/,'')+')');
const ses={classification:'Sesión 1 · Clasificación de Fallas',anomaly:'Sesión 2 · Detección de Anomalías'};
const rows=[];
for(const k of ['classification','anomaly'])for(const m of CFG[k].models){
 rows.push({sesion:ses[k],id:m.id,modelo:m.name,resumen:m.short,que_hace:m.short+'. '+m.use.split(';')[0].length&&m.short,cuando_usarlo:m.use,datos:m.facts,metrica:m.metrics,evitar_si:m.avoid,familia:m.tags.join(' / '),
 etiquetas_ajuste_selector:m.fit,puntajes_comparador:{interpretabilidad:m.scores.interpret,no_lineal:m.scores.nonlinear,velocidad:m.scores.speed,pocos_datos:m.scores.small},parametros_visuales:m.params.map(p=>({nombre:p[0],min:p[1],max:p[2],paso:p[3],valor_inicial:p[4]}))});
}
for(const r of rows)r.que_hace=r.resumen;
console.log(JSON.stringify({c:CFG.classification.models.length,a:CFG.anomaly.models.length}));
const selector={
 origen:'Panel «¿Qué modelo conviene explorar primero?» (material aportado por la persona, pedagógico; no es evidencia científica).',
 texto_panel:'Selecciona el contexto del problema y el laboratorio filtrará modelos compatibles.',
 controles:{
  'Etiquetas de falla':{any:'No importa',yes:'Sí, tengo clases/etiquetas',few:'Muy pocas fallas etiquetadas',no:'No tengo etiquetas'},
  'Tipo de señal':{any:'Cualquiera',tabular:'Variables tabulares',timeseries:'Serie temporal / sensores',highdim:'Muchas variables'},
  'Prioridad':{any:'Equilibrada',interpret:'Interpretabilidad',performance:'Capacidad no lineal',fast:'Entrenamiento simple'},
  'Patrón esperado':{any:'No lo sé',global:'Anomalía global',local:'Anomalía local',cluster:'Regímenes operativos',sequence:'Dependencia temporal'}},
 reglas_filtro:[
  'Se ignoran los controles en «any». Si todos están en «any», no se filtra nada.',
  'Los controles activos se combinan con Y lógico: el modelo debe cumplir todos.',
  'Etiquetas = «Sí, tengo clases/etiquetas»: solo pasan los modelos de la Sesión 1 (Clasificación de Fallas); en la Sesión 2 no pasa ninguno.',
  'Etiquetas = «Muy pocas fallas etiquetadas» o «No tengo etiquetas»: en la Sesión 2 pasan todos los modelos en este criterio; en la Sesión 1 no pasa ninguno, porque ningún modelo de clasificación declara esos valores.',
  'Tipo de señal, Prioridad y Patrón: el modelo pasa si su lista de ajuste contiene el valor elegido (tabular, timeseries, highdim, interpret, performance, fast, global, local, cluster, sequence).',
  'El filtro actúa sobre la sesión (pestaña) activa; hay además un buscador por nombre.',
  'Si ningún modelo cumple todo, el panel muestra: «No hay modelos que cumplan todos los filtros. Prueba flexibilizar una condición.»'],
 orden_sugerencias:{regla:'Entre los modelos compatibles se ordenan de mayor a menor por un puntaje del comparador y se muestran como máximo 5 con la etiqueta «Explora:».',
  clave_orden:{'Interpretabilidad':'interpretabilidad','Capacidad no lineal':'no lineal','Entrenamiento simple':'velocidad','Equilibrada (o cualquier otro valor)':'pocos datos'}},
 modelos_por_valor:{}
};
const vals={'Etiquetas de falla':['yes','few','no'],'Tipo de señal':['tabular','timeseries','highdim'],'Prioridad':['interpret','performance','fast'],'Patrón esperado':['global','local','cluster','sequence']};
for(const k of ['classification','anomaly']){selector.modelos_por_valor[ses[k]]={};
 const ms=CFG[k].models;
 for(const [c,vs] of Object.entries(vals))for(const v of vs){
  let list;
  if(c==='Etiquetas de falla'){ if(v==='yes') list=k==='classification'?ms.map(m=>m.name):[]; else list=k==='anomaly'?ms.map(m=>m.name):ms.filter(m=>m.fit.includes(v)).map(m=>m.name);}
  else list=ms.filter(m=>m.fit.includes(v)).map(m=>m.name);
  selector.modelos_por_valor[ses[k]][c+' = '+v]=list;}}
selector.pipelines={[ses.classification]:CFG.classification.pipeline,[ses.anomaly]:CFG.anomaly.pipeline};
selector.comparador={texto:'Compara tres alternativas por criterios pedagógicos generales, no por accuracy inventada.',criterios:['Interpret.','No lineal','Velocidad','Pocos datos'],escala:'0 a 5 (se muestra n/5)'};
const adv={
 origen:'Nota «Importante» al pie del archivo (material aportado por la persona).',
 textos:[
  'Las visualizaciones no sustituyen validación con datos reales.',
  'Separar por tiempo/equipo.',
  'Evitar fuga de información.',
  'Controlar desbalance.',
  'Evaluar coste de falsos negativos.',
  'Revisar drift.',
  'Para anomalías, las métricas requieren etiquetas parciales, revisión experta o evaluación basada en eventos.'],
 otras_menciones_en_modelos:[
  'Las animaciones son conceptuales: sirven para comprender el comportamiento antes de pasar al entrenamiento real en Python.',
  'XGBoost: no asumir que siempre ganará; requiere tuning, validación temporal y control de leakage.',
  'CNN 1D: ventanas bien construidas y cuidado con leakage entre ventanas del mismo evento.',
  'LSTM / GRU: sensible al diseño de ventanas; no siempre supera a features temporales + boosting.',
  'Random Forest: modelos muy grandes consumen memoria y pueden ocultar drift.',
  'LSTM Autoencoder: ventanas, normalización, drift y costo de entrenamiento requieren mucha atención.',
  'Isolation Forest: threshold y contamination deben validarse con contexto operativo.',
  'Pie del comparador y métricas: sin cifras de accuracy; los puntajes son pedagógicos.']
};
const out={fuente:'reliabilit_ia_ml_visual_lab_v2_ampliado.html (Reliabilit-IA · ML Visual Lab v2)',estatus:'material aportado por la persona (pedagógico); no es evidencia científica',conteo:{total:rows.length,por_sesion:{[ses.classification]:CFG.classification.models.length,[ses.anomaly]:CFG.anomaly.models.length}},modelos:rows,selector,advertencias:adv};
fs.writeFileSync('/home/user/clima-lima/historial/dossiers/chumacera_polea_faja/ml_lab.json',JSON.stringify(out,null,1));
// markdown
const esc=s=>String(s).replace(/\|/g,'\\|');
let md=`# Referencia: ML Visual Lab v2 (modelos para mantenimiento predictivo)\n\nFuente: reliabilit_ia_ml_visual_lab_v2_ampliado.html (Reliabilit-IA · ML Visual Lab v2). Registro: **material aportado por la persona**, pedagógico; no es evidencia científica. Los puntajes (0 a 5) son criterios pedagógicos del archivo, no resultados medidos. Los datos estructurados están en historial/dossiers/chumacera_polea_faja/ml_lab.json.\n\nTotal: ${rows.length} modelos (${CFG.classification.models.length} en la Sesión 1, ${CFG.anomaly.models.length} en la Sesión 2).\n`;
for(const k of ['classification','anomaly']){
 md+=`\n## ${ses[k]} (${CFG[k].models.length} modelos)\n\nFlujo del archivo: ${CFG[k].pipeline.join(' → ')}.\n\n`;
 md+=`| Modelo | Qué hace | Cuándo usarlo | Datos | Métrica a vigilar | Evitar si | Familia | Interp / No lineal / Veloc / Pocos datos |\n|---|---|---|---|---|---|---|---|\n`;
 for(const m of CFG[k].models){const f=Object.entries(m.facts).map(([a,b])=>a+': '+b).join('; ');
  md+=`| ${esc(m.name)} | ${esc(m.short)} | ${esc(m.use)} | ${esc(f)} | ${esc(m.metrics)} | ${esc(m.avoid)} | ${esc(m.tags.join(' / '))} | ${m.scores.interpret}/${m.scores.nonlinear}/${m.scores.speed}/${m.scores.small} |\n`;}
}
md+=`\n## Selector: «¿Qué modelo conviene explorar primero?»\n\nEntradas (cuatro listas):\n\n| Control | Opciones |\n|---|---|\n`;
for(const [c,o] of Object.entries(selector.controles))md+=`| ${c} | ${Object.values(o).join('; ')} |\n`;
md+=`\nReglas:\n\n`+selector.reglas_filtro.map(r=>'- '+r).join('\n')+`\n\nOrden de las sugerencias: ${selector.orden_sugerencias.regla} Clave de orden: Interpretabilidad usa el puntaje de interpretabilidad; Capacidad no lineal usa el puntaje no lineal; Entrenamiento simple usa velocidad; Equilibrada usa pocos datos.\n\nModelos que pasan cada valor de filtro por sesión (según las listas de ajuste del archivo):\n\n`;
for(const k of ['classification','anomaly']){md+=`### ${ses[k]}\n\n| Valor del filtro | Modelos |\n|---|---|\n`;
 for(const [c,l] of Object.entries(selector.modelos_por_valor[ses[k]]))md+=`| ${c} | ${l.length?l.join(', '):'ninguno'} |\n`;md+='\n';}
md+=`Comparador rápido: ${selector.comparador.texto} Criterios: ${selector.comparador.criterios.join(', ')} (escala 0 a 5).\n\n## Advertencias de validación (nota al pie del archivo)\n\n`+adv.textos.map(t=>'- '+t).join('\n')+`\n\nOtras advertencias dentro de los modelos:\n\n`+adv.otras_menciones_en_modelos.map(t=>'- '+t).join('\n')+'\n';
fs.writeFileSync('/home/user/clima-lima/knowledge/ml_lab_referencia.md',md);

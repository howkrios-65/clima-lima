const { chromium } = require('playwright');
const OUT='/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/mapa/';
(async()=>{
  const b=await chromium.launch();
  const errs=[];
  async function mk(opts){const c=await b.newContext(opts);const p=await c.newPage();
    p.on('console',m=>{if(m.type()==='error'||m.type()==='warning')errs.push(m.type()+': '+m.text())});
    p.on('pageerror',e=>errs.push('pageerror: '+e.message));
    p.on('requestfailed',r=>errs.push('reqfailed: '+r.url()));
    return p}
  const url='file:///home/user/clima-lima/docs/agentes/mapa_agentes.html';
  // escritorio claro
  let p=await mk({viewport:{width:1440,height:900},colorScheme:'light'});
  await p.goto(url);await p.waitForTimeout(500);
  await p.screenshot({path:OUT+'01_desktop_full.png',fullPage:true});
  // doble clic
  await p.dblclick('.card[data-id="life"]');await p.waitForTimeout(500);
  await p.screenshot({path:OUT+'02_panel_life.png'});
  const title=await p.textContent('#dTitle');
  const blocks=await p.locator('.block').count();
  console.log('panel',title,blocks,'bloques', await p.textContent('#dBadge'));
  await p.mouse.click(200,400);await p.waitForTimeout(400);
  console.log('cerrado tras clic fuera:',!(await p.evaluate(()=>document.getElementById('drawer').classList.contains('open'))));
  // agente sin caso
  await p.dblclick('.card[data-id="integ"]');await p.waitForTimeout(400);
  await p.screenshot({path:OUT+'03_panel_integ.png'});
  await p.keyboard.press('Escape');await p.waitForTimeout(300);
  // reproducción
  await p.click('#playBtn');await p.waitForTimeout(700);
  const s1=await p.textContent('#stepNo');await p.screenshot({path:OUT+'04_play_step1.png',fullPage:true});
  await p.click('#nextBtn');await p.click('#nextBtn');await p.click('#nextBtn');await p.waitForTimeout(500);
  await p.screenshot({path:OUT+'05_step4.png',fullPage:true});
  console.log('paso',s1,'->',await p.textContent('#stepNo'));
  // avance automatico
  await p.click('#resetBtn');await p.click('#playBtn');await p.waitForTimeout(5600);
  console.log('tras 5.6 s en 1x:',await p.textContent('#stepNo'),'barra',await p.getAttribute('#barBox','aria-valuenow'));
  await p.click('#playBtn');
  for(let i=1;i<=11;i++){await p.evaluate(i=>window.__mapa.go(i-1),i);await p.waitForTimeout(150);if(i===7||i===11)await p.screenshot({path:OUT+'06_step'+i+'.png',fullPage:true})}
  await p.click('.speed[data-speed="0.25"]');console.log('speed pressed',await p.getAttribute('.speed[data-speed="0.25"]','aria-pressed'));
  await p.click('#fullBtn');await p.waitForTimeout(300);
  // pestaña comandos
  await p.click('#tab-cmd');await p.waitForTimeout(300);await p.screenshot({path:OUT+'07_comandos.png'});
  // tema oscuro
  await p.click('#themeBtn');await p.click('#tab-map');await p.waitForTimeout(500);
  await p.screenshot({path:OUT+'08_dark_full.png',fullPage:true});
  await p.dblclick('.card[data-id="eng"]');await p.waitForTimeout(500);await p.screenshot({path:OUT+'09_dark_panel_eng.png'});
  // overflow horizontal
  console.log('scrollWidth desktop',await p.evaluate(()=>[document.documentElement.scrollWidth,innerWidth]));
  // todas las tarjetas abren y no desbordan
  await p.keyboard.press('Escape');
  const ids=await p.$$eval('.card[data-id]',els=>els.map(e=>e.dataset.id));
  let okc=0;for(const id of ids){if(!/^(in_|persona|entrega)/.test(id)){await p.evaluate(id=>window.__mapa.openDrawer(id),id);const t=await p.textContent('#dTitle');if(t.startsWith('reliability-'))okc++;await p.evaluate(()=>window.__mapa.closeDrawer())}}
  console.log('paneles ok',okc);
  // truncado de textos en tarjetas
  const trunc=await p.evaluate(()=>[...document.querySelectorAll('.card .fn,.card .io,.card .nm')].filter(e=>e.scrollWidth>e.clientWidth+1).map(e=>e.closest('.card').dataset.id+':'+e.className+':'+e.textContent.slice(0,40)));
  console.log('truncados',JSON.stringify(trunc));
  await p.context().close();
  // móvil
  p=await mk({viewport:{width:390,height:800},isMobile:true,hasTouch:true,colorScheme:'light'});
  await p.goto(url);await p.waitForTimeout(600);
  await p.screenshot({path:OUT+'10_mobile.png',fullPage:true});
  console.log('mobile scrollWidth',await p.evaluate(()=>[document.documentElement.scrollWidth,innerWidth]));
  await p.click('#playBtn');await p.waitForTimeout(800);await p.click('#nextBtn');await p.click('#nextBtn');await p.waitForTimeout(900);
  await p.screenshot({path:OUT+'11_mobile_step3.png'});
  await p.click('#tab-cmd');await p.waitForTimeout(300);await p.screenshot({path:OUT+'12_mobile_cmd.png'});
  await p.context().close();
  console.log('ERRORES:',JSON.stringify(errs,null,1));
  await b.close();
})();

const { chromium } = require('playwright');
(async()=>{const b=await chromium.launch();const c=await b.newContext({viewport:{width:390,height:800},isMobile:true,hasTouch:true});const p=await c.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/user/clima-lima/docs/agentes/mapa_agentes.html');await p.waitForTimeout(400);
await p.evaluate(()=>document.getElementById('viewport').scrollIntoView());
const t0=await p.evaluate(()=>document.getElementById('stage').style.transform);
// arrastre con mouse
const bb=await p.locator('#viewport').boundingBox();
await p.mouse.move(bb.x+100,bb.y+300);await p.mouse.down();await p.mouse.move(bb.x+20,bb.y+260,{steps:6});await p.mouse.up();
const t1=await p.evaluate(()=>document.getElementById('stage').style.transform);
console.log('pan',t0,'->',t1);
await p.click('#zoomIn');console.log('zoom',await p.evaluate(()=>document.getElementById('stage').style.transform));

// doble toque
const card=p.locator('.card[data-id="eng"]');await p.evaluate(()=>document.getElementById('viewport').scrollIntoView());await p.click('#zoomFit');await p.waitForTimeout(700);
const cb=await card.boundingBox();console.log('card',cb);
if(cb){await p.touchscreen.tap(cb.x+cb.width/2,cb.y+cb.height/2);await p.waitForTimeout(120);await p.touchscreen.tap(cb.x+cb.width/2,cb.y+cb.height/2);await p.waitForTimeout(500);
console.log('drawer open',await p.evaluate(()=>document.getElementById('drawer').classList.contains('open')),await p.textContent('#dTitle'));
await p.screenshot({path:'13_mobile_panel.png'});}
console.log(errs);await b.close()})();

import json, re, html, sys
S='/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/'
tpl=open(S+'mapa/template.html',encoding='utf-8').read()
fich=json.load(open(S+'fichas.json',encoding='utf-8'))
traza=json.load(open('/home/user/clima-lima/historial/dossiers/chumacera_polea_faja/trazabilidad.json',encoding='utf-8'))
md=open('/home/user/clima-lima/docs/agentes/guia_comandos.md',encoding='utf-8').read()

DARK="""--bg:#0e1822; --bg2:#13212e; --card:#152635; --ink:#e4eef8; --ink2:#aac0d3; --mute:#7f97ab; --line:#2a4258; --edge:#3d6585;
  --b1:#3f6d96; --b2:#6aa6dc; --b3:#9cc8ee; --bsoft:#132434;
  --g1:#3b6f55; --g2:#5fb583; --g3:#8fd6ab; --gsoft:#12281f;
  --p1:#7d5f43; --p3:#f0b98a; --psoft:#2a2019;
  --s1:#74673a; --s3:#e2cf8f; --ssoft:#26220f;
  --pill:#152635; --shadow:0 1px 2px rgba(0,0,0,.3),0 8px 24px rgba(0,0,0,.25);"""
tpl=tpl.replace('/*DARK_MEDIA*/','@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){'+DARK+'}}')
tpl=tpl.replace('/*DARK_ATTR*/',':root[data-theme="dark"]{'+DARK+'}')

# --- md a html
def inline(t):
    t=html.escape(t,quote=False)
    t=re.sub(r'`([^`]+)`',r'<code>\1</code>',t)
    t=re.sub(r'\*\*([^*]+)\*\*',r'<strong>\1</strong>',t)
    return t
def conv(md):
    out=[];lines=md.split('\n');i=0;first=True
    while i<len(lines):
        l=lines[i]
        if l.startswith('```'):
            j=i+1;buf=[]
            while not lines[j].startswith('```'):buf.append(lines[j]);j+=1
            out.append('<pre><code>'+html.escape('\n'.join(buf),quote=False)+'</code></pre>');i=j+1;continue
        m=re.match(r'(#{1,3}) (.*)',l)
        if m:
            n=len(m.group(1));out.append('<h%d>%s</h%d>'%(n,inline(m.group(2)),n));i+=1;continue
        if l.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].startswith('|'):rows.append(lines[i]);i+=1
            cells=lambda r:[c.strip() for c in r.strip().strip('|').split('|')]
            h=cells(rows[0]);body=[cells(r) for r in rows[2:]]
            t='<div class="tw"><table><thead><tr>'+''.join('<th>%s</th>'%inline(c) for c in h)+'</tr></thead><tbody>'
            for b in body:t+='<tr>'+''.join('<td>%s</td>'%inline(c) for c in b)+'</tr>'
            out.append(t+'</tbody></table></div>');continue
        if re.match(r'\d+\. ',l):
            items=[]
            while i<len(lines) and re.match(r'\d+\. ',lines[i]):items.append(re.sub(r'^\d+\. ','',lines[i]));i+=1
            out.append('<ol>'+''.join('<li>%s</li>'%inline(x) for x in items)+'</ol>');continue
        if l.startswith('- '):
            items=[]
            while i<len(lines) and lines[i].startswith('- '):items.append(lines[i][2:]);i+=1
            out.append('<ul>'+''.join('<li>%s</li>'%inline(x) for x in items)+'</ul>');continue
        if l.strip()=='' :i+=1;continue
        buf=[l];i+=1
        while i<len(lines) and lines[i].strip()!='' and not re.match(r'(#|\||```|- |\d+\. )',lines[i]):buf.append(lines[i]);i+=1
        out.append('<p>'+inline(' '.join(buf))+'</p>')
    return '\n'.join(out)
guide=conv(md)

data={'agentes':{k:{'ficha':v['ficha']} for k,v in fich.items()},'traza':traza}
tpl=tpl.replace('__DATA__',json.dumps(data,ensure_ascii=False)).replace('__GUIDE__',guide)
open('/home/user/clima-lima/docs/agentes/mapa_agentes.html','w',encoding='utf-8').write(tpl)
print('ok',len(tpl))

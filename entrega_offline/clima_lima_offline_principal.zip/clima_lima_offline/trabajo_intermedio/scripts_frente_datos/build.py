import json, sys
sys.path.insert(0, "/home/user/clima-lima/tools/reliability")
from reliability_kit.evidence import Ledger
F = "2026-10-27"
E = []
E.append(dict(id="E-7001", tipo="repositorio", acceso="fragmento", via="hf_fs", fecha_acceso=F,
 referencia=dict(autores="Aimiyekagbon, O. K.; datos reempaquetados por Nounours777 en el Hub", anio=2024,
  titulo="Run-to-failure data set of ball bearings subjected to time-varying load and speed conditions (Paderborn LDM; repack int16)",
  fuente="Hugging Face Hub, dataset Nounours777/Paderborn-bearing; original Zenodo", doi="10.5281/zenodo.10805042",
  url="https://huggingface.co/datasets/Nounours777/Paderborn-bearing", pais="Alemania"),
 extracto="license: cc-by-4.0 ... Repack of Run-to-failure data set of ball bearings subjected to time-varying load and speed conditions (O. K. Aimiyekagbon, Paderborn University, Zenodo, DOI 10.5281/zenodo.10805042, CC BY 4.0). Bearings: B01, B02, ... B17. data/<B>/vibration.npy int16 (records, 2, samples)",
 localizador="README.md del dataset (cabecera y primer parrafo)",
 afirma="Existe un conjunto abierto CC BY 4.0 con 17 rodamientos de bolas (B01-B17) con vibracion de dos acelerometros y archivos de condiciones de operacion, temperaturas y bitacora de ensayo; es un reempaquetado sin perdida del original.",
 limites="Laboratorio, rodamientos de bolas pequenos, carga y velocidad variables en banco; fallas aceleradas. El README no declara cuantos de los 17 terminaron en falla ni si hay censura; hay que leer el PDF y la bitacora (no se abrieron). No es faja transportadora ni chumacera con soporte. Tamano: decenas de GB (no descargado). Duplicado de hunglam015/Paderborn_Bearing_Run-to-Failure_Time-Varying (17 zip, solo se vio el listado).",
 aplica_a="Series de vibracion hasta la falla (modelos de degradacion/RUL); tiempos hasta la falla solo tras leer la bitacora",
 licencia="CC BY 4.0 (declarada en README del reempaquetado)", n_unidades=17, n_fallas="NO-VERIFICADO", censura="NO-VERIFICADO", comparabilidad="baja-media"))
E.append(dict(id="E-7002", tipo="repositorio", acceso="fragmento", via="hf_fs", fecha_acceso=F,
 referencia=dict(autores="Wang, B.; Lei, Y. (grupo XJTU y Changxing Sumyoung Technology); espejo en el Hub: DavidNguyen", anio=2019,
  titulo="XJTU-SY Bearing Datasets (espejo en Hugging Face)", fuente="Hugging Face Hub, dataset DavidNguyen/XJTU-SY_Bearing_Datasets",
  url="https://huggingface.co/datasets/DavidNguyen/XJTU-SY_Bearing_Datasets", pais="China"),
 extracto="XJTU-SY bearing datasets can be downloaded by the following links: 1) Google Drive ... 5) Baidu Netdisk ... If you have any questions or suggestions, please contact me: Biao Wang",
 localizador="Download_Links_20190306.txt; listado de archivos del repositorio (Data/*.rar, Important References/*.pdf)",
 afirma="El Hub aloja una copia (~5.4 GB en rar/zip) de XJTU-SY con 5 PDF de referencias; el archivo de enlaces identifica al autor de contacto.",
 limites="No se pudo leer ReadMe.txt (no UTF-8), la tarjeta no tiene README.md ni licencia declarada (VACIO de licencia: pedir al autor original antes de redistribuir). Las cifras (15 rodamientos, 3 condiciones, 5 por condicion, 1.28 s cada minuto, 25.6 kHz) provienen solo de un resumen de buscador (E-7004 nota) y NO estan verificadas. Banco acelerado, no faja.",
 aplica_a="Series de vibracion hasta la falla; vida por condicion tras leer el reporte original",
 licencia="NO DECLARADA en el espejo", n_unidades="15 (SOLO-SNIPPET)", n_fallas="15 (SOLO-SNIPPET)", censura="no verificado", comparabilidad="baja-media"))
E.append(dict(id="E-7003", tipo="repositorio", acceso="fragmento", via="hf_fs", fecha_acceso=F,
 referencia=dict(autores="alidi (subconjunto); datos originales UNSW", anio=2022,
  titulo="Bearing run-to-failure dataset of UNSW - test 1 & 3 - horizontal acceleration (subconjunto)", fuente="Hugging Face Hub, dataset alidi/bearing-run2failure-unsw; original Mendeley Data",
  doi="10.17632/h4df4mgrfb.3", url="https://huggingface.co/datasets/alidi/bearing-run2failure-unsw", pais="Australia"),
 extracto="This dataset is a subset of the bearing run-to-failure dataset of UNSW: Horizontal acceleration (accH) measurements; Test 1 and Test 3; Sampling frequency: 51200 Hz; speed (6.0 Hz), radial load (10.5 kN), defect size (1.0 and 0.5 mm), and defect type (BPFO). Source: 10.17632/h4df4mgrfb.3. License: CC BY 4.0",
 localizador="README.md del dataset; metadatos splits test1=80 ejemplos, test3=79",
 afirma="Conjunto abierto CC BY 4.0 con 2 ensayos (Test 1 y 3) de rodamiento hasta la falla por defecto de pista externa, con 80 y 79 registros; el original tiene 4 ensayos.",
 limites="Solo 2 de 4 ensayos y un canal (aceleracion horizontal); 2 fallas = minimo absoluto para Weibull y sin censura declarada. Banco de laboratorio a 6 Hz (360 rpm) y 10.5 kN; rodamiento de rodillos/bolas autoalineante no confirmado. Los ensayos aqui son unidades de un mismo diseno, no una poblacion de campo.",
 aplica_a="Series de vibracion hasta falla; Weibull inviable con n=2 (solo exploratorio extremo)",
 licencia="CC BY 4.0 (declarada)", n_unidades=2, n_fallas=2, censura="no declarada", comparabilidad="baja"))
E.append(dict(id="E-7004", tipo="repositorio", acceso="snippet", via="websearch", fecha_acceso=F,
 referencia=dict(autores="Wang, B.; Lei, Y.", anio=2019, titulo="XJTU-SY rolling element bearing accelerated life test dataset", url="https://github.com/VictorBauler/awesome-bearing-dataset", pais="China"),
 afirma="PISTA: segun buscador, 15 rodamientos hasta la falla en 3 condiciones (2100 rpm/12 kN, 2250/11, 2400/10), 5 por condicion, 1.28 s por minuto, 25.6 kHz; el propio resumen reporta discrepancias entre fuentes.",
 limites="Solo resumen de buscador: no respalda cifras en entregables. Verificar en el reporte original (PDF de referencias en E-7002).",
 aplica_a="Pista de comparabilidad", licencia="no verificada", n_unidades="15 (snippet)", comparabilidad="baja-media"))
E.append(dict(id="E-7005", tipo="repositorio", acceso="snippet", via="websearch", fecha_acceso=F,
 referencia=dict(autores="Nectoux, P.; Gouriveau, R.; Medjaher, K.; Ramasso, E.; Morello, B.; Zerhouni, N.; Varnier, C.", anio=2012,
  titulo="PRONOSTIA: An experimental platform for bearings accelerated degradation tests (reto IEEE PHM 2012)", pais="Francia"),
 afirma="PISTA: segun buscador, 17 rodamientos en 3 condiciones, 2 aceleros a 25.6 kHz, 2560 muestras cada 10 s, fin de vida al superar 20 g; en el reto, algunos ensayos estan truncados (censura por diseno del reto).",
 limites="Solo resumen de buscador; el conteo train/test es contradictorio entre fuentes. Repositorio oficial (NASA PCoE/GitHub) no abierto. Licencia no verificada.",
 aplica_a="Pista de series hasta falla con truncamiento", licencia="no verificada", n_unidades="17 (snippet)", comparabilidad="baja"))
E.append(dict(id="E-7006", tipo="repositorio", acceso="snippet", via="websearch", fecha_acceso=F,
 referencia=dict(autores="Qiu, H.; Lee, J.; Lin, J.; Yu, G. (atribucion segun buscador; Centro IMS, Univ. de Cincinnati)", anio=2006,
  titulo="NASA IMS bearings run-to-failure dataset", url="https://github.com/VictorBauler/awesome-bearing-dataset", pais="Estados Unidos"),
 afirma="PISTA: segun buscador, 3 ensayos hasta la falla con 4 rodamientos de doble hilera por eje, ~2000 rpm, 6000 lbf radial, 20 kHz, 1 s cada 10 min; fallas de pista interna, rodillo y pista externa.",
 limites="Solo resumen de buscador; atribucion de autores y alojamiento (repositorio de datos de prognostico de la agencia) no verificados; sitio probablemente bloqueado. Un banco con 3 ensayos y varios rodamientos por ensayo sin falla (censura implicita) que habria que reconstruir.",
 aplica_a="Pista de series hasta falla; la unica con rodamientos de doble hilera de rodillos de tamano industrial (comparabilidad media)",
 licencia="no verificada", n_unidades="3 ensayos x 4 rodamientos (snippet)", comparabilidad="media (por tamano y carga)"))
E.append(dict(id="E-7007", tipo="otro", acceso="snippet", via="websearch", fecha_acceso=F,
 referencia=dict(autores="SAS Institute (documentacion; datos de Nelson, 1990)", anio=2016, titulo="The RELIABILITY Procedure: Weibull regression example on Nelson load-accelerated rolling bearing data",
  url="https://support.sas.com/documentation/cdl/en/qcug/67522/HTML/default/qcug_reliability_gettingstarted06.htm"),
 afirma="PISTA de parametro publicado: forma Weibull 1.2434 (error estandar 0.1545; IC95 aprox. 0.97 a 1.59), 39 observaciones sin censura, datos de ensayo de rodamientos con carga acelerada (Nelson 1990).",
 limites="Solo resumen de buscador; la escala depende de la carga del ensayo y no se reporta aqui; ensayo de laboratorio de rodamientos de rodillos, no de campo. No abierto.",
 aplica_a="Contraste de la forma beta (rodamientos ~1.2) frente a supuestos", licencia="no aplica", comparabilidad="baja"))
E.append(dict(id="E-7008", tipo="otro", acceso="snippet", via="websearch", fecha_acceso=F,
 referencia=dict(autores="Autor no identificado en el resumen (articulo de revista tecnica)", anio=None, titulo="Calculating Machine Reliability from Bearing Life", url="https://machinedesign.com/archive/article/21831948/calculating-machine-reliability-from-bearing-life"),
 afirma="PISTA: segun buscador, la forma beta para rodamientos varia con la carga (cerca de 1.0 con carga ligera, 4.0 o mas con carga pesada).",
 limites="Solo resumen de buscador, articulo divulgativo sin autor ni anio verificados; no es dato de falla.",
 aplica_a="Rango de beta de referencia (hipotesis)", licencia="no aplica", comparabilidad="baja"))
E.append(dict(id="E-7009", tipo="otro", acceso="snippet", via="websearch", fecha_acceso=F,
 referencia=dict(autores="Autores no identificados (trabajo PSAM 12)", anio=None, titulo="PSAM 12 paper 168 (supuestos de forma Weibull para rodamientos)", url="https://www.iapsam.org/psam12/proceedings/paper/paper_168_1.pdf"),
 afirma="PISTA: segun buscador, el articulo asume beta=1.5 para rodamientos de rodillos y 2.0 para de bolas (Weibayes) porque los datos de falla eran insuficientes.",
 limites="Valores ASUMIDOS, no ajustados; solo resumen de buscador; no es dato de campo ni de faja.",
 aplica_a="Referencia de supuesto beta para Weibayes (declarar como SUPUESTO)", licencia="no aplica", comparabilidad="baja"))
E.append(dict(id="E-7010", tipo="paper", acceso="solo_referencia", via="readme_repositorio", fecha_acceso=F,
 referencia=dict(autores="Javanmardi, A.; Aimiyekagbon, O. K.; Bender, A.; Kimotho, J. K.; Sextro, W.; Hullermeier, E.", anio=2024,
  titulo="Remaining Useful Lifetime Estimation of Bearings Operating under Time-Varying Conditions", fuente="PHM Society European Conference 8(1)", doi="10.36001/phme.2024.v8i1.4101", pais="Alemania"),
 afirma="Articulo que describe el conjunto de E-7001 (citado en su README); no leido.",
 limites="No leido: no respalda ninguna cifra. Pendiente para saber cuantos rodamientos fallaron y como se definio el fin de vida.",
 aplica_a="Pendiente de lectura"))
L = Ledger(E)
L.to_json("/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_chumacera/evidencia/frente_datos.json")
print(L.resumen()); print({k:v for k,v in L.avisos.items() if v})

import json, re, html
S='/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/'
D='/home/user/clima-lima/historial/dossiers/bomba_centrifuga/'
tpl=open(S+'mapa/template.html',encoding='utf-8').read()
fich=json.load(open(S+'fichas.json',encoding='utf-8'))
traza_raw=json.load(open(D+'trazabilidad.json',encoding='utf-8'))
md=open('/home/user/clima-lima/docs/agentes/guia_comandos.md',encoding='utf-8').read()

# ---- cifras reales (se recalculan, no se escriben a mano)
ev=json.load(open(D+'evidencia.json',encoding='utf-8'))
from collections import Counter
niv=Counter(e['nivel_evidencia'] for e in ev)
num=lambda e:int(re.sub(r'\D','',e['id']))
new=[e for e in ev if 1100<=num(e)<2000]; old=[e for e in ev if num(e)>=6000]
nn=Counter(e['nivel_evidencia'] for e in new); no=Counter(e['nivel_evidencia'] for e in old)
assert len(ev)==351 and len(new)==115 and len(old)==236
assert (niv['SOLO-SNIPPET'],niv['VERIFICADO-TEXTO'],niv['VERIFICADO-ABSTRACT'],niv['NO-VERIFICADO'])==(169,158,13,11)
assert (nn['SOLO-SNIPPET'],nn['VERIFICADO-TEXTO'],nn['VERIFICADO-ABSTRACT'],nn['NO-VERIFICADO'])==(97,12,2,4)
assert (no['VERIFICADO-TEXTO'],no['VERIFICADO-ABSTRACT'],no['SOLO-SNIPPET'],no['NO-VERIFICADO'])==(146,11,72,7)
meta=json.load(open(D+'meta.json',encoding='utf-8')); assert meta['entradas_registro']==351
an=lambda f:json.load(open(D+'analisis/'+f+'.json',encoding='utf-8'))
acr,arb,fm,pr,obs,por=an('acr'),an('arbol'),an('fmeca'),an('predictivo'),an('observar'),an('porques')
assert len(acr['hipotesis'])==11 and all(h['estado']=='posible' for h in acr['hipotesis'])
assert len(fm['items'])==7 and len(fm['vacios'])==17 and len(arb['nodos'])==20 and len(arb['vacios'])==13
assert len(pr['hallazgos'])==20 and len(pr['riesgos_de_validacion'])==13 and len(obs['items'])==25 and len(por['items'])==7
dz=json.load(open(D+'dossier.json',encoding='utf-8'))['secciones']
con=[k for k,v in dz.items() if v.get('elementos')]; assert len(dz)==14 and len(con)==7 and sum(len(dz[k]['elementos']) for k in con)==8
assert len(json.load(open(D+'cifras.json')))==5 and len(json.load(open(D+'replicas.json')))==1
assert len(json.load(open(D+'normas.json')))==51
assert all(e.get('revista_cuartil') is None for e in ev)
fb=sum(1 for l in open('/home/user/clima-lima/historial/feedback/feedback.jsonl',encoding='utf-8') if l.strip()); assert fb==18

# ---- trazabilidad: une las dos entradas del investigador de literatura
tz={}
for t in traza_raw:
    a=t['agente']
    if a in tz:
        o=tz[a]
        o['hizo']+=' '+t['hizo']; o['entrada']+=' · '+t['entrada']; o['salida']+=' · '+t['salida']; o['aprendio']+=' '+t['aprendio']
    else: tz[a]=dict(t)
traza=list(tz.values())
assert len(traza)==8

DARK="""--bg:#0e1822; --bg2:#13212e; --card:#152635; --ink:#e4eef8; --ink2:#aac0d3; --mute:#7f97ab; --line:#2a4258; --edge:#3d6585;
  --b1:#3f6d96; --b2:#6aa6dc; --b3:#9cc8ee; --bsoft:#132434;
  --g1:#3b6f55; --g2:#5fb583; --g3:#8fd6ab; --gsoft:#12281f;
  --p1:#7d5f43; --p3:#f0b98a; --psoft:#2a2019;
  --s1:#74673a; --s3:#e2cf8f; --ssoft:#26220f;
  --pill:#152635; --shadow:0 1px 2px rgba(0,0,0,.3),0 8px 24px rgba(0,0,0,.25);"""
tpl=tpl.replace('/*DARK_MEDIA*/','@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){'+DARK+'}}')
tpl=tpl.replace('/*DARK_ATTR*/',':root[data-theme="dark"]{'+DARK+'}')

def rep(a,b):
    global tpl
    assert tpl.count(a)==1,(tpl.count(a),a[:60]); tpl=tpl.replace(a,b)
rep('<title>Mapa del equipo de confiabilidad</title>','<title>Mapa del equipo - bomba centrífuga</title>')
rep('para el caso chumacera de polea de faja transportadora.','para el caso bomba centrífuga, con lo que el equipo pudo y no pudo leer.')
rep('<h1>Chumacera de polea de faja transportadora</h1>','<h1>Bomba centrífuga</h1>')
rep('Pulsa Reproducir para ver el flujo real del caso paso a paso, o haz doble clic en una tarjeta para abrir su ficha.</p>','Pulsa Reproducir para ver el flujo real del caso paso a paso, incluida la limitación de acceso que dejó casi todo como pistas sin leer, o haz doble clic en una tarjeta para abrir su ficha.</p>')
rep('Fuente: .claude/agents, .claude/commands, knowledge, tools/reliability e historial/dossiers/chumacera_polea_faja.','Fuente: .claude/agents, .claude/commands, knowledge, tools/reliability e historial/dossiers/bomba_centrifuga.')
rep("(id==='integ'?' La trazabilidad indica que las compuertas del kit se ejecutaron en el ensamblado lanzado por el estratega, y que el agente integrador ya existe y se usará en el próximo caso.':'')","(id==='integ'?' En este caso el estratega armó el dossier con las compuertas del kit; el agente integrador no figura en la trazabilidad.':'')")
rep("const x=16+i*264","const x=16+i*264") if False else None
rep("x:'Los números sobre cada tarjeta","x:'En este caso trabajaron 8 de los 20 agentes (los puntos verdes). Los números sobre cada tarjeta") if False else None
rep("st.full?'Los números sobre cada tarjeta indican en qué pasos participa. Reproduce","st.full?'En este caso figuran 8 de los 20 agentes en la trazabilidad (los puntos verdes). Los números sobre cada tarjeta indican en qué pasos participa. Reproduce")

STEPS=r"""const STEPS=[
{t:'Solicitud: la persona nombra la bomba centrífuga',
 x:'La persona lanza el comando de modo de falla con el componente: bomba centrífuga. El estratega lo clasifica, lee las reglas vigentes de historial/feedback y prepara el reparto de frentes. No se aportaron datos de planta: este caso no tiene un activo real detrás.',
 r:'Solicitud registrada: falla de bomba centrífuga. La carpeta del caso no trae datos reales del activo, y el historiador no figura en trazabilidad.json.',
 n:['in_modo','in_datos','eng'],f:[],e:['e_modo','e_datos']},
{t:'Siete frentes en paralelo',
 x:'El estratega lanza los frentes a la vez, cada uno con un encargo de ocho bloques y su rango de ids: mecanismos y modos, sellos y rodamientos, monitoreo de condición, vida y costos, normas, ML y RUL, y datos abiertos.',
 r:'Siete frentes: cuatro a cargo del investigador de literatura, uno del investigador de normas, uno del analista de papers (ML y RUL) y uno del buscador de datos abiertos.',
 n:['eng','lit','std','dat','pap'],f:['fo_doss','fo_know'],e:['enc_A','g_know']},
{t:'La red impide leer: casi todo queda como pista',
 x:'Cada fuente se registra con extracto literal, localizador y límites, y con su nivel de lectura. Aquí el acceso decidió el resultado: el índice de preprints legible no contiene literatura de bombas y los sitios de revistas están bloqueados. Una pista SOLO-SNIPPET se ve en un resumen de buscador y no respalda ninguna afirmación.',
 r:'Los frentes nuevos suman 115 entradas: 97 son SOLO-SNIPPET (84 %), 14 se leyeron (12 en texto y 2 en resumen) y 4 son NO-VERIFICADO. El frente de ML y RUL no registró ninguna entrada. Del investigador de literatura, solo 10 de 50 entradas tienen lectura, y son de rodamientos y de motor.',
 n:['lit','std','dat','pap'],f:['fo_doss'],e:['f_evid']},
{t:'Se heredan las fuentes de rodamientos del caso previo',
 x:'Como la bomba no se podía leer, el estratega reutiliza las fuentes de rodamientos ya leídas en el caso anterior. Conservan su id, su referencia y su extracto literal; los límites se reescriben para decir que no son de bombas.',
 r:'236 entradas con los mismos ids del caso previo: 146 VERIFICADO-TEXTO, 11 VERIFICADO-ABSTRACT, 72 SOLO-SNIPPET y 7 NO-VERIFICADO. Con las 115 nuevas, el registro llega a 351 entradas.',
 n:['eng','lit'],f:['fo_doss'],e:[]},
{t:'Normas y datos abiertos',
 x:'El investigador de normas ubica normas y guías y anota el estado que alcanzó a ver; el buscador de datos revisa conjuntos abiertos y sus límites. Sin lectura del documento no se citan cláusulas ni ediciones.',
 r:'51 normas y guías vistas en resúmenes de buscador (5 con conflicto de estado) y 23 vacíos declarados. Datos abiertos: 7 entradas; hay audio de bombas para diagnóstico y ninguno con tiempos hasta la falla, así que no se ajusta Weibull ni RUL de la bomba.',
 n:['std','dat'],f:['fo_know','fo_doss'],e:['g_know']},
{t:'Lectura profunda y réplicas: casi vacías',
 x:'Los papers más útiles se leen completos para extraer tablas, figuras y parámetros con su extracto literal. El control del kit rechaza cualquier número que no esté literal en el extracto, por eso sin lectura no hay cifras de bombas.',
 r:'El analista de papers buscó ML y RUL en bombas: no hay ninguno en el índice legible. Quedaron 5 cifras y 1 réplica, todas de rodamientos o de un banco de motor sin bomba.',
 n:['pap'],f:['fo_doss'],e:['f_cifras']},
{t:'Análisis con lo respaldado',
 x:'Causa raíz, FMECA y estrategia predictiva trabajan solo sobre lo que tiene fuente leída: rodamientos de bomba, contaminación, lubricación y desalineación. Los modos propios de la bomba no se arman con pistas: quedan como SIN DATOS PARA ARMARLO, con la lectura que los cerraría.',
 r:'ACR con 11 hipótesis, todas en estado posible; FMECA con 7 modos de rodamiento, sin puntaje S, O ni D, y 17 vacíos; árbol de 20 nodos con 13 vacíos; predictivo con 20 hallazgos y 13 riesgos de validación. Sin armar: sello mecánico, cavitación, recirculación, anillos de desgaste, golpe de ariete y desbalance con desalineación de la bomba.',
 n:['rca','fmeca','pred'],f:['fo_kit','fo_doss'],e:['enc_B','g_kit']},
{t:'Ensamblado con compuertas',
 x:'El estratega une los JSON de análisis, evidencia y cifras y arma informe.html con las compuertas del kit. Cada elemento sin fuente válida se elimina y queda registrado, y cada sección sin respaldo se declara vacía.',
 r:'Dossier de 14 secciones: 7 con elementos con fuente (8 en total) y 7 con la leyenda de sin hallazgo respaldado. El kit omitió 1 candidato por evidencia no leída. No existe ranking.json: ninguna de las 351 entradas trae cuartil de revista. El integrador no figura en la trazabilidad.',
 n:['integ','rca','fmeca','pred'],f:['fo_doss'],e:['enc_C','f_anal','g_doss']},
{t:'Verificación independiente',
 x:'El verificador ve solo los archivos y las fuentes, no el razonamiento del autor, e intenta refutar: cifras sin origen, niveles inflados, pistas usadas como respaldo y nombres de empresa. Devuelve al estratega una tabla de problemas por severidad.',
 r:'El verificador no figura en trazabilidad.json y los archivos del caso no registran cuántas pasadas hubo ni qué hallazgos devolvió.',
 n:['verif','integ'],f:[],e:['e_hall']},
{t:'Entrega',
 x:'El estratega entrega el informe HTML aunque haya secciones vacías, con la tabla de quién hizo qué y las preguntas finales para la persona: qué datos del activo faltan y qué lectura cerraría cada vacío.',
 r:'Informe en historial/dossiers/bomba_centrifuga/informe.html. Piden al activo: evento y fecha, series de caudal, presión, NPSH, corriente y temperatura, historial de órdenes, análisis de lubricante y evidencia física. Pendiente de la red: habilitar el acceso a artículos, datos, tesis y normas.',
 n:['eng','persona','entrega'],f:['fo_doss'],e:['e_entr','e_pers','g_doss']},
{t:'Aprendizaje',
 x:'El estratega envía a cada agente lo aprendido de su entrega y el agente de feedback lo registra. El curador propone lecciones a la cuarentena y solo una persona las aprueba; el historiador guarda el caso.',
 r:'Lo aprendido por el estratega: cuando no hay lectura posible, el dossier queda con SIN DATOS PARA ARMARLO y lista las fuentes por abrir. historial/feedback tiene 18 entradas; la memoria tiene 0 lecciones aprobadas y 1 en cuarentena. El agente de feedback, el curador y el historiador no figuran en la trazabilidad.',
 n:['eng','feed','cur','hist'],f:['fo_feed','fo_cuar','fo_casos'],e:['enc_D','g_feed','g_cuar','g_casos']}
];
// chips de pasos"""
m=re.search(r"const STEPS=\[.*?\];\n// chips de pasos",tpl,re.S); assert m
tpl=tpl[:m.start()]+STEPS+tpl[m.end():]

# ---- guía de comandos adaptada al caso
lines=md.split('\n')
def idx(prefix,start=0):
    for i in range(start,len(lines)):
        if lines[i].startswith(prefix): return i
    raise SystemExit('no '+prefix)
i=idx('Esta guía explica'); lines[i]=lines[i].replace('y el caso real `historial/dossiers/chumacera_polea_faja/`','y el caso real `historial/dossiers/bomba_centrifuga/`').replace('`docs/agentes/mapa_agentes.html`','`docs/agentes/mapa_agentes_bomba.html`')
i=idx('/modo-de-falla chumacera'); lines[i]='/modo-de-falla bomba centrífuga'
a=idx('Este es el orden que sigue'); b=idx('### 3.1')
sec3="""Este es el orden que sigue un modo de falla (protocolo del dossier) con lo que ocurrió de verdad en el caso de la bomba centrífuga. Donde el caso real no coincide con el protocolo, se dice.

1. **Solicitud.** La persona nombra el modo de falla. El estratega lo clasifica y lee las reglas vigentes de `historial/feedback/feedback.jsonl`. No hay datos de planta, y el historiador no figura en la trazabilidad.
2. **Siete frentes en paralelo.** Mecanismos y modos, sellos y rodamientos, monitoreo de condición, vida y costos, normas, ML y RUL, y datos abiertos, cada uno con su rango de ids.
3. **La red impide leer.** El índice de preprints legible no contiene literatura de bombas y los sitios de revistas están bloqueados. De 115 entradas nuevas, 97 son SOLO-SNIPPET, 14 se leyeron y 4 son NO-VERIFICADO.
4. **Fuentes heredadas.** Se reutilizan 236 entradas de rodamientos del caso previo, con los límites reescritos para decir que no son de bombas. El registro llega a 351 entradas.
5. **Normas y datos abiertos.** 51 normas y guías vistas solo en resúmenes de buscador y 23 vacíos declarados; 7 entradas de datos abiertos, ninguna con tiempos hasta la falla.
6. **Lectura profunda y réplicas.** Sin papers de bombas legibles quedan 5 cifras y 1 réplica, todas de rodamientos o de un banco de motor.
7. **Análisis con lo respaldado.** Causa raíz (11 hipótesis, todas posibles), FMECA (7 modos de rodamiento) y estrategia predictiva. Los modos propios de la bomba quedan como SIN DATOS PARA ARMARLO.
8. **Ensamblado con compuertas.** En `informe.html` hay 7 de 14 secciones con elementos y 7 declaradas vacías. No existe `ranking.json`.
9. **Verificación.** El verificador ve solo los archivos y las fuentes e intenta refutar. En este caso no figura en la trazabilidad y los archivos no registran sus pasadas.
10. **Entrega.** El estratega entrega el HTML aunque haya secciones vacías, con una tabla de quién hizo qué y preguntas finales a la persona.
11. **Aprendizaje.** El estratega envía a cada agente lo aprendido, el agente de feedback lo registra y el curador propone lecciones en cuarentena.

Resultado del caso real (`meta.json`): 351 entradas de registro; 7 secciones del dossier con elementos y 7 vacías.
"""
lines[a:b]=sec3.split('\n')
i=idx('En el caso real el registro tiene'); lines[i]='En el caso real el registro tiene 146 + 12 = 158 entradas VERIFICADO-TEXTO, 13 VERIFICADO-ABSTRACT, 169 SOLO-SNIPPET y 11 NO-VERIFICADO.'
lines[i]='En el caso real el registro tiene 158 entradas VERIFICADO-TEXTO, 13 VERIFICADO-ABSTRACT, 169 SOLO-SNIPPET y 11 NO-VERIFICADO.'
i=idx('2. **Lectura incompleta.**'); lines[i]='2. **Lectura incompleta.** De las 351 entradas del caso real, 169 son SOLO-SNIPPET y 11 NO-VERIFICADO: no respaldan ninguna afirmación. Todo lo propio de la bomba (cavitación, recirculación, sellos, anillos de desgaste, golpe de ariete y reparto de modos de falla) está solo como pista.'
i=idx('3. **Sin datos de planta.**'); lines[i]='3. **Sin datos de planta.** El caso real no tiene datos reales del activo. Por eso ninguna causa pasa de posible, no se ajusta ninguna distribución de vida, los puntajes S, O y D están sin puntuar y las secciones top de fallas, FMECA, punto óptimo, LCC, IBR, ACR y mantenimiento predictivo con normas del dossier quedaron vacías.'
i=idx('8. **Agentes aún no usados'); lines[i]='8. **Agentes que no figuran en el caso.** En la trazabilidad del caso de la bomba trabajaron ocho agentes: el estratega, el investigador de literatura, el de normas, el analista de papers, el buscador de datos, el de causa raíz, el de FMECA y el predictivo. No figuran el integrador, el historiador, el auditor de datos, el replicador, el rankeador de citas, el redactor, el diseñador UX, el curador, el agente de feedback, el verificador, el analista de vida ni el de economía.'
md='\n'.join(lines)

def inline(t):
    t=html.escape(t,quote=False)
    t=re.sub(r'`([^`]+)`',r'<code>\1</code>',t)
    t=re.sub(r'\*\*([^*]+)\*\*',r'<strong>\1</strong>',t)
    return t
def conv(md):
    out=[];lines=md.split('\n');i=0
    while i<len(lines):
        l=lines[i]
        if l.startswith('```'):
            j=i+1;buf=[]
            while not lines[j].startswith('```'):buf.append(lines[j]);j+=1
            out.append('<pre><code>'+html.escape('\n'.join(buf),quote=False)+'</code></pre>');i=j+1;continue
        m=re.match(r'(#{1,3}) (.*)',l)
        if m:
            n=len(m.group(1));out.append('<h%d>%s</h%d>'%(n,inline(m.group(2)),n));i+=1;continue
        if l.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].startswith('|'):rows.append(lines[i]);i+=1
            cells=lambda r:[c.strip() for c in r.strip().strip('|').split('|')]
            h=cells(rows[0]);body=[cells(r) for r in rows[2:]]
            t='<div class="tw"><table><thead><tr>'+''.join('<th>%s</th>'%inline(c) for c in h)+'</tr></thead><tbody>'
            for bb in body:t+='<tr>'+''.join('<td>%s</td>'%inline(c) for c in bb)+'</tr>'
            out.append(t+'</tbody></table></div>');continue
        if re.match(r'\d+\. ',l):
            items=[]
            while i<len(lines) and re.match(r'\d+\. ',lines[i]):items.append(re.sub(r'^\d+\. ','',lines[i]));i+=1
            out.append('<ol>'+''.join('<li>%s</li>'%inline(x) for x in items)+'</ol>');continue
        if l.startswith('- '):
            items=[]
            while i<len(lines) and lines[i].startswith('- '):items.append(lines[i][2:]);i+=1
            out.append('<ul>'+''.join('<li>%s</li>'%inline(x) for x in items)+'</ul>');continue
        if l.strip()=='' :i+=1;continue
        buf=[l];i+=1
        while i<len(lines) and lines[i].strip()!='' and not re.match(r'(#|\||```|- |\d+\. )',lines[i]):buf.append(lines[i]);i+=1
        out.append('<p>'+inline(' '.join(buf))+'</p>')
    return '\n'.join(out)
guide=conv(md)
data={'agentes':{k:{'ficha':v['ficha']} for k,v in fich.items()},'traza':traza}
tpl=tpl.replace('__DATA__',json.dumps(data,ensure_ascii=False)).replace('__GUIDE__',guide)
open('/home/user/clima-lima/docs/agentes/mapa_agentes_bomba.html','w',encoding='utf-8').write(tpl)
print('ok',len(tpl))

const { chromium } = require('playwright');
const OUT=__dirname+'/';
(async()=>{
  const b=await chromium.launch(); const errs=[];
  async function mk(o){const c=await b.newContext(o);const p=await c.newPage();
    p.on('console',m=>{if(m.type()==='error'||m.type()==='warning')errs.push(m.type()+': '+m.text())});
    p.on('pageerror',e=>errs.push('pageerror: '+e.message));
    p.on('requestfailed',r=>{if(!/fonts\.g/.test(r.url()))errs.push('reqfailed: '+r.url())});return p}
  const url='file:///home/user/clima-lima/docs/agentes/mapa_agentes_bomba.html';
  let p=await mk({viewport:{width:1440,height:900},colorScheme:'light'});
  await p.goto(url);await p.waitForTimeout(500);
  await p.screenshot({path:OUT+'01_desktop_full.png',fullPage:true});
  await p.dblclick('.card[data-id="lit"]');await p.waitForTimeout(500);
  await p.screenshot({path:OUT+'02_panel_lit.png'});
  console.log('panel',await p.textContent('#dTitle'),await p.locator('.block').count(),'bloques',await p.textContent('#dBadge'));
  await p.mouse.click(200,400);await p.waitForTimeout(400);
  console.log('cerrado tras clic fuera:',!(await p.evaluate(()=>document.getElementById('drawer').classList.contains('open'))));
  await p.dblclick('.card[data-id="integ"]');await p.waitForTimeout(400);await p.screenshot({path:OUT+'03_panel_integ.png'});
  await p.keyboard.press('Escape');await p.waitForTimeout(300);
  await p.click('#playBtn');await p.waitForTimeout(700);
  const s1=await p.textContent('#stepNo');await p.screenshot({path:OUT+'04_play_step1.png',fullPage:true});
  await p.click('#resetBtn');await p.click('#playBtn');await p.waitForTimeout(5600);
  console.log('paso',s1,'-> tras 5.6s:',await p.textContent('#stepNo'));
  await p.click('#playBtn');
  const N=await p.evaluate(()=>window.__mapa.STEPS.length);console.log('pasos',N);
  for(let i=1;i<=N;i++){await p.evaluate(i=>window.__mapa.go(i-1),i);await p.waitForTimeout(700);await p.screenshot({path:OUT+'05_step'+String(i).padStart(2,'0')+'.png',fullPage:true})}
  await p.click('.speed[data-speed="0.25"]');console.log('speed',await p.getAttribute('.speed[data-speed="0.25"]','aria-pressed'));
  await p.click('#fullBtn');await p.waitForTimeout(300);
  await p.click('#zoomIn');await p.waitForTimeout(700);const tr1=await p.evaluate(()=>document.getElementById('stage').style.transform);await p.click('#zoomFit');await p.waitForTimeout(700);
  console.log('zoom',tr1);
  await p.click('#tab-cmd');await p.waitForTimeout(300);await p.screenshot({path:OUT+'06_comandos.png'});
  await p.click('#themeBtn');await p.click('#tab-map');await p.waitForTimeout(500);
  await p.screenshot({path:OUT+'07_dark_full.png',fullPage:true});
  await p.dblclick('.card[data-id="fmeca"]');await p.waitForTimeout(500);await p.screenshot({path:OUT+'08_dark_panel_fmeca.png'});
  console.log('scrollWidth',await p.evaluate(()=>[document.documentElement.scrollWidth,innerWidth]));
  await p.keyboard.press('Escape');
  const ids=await p.$$eval('.card[data-id]',els=>els.map(e=>e.dataset.id));let okc=0;
  for(const id of ids){if(!/^(in_|persona|entrega)/.test(id)){await p.evaluate(id=>window.__mapa.openDrawer(id),id);const t=await p.textContent('#dTitle');if(t.startsWith('reliability-'))okc++;await p.evaluate(()=>window.__mapa.closeDrawer())}}
  console.log('paneles ok',okc,'de 20');
  console.log('trabajaron',await p.$$eval('.card.worked',e=>e.map(x=>x.dataset.id).join(',')));
  console.log('truncados',JSON.stringify(await p.evaluate(()=>[...document.querySelectorAll('.card .fn,.card .io,.card .nm')].filter(e=>e.scrollWidth>e.clientWidth+1).map(e=>e.closest('.card').dataset.id+':'+e.textContent.slice(0,30)))));
  // overflow de texto en la caja de explicación en cada paso
  await p.context().close();
  p=await mk({viewport:{width:390,height:800},isMobile:true,hasTouch:true,colorScheme:'light'});
  await p.goto(url);await p.waitForTimeout(600);await p.screenshot({path:OUT+'09_mobile.png',fullPage:true});
  console.log('mobile scrollWidth',await p.evaluate(()=>[document.documentElement.scrollWidth,innerWidth]));
  await p.click('#playBtn');await p.waitForTimeout(800);await p.click('#nextBtn');await p.click('#nextBtn');await p.waitForTimeout(900);
  await p.screenshot({path:OUT+'10_mobile_step3.png'});
  await p.context().close();
  console.log('ERRORES:',JSON.stringify(errs,null,1));await b.close();
})();

import json, glob, sys
sys.path.insert(0, '/home/user/clima-lima/tools/reliability')
from reliability_kit import Ledger
BASE = '/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/'
L = Ledger(); omit = []; SEEN = set()
def add(e):
    k = (e.get('extracto') or '').strip()
    if k and k in SEEN: omit.append((e['id'], 'extracto duplicado')); return
    try: L.add(e)
    except Exception as ex: omit.append((e['id'], str(ex)[:90])); return
    if k: SEEN.add(k)
for f in sorted(glob.glob(BASE + 'modo_prensa/evidencia/*_registro.json')):
    for e in json.load(open(f, encoding='utf-8')): add(e)
n = len(L.entradas)
for e in json.load(open(BASE + 'modo_bomba/evidencia_total.json', encoding='utf-8')):
    if e['id'] in L.entradas: omit.append((e['id'], 'id repetido')); continue
    e = json.loads(json.dumps(e)); e['limites'] = (e.get('limites') or '') + ' Fuente heredada del caso de la bomba centrífuga (rodamientos o máquinas rotativas); no trata prensaestopa.'
    add(e)
L.to_json(BASE + 'modo_prensa/evidencia_total.json')
print('nuevas', n, 'total', len(L.entradas), 'omitidas', omit[:6], L.resumen()['por_nivel'])

# Simulacion SINTETICA e ilustrativa (semilla 20261027): que tan informativo es el kit segun el numero de fallas.
import sys, numpy as np
sys.path.insert(0,'/home/user/clima-lima/tools/reliability')
from reliability_kit.weibull import fit_weibull_mle, weibull_beta_ci_lr
from reliability_kit.survival import kaplan_meier, logrank_test
import scipy, numpy
rng=np.random.default_rng(20261027)
print('numpy',numpy.__version__,'scipy',scipy.__version__)
beta,eta=1.5,1000.0
for r in (5,10,30):
    ratios=[];cover=0;N=200
    for _ in range(N):
        t=eta*rng.weibull(beta,r)
        lo,hi=weibull_beta_ci_lr(t,np.zeros(r,bool)); ratios.append(hi/lo); cover+= lo<=beta<=hi
    print('r',r,'mediana hi/lo de beta',round(float(np.median(ratios)),2),'cobertura',cover/N)
# log-rank: dos grupos, razon de tiempos eta 1000 vs 500 (riesgo relativo ~2.8 con beta 1.5), censura administrativa en 1200
for n in (5,10,15,30):
    rej=0;N=300;evs=[]
    for _ in range(N):
        a=eta*rng.weibull(beta,n); b=(eta/2)*rng.weibull(beta,n)
        ea=a<1200; eb=b<1200; a=np.minimum(a,1200); b=np.minimum(b,1200)
        evs.append(ea.sum()+eb.sum())
        try: rej+= logrank_test(a,ea,b,eb)['p_value']<0.05
        except ValueError: pass
    print('n por grupo',n,'eventos medios',round(float(np.mean(evs)),1),'potencia logrank',rej/N)

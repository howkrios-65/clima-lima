import json, sys
from pathlib import Path
sys.path.insert(0, "/home/user/clima-lima/tools/reliability")
from reliability_kit.evidence import Ledger, apa

OUT = Path("/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_prensa/evidencia")
OUT.mkdir(parents=True, exist_ok=True)
HOY = "2026-10-27"

# ---------------- NORMAS ----------------
# (org, codigo, titulo, edicion, estado, uso, relaciones, url, conflicto)
N = [
("ISO", "ISO 3069", "End-suction centrifugal pumps - Dimensions of cavities for mechanical seals and for soft packing",
 "2000, 2.a edicion (segun resumen); un catalogo nacional lista ademas GSO ISO 3069:2013; edicion no verificada",
 "CONFLICTO de edicion entre listados (2000 frente a una adopcion nacional de 2013); no se confirmo cual es la vigente en el publicador",
 "Dimensiones de las cavidades (caja de empaquetadura o camara de sello) de bombas centrifugas horizontales de succion axial, incluidas las de ISO 2858: una gama hasta 16 bar manometricos para empaquetadura blanda o sello mecanico y cavidades mayores hasta 40 bar para sellos mecanicos y de cartucho",
 "Segun el resumen: la ed. 2000 reemplaza a la de 1974 sin cambiar las dimensiones ya publicadas y amplia los tamanos; no es para lodos ni altos solidos; EN 12756 remite a sus cavidades",
 "https://www.sis.se/en/produkter/fluid-systems-and-components-for-general-use/pumps/ssiso3069/", True),
("CEN/EN", "EN 12756", "Mechanical seals - Principal dimensions, designation and material codes",
 "EN 12756:2000 (adopciones 2001 segun resumenes); un listado muestra tambien una ed. 2004; edicion no verificada",
 "CONFLICTO menor de edicion (2000/2001 frente a 2004 en un listado); no se confirmo vigencia",
 "Dimensiones de instalacion en la cavidad, designacion y codigos de materiales de sellos mecanicos de resortes rotativos; define la envolvente, no el desempeno: sirve para evaluar la conversion de empaquetadura a sello mecanico",
 "Segun el resumen: las dimensiones de cavidad siguen ISO 3069 y las bombas de EN 22858 y EN 733",
 "https://www.sis.se/en/produkter/mechanical-systems-and-components-for-general-use/seals-glands/ssen12756/", True),
("CEN/EN", "EN 16752", "Centrifugal pumps - Test procedure for seal packings",
 "2015 (adopciones BS, DIN y SS segun resumenes; edicion no verificada)",
 "Listada como edicion 2015 en varias tiendas nacionales; no se vio su estado de vigencia ni su revision",
 "Procedimiento de ensayo de empaquetaduras de cajas de empaquetadura de bombas centrifugas (equipo, parametros estandar, informe); define 3 clases de estanqueidad sin fijar criterios de desempeno",
 "Segun el resumen: los limites de fuga de las clases no se vieron; un resumen del borrador (Pr EN 16752) de un instituto tecnico menciona agua limpia a temperatura ambiente, ejes de 40 mm a 65 mm y minimo 2 ensayos, que puede diferir de la ed. final",
 "https://www.technickenormy.cz/bs-en-16752-2015-centrifugal-pumps-test-procedure-for-seal-packings/", False),
("ANSI/HI", "ANSI/HI 1.3", "Rotodynamic (Centrifugal) Pumps for Design and Application",
 "2013 (con edicion previa 2009 vista en la tienda ANSI); edicion no verificada",
 "CONFLICTO: la tienda ANSI muestra la ed. 2013 como historica y otro listado la da por retirada sin indicar sustituto con el mismo numero; se desconoce la edicion vigente",
 "Guia de diseno y aplicacion de bombas rotodinamicas centrifugas (incluye consideraciones de sellado); el resumen no permitio ver el texto sobre empaquetadura ni caja de empaquetadura",
 "El resumen excluye los tipos verticales de una y varias etapas con difusor; no se vio si la serie fue reorganizada en otros numeros HI",
 "https://webstore.ansi.org/standards/hi/ansihi2013", True),
("ASME", "ASME B73.1", "Specification for Horizontal End Suction Centrifugal Pumps for Chemical Process",
 "CONFLICTO de edicion: un catalogo lista B73.1-2026 (31/03/2026) y otro B73.1-2020; edicion 2012 y 2001 (R2007) figuran como anteriores; edicion no verificada",
 "Las paginas de ASME son inconsistentes entre 2026 y 2020; no se confirmo cual es la vigente",
 "Especificacion de bombas de proceso quimico horizontales de succion axial, una etapa (metalicas y de polimero solido), con intercambiabilidad dimensional; no se vio texto sobre caja de empaquetadura o camara de sello",
 "Sin relacion vista con otras normas",
 "https://store.sfs.fi/en/asme-b731-2026", True),
("API", "API Std 682 (actualizacion de estado)", "Pumps - Shaft Sealing Systems for Centrifugal and Rotary Pumps",
 "4.a edicion, mayo de 2014; listados muestran API STD 682(R2022), es decir reafirmada, no revisada (segun resumen; edicion no verificada)",
 "Complementa E-1506: dos consultas adicionales no hallaron una 5.a edicion; esto NO prueba que no exista",
 "Sistemas de sello de eje de bombas centrifugas y rotativas (ejes de 20 mm a 110 mm); API 610 la cita de forma normativa; referencia para justificar la conversion de empaquetadura a sello mecanico en servicios peligrosos",
 "Segun el resumen: la 4.a ed. prefiere transmisores continuos de presion y nivel en lugar de interruptores en los sistemas auxiliares de lavado y agrega un metodo alternativo de seleccion de arreglos (anexo A.4); la 3.a ed. es la adopcion identica de ISO 21049",
 "https://eshop.normservis.sk/norma/apistd-682_r2022-1.5.2014.html", False),
("ISO", "ISO 21049 (actualizacion de estado)", "Pumps - Shaft sealing systems for centrifugal and rotary pumps",
 "2004, 1.a edicion (segun resumen; edicion no verificada); adopcion EN ISO 21049:2004",
 "Complementa E-1507: la pagina ISO (segun el resumen) dice revisada y confirmada en 2021, pero su version en espanol dice en revision sistematica: el CONFLICTO sigue sin resolverse; un borrador de 2010 figura abandonado",
 "Sistemas de sello de eje (20 mm a 110 mm); equivalente tecnico de la 3.a ed. de API 682",
 "Segun el resumen: el borrador ISO/DIS 21049:2010 fue abandonado segun un catalogo esloveno",
 "https://www.iso.org/standard/35625.html", True),
("ISO", "ISO 10438 (partes 1 a 3)", "Petroleum, petrochemical and natural gas industries - Lubrication, shaft-sealing and control-oil systems and auxiliaries",
 "Parte 1: 2007 (2.a ed.); parte 2: 2007 (2.a ed.), confirmada tras revision de 2018; parte 3: 2007 (la ed. 2003 retirada) (segun resumenes); ediciones no verificadas",
 "No se confirmo si existe una edicion posterior a 2007 en alguna parte; la parte 4 no se vio",
 "Sistemas de lubricacion y de sellado por aceite de equipos rotativos de proceso (parte 3: sistemas de uso general que solo lubrican); contexto de lubricacion de rodamientos, no define la lubricacion por anillo ni por bano de aceite de una bomba de empaquetadura",
 "Segun el resumen: la parte 1 se usa junto con las partes 2, 3 o 4",
 "https://www.sis.se/en/produkter/petroleum-and-related-technologies/equipment-for-petroleum-and-natural-gas-industries/processing/sseniso1043812007/", False),
("ISO", "ISO 4406", "Hydraulic fluid power - Fluids - Method for coding the level of contamination by solid particles",
 "2021, 4.a edicion, enero de 2021 (segun resumen; edicion no verificada)",
 "CONFLICTO menor: una version de la pagina ISO dice confirmada en 2026 y otra la lista en revision sistematica; reemplaza a ISO 4406:2017",
 "Codigo de limpieza por conteo de particulas; referencia para reportar contaminacion solida de aceite de rodamientos (no cubre agua disuelta ni libre)",
 "Segun el resumen: cada incremento de codigo equivale aproximadamente a duplicar la contaminacion",
 "https://www.iso.org/standard/79716.html", True),
("ISO", "ISO 3448", "Industrial liquid lubricants - ISO viscosity classification",
 "1992, 2.a edicion (segun resumen; edicion no verificada)",
 "La pagina ISO (segun el resumen) la muestra revisada y confirmada en 2023; no se vio una edicion posterior",
 "Grados ISO de viscosidad de lubricantes industriales; sirve para fijar el grado del aceite del rodamiento de la bomba",
 "Segun el resumen: la viscosidad cinematica se mide por ISO 3104",
 "https://www.iso.org/standard/8774.html", False),
("VDI", "VDI 2290", "Emission control - Fugitive emissions - Sealing technology: leak tightness of flange joints (resumen del alcance)",
 "Edicion 2025-11 marcada como vigente en un listado DIN; referencias antiguas citan junio de 2012; edicion no verificada",
 "Dos ediciones en circulacion; no se abrio el texto",
 "TANGENCIAL: es una guia de estanqueidad de bridas hasta 400 grados Celsius; segun el resumen no cubre empaquetaduras ni sellos de eje de bombas; solo contexto de emisiones fugitivas",
 "Segun el resumen: companeras VDI 2200 y VDI 2440; se apoya en TA Luft y EN 1591-1",
 "https://www.din.de/en/getting-involved/standards-committees/napa/wdc-beuth:din21:391880376", False),
]

L = Ledger(); tabla = []
for i, (org, cod, tit, ed, est, uso, rel, url, conf) in enumerate(N):
    e = {"id": f"E-{2400+i}", "tipo": "norma", "acceso": "snippet", "via": "websearch", "fecha_acceso": HOY,
         "referencia": {"autores": org, "anio": None, "titulo": f"{cod}: {tit}", "fuente": org, "url": url},
         "extracto": None,
         "localizador": "resumen del buscador (WebSearch); la pagina no se abrio: WebFetch y curl no resolvieron los dominios de los publicadores",
         "afirma": f"Segun el resumen: edicion {ed}; estado: {est}. Uso: {uso}.",
         "limites": "Solo resumen de buscador con listados de terceros; no se leyo el texto ni la pagina oficial; no respalda clausulas, valores ni formulas. Edicion y estado por confirmar en el publicador.",
         "aplica_a": uso, "revista_cuartil": None}
    L.add(e)
    tabla.append({"organismo": org, "codigo": cod, "titulo": tit, "edicion_vista": ed, "estado_visto": est,
                  "nivel": "CONFLICTO" if conf else "SOLO-SNIPPET", "nivel_evidencia": "SOLO-SNIPPET",
                  "uso_en_el_caso": uso, "relaciones": rel, "url": url, "evidencia": [e["id"]]})
NORMAS_N = len(N)
(OUT / "normas_registro.json").write_text(json.dumps(list(L.entradas.values()), ensure_ascii=False, indent=1), encoding="utf-8")
(OUT / "normas_tabla.json").write_text(json.dumps(tabla, ensure_ascii=False, indent=1), encoding="utf-8")

SD = [
("ANSI/HI", "ANSI/HI 1.3 edicion vigente", "No se halla la edicion vigente ni el sustituto; el resumen no mostro texto sobre caja de empaquetadura. Consultar el publicador (Hydraulic Institute)"),
("API", "API Std 682 edicion posterior a la 4.a (R2022)", "Dos consultas no hallaron 5.a edicion; ausencia de resultado no prueba que no exista. Verificar en el catalogo de API"),
("API", "API Std 610 y API RP 691 en relacion con empaquetadura", "No se busco si API 610 admite empaquetadura blanda como arreglo de sello ni en que clausula; solo se vio que cita a API 682 de forma normativa"),
("CEN/EN", "EN 16752 limites de las tres clases de estanqueidad", "Los limites de fuga, torque y temperatura no estan en los resumenes; requieren adquirir la norma"),
("ISO", "ISO 3069 texto de las cavidades y edicion 2013 de un catalogo nacional", "No se abrio texto; los vistas previas muestran solo alcance. Falta resolver 2000 frente a 2013"),
("ISO", "Norma ISO sobre empaquetaduras blandas o compresion (materiales y desempeno)", "No se hallo una norma ISO de empaquetaduras blandas; solo EN 16752 de ensayo; falta buscar normas ASTM, DIN y guias de asociaciones de sellado"),
("ASTM", "Normas ASTM de materiales y ensayo de empaquetadura", "No buscadas en esta pasada"),
("FSA/ESA", "Guias de asociaciones de sellado (norteamericana y europea) sobre empaquetadura", "Solo se vio de pasada un articulo de energia de empaquetaduras alojado por un fabricante; las guias propias no se abrieron"),
("ISO", "ISO 15243 y ISO 281 en relacion con contaminacion por agua", "Heredadas del caso de la bomba; no se busco que clausula trata agua o contaminacion de lubricante"),
("ISO", "Normas de agua en aceite (ISO 12937 y similares) y de grasa lubricante", "No buscadas en esta pasada"),
("API", "API RP 682 emisiones fugitivas, EPA Metodo 21 y LDAR", "Regulacion de emisiones fugitivas de sellos y empaquetaduras no buscada; fuera de la lista pedida"),
("NTP", "Norma Tecnica Peruana de empaquetaduras, sellos o bombas", "No se busco ninguna; consultar el catalogo del INACAL"),
("ISO", "ISO 20816-3 aplicada a bombas con empaquetadura", "Heredada; no se busco si la clasificacion por cimentacion cambia por el tipo de sello"),
]
(OUT / "normas_sin_datos.json").write_text(json.dumps([{"organismo": o, "codigo": c, "estado_visto": "SIN DATOS", "motivo": m} for o, c, m in SD], ensure_ascii=False, indent=1), encoding="utf-8")

# ---------------- VIDA / COSTOS ----------------
V = Ledger()
LIM = ("SOLO-SNIPPET: no se abrio el documento (dominio sin resolucion en este entorno); autoria, anio y cifras no verificados; "
       "no respalda ningun valor de vida, MTBF, porcentaje ni costo. Se nombra solo como pista de lectura.")
LOC = "Resumen de buscador web (sin abrir el documento; dominio bloqueado por la red)"
def S(n, titulo, url, afirma, aplica, fuente, tipo="otro", acceso="snippet", extra=None, lim=None, loc=None, ref_extra=None):
    ref = {"titulo": titulo, "fuente": fuente, "url": url}
    if ref_extra: ref.update(ref_extra)
    e = {"id": f"E-{2430+n}", "tipo": tipo, "acceso": acceso, "via": "websearch", "fecha_acceso": HOY, "referencia": ref,
         "extracto": "", "localizador": loc or LOC, "afirma": afirma, "limites": lim or LIM, "aplica_a": aplica, "revista_cuartil": None}
    return V.add(e)

S(0, "Tesis de 2016 de una universidad tecnica chilena: estrategias de mantencion de sellos mecanicos para bombas centrifugas orientadas a los requerimientos de una refineria",
  "https://repositorio.usm.cl/handle/123456789/65602",
  "Pista: el resumen de buscador indica que el trabajo orienta la seleccion de sellos mecanicos segun condiciones de operacion, presiones y tablas de fabricantes. Pendiente de lectura del documento completo; sin cifras de vida ni costo.",
  "Vida y mantenimiento de sellos mecanicos en bombas centrifugas (Chile); comparabilidad media; no es comparacion con empaquetadura",
  "Repositorio institucional (autoria no verificada)", ref_extra={"anio": 2016, "pais": "Chile"})
S(1, "Tesis de 2011 de una universidad tecnica chilena: diseno de planes de inspeccion predictiva para bombas centrifugas en una planta refineria",
  "https://repositorio.usm.cl/handle/123456789/67483",
  "Pista: el resumen de buscador indica que el sello mecanico es el motivo de reparacion mas frecuente y que una parte alta de las solicitudes son de emergencia (los porcentajes vistos en el resumen no se transcriben). Pendiente de lectura; sin cifras.",
  "Top de fallas y mantenimiento predictivo de bombas centrifugas (Chile); comparabilidad media",
  "Repositorio institucional (autoria no verificada)", ref_extra={"anio": 2011, "pais": "Chile"})
S(2, "Tesis de 1978 de una universidad mexicana (facultad de quimica) sobre el reemplazo de sellos mecanicos en bombas centrifugas",
  "https://ru.dgb.unam.mx/bitstream/20.500.14330/TES01000168606/3/0168606.pdf",
  "Pista: el resumen de buscador indica el argumento de que el sello mecanico tiene alto costo inicial pero reduce friccion, desgaste de eje y fuga frente a la empaquetadura de compresion. Pendiente de lectura; sin cifras.",
  "Comparacion cualitativa empaquetadura frente a sello mecanico (Mexico, 1978); comparabilidad baja por antiguedad",
  "Repositorio institucional (autoria no verificada)", ref_extra={"anio": 1978, "pais": "Mexico"})
S(3, "Tesis de 1990 de una universidad mexicana (campus Cuautitlan) sobre seleccion de sellos mecanicos para bombas centrifugas",
  "https://ru.dgb.unam.mx/bitstream/20.500.14330/TES01000137517/3/0137517.pdf",
  "Pista: el indice visto en el buscador incluye una seccion de limitaciones de la empaquetadura. Pendiente de lectura; sin cifras.",
  "Limitaciones de empaquetadura segun una tesis (Mexico, 1990); comparabilidad baja",
  "Repositorio institucional (autoria no verificada)", ref_extra={"anio": 1990, "pais": "Mexico"})
S(4, "Tesis de 1996 de una universidad mexicana (campus Aragon) sobre especificacion y seleccion de sellos mecanicos para bombas centrifugas",
  "https://ru.dgb.unam.mx/bitstream/20.500.14330/TES01000234540/3/0234540.pdf",
  "Pista: el indice visto en el buscador cubre tipos de empaquetadura y sus inconvenientes. Pendiente de lectura; sin cifras.",
  "Tipos de empaquetadura y sus inconvenientes segun una tesis (Mexico, 1996); comparabilidad baja",
  "Repositorio institucional (autoria no verificada)", ref_extra={"anio": 1996, "pais": "Mexico"})
S(5, "Brochure de un fabricante de empaquetadura con modelo de costo anual de una bomba empacada (PDF alojado por el fabricante)",
  "https://www.gore.com/system/files/2023-06/GORE-GFO-Brochure-EN-JUN23.pdf",
  "Pista de costos con sesgo comercial: el resumen de buscador indica un modelo con empaquetadura de bajo precio reemplazada varias veces al anio y una relacion entre costo anual de operacion y costo de la empaquetadura; los supuestos son del fabricante. No se transcribe ninguna cifra.",
  "Estructura de costo de empaquetadura (agua de sellado, mantenimiento, reemplazos); comparabilidad baja; fuente comercial",
  "Folleto comercial (autoria corporativa)", ref_extra={"anio": 2023},
  lim=LIM + " Fuente comercial: sus supuestos de costo no son datos de planta; los costos de planta los aporta la persona.")
S(6, "Caso de estudio de un fabricante de sellos: bombas de agua contra incendio con empaquetadura cambiadas a sello mecanico",
  "https://static.aesseal.com/cases/CS0175.pdf",
  "Pista de campo con sesgo comercial: el resumen de buscador indica intervalos de ajuste y reemplazo de la empaquetadura y un aumento de MTBF tras el cambio a sello mecanico; fuente unica del fabricante. No se transcribe ninguna cifra.",
  "Intervalo de empaquetadura frente a sello mecanico en un caso (agua); comparabilidad baja; fuente comercial",
  "Caso de estudio comercial (autoria corporativa)",
  lim=LIM + " Caso unico del fabricante que vende la alternativa; no generalizable.")
S(7, "Articulo divulgativo de un fabricante de sellos: por que usar sellos mecanicos (fuga de la empaquetadura cerca de los rodamientos y contaminacion del lubricante)",
  "https://www.aesseal.com/en/resources/academy/why-use-mechanical-seals/",
  "Pista de mecanismo con sesgo comercial: el resumen de buscador indica que la empaquetadura fuga por diseno cerca de los rodamientos y atribuye a un estudio de una petrolera una perdida de vida por agua en el lubricante; la cita es de segunda mano y no se vio el original. No se transcribe ninguna cifra.",
  "Mecanismo agua de la empaquetadura hacia el rodamiento (hipotesis de causa); comparabilidad baja",
  "Articulo web comercial (autoria corporativa)",
  lim=LIM + " La cifra atribuida a un estudio de una petrolera NO esta verificada: falta el original.")
S(8, "Cantley (1977), articulo de ASLE Transactions sobre el efecto del agua disuelta en el aceite lubricante en la vida a fatiga de rodamientos de rodillos (vista solo como cita de terceros)",
  "https://www.stle.org/files/TLTArchives/2021/06_June/From_the_Editor.aspx",
  "Referencia citada por terceros como base del efecto del agua disuelta en la vida de rodamientos; el original no se leyo. Los porcentajes de los resumenes discrepan entre fuentes y no se transcriben.",
  "Mecanismo agua en aceite reduce vida a fatiga del rodamiento (ensayo de rodamientos de rodillos conicos); comparabilidad media",
  "ASLE Transactions (citado en un editorial de STLE; volumen 20, numero 3, paginas 244 a 248 segun un resumen)",
  acceso="solo_referencia", loc="Cita secundaria vista en un resumen de buscador; no se abrio ni el editorial ni el original",
  lim="NO-VERIFICADO: referencia conocida solo por citas de terceros; no se leyo; no respalda ninguna cifra ni formula de vida relativa.",
  ref_extra={"anio": 1977, "autores": "Cantley, R. E."})
S(9, "Schatzberg y Felsen (1968), trabajo citado por terceros sobre la reduccion de vida a fatiga de contacto por agua en el aceite en un probador de cuatro bolas",
  "https://www.mechanics-industry.org/articles/meca/pdf/2020/03/mi190362.pdf",
  "Referencia citada en un articulo de 2020 como antecedente del efecto del agua en el aceite; el original no se leyo; las cifras vistas en el resumen no se transcriben.",
  "Antecedente del mecanismo agua en aceite; probador de cuatro bolas, no rodamiento de bomba; comparabilidad baja",
  "Trabajo de 1968 (citado en un articulo de Mechanics and Industry)",
  acceso="solo_referencia", loc="Cita secundaria vista en un resumen de buscador; no se abrio el articulo que la cita",
  lim="NO-VERIFICADO: referencia conocida solo por citas de terceros; no se leyo; no respalda ninguna cifra.",
  ref_extra={"anio": 1968, "autores": "Schatzberg, P., y Felsen, I. M."})
S(10, "Articulo de 2020 de la revista Mechanics and Industry sobre contaminacion del lubricante (agua y detergente) y vida a fatiga en ensayo bola sobre rodillo",
  "https://www.mechanics-industry.org/10.1051/meca/2020023",
  "Pista: el resumen de buscador indica un ensayo bola sobre rodillo donde la contaminacion con agua y con detergente reduce la vida a fatiga de los rodillos; sin cifras vistas. Pendiente de lectura (acceso abierto declarado por el buscador).",
  "Mecanismo agua en lubricante y vida a fatiga (laboratorio); comparabilidad baja a media; no es bomba",
  "Mechanics and Industry (revista; cuartil no verificado)", ref_extra={"anio": 2020, "doi": "10.1051/meca/2020023"})
S(11, "Articulo de 2024 de la revista Problems of Tribology: modelo de desgaste de la empaquetadura de una caja de empaquetadura y de su manguito protector (Archard, ANSYS)",
  "https://doaj.org/article/610ebbce9df24e99b490aafd3da872be",
  "Pista: el resumen de buscador indica una simulacion de desgaste de empaquetadura y manguito con el modelo de Archard, validada segun el texto con ensayos previos; es simulacion, no medicion. Pendiente de lectura; sin cifras.",
  "Desgaste de empaquetadura y manguito (simulacion); comparabilidad baja a media",
  "Problems of Tribology (revista; cuartil no verificado)", ref_extra={"anio": 2024})
S(12, "Articulo de 2015 de la asociacion norteamericana de sellado sobre eficiencia energetica de empaquetaduras de compresion (PDF alojado por un fabricante; autor Azibert segun el buscador)",
  "https://www.gore.com/sites/default/files/2016-05/Article-EnergyEfficiency-of-CompressionPackings-Henri%20Azibert-FSA-August2015-Web.pdf",
  "Pista: el resumen de buscador indica ensayos de torque de una empaquetadura de grafito y PTFE expandido frente a un sello mecanico de fuelle elastomerico, con friccion de la empaquetadura del mismo orden o menor. Pendiente de lectura; sin cifras.",
  "Friccion y energia de empaquetadura frente a sello mecanico; fuente de fabricante; comparabilidad media",
  "Articulo de asociacion alojado por un fabricante", ref_extra={"anio": 2015},
  lim=LIM + " Alojado por un fabricante de empaquetadura: posible sesgo.")
S(13, "Articulo divulgativo de una revista de confiabilidad: empaquetadura de caja de empaquetadura, desgaste concentrado en los primeros anillos",
  "https://accendoreliability.com/shaft-sealing-packed-gland/",
  "Pista: el resumen de buscador atribuye el desgaste principal a los primeros anillos cercanos al prensaestopa, salvo servicio con lodos; sin cifra verificada ni fuente primaria.",
  "Practica de ajuste y desgaste de empaquetadura; comparabilidad baja; blog",
  "Articulo web divulgativo (autoria no verificada)")
S(14, "Tabla de seleccion de un proveedor industrial con vida de empaquetadura frente a sello mecanico, sin fuente declarada",
  "https://industrialmonitordirect.com/blogs/knowledgebase/mechanical-seal-vs-packing-gland-pump-seal-selection-guide",
  "Pista descartable: el resumen de buscador muestra rangos de vida de empaquetadura y de sello sin fuente que los respalde y que contradicen otros textos. No se transcribe ninguna cifra.",
  "Rangos de vida sin fuente; comparabilidad baja; no usar como respaldo",
  "Guia web comercial (autoria no verificada)",
  lim=LIM + " Los rangos de la guia no tienen fuente: no son evidencia.")
S(15, "Pump User's Handbook: Life Extension (Bloch; 4.a edicion segun un listado de 2013; otro listado muestra 2020)",
  "https://routledge.com/9781482228649",
  "Libro de referencia a leer: los listados muestran capitulos sobre rodamientos en bombas centrifugas, seleccion y aplicacion de sellos mecanicos y estadisticas de falla; no se leyo ningun capitulo.",
  "Libro de referencia para modos de falla de bomba, sello y rodamiento; comparabilidad media (practica de campo)",
  "Libro (editorial no verificada)", tipo="libro", acceso="solo_referencia",
  loc="Listado de librerias vista en un resumen de buscador; no se leyo el libro",
  lim="NO-VERIFICADO: solo ficha bibliografica; edicion y anio en conflicto entre listados; no respalda cifras de vida ni costo.",
  ref_extra={"autores": "Bloch, H. P.", "anio": 2013})

(OUT / "vida_registro.json").write_text(json.dumps(list(V.entradas.values()), ensure_ascii=False, indent=1), encoding="utf-8")
(OUT / "vida_cifras.json").write_text("[]", encoding="utf-8")
(OUT / "vida_replicas.json").write_text("[]", encoding="utf-8")
VE = [
 {"seccion": "vida_util", "titulo": "Comparacion empaquetadura frente a sello mecanico: pistas de tesis y fabricantes (sin cifras leidas)",
  "evidencia": ["E-2430", "E-2431", "E-2432", "E-2433", "E-2434", "E-2435", "E-2436"],
  "limite": "Todo es SOLO-SNIPPET: ninguna tesis ni documento se abrio (repositorios y sitios sin resolucion en este entorno). Las fuentes de fabricantes tienen sesgo comercial. No hay cifra de vida, MTBF ni costo respaldable; los costos de planta los aporta la persona."},
 {"seccion": "fenomenos", "titulo": "Mecanismo: fuga de la empaquetadura, agua en el lubricante y vida del rodamiento",
  "evidencia": ["E-2437", "E-2438", "E-2439", "E-2440", "E-2441"],
  "limite": "Cantley y Schatzberg son NO-VERIFICADO (citas de terceros); el articulo de 2020 es SOLO-SNIPPET; los ensayos son de laboratorio con rodamientos de rodillos o cuatro bolas, no de bomba con prensaestopa; sin dosis-respuesta leida."},
 {"seccion": "costos", "titulo": "Estructura de costo de una bomba empacada: agua de sellado, energia, mantenimiento y reemplazos",
  "evidencia": ["E-2435", "E-2442", "E-2445"],
  "limite": "Modelos y supuestos de fabricantes, sin datos de planta; ninguna cifra transcrita; el libro de referencia no se leyo."},
]
(OUT / "vida_elementos.json").write_text(json.dumps(VE, ensure_ascii=False, indent=1), encoding="utf-8")

# comprobar que ids de elementos existan
ids = set(V.entradas) | set(L.entradas)
for s in VE:
    for i in s["evidencia"]: assert i in ids, i
print("normas", NORMAS_N, "vida", len(V.entradas))
print("\n".join(apa(e) for e in list(L.entradas.values())[:3]))
print("---")
for e in V.entradas.values(): print(e["id"], apa(e))

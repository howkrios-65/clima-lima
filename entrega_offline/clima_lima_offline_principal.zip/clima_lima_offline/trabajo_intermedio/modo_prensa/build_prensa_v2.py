import json, glob, sys, os, shutil, datetime as dt
sys.path.insert(0, '/home/user/clima-lima/tools/reliability')
from reliability_kit import Ledger, dossier
from reliability_kit import report_html as rh
BASE = '/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_prensa/'
EVD = BASE + 'evidencia/'; EVB = BASE.replace('modo_prensa','modo_bomba') + 'evidencia/'; AN = BASE + 'analisis_v3/'
OUT = '/home/user/clima-lima/historial/dossiers/bomba_prensaestopa_rodamientos/'
L = Ledger.from_json(BASE + 'evidencia_total.json')
J = lambda p, d=None: (json.load(open(p, encoding='utf-8')) if os.path.exists(p) else d)
leida = lambda i: L.puede_afirmar([i], 'VERIFICADO-ABSTRACT')[0]
titulos = {s[0]: s[1] for s in dossier.SECCIONES}
V = "Sin hallazgo con respaldo leído para este modo de falla en las vías disponibles"
S = {s[0]: {"elementos": []} for s in dossier.SECCIONES}; omit = []
for f in sorted(glob.glob(EVD + '*_elementos.json')) + sorted(glob.glob(EVB + '*_elementos.json')) + sorted(glob.glob(AN + 'elementos_*.json')):
    for el in J(f, []):
        sec = el.get('seccion')
        if sec not in S or sec == 'referencias': omit.append((os.path.basename(f), 'sección inválida')); continue
        ids = [i for i in el.get('evidencia', []) if i in L.entradas and i not in ('E-1702', 'E-2351')]
        if not ids or not all(leida(i) for i in ids): omit.append((el.get('titulo', '')[:60], 'evidencia no leída o inexistente')); continue
        S[sec]["elementos"].append({"tipo": "afirmacion", "titulo": el['titulo'], "evidencia": ids, "limite": el.get('limite') or "no declarado"})
for k, s in S.items():
    if k != 'referencias' and not s['elementos']: s['vacio'] = V
for _s in S.values():
    for _e in _s['elementos']:
        if any(i in _e['evidencia'] for i in ('E-1301','E-1302','E-1303')): _e['limite'] = (_e['limite'] or '') + ' Detalles como vibración triaxial, FFT, wavelet y entornos de fábrica constan en resúmenes, no en los extractos.'
for _k in ('fmeca', 'acr', 'lcc', 'top_fallas'):
    if S[_k].get('vacio'): S[_k]['vacio'] = V + '. El análisis del equipo (síntesis) está en las pestañas Modos y causas y Vida y costos, con su nivel de evidencia.' if _k in ('fmeca', 'acr') else V
S['mpd_normas']['nota'] = "Las normas identificadas se vieron solo en resúmenes de buscador (SOLO-SNIPPET): ver Referencias, Normas técnicas."
cit = sorted({i for k, s in S.items() for e in s['elementos'] for i in e['evidencia']})
import re as _re
_extra = set()
for _f in glob.glob(AN + '*.json') + [BASE + 'abstract.json']:
    _extra |= set(_re.findall(r'E-\d{4}', open(_f, encoding='utf-8').read()))
cit = sorted(set(cit) | {i for i in _extra if i in L.entradas and leida(i)})
S['referencias'] = ({"elementos": [{"tipo": "referencia", "titulo": "Fuentes realmente usadas en este dossier", "evidencia": cit, "limite": "no declarado"}]} if cit else {"elementos": [], "vacio": V})
D = {"modo_falla": "falla del paquete de rodamientos de bombas con prensaestopa", "secciones": S}
val = dossier.validar_dossier(D, L); print(val['cobertura'], val['errores'][:3]); assert not val['errores'], val['errores']
hall = []; k = 0
for sid, s in S.items():
    if sid == 'referencias': continue
    for e in s['elementos']:
        k += 1; hall.append({"id": f"H{k}", "texto": f"[{titulos[sid]}] {e['titulo']}. Límite: {e['limite']}", "evidencia": e['evidencia']})
vac = [f"{titulos[s]}: {x['vacio']}" for s, x in S.items() if x.get('vacio')] + [f"{titulos[s]}: {x['nota']}" for s, x in S.items() if x.get('nota')] + J(BASE + 'vacios_extra.json', [])
primero = next(iter(L.entradas))
caso = {"meta": {"titulo": "Dossier del modo de falla: paquete de rodamientos de bombas con prensaestopa", "activo": "Bomba con prensaestopa (rodamientos)", "origen_datos": "literatura leída por el equipo; sin datos de planta", "n_fallas": 0},
        "resumen": {"kpis": [{"label": "entradas en el registro (incluye pistas)", "valor": str(len(L.entradas)), "evidencia": [primero]},
                             {"label": "secciones con evidencia leída (sin Referencias)", "valor": f"{val['cobertura']['con_evidencia'] - (1 if cit else 0)} de 13", "evidencia": [primero]},
                             {"label": "secciones SIN DATOS PARA ARMARLO", "valor": str(val['cobertura']['vacias']), "evidencia": [primero]}], "hallazgos": hall},
        "tablas": J(BASE + 'tablas.json', []), "vacios": vac, "supuestos": J(BASE + 'supuestos.json', ["Sin caso real: ningún dato de planta se usó."]), "preguntas": J(BASE + 'preguntas.json', []),
        "historial": [{"version": "v1", "fecha": dt.date.today().isoformat(), "cambio": "Primer dossier de rodamientos de bombas con prensaestopa", "baseline": "SIN DATOS PARA ARMARLO: sin datos de falla del activo"}, {"version": "v2", "fecha": dt.date.today().isoformat(), "cambio": "v2: análisis del paquete de rodamientos con la cadena prensaestopa, fuga, agua y rodamiento como hipótesis; hereda lo leído del caso de la bomba centrífuga", "baseline": "SIN DATOS PARA ARMARLO: sin datos de falla del activo"}],
        "recurrencia": {"detectada": False, "texto": "Sin casos reales de bombas con prensaestopa en el historial; el caso de la bomba centrífuga comparte los rodamientos."},
        "busqueda": {"frentes": ["mecanismos", "sellos y rodamientos", "monitoreo", "vida y costos", "normas", "ML y RUL", "datos abiertos"], "validacion_dossier": val['cobertura']}}
caso["dossier"] = {"orden": [x[0] for x in dossier.SECCIONES], "titulos": titulos, "frentes": {x[0]: x[2] for x in dossier.SECCIONES}, "secciones": S}
caso["simulador"] = True
an = {}
fm = J(AN + 'fmeca.json')
if fm:
    for it in fm['items']:
        t = it.get('tarea_rcm')
        if isinstance(t, dict): it['tarea_rcm'] = f"{t.get('tipo','')} (consecuencia: {t.get('consecuencia_a_confirmar','')}). {t.get('razonamiento','')}"
    an['fmeca'] = fm
for n in ('arbol', 'acr', 'lcc', 'vida', 'predictivo'):  # lcc propio v2
    x = J(AN + n + '.json')
    if x: an[n] = x
ar = an.get('arbol')
if ar:
    vv = [n for n in ar['nodos'] if n.get('nivel') == 'VACIO' or not n.get('evidencia')]
    ids_v = {n['id'] for n in vv}
    ar['nodos'] = [n for n in ar['nodos'] if n['id'] not in ids_v]
    for n in ar['nodos']: n['hijos'] = [h for h in n.get('hijos', []) if h not in ids_v]
    _hij = {h for n in ar['nodos'] for h in n.get('hijos', [])}; _raiz = ar['nodos'][0]
    for n in ar['nodos'][1:]:
        if n['id'] not in _hij: _raiz['hijos'].append(n['id'])
    ar['vacios'] = (ar.get('vacios') or []) + ['SIN DATOS PARA ARMARLO (modo propio de la bomba sin fuente leída): ' + n['texto'] for n in vv]
ish = J(AN + 'ishikawa.json')
if ish and 'acr' in an:
    an['acr']['ishikawa'] = {c: [x for x in v if x] for c, v in ish.items() if not c.startswith('_')}
    an['acr']['ishikawa_notas'] = J(AN + 'ishikawa_notas.json', {})
for n in ('porques', 'observar'):
    x = J(AN + n + '.json')
    if x: an[n] = {"items": x} if isinstance(x, list) else x
an["herramientas"] = True
caso["analisis"] = an
for _n, _v in an.items():
    if isinstance(_v, dict):
        for _x in _v.get("vacios", []) or []:
            if _x not in caso["vacios"]: caso["vacios"].append(_x)
def cargar(suf):
    out = []
    for p in sorted(glob.glob(EVD + '*_' + suf + '.json')) + sorted(glob.glob(EVB + '*_' + suf + '.json')):
        tag = ('h' if '/modo_bomba/' in p else 'p') + os.path.basename(p).split('_')[0][:3] + '-'
        for x in J(p, []):
            if 'id' in x: x['id'] = tag + str(x['id'])
            out.append(x)
    return out
caso["cifras"] = cargar('cifras'); caso["replicas"] = cargar('replicas'); caso["sensores"] = cargar('tecnicas'); caso["topfallas"] = cargar('topfallas')
_nn = J(EVD + 'normas_tabla.json', []); _ids = {x.get('codigo') for x in _nn}
def _solo_leidas(lst, key='evidencia'):
    out = []
    for x in lst:
        ids = [i for i in x.get(key, []) if i in L.entradas]
        if ids and all(leida(i) for i in ids): x[key] = ids; out.append(x)
    return out
caso["cifras"] = _solo_leidas(caso["cifras"]); caso["replicas"] = _solo_leidas(caso["replicas"]); caso["sensores"] = _solo_leidas(caso["sensores"])
_cb = ('E-2615', 'E-2600', 'E-2608', 'E-2609', 'E-2610', 'E-2611', 'E-2612')
caso["cifras"] = [x for x in caso["cifras"] if not any(i in _cb for i in x['evidencia'])]
caso["normas"] = _nn + [x for x in J(BASE + 'normas_bomba_tabla.json', []) if x.get('codigo') not in _ids]
caso["normas_sin_datos"] = J(EVD + 'normas_sin_datos.json', []) + J(EVB + 'normas_sin_datos.json', [])
caso["evaluar"] = J(BASE + 'evaluar.json', [])
ml = J('/home/user/clima-lima/historial/dossiers/chumacera_polea_faja/ml_lab.json'); ml["refs"] = J(BASE + 'ml_refs.json', []); caso["ml_lab"] = ml
caso["topfallas_pendiente"] = J(BASE + 'topfallas_pendiente.json', None)
caso["trazabilidad"] = J(BASE + 'trazabilidad.json', []); caso["ranking"] = []
ab = J(BASE + 'abstract.json')
if ab: caso["abstract"] = ab
dg = J(BASE + 'degradacion.json')
if dg: caso["degradacion"] = dg
_t = json.dumps(caso, ensure_ascii=False).replace('VACÍO', 'SIN DATOS PARA ARMARLO')
for _a, _b in (('MCC5 Group Shanghai', 'institución industrial'), ('Gilbert High Speed Planer', 'cepilladora de alta velocidad'), ('FPInnovations', 'instituto de investigación'), ('SKF 6205', 'rodamiento rígido de bolas 6205')): _t = _t.replace(_a, _b)
caso = json.loads(_t)
os.makedirs(OUT + 'analisis', exist_ok=True)
r = rh.construir_informe(caso, L, BASE + 'informe_bomba.html')
shutil.copy(BASE + 'informe_bomba.html', OUT + 'informe.html'); L.to_json(OUT + 'evidencia.json')
json.dump(D, open(OUT + 'dossier.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
for n, o in an.items():
    if n != 'herramientas': json.dump(o, open(OUT + 'analisis/' + n + '.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
for n in ('cifras', 'replicas', 'sensores', 'topfallas', 'normas', 'trazabilidad'): json.dump(caso[n], open(OUT + n + '.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
if ab: json.dump(ab, open(OUT + 'abstract.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
json.dump({"modo_falla": "falla del paquete de rodamientos de bombas con prensaestopa", "fecha": dt.date.today().isoformat(), "version": 2, "entradas_registro": len(L.entradas), "omitidos": omit[:20], "nota": "Pistas SOLO-SNIPPET no respaldan afirmaciones"}, open(OUT + 'meta.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
import collections as _c
for _a in r['ajustes']: print('AJ', _a.get('donde'), '|', _a.get('tipo'), '|', str(_a.get('detalle'))[:110])
print('ajustes', len(r['ajustes']), L.resumen()['por_nivel'], 'omitidos', omit[:6])

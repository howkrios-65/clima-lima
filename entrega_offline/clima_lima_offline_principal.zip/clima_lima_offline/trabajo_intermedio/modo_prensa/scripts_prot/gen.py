import json
OUT='/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_prensa/evidencia/'
NA='Autoria no visible en el resumen'
def E(n,tipo,aut,anio,tit,fuente,url,afirma,limites,aplica,acc='snippet',via='websearch',ext='',loc=''):
    return {"id":f"E-{n}","tipo":tipo,"acceso":acc,"via":via,"fecha_acceso":"2026-10-27",
      "referencia":{"autores":aut,"anio":anio,"titulo":tit,"fuente":fuente,"url":url},
      "extracto":ext,"localizador":loc,"afirma":"SOLO-SNIPPET (pagina no abierta): "+afirma,
      "limites":limites+" Texto no leido; solo resumen de buscador; no respalda cifras ni entregables hasta abrir la fuente.",
      "aplica_a":aplica,"revista_cuartil":None}
R=[]
R.append(E(2600,'otro','Hydraulic Institute (preguntas frecuentes)',2020,'HI Pump FAQs, Pumps & Systems, noviembre 2020 (titulo de pagina visto: "Pumps & Systems - November 2020")','Pumps & Systems, nov. 2020 segun el buscador','https://www.qgdigitalpublishing.com/article/HI+PUMP+FAQS/3789953/677480/article.html',
 'el resumen del buscador dice que cada aceite tiene su nivel seguro de agua, que no hay un ppm uniforme, da como ejemplo en aceites minerales dano por agua libre entre 400 y 500 ppm a 60 C y agua libre desde 200 ppm a 52 C, y recomienda un lubricador de nivel constante de sistema cerrado con tapon sellante en lugar de respiradero.',
 'Pagina de preguntas frecuentes de una asociacion de bombas, no estudio; ejemplos para un aceite mineral no identificado; no es limite de norma.',
 'Limite de agua en aceite de soporte de bomba (c); respiraderos y lubricador (a)'))
R.append(E(2601,'otro',NA,None,'Understanding bearing housing protection and reliable lubricant application (articulo de revista tecnica en linea)','reliabilityweb.com (fecha no vista)','https://reliabilityweb.com/articles/entry/understanding_bearing_housing_protection_and_reliable_lubricant_application',
 'el resumen del buscador dice que los soportes respiran por dilatacion y contraccion del gas con la temperatura y aspiran aire humedo en cada ciclo, y recomienda quitar respiraderos y usar lubricadores de nivel constante compensados por presion.',
 'Articulo de revista tecnica de mantenimiento sin ensayo visible; autoria y fecha no vistas.',
 'Respiraderos y ciclos termicos como via de agua distinta del prensaestopa (a)'))
R[-1]['tipo']='otro'
R.append(E(2602,'otro',NA,2014,'Articulo de revista tecnica de un fabricante de rodamientos sobre sellado de cubos de eje (resumen del buscador; titulo exacto no visto)','Revista de ingenieria de un fabricante (2014 segun el buscador)','',
 'el resumen del buscador dice que el agua es atraida al laberinto por tension superficial, que una pelicula de agua en el laberinto puede bloquear mas penetracion con el cubo girando y que queda agua residual al parar; tambien trata desgaste de labio y oxido.',
 'Dominio de empresa (url vacia); cubo de eje de vehiculo, no soporte de bomba; no cuantifica eficacia en soporte de bomba.',
 'Comportamiento de un laberinto frente a agua (a); comparabilidad con soporte de bomba: baja'))
R.append(E(2603,'otro',NA,None,'Bearing device with seal treatment to reduce water ingress and method thereof (patente US9677604B2)','Patente US9677604B2 (Google Patents)','https://patents.google.com/patent/US9677604',
 'el resumen del buscador dice que la patente describe que un laberinto de trayecto serpenteante da proteccion limitada contra el agua y que un retén de labio separado es solo parcialmente eficaz; propone tratamiento hidrofobico.',
 'Patente: texto de antecedentes del solicitante, sin datos de ensayo visibles; no es estudio revisado por pares.',
 'Limites declarados de laberinto y retén de labio frente a agua (a)'))
R.append(E(2604,'otro',NA,None,'Sealing device (patente US10344803)','Patente US10344803 (US PPUBS)','https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/10344803',
 'el resumen del buscador dice que la patente reporta ejemplos experimentales de vida de sellado con un laberinto: mayor vida si el primer tramo mide al menos 1,5 mm de largo axial y el segundo tramo tiene holgura de 1 mm o menos, y que el bombeo por rotacion expulsa agua con barro.',
 'Patente de un dispositivo concreto, con agua con barro; no es soporte de bomba ni prensaestopa; cifras no verificadas en el texto.',
 'Geometria de laberinto y expulsion de agua por rotacion (a)'))
R.append(E(2605,'otro',NA,None,'Bearing isolators meet tough demands (articulo de revista de la industria de bombas)','Pumps & Systems (fecha no vista)','https://pumpsandsystems.com/bearing-isolators-meet-tough-demands',
 'el resumen del buscador dice que los aisladores de rodamiento son sellos sin contacto con trayecto tortuoso, fuerza centrifuga y puertos de drenaje, y que no son la seleccion correcta si el soporte puede quedar sumergido.',
 'Articulo de revista tecnica sin ensayo comparativo visible; el buscador no halló ensayo de ingreso de agua con aislador, retén y laberinto en soporte de bomba.',
 'Aisladores sin contacto y drenaje (a); comparabilidad con soporte de bomba: media'))
R.append(E(2606,'tesis','Marcello Attilio Gracia',2003,'Avaliacao da contaminacao em oleos lubrificantes de rolamentos atraves da analise do oleo e da assinatura dos sinais de vibracoes','Dissertacion de maestria, Universidad de Sao Paulo (segun el buscador; orientador Linilson Rodrigues Padovese)','https://www.teses.usp.br/teses/disponiveis/3/3132/tde-19022024-105452/?&lang=en',
 'el resumen del buscador dice que se midio a la vez el nivel de contaminacion segun ISO 4406 y la vibracion de rodamientos en bano de aceite limpio y contaminado y se compararon con el RMS en bandas de frecuencia; contaminacion de origen fisico (particulas).',
 'Contaminacion por particulas, no agua; banco; el buscador no mostro texto integral ni cifras; resumen truncado en la fuente.',
 'Deteccion con aceite mas vibracion (b); ISO 4406 aplicado a rodamientos (c); no cubre agua'))
R[-1]['referencia']['pais']='Brasil'
R.append(E(2607,'otro',NA,None,'How to Determine Moisture Limits in Oil (articulo de revista tecnica de lubricacion)','machinerylubrication.com, articulo 30744 (fecha no vista)','https://www.machinerylubrication.com/Articles/Print/30744',
 'el resumen del buscador dice que los niveles objetivo de humedad dependen de la sensibilidad y criticidad de la maquina, que como referencia para motores sobre 300 ppm se vigila y entre 1500 y 2000 ppm hay alarma, que los aditivos pueden interferir con Karl Fischer y que el limite lo fija normalmente el fabricante.',
 'Articulo de revista tecnica; las cifras se dieron como referencia de motores, no de rodamientos de bomba; atribucion de las cifras al articulo viene del resumen del buscador.',
 'Limites practicos de agua en aceite (c); interferencia en la medicion (b)'))
R.append(E(2608,'otro',NA,None,'Water in Turbine Oil: What is the Suggested Limit? (articulo de revista tecnica de lubricacion)','machinerylubrication.com, articulo 30440 (fecha no vista)','https://machinerylubrication.com/Articles/Print/30440?id=30440',
 'el resumen del buscador dice que no hay norma que fije el agua permitida en aceite de turbina, que ASTM D4378 trata 1000 ppm como cantidad significativa a condenar, que algunos fabricantes usan 500 ppm de advertencia y que el articulo sugiere fijar limites con Karl Fischer.',
 'Aceite de turbina, no de soporte de bomba; atribuciones por resumen de buscador.',
 'Limites de agua en aceite de turbina como referencia comparativa (c)'))
R.append(E(2609,'otro',NA,None,'Tabla de extension de vida por limpieza y humedad de un fabricante de lubricantes (febrero 2016)','Hoja de ventas de fabricante de lubricantes','',
 'el resumen del buscador dice que la tabla da un factor de extension de vida de 2,0 para rodamientos de elementos rodantes al bajar la humedad de 1000 a 250 ppm y cita una revista tecnica como fuente.',
 'Dominio de empresa (url vacia); material comercial; origen del factor no verificado; no es ensayo.',
 'Efecto del agua en la vida del rodamiento (c)'))
R.append(E(2610,'paper','Felsen, McQuaid y Marzani (segun el resumen del buscador)',1972,'Effect of seawater on the fatigue life and failure distribution of flood-lubricated angular contact ball bearings','ASLE (segun el buscador); registro de base de datos de transporte','https://trid.trb.org/View/11446',
 'el resumen del buscador dice que la vida a fatiga de contacto cayo hasta 80 por ciento al anadir 1 por ciento de agua de mar en volumen a varios lubricantes y que las fallas pasaron de las bolas a las pistas.',
 'Agua de mar en aceite con lubricacion por inundacion, ensayo de banco de 1972; no es grasa ni agua dulce de prensaestopa; titulo y datos vistos solo en listado; el resumen resume el registro.',
 'Efecto del agua en la vida a fatiga (mecanismo) que justifica proteccion y deteccion (a, b)'))
R[-1]['referencia']['doi']=None
del R[-1]['referencia']['doi']
R.append(E(2611,'norma','ISO',2000,'ISO 12937:2000 Petroleum products - Determination of water - Coulometric Karl Fischer titration method','ISO 12937:2000 (copia del catalogo de un organismo de normalizacion)','https://dgsm.gso.org.sa/store/standards/iso:pub:std:IS:2730/ISO%2012937:2000?lang=en',
 'el resumen del buscador reproduce el alcance: determinacion directa de agua en productos del petroleo que hierven por debajo de 390 C, rango de fraccion masica 0,003 % a 0,100 % (m/m); no aplica a productos con cetonas ni a combustibles residuales; puede aplicar a aceites base lubricantes pero la precision no esta establecida para ellos.',
 'Pagina de catalogo, no el documento de la norma; la precision de la clausula 12 y el anexo B no se verificaron; edicion vigente no confirmada. No fija limite alguno de agua para lubricantes.',
 'Metodo de medicion de agua (c): su alcance no cubre bien aceites lubricantes ni grasas'))
R.append(E(2612,'norma','ASTM',2016,'ASTM D6304-16e1 Standard Test Method for Determination of Water in Petroleum Products, Lubricating Oils, and Additives by Coulometric Karl Fischer Titration','ASTM D6304 (edicion 2016 en catalogo; el buscador indica edicion 2025 vigente)','https://store.astm.org/d6304-16e01.html',
 'el resumen del buscador reproduce el alcance de la edicion 2016: agua entre 10 y 25000 mg/kg en productos del petroleo e hidrocarburos, incluye aceites lubricantes y aditivos, analisis indirecto con gas inerte seco, e interferencias de mercaptanos y sulfuros.',
 'Alcance de la edicion 2016 por secundarias; no se abrio la edicion 2025; norma de metodo, no de limite.',
 'Metodo de agua en aceite de lubricacion (b, c)'))
R.append(E(2613,'norma','ISO',2017,'ISO 15243:2017 Rolling bearings - Damage and failures - Terms, characteristics and causes','ISO 15243:2017 (catalogo de un organismo de normalizacion)','https://genorma.com/en/standards/iso-15243-2017',
 'el resumen del buscador dice que la norma clasifica los modos de falla en servicio de rodamientos de acero estandar, por apariencia y no solo por causa raiz; fuentes secundarias listan corrosion y fallas relacionadas con la lubricacion, pero las listas de categorias difieren entre fuentes.',
 'No se vio ninguna clausula de la norma ni limite de agua; la norma clasifica dano y no fija ppm. Ya hay entrada previa de esta norma (E-1520); esta anade solo el alcance visto.',
 'Clasificacion de dano por agua y corrosion (c); no limite de agua'))
R.append(E(2614,'norma','ISO',2001,'ISO 4406 Hydraulic fluid power - Fluids - Method for coding the level of contamination by solid particles (edicion 2001 en catalogo)','SIST ISO 4406:2001 (catalogo de un organismo de normalizacion)','https://iteh.es/catalog/standards/sist/b95d029c-b576-4ac4-90da-01f32a73eadf/sist-iso-4406-2001',
 'el resumen del buscador indica que el codigo ISO 4406 clasifica la contaminacion por conteo de particulas solidas, con un paso de codigo equivalente a duplicar la contaminacion; no hallo texto que trate el agua como parte del codigo.',
 'Catalogo; no se leyo el alcance ni la clausula de interferencia por agua en contadores opticos (no confirmado). ISO 4406 es de particulas solidas, no de agua. Ya hay entrada previa de la norma (E-2408).',
 'Aclara que ISO 4406 no es limite de agua (c)'))
R.append(E(2615,'otro','Blair Fraser (presentacion; segun el buscador)',None,'Gain Deep Insights Into Bearing Health (presentacion alojada en sitio universitario)','rmc.utk.edu, PDF de presentacion (2021 segun la ruta)','https://rmc.utk.edu/wp-content/uploads/2021/07/Blair_Fraser-Gain_Deep_Insights_Into_Bearing_Health.pdf',
 'el resumen del buscador describe material de proveedor que usa aumentos en dB sobre la linea base: 8 dB como falta de lubricacion, 16 dB como dano de rodamiento y 35 dB como cercano a la falla.',
 'Presentacion de proveedor: heuristica sin validacion; no mide agua; no es evidencia segun el protocolo. Cifras no leidas en el documento.',
 'Ultrasonido para deteccion temprana (b); umbrales NO usables hasta leer'))
R[-1]['tipo']='otro'
R.append(E(2616,'paper',NA,2025,'Monitoring of water contamination in lubricants for rotating machines (emision acustica con metodo hibrido IVY-VMD y CNN; titulo recortado por el buscador)','Repositorio de la Universidad de Huddersfield (segun el buscador)','https://pure.hud.ac.uk/en/publications/monitoring-of-water-contamination-in-lubricants-for-rotating-mach/',
 'el resumen del buscador dice que un estudio de 2025 aborda la humedad en lubricantes de maquinas rotativas con emision acustica y un metodo hibrido IVY-VMD con CNN.',
 'Solo titulo y resumen del buscador; metodo, niveles de agua y resultados no vistos; no es bomba ni prensaestopa.',
 'Deteccion de agua en lubricante con emision acustica (b)'))
R[-1]['tipo']='otro'
R[-1]['referencia']['pais']='Reino Unido'
R.append(E(2617,'paper',NA,2022,'Grease Contamination Detection in the Rolling Element Bearing Using Deep Learning Technique','Repositorio institucional ir.vignan.ac.in (segun el buscador)','https://ir.vignan.ac.in/id/eprint/516/',
 'el resumen del buscador dice que se uso polvo de arena en grasa de rodamientos de bolas y que vibracion con SVM y CNN clasifico bien las fallas por contaminacion del lubricante.',
 'Contaminante solido (arena), no agua; banco; modelos de aprendizaje; solo resumen de buscador.',
 'Deteccion de contaminacion de grasa por vibracion (b); no cubre agua'))
R[-1]['tipo']='otro'
R.append(E(2618,'paper',NA,2005,'Contaminacion de aceite con cuarzo y analisis espectral de vibracion en rodamiento (trabajo en actas COBEM 2005; titulo exacto no visto)','Actas COBEM 2005, trabajo 0808 (abcm.org.br)','https://abcm.org.br/app/webroot/anais/cobem/2005/PDF/COBEM2005-0808.pdf',
 'el resumen del buscador dice que el analisis espectral de acelerometro indico que la contaminacion se puede identificar en bandas de frecuencia concretas de la vibracion.',
 'Contaminante de cuarzo, no agua; banco; autoria y titulo no vistos.',
 'Vibracion para contaminacion del lubricante (b); no cubre agua'))
R[-1]['tipo']='otro'
R.append(E(2619,'tesis',NA,2018,'Propuesta de mejora para elementos sellantes de la unidad rotatoria en bomba centrifuga de la zona de caustificacion de una planta de celulosa (palabra clave: sello laberinto)','Tesis, Universidad Tecnica Federico Santa Maria, Chile (segun el buscador)','https://repositorio.usm.cl/entities/tesis/7d59ea64-f5ec-480a-baca-d99a51a4c1ec/full',
 'el resumen del buscador la senala como tesis de acceso abierto sobre mejora de elementos sellantes de una bomba centrifuga que incluye palabra clave sello laberinto.',
 'Solo titulo y palabras clave vistos; no se sabe si trata ingreso de agua al soporte de rodamientos ni si mide eficacia; pista principal para abrir.',
 'Sellado de bomba centrifuga con laberinto (a): pista por abrir'))
R[-1]['referencia']['pais']='Chile'
R.append(E(2620,'otro',NA,None,'Patente de respiradero con desecante para rodamientos (US4177048A) y patente de sistema de lubricacion cerrado (US5129482)','Patentes en Google Patents y US PPUBS','https://patents.google.com/patent/US4177048A/en',
 'el resumen del buscador dice que una patente de 1978 describe un dispositivo con desecante que alimenta aire seco a los rodamientos para reducir condensacion y oxido y que reconoce que no es posible eliminar toda la humedad del aire; otra patente describe humedad que condensa en paredes de la bomba durante paradas y que pequenas cantidades de agua causan deterioro rapido del rodamiento.',
 'Patentes; sin datos de eficacia vistos; dos documentos resumidos en una entrada.',
 'Respiraderos con desecante y sistemas cerrados (a)'))
R.append(E(2621,'otro',NA,None,'Capacitance measurement in a bearing housing (patentes US9644684 y US9556913)','Patentes en US PPUBS','https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/9644684',
 'el resumen del buscador muestra solo el titulo de dos patentes sobre medicion de capacitancia en un soporte de rodamientos; no se vio su contenido.',
 'Solo titulo; no se sabe si miden agua en el aceite; sin datos de desempeno.',
 'Posible sensor de agua en soporte (b): pista por abrir'))
R.append(E(2622,'otro',NA,None,'Water contamination in bearing lubrication (articulo de Pumps & Systems; solo titulo y direccion vistos)','Pumps & Systems (fecha no vista)','https://pumpsandsystems.com/water-contamination-bearing-lubrication',
 'solo se vio el titulo y la direccion en el listado del buscador; el contenido no se vio.',
 'Contenido desconocido.',
 'Agua en lubricacion de rodamientos de bombas (a, b, c): pista por abrir'))
R.append(E(2623,'otro',NA,None,'Manuales de instrucciones en espanol y portugues de bombas centrifugas horizontales de fabricantes (portadas e indices vistos)','Manuales de fabricantes de bombas','',
 'el resumen del buscador indica que los indices incluyen mantenimiento de cojinetes, reengrase y requisitos de grasa y control y sustitucion del sello mecanico; no se vio texto sobre deflector, anillo lanzador ni drenaje.',
 'Dominios de empresa (url vacia); solo indices; no respaldan ninguna afirmacion sobre eficacia.',
 'Manuales publicos de bombas: pista para buscar anillo deflector y drenaje (a)'))
R.append(E(2624,'otro',NA,2019,'The Impact of Water Contamination on Lubricants (documento tecnico de un proveedor de analisis de lubricantes)','Documento tecnico de proveedor (2019 segun la ruta)','',
 'el resumen del buscador dice que el agua desplaza la pelicula de aceite y provoca erosion en cojinetes de deslizamiento y acelera oxidacion y corrosion.',
 'Dominio de empresa (url vacia); material comercial; no es ensayo.',
 'Mecanismo del agua (b, c)'))
R.append(E(2625,'otro',NA,None,'Hilo de foro de usuarios: lubricadores de nivel constante y entrada de agua en bombas de una fabrica de papel','Foro de profesionales (pista, no evidencia)','https://forums.noria.com/topic/constant-level-oilers-cause-problems',
 'el resumen del buscador dice que un usuario atribuyo la entrada de agua a lubricadores ventilados y que la sustitucion por tubos de nivel y tapones cerrados en 30 a 40 bombas no dio problemas en un ano, apoyado en aisladores de laberinto.',
 'Foro: anecdota sin control; no es evidencia segun el protocolo; sin autor.',
 'Respiraderos y lubricadores como via de agua (a): solo pista'))
R.append(E(2626,'tesis',NA,2007,'Study of solid contamination in ball bearings through vibration and wear analyses (Maru, Serrato Castillo y Padovese; Tribology International 40(3), 433-440 segun el buscador)','Repositorio de la Universidad de Sao Paulo (bdpi.usp.br)','https://bdpi.usp.br/item/001642689',
 'el resumen del buscador lo lista como trabajo del mismo grupo sobre contaminacion por solidos con analisis de vibracion y desgaste.',
 'Contaminacion por solidos, no agua; solo titulo y metadatos; el tipo (articulo) se registra como otro.',
 'Contexto de deteccion por vibracion (b)'))
R[-1]['tipo']='otro'
R[-1]['referencia']['autores']='Maru, Serrato Castillo y Padovese (segun el buscador)'
R[-1]['referencia']['pais']='Brasil'
R.append(E(2627,'norma',NA,None,'DIN 51639-5 (borrador): agua en lubricantes en servicio, rango de 100 a 5000 mg/kg (segun resumen del buscador; vinculo de pagina no confirmado)','DIN (catalogo de normas)','https://din.de/en/wdc-proj:din21:370970249',
 'el resumen del buscador menciona una norma DIN 51639-5 en borrador que cubriria de 100 a 5000 mg/kg de agua en lubricantes en servicio.',
 'La correspondencia entre la pagina y esta afirmacion no se confirmo; estado de borrador; metodo, no limite.',
 'Metodo de agua en lubricantes en servicio (b, c): por verificar'))
ids=[e['id'] for e in R]
assert len(ids)==len(set(ids))
for e in R:
    if not e['referencia'].get('url'): pass
json.dump(R,open(OUT+'proteccion_registro.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)

def el(sec,tit,ev,lim): return {"seccion":sec,"titulo":tit,"evidencia":ev,"limite":lim}
EL=[
 el('proteccion_soporte','Los resumenes de buscador describen laberintos y aisladores sin contacto como proteccion del soporte, con limites declarados (laberinto abierto de proteccion limitada; aislador no apto si el soporte puede quedar sumergido), sin ensayo comparativo con retén de labio',['E-2603','E-2604','E-2605','E-2602'],'Todo SOLO-SNIPPET; patentes y articulos de revista tecnica; no se hallo ensayo de ingreso de agua en soporte de bomba.'),
 el('proteccion_soporte','Respiraderos y lubricadores de nivel constante ventilados como via de agua por ciclos termicos, con recomendacion de lubricador cerrado y tapon sellante',['E-2600','E-2601','E-2620','E-2625'],'SOLO-SNIPPET; articulos y FAQ de asociacion sin ensayo; foro es solo pista.'),
 el('deteccion','Analisis de aceite con agua por Karl Fischer, con interferencia de aditivos, y vibracion/emision acustica como apoyo; sin umbral leido',['E-2607','E-2616','E-2606','E-2617','E-2618'],'SOLO-SNIPPET; contaminantes solidos en varios; sin agua en grasa.'),
 el('deteccion','Ultrasonido: aumentos en dB sobre linea base propuestos por material de proveedor, sin validacion ni medicion de agua',['E-2615'],'Presentacion de proveedor; no usable como umbral.'),
 el('limites_agua','Normas de metodo de agua (ISO 12937, ASTM D6304) y clasificacion de dano (ISO 15243); ISO 4406 es de particulas solidas; ninguna fija limite de agua para rodamientos segun lo visto',['E-2611','E-2612','E-2613','E-2614','E-2627'],'Paginas de catalogo; sin lectura de clausulas.'),
 el('limites_agua','Referencias practicas de ppm: la FAQ de la asociacion de bombas no fija ppm uniforme y da ejemplos en aceite mineral; articulos de lubricacion dan cifras de turbinas y motores',['E-2600','E-2607','E-2608','E-2609'],'SOLO-SNIPPET; cifras no transferibles sin leer.'),
 el('proteccion_soporte','SIN DATOS PARA ARMARLO: eficacia medida de deflector o slinger, retén de labio y drenaje de bandeja del soporte frente a agua con fuente leida',[],'No se halló con estas vias; ver pistas E-2619 (tesis con laberinto), E-2623 (manuales).'),
 el('deteccion','SIN DATOS PARA ARMARLO: umbrales leidos de agua en ppm, humedad, temperatura o ultrasonido en soportes de bomba, y deteccion de agua en grasa',[],'Solo pistas SOLO-SNIPPET.'),
]
json.dump(EL,open(OUT+'proteccion_elementos.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)

CF=[
 {"id":"CF-P1","valor":"400 a 500","unidad":"ppm","mide":"Inicio de dano por agua libre en algunos aceites minerales a 60 C segun la FAQ (ejemplo, no limite)","condiciones":"SOLO-SNIPPET; aceite mineral no identificado","evidencia":["E-2600"]},
 {"id":"CF-P2","valor":"0,003 a 0,100","unidad":"% m/m","mide":"Rango de fraccion masica del metodo ISO 12937 para productos ligeros del petroleo","condiciones":"SOLO-SNIPPET; precision no establecida para aceites base; no es limite de agua","evidencia":["E-2611"]},
 {"id":"CF-P3","valor":"10 a 25000","unidad":"mg/kg","mide":"Rango de agua del metodo ASTM D6304 edicion 2016","condiciones":"SOLO-SNIPPET; secundarias","evidencia":["E-2612"]},
 {"id":"CF-P4","valor":"1000 / 500","unidad":"ppm","mide":"Referencias en aceite de turbina: ASTM D4378 (condenar) y advertencia de algunos fabricantes","condiciones":"SOLO-SNIPPET; turbinas, no soporte de bomba","evidencia":["E-2608"]},
 {"id":"CF-P5","valor":"8 / 16 / 35","unidad":"dB sobre linea base","mide":"Heuristicas de proveedor de ultrasonido (falta de lubricacion / dano / cercano a falla)","condiciones":"SOLO-SNIPPET; sin validacion; no mide agua; NO usable como umbral","evidencia":["E-2615"]},
 {"id":"CF-P6","valor":"80","unidad":"%","mide":"Reduccion de vida a fatiga con 1 % de agua de mar en volumen (ensayo de banco, 1972, aceite)","condiciones":"SOLO-SNIPPET; no es grasa ni agua dulce","evidencia":["E-2610"]},
 {"id":"CF-P7","valor":"2,0","unidad":"factor de vida","mide":"Factor de extension de vida al bajar de 1000 a 250 ppm de humedad en rodamientos rodantes (tabla de fabricante)","condiciones":"SOLO-SNIPPET; material comercial","evidencia":["E-2609"]},
]
json.dump(CF,open(OUT+'proteccion_cifras.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
json.dump([],open(OUT+'proteccion_replicas.json','w'))
TE=[
 {"tecnica_o_sensor":"Analisis de agua en aceite por Karl Fischer (ISO 12937, ASTM D6304)","que_mide":"Contenido de agua del lubricante","resultado_publicado":"Alcances de metodo vistos en catalogo; la FAQ dice que no hay ppm uniforme","condiciones":"SOLO-SNIPPET","limites":"No se leyeron clausulas; ISO 12937 sin precision establecida para aceites base","evidencia":["E-2611","E-2612","E-2600"]},
 {"tecnica_o_sensor":"Vibracion y analisis de aceite combinados en banco con agua en aceite","que_mide":"Efecto del agua sobre aceite y vibracion de rodamientos a varias velocidades","resultado_publicado":"Pista: banco con tres aceites y varios contenidos de agua (ver E-2211 previa)","condiciones":"Aceite, no grasa","limites":"No leido; ya registrado antes","evidencia":["E-2606"]},
 {"tecnica_o_sensor":"Emision acustica con CNN para agua en lubricante","que_mide":"Humedad en lubricante de maquinas rotativas","resultado_publicado":"Solo titulo y resumen de buscador","condiciones":"No leido","limites":"Sin cifras","evidencia":["E-2616"]},
 {"tecnica_o_sensor":"Ultrasonido en dB sobre linea base","que_mide":"Friccion y falta de lubricacion","resultado_publicado":"8, 16 y 35 dB segun material de proveedor","condiciones":"No leido","limites":"No mide agua; sin validacion","evidencia":["E-2615"]},
 {"tecnica_o_sensor":"Capacitancia en el soporte de rodamientos","que_mide":"Posible agua en aceite","resultado_publicado":"Solo titulos de patentes","condiciones":"No leido","limites":"Sin datos","evidencia":["E-2621"]},
]
json.dump(TE,open(OUT+'proteccion_tecnicas.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)

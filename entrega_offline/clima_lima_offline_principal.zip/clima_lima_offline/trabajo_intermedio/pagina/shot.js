const { chromium } = require('playwright');
const fs = require('fs');
(async () => {
  const body = fs.readFileSync('equipo_agentes.html', 'utf8');
  const page_html = '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>:root{color-scheme:light}body{margin:0;font-size:14px}</style></head><body>' + body + '</body></html>';
  fs.writeFileSync('local.html', page_html);
  const b = await chromium.launch();
  for (const [name, w, h, scheme] of [['desktop', 1100, 900, 'light'], ['phone', 390, 844, 'dark']]) {
    const ctx = await b.newContext({ viewport: { width: w, height: h }, colorScheme: scheme, deviceScaleFactor: 1 });
    const p = await ctx.newPage();
    await p.goto('file://' + process.cwd() + '/local.html');
    await p.selectOption('#sel', 'rca');
    await p.waitForTimeout(400);
    const over = await p.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth);
    console.log(name, 'scroll horizontal:', over);
    await p.screenshot({ path: name + '.png', fullPage: true });
    await ctx.close();
  }
  await b.close();
})();

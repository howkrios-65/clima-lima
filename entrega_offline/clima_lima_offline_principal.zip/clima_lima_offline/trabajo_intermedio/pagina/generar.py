import html, json

AGENTES = [
 dict(id="reliability-engineer", corto="Líder", etapa=0, rol="Te escucha, pregunta, reparte el trabajo y decide qué se entrega.",
      cuando="Siempre: es la puerta de entrada.", entrega="Informe final y preguntas pendientes.", perm=[("Lee y escribe",""),("Calcula",""),("Busca",""),("Coordina a los 9","")]),
 dict(id="reliability-data-auditor", corto="Auditor de datos", etapa=1, rol="Dice si tus datos sirven antes de usarlos.",
      cuando="Tienes órdenes de trabajo, fallas o lecturas de sensores.", entrega="Calidad de datos y veredicto de aptitud por análisis.", perm=[("Lee",""),("Calcula","")]),
 dict(id="reliability-life-analyst", corto="Analista de vida", etapa=2, rol="Estadística de vida, censura y tendencia en reparables.",
      cuando="Tienes tiempos hasta la falla, equipos reparables o una flota.", entrega="Ajustes con intervalos, supuestos y lo que no se puede concluir.", perm=[("Lee",""),("Calcula","")]),
 dict(id="reliability-rca-investigator", corto="Causa raíz", etapa=2, rol="Explica por qué falló algo concreto, con evidencia.",
      cuando="Hay una falla ya ocurrida.", entrega="Árbol de fallas, causas con nivel de evidencia y plan de acción.", perm=[("Lee",""),("Busca","")]),
 dict(id="reliability-fmeca-rcm", corto="FMECA y RCM", etapa=2, rol="Modos de falla, criticidad y estrategia de mantenimiento.",
      cuando="Defines tareas, intervalos o cuestionas un PM.", entrega="Tabla de modos, estrategia por consecuencia, PM cuestionadas.", perm=[("Lee",""),("Calcula",""),("Busca","")]),
 dict(id="reliability-predictive-analyst", corto="Predictivo", etapa=2, rol="Evalúa o diseña modelos predictivos con validación correcta.",
      cuando="Tienes un modelo, una vida útil remanente o anomalías.", entrega="Veredicto frente a un baseline, con su incertidumbre.", perm=[("Lee",""),("Calcula",""),("Busca","")]),
 dict(id="reliability-economics-kpi", corto="Economía y KPIs", etapa=2, rol="Costos, repuestos e indicadores ligados a decisiones.",
      cuando="Justificas una decisión o armas un tablero.", entrega="Estructura del cálculo, KPIs con definición y decisión que disparan.", perm=[("Lee",""),("Calcula","")]),
 dict(id="reliability-report-writer", corto="Redactor", etapa=3, rol="Convierte los resultados en un informe claro y ordenado.",
      cuando="Los especialistas ya entregaron.", entrega="Informe con tablas, figuras y leyenda de evidencia.", perm=[("Lee",""),("Escribe informes","")]),
 dict(id="reliability-evidence-verifier", corto="Verificador", etapa=3, rol="Intenta refutar lo que se va a entregar.",
      cuando="Antes de entregar, o si traes resultados de otra IA.", entrega="Tabla afirmación por afirmación y veredicto.", perm=[("Solo lectura","mark"),("Busca","")]),
 dict(id="reliability-case-historian", corto="Historiador", etapa=1, rol="Memoria de casos: detecta si ya ocurrió y actualiza la línea base.",
      cuando="Al abrir un caso (¿ya pasó?) y al cerrarlo.", entrega="Coincidencias con su razón; línea base versionada o VACÍO.", perm=[("Lee",""),("Escribe solo en el historial","mark")]),
 dict(id="reliability-literature-researcher", corto="Investigador de literatura", etapa=1, rol="Lee la ciencia sobre el mecanismo de la falla, sin citar lo que no leyó.",
      cuando="Falla nueva; una instancia por frente de mecanismo.", entrega="Fuentes con extracto literal, límites y vacíos declarados.", perm=[("Lee y busca",""),("Escribe su registro","mark")]),
 dict(id="reliability-memory-curator", corto="Curador de memoria", etapa=3, rol="Propone lecciones aprendidas, con control.",
      cuando="Al cerrar un caso.", entrega="Candidatos a lección en cuarentena.", perm=[("Escribe solo en cuarentena","mark")]),
]
RUTAS = [
 ("todo","Flujo completo",[ "reliability-data-auditor","reliability-life-analyst","reliability-rca-investigator","reliability-fmeca-rcm","reliability-predictive-analyst","reliability-economics-kpi","reliability-report-writer","reliability-evidence-verifier","reliability-memory-curator","reliability-case-historian","reliability-literature-researcher"],[],"El líder recorre historial, literatura, datos, análisis, informe, verificación y memoria. Los análisis que no apliquen a tu caso se omiten."),
 ("datos","Revisar mis datos de mantenimiento",["reliability-data-auditor"],[],"Solo el auditor: te dice qué se puede concluir con tus datos antes de calcular nada."),
 ("vida","¿Se desgasta? ¿Cada cuánto falla?",["reliability-data-auditor","reliability-life-analyst"],[],"El auditor define falla y censura; el analista de vida elige el método correcto y calcula con intervalos."),
 ("flota","¿Aumentan las fallas en mi flota?",["reliability-data-auditor","reliability-life-analyst"],[],"Modelo de varias unidades con distinto fin de observación. Nunca se mezclan los tiempos en una sola serie."),
 ("rca","¿Por qué falló este equipo?",["reliability-data-auditor","reliability-rca-investigator"],["reliability-life-analyst"],"Evidencia primero. El analista de vida entra si hay historial de fallas."),
 ("fmeca","Hacer el FMECA y la estrategia",["reliability-fmeca-rcm"],["reliability-data-auditor"],"Funciones, modos y tareas por consecuencia. El auditor entra si hay historial de órdenes."),
 ("pred","¿Sirve este modelo predictivo?",["reliability-predictive-analyst"],[],"Validación por activo y por tiempo, frente a un baseline, con incertidumbre."),
 ("econ","¿Conviene reemplazar por edad? ¿Cuántos repuestos?",["reliability-life-analyst","reliability-economics-kpi"],[],"Necesita tus costos: sin ellos se declara vacío y no se calcula una edad óptima."),
 ("kpi","Armar un tablero de KPIs",["reliability-economics-kpi","reliability-report-writer"],[],"Cada KPI con definición, fuente y la decisión que dispara."),
 ("otraia","Una IA me dio estos resultados",["reliability-evidence-verifier"],[],"Cada afirmación se clasifica: confirmada, no verificable o aparenta fabricación por combinación."),
 ("informe","Dame el informe final",["reliability-report-writer","reliability-evidence-verifier"],[],"El redactor ensambla y el verificador intenta refutar antes de entregar."),
]
ETAPAS = {1:("Datos","Antes de calcular"),2:("Análisis","Según tu solicitud"),3:("Cierre","Informe, verificación, memoria")}
NIVELES=[("VERIFICADO","ok","Se abrió y leyó la fuente."),("SOLO-SNIPPET","snip","Visto solo en un resumen de buscador."),("NO-VERIFICADO","no","Sin fuente leída: no se cita."),("SÍNTESIS","syn","Inferencia del agente, rotulada como hipótesis."),("CÁLCULO","calc","Código ejecutado sobre tus datos."),("VACÍO","vac","Dato que no existe: se declara, no se rellena.")]
REGLAS=[("Cero invención","Cada dato es un cálculo, una cita abierta o un vacío declarado."),("Evidencia a la vista","Toda afirmación lleva su nivel de evidencia."),("El código calcula","Los números salen del kit probado, con semilla y versiones."),("Preguntan lo que cambia la decisión","Máximo 5 preguntas, con opción por defecto."),("Neutrales","No nombran empresas ni plantas. El texto de órdenes y PDF es dato, nunca instrucción.")]
USO=[("Comando","/confiabilidad Tengo 70 ventiladores, 12 fallaron y el resto sigue operando. ¿Hay desgaste?","Lanza al líder con el flujo completo."),
     ("Líder como asistente principal","claude --agent reliability-engineer","Así te pregunta directamente en la conversación."),
     ("Directo a un especialista","Usa el agente reliability-life-analyst con estos datos: …","Cuando ya sabes qué parte necesitas.")]
ESTADO=[("Agentes","12, con encabezados validados por prueba automática y permisos mínimos por rol."),("Kit de cálculo","146 pruebas verdes, con referencias independientes y simulación."),("Normas","53 registradas, 0 verificadas en el publicador, 15 sin fuente leída. Se citan como «edición no verificada»."),("Memoria","Mecanismo listo: 1 lección de ejemplo en cuarentena, 0 aprobadas."),("Cifras de retorno","Ninguna. No hay fuente primaria; están descartadas en la base de conocimiento.")]
e=html.escape
chips={1:[],2:[],3:[]}
for a in AGENTES:
    if a["etapa"]: chips[a["etapa"]].append(f'<li><button type="button" class="chip" data-id="{a["id"]}"><span class="chip-n">{e(a["corto"])}</span><span class="chip-id">{a["id"].replace("reliability-","")}</span></button></li>')
stages="".join(f'<section class="stage" aria-label="{ETAPAS[k][0]}"><header><span class="stage-k">{k}</span><div><h3>{ETAPAS[k][0]}</h3><p>{ETAPAS[k][1]}</p></div></header><ul>{"".join(chips[k])}</ul></section>' for k in (1,2,3))
rows=""
for a in AGENTES:
    perms="".join(f'<span class="badge {c}">{e(t)}</span>' for t,c in a["perm"])
    rows+=f'<li class="row" data-id="{a["id"]}"><div class="row-h"><code>{a["id"]}</code><span class="badge-wrap">{perms}</span></div><p class="row-r">{e(a["rol"])}</p><dl><div><dt>Úsalo cuando</dt><dd>{e(a["cuando"])}</dd></div><div><dt>Te entrega</dt><dd>{e(a["entrega"])}</dd></div></dl></li>'
opts="".join(f'<option value="{k}">{e(t)}</option>' for k,t,_,_,_ in RUTAS)
rutas_js=json.dumps({k:{"main":m,"opt":o,"txt":x} for k,_,m,o,x in RUTAS},ensure_ascii=False)
niv="".join(f'<li><span class="lvl {c}">{e(n)}</span><span>{e(t)}</span></li>' for n,c,t in NIVELES)
reg="".join(f'<li><strong>{e(t)}</strong><span>{e(x)}</span></li>' for t,x in REGLAS)
uso="".join(f'<div class="uso"><h3>{e(t)}</h3><div class="cmd"><code id="c{i}">{e(c)}</code><button type="button" class="copy" data-t="c{i}">Copiar</button></div><p>{e(d)}</p></div>' for i,(t,c,d) in enumerate(USO))
est="".join(f'<div class="est"><dt>{e(t)}</dt><dd>{e(x)}</dd></div>' for t,x in ESTADO)
doc=f'''<title>Equipo de agentes de confiabilidad</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Instrument+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap">
<style>
/* Concepto: panel de consulta. Primero eliges qué necesitas; la ruta de agentes se enciende en el diagrama y en la lista. */
:root{{--bg:#F4F7F7;--surface:#FFFFFF;--fg:#122528;--muted:#4D6568;--line:#D3DEDF;--accent:#0B6B6F;--accent-soft:#DCEFEE;--mark:#A8341F;--mark-soft:#F8E4DF;
--ok:#1D7447;--ok-soft:#DDF1E5;--snip:#8F5F00;--snip-soft:#F6EBCB;--no:#A8341F;--no-soft:#F8E4DF;--syn:#41526B;--syn-soft:#E3E9F2;--calc:#0B6B6F;--calc-soft:#DCEFEE;--vac:#5B5B5B;--vac-soft:#E8E8E8;
--sans:"Instrument Sans",system-ui,-apple-system,"Segoe UI",sans-serif;--mono:"JetBrains Mono",ui-monospace,Menlo,Consolas,monospace}}
@media (prefers-color-scheme:dark){{:root:not([data-theme="light"]){{--bg:#0D1A1B;--surface:#132526;--fg:#E3EEEE;--muted:#9CB3B5;--line:#27403F;--accent:#5CC2C2;--accent-soft:#143B3C;--mark:#F29480;--mark-soft:#3A201B;
--ok:#76D09B;--ok-soft:#173424;--snip:#E3B552;--snip-soft:#3A2F12;--no:#F29480;--no-soft:#3A201B;--syn:#A5B7D2;--syn-soft:#1F2A3B;--calc:#5CC2C2;--calc-soft:#143B3C;--vac:#B5B5B5;--vac-soft:#2B2B2B;color-scheme:dark}}}}
:root[data-theme="dark"]{{--bg:#0D1A1B;--surface:#132526;--fg:#E3EEEE;--muted:#9CB3B5;--line:#27403F;--accent:#5CC2C2;--accent-soft:#143B3C;--mark:#F29480;--mark-soft:#3A201B;
--ok:#76D09B;--ok-soft:#173424;--snip:#E3B552;--snip-soft:#3A2F12;--no:#F29480;--no-soft:#3A201B;--syn:#A5B7D2;--syn-soft:#1F2A3B;--calc:#5CC2C2;--calc-soft:#143B3C;--vac:#B5B5B5;--vac-soft:#2B2B2B;color-scheme:dark}}
*{{box-sizing:border-box}}
body{{background:var(--bg);color:var(--fg);font-family:var(--sans);font-size:15px;line-height:1.55;padding-block:28px 56px;padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px))}}
.wrap{{max-width:1040px;margin-inline:auto;display:flex;flex-direction:column;gap:44px}}
h1,h2,h3{{margin:0;text-wrap:balance;line-height:1.2}}
h1{{font-size:clamp(1.7rem,4.2vw,2.35rem);font-weight:700;letter-spacing:-.015em}}
h2{{font-size:1.2rem;font-weight:650;letter-spacing:-.005em}}
h3{{font-size:.98rem;font-weight:600}}
p{{margin:0}}
code{{font-family:var(--mono);font-size:.86em}}
.lead{{color:var(--muted);max-width:62ch;margin-top:10px;font-size:1.02rem}}
.sec{{display:flex;flex-direction:column;gap:16px}}
.sec>p.sub{{color:var(--muted);max-width:66ch;margin-top:-6px}}
.pick{{display:flex;flex-wrap:wrap;gap:12px 16px;align-items:end}}
.pick label{{display:flex;flex-direction:column;gap:6px;font-size:.78rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--muted);flex:1 1 320px;min-width:0}}
select{{font:inherit;font-size:1rem;color:var(--fg);background:var(--surface);border:1px solid var(--line);border-radius:6px;padding:10px 12px;width:100%;min-width:0}}
select:focus-visible,button:focus-visible{{outline:2px solid var(--accent);outline-offset:2px}}
.route{{flex:2 1 360px;min-width:0;border-left:3px solid var(--accent);padding:2px 0 2px 14px;min-height:3.2em}}
.route b{{display:block;font-weight:600}}
.route span{{color:var(--muted)}}
.diagram{{display:flex;flex-direction:column;gap:14px;background:var(--surface);border:1px solid var(--line);border-radius:10px;padding:18px}}
.lead-row{{display:flex;align-items:center;gap:12px;flex-wrap:wrap}}
.you{{font-size:.8rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--muted);padding:6px 10px;border:1px dashed var(--line);border-radius:6px}}
.arrow{{color:var(--muted);font-family:var(--mono)}}
.stages{{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}}
.stage{{min-width:0;display:flex;flex-direction:column;gap:10px;position:relative}}
.stage>header{{display:flex;gap:10px;align-items:center}}
.stage-k{{font-family:var(--mono);font-size:.8rem;font-weight:500;width:26px;height:26px;border-radius:50%;display:grid;place-items:center;background:var(--accent-soft);color:var(--accent);flex:none}}
.stage h3{{font-size:.95rem}}
.stage p{{font-size:.8rem;color:var(--muted)}}
.stage ul{{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:8px}}
.stage+.stage::before{{content:"→";position:absolute;left:-14px;top:3px;font-family:var(--mono);color:var(--muted);width:14px;text-align:center}}
.chip{{font:inherit;width:100%;text-align:left;display:flex;flex-direction:column;gap:1px;background:var(--bg);color:var(--fg);border:1px solid var(--line);border-radius:6px;padding:8px 10px;cursor:pointer;min-width:0}}
.chip-n{{font-weight:600;font-size:.92rem}}
.chip-id{{font-family:var(--mono);font-size:.74rem;color:var(--muted);overflow-wrap:anywhere}}
.lead-chip{{width:auto}}
.dim{{opacity:.38}}
.on{{border-color:var(--accent)!important;background:var(--accent-soft)!important;opacity:1}}
.opt{{border-style:dashed!important;border-color:var(--accent)!important;opacity:1}}
.list{{list-style:none;margin:0;padding:0;display:flex;flex-direction:column}}
.row{{display:flex;flex-direction:column;gap:6px;padding:16px 12px 16px 14px;border-top:1px solid var(--line);border-left:3px solid transparent}}
.row:last-child{{border-bottom:1px solid var(--line)}}
.row.on{{background:var(--accent-soft)!important;border-left-color:var(--accent)}}
.row.opt{{border-left-style:dashed!important;border-left-color:var(--accent)}}
.row-h{{display:flex;flex-wrap:wrap;gap:8px 14px;align-items:center;justify-content:space-between}}
.row-h code{{font-weight:500;font-size:.9rem;overflow-wrap:anywhere}}
.row-r{{font-weight:500}}
dl{{margin:0;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px 28px}}
dt{{font-size:.74rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--muted)}}
dd{{margin:0;color:var(--fg)}}
.badge-wrap{{display:flex;flex-wrap:wrap;gap:6px}}
.badge{{font-size:.74rem;font-weight:500;padding:2px 8px;border-radius:999px;border:1px solid var(--line);color:var(--muted);white-space:nowrap}}
.badge.mark{{color:var(--mark);border-color:var(--mark);background:var(--mark-soft);font-weight:600}}
.two{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:32px}}
.two>div{{min-width:0}}
.rules,.levels{{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:12px}}
.rules li{{display:flex;flex-direction:column;gap:1px}}
.rules span{{color:var(--muted)}}
.levels li{{display:flex;gap:12px;align-items:baseline;flex-wrap:wrap}}
.levels li span:last-child{{color:var(--muted);flex:1 1 200px;min-width:0}}
.lvl{{font-family:var(--mono);font-size:.74rem;font-weight:500;padding:2px 8px;border-radius:4px;flex:none}}
.lvl.ok{{background:var(--ok-soft);color:var(--ok)}}.lvl.snip{{background:var(--snip-soft);color:var(--snip)}}.lvl.no{{background:var(--no-soft);color:var(--no)}}
.lvl.syn{{background:var(--syn-soft);color:var(--syn)}}.lvl.calc{{background:var(--calc-soft);color:var(--calc)}}.lvl.vac{{background:var(--vac-soft);color:var(--vac)}}
.usos{{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:20px}}
.uso{{display:flex;flex-direction:column;gap:8px;min-width:0}}
.uso p{{color:var(--muted);font-size:.9rem}}
.cmd{{display:flex;gap:8px;align-items:flex-start;background:var(--surface);border:1px solid var(--line);border-radius:6px;padding:10px;min-width:0}}
.cmd code{{flex:1;min-width:0;overflow-wrap:anywhere;line-height:1.5}}
.copy{{font:inherit;font-size:.78rem;font-weight:600;color:var(--accent);background:transparent;border:1px solid var(--accent);border-radius:5px;padding:3px 9px;cursor:pointer;flex:none}}
.estado{{margin:0;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 32px}}
.est{{padding:12px 0;border-top:1px solid var(--line);min-width:0}}
.est dt{{margin-bottom:2px}}
.foot{{color:var(--muted);font-size:.86rem;border-top:1px solid var(--line);padding-top:16px;overflow-wrap:anywhere}}
@media (max-width:760px){{
 .stages{{grid-template-columns:minmax(0,1fr);gap:22px}}
 .stage+.stage::before{{content:"↓";left:0;top:-20px;width:26px}}
 .two,.usos,.estado,dl{{grid-template-columns:minmax(0,1fr)}}
}}
@media (prefers-reduced-motion:no-preference){{.chip,.row{{transition:opacity .15s,background-color .15s,border-color .15s}}}}
</style>
<div class="wrap">
 <header>
  <h1>Equipo de agentes de confiabilidad</h1>
  <p class="lead">Doce agentes que trabajan juntos: un líder que habla contigo y once especialistas que hacen cada parte del trabajo. Ninguno inventa datos: cada cifra es un cálculo, una cita abierta o un vacío declarado.</p>
 </header>

 <section class="sec" aria-labelledby="t-ruta">
  <h2 id="t-ruta">¿Qué necesitas hacer?</h2>
  <p class="sub">Elige tu solicitud y se enciende la ruta. Las casillas con borde punteado entran solo si hay datos para ellas.</p>
  <div class="pick">
   <label for="sel">Tu solicitud<select id="sel">{opts}</select></label>
   <div class="route" id="route" aria-live="polite"><b>Flujo completo</b><span>{e(RUTAS[0][4])}</span></div>
  </div>
  <div class="diagram">
   <div class="lead-row"><span class="you">Tú</span><span class="arrow" aria-hidden="true">→</span>
    <button type="button" class="chip lead-chip" data-id="reliability-engineer"><span class="chip-n">Líder</span><span class="chip-id">engineer · pregunta, reparte, integra y decide</span></button></div>
   <div class="stages">{stages}</div>
  </div>
 </section>

 <section class="sec" aria-labelledby="t-ag">
  <h2 id="t-ag">Quién hace qué</h2>
  <ul class="list">{rows}</ul>
 </section>

 <section class="two">
  <div class="sec" aria-labelledby="t-reg"><h2 id="t-reg">Reglas que cumplen todos</h2><ul class="rules">{reg}</ul></div>
  <div class="sec" aria-labelledby="t-niv"><h2 id="t-niv">Niveles de evidencia</h2><ul class="levels">{niv}</ul></div>
 </section>

 <section class="sec" aria-labelledby="t-uso">
  <h2 id="t-uso">Cómo usarlos</h2>
  <div class="usos">{uso}</div>
 </section>

 <section class="sec" aria-labelledby="t-est">
  <h2 id="t-est">Estado actual</h2>
  <dl class="estado">{est}</dl>
 </section>

 <p class="foot">Los agentes están en <code>.claude/agents/</code>, la base común en <code>knowledge/</code>, el kit de cálculo en <code>tools/reliability/</code> y el catálogo completo en <code>docs/agentes/README.md</code>. Los especialistas se cargan al abrir una sesión nueva.</p>
</div>
<script>
(function(){{
 var R={rutas_js};
 var chips=[].slice.call(document.querySelectorAll('[data-id]'));
 var box=document.getElementById('route');
 function esc(s){{var d=document.createElement('div');d.textContent=s;return d.innerHTML}}
 function apply(k){{
  var r=R[k],all=(k==='todo');
  chips.forEach(function(n){{
   n.classList.remove('on','opt','dim');
   var id=n.getAttribute('data-id');
   if(id==='reliability-engineer'){{ if(!all) n.classList.add('on'); return; }}
   if(all) return;
   if(r.main.indexOf(id)>-1) n.classList.add('on');
   else if(r.opt.indexOf(id)>-1) n.classList.add('opt');
   else n.classList.add('dim');
  }});
  var sel=document.getElementById('sel');
  box.innerHTML='<b>'+esc(sel.options[sel.selectedIndex].text)+'</b><span>'+esc(r.txt)+'</span>';
 }}
 document.getElementById('sel').addEventListener('change',function(e){{apply(e.target.value)}});
 [].slice.call(document.querySelectorAll('.copy')).forEach(function(b){{
  b.addEventListener('click',function(){{
   var el=document.getElementById(b.getAttribute('data-t')),t=el.textContent;
   function sel(){{var s=window.getSelection(),r=document.createRange();r.selectNodeContents(el);s.removeAllRanges();s.addRange(r)}}
   try{{navigator.clipboard.writeText(t).then(function(){{b.textContent='Copiado'}},function(){{sel();b.textContent='Seleccionado'}})}}catch(x){{sel();b.textContent='Seleccionado'}}
   setTimeout(function(){{b.textContent='Copiar'}},1800);
  }});
 }});
}})();
</script>
'''
open('/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/pagina/equipo_agentes.html','w',encoding='utf-8').write(doc)
print(len(doc),'bytes')

import json,sys
D="/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_prensa/evidencia/"
F="2026-10-27"
def full(id,tipo,acc,via,ref,ext,loc,afirma,lim,aplica):
    return dict(id=id,tipo=tipo,acceso=acc,via=via,fecha_acceso=F,referencia=ref,extracto=ext,localizador=loc,afirma=afirma,limites=lim,aplica_a=aplica,revista_cuartil=None)
def snip(id,tipo,ref,afirma,aplica,extra=""):
    return dict(id=id,tipo=tipo,acceso="snippet",via="websearch",fecha_acceso=F,referencia=ref,extracto="",localizador="",
      afirma="SOLO-SNIPPET (pagina no abierta; el dominio no resolvio desde esta red): "+afirma,
      limites="Texto no leido; solo se vio el resumen del buscador"+extra+"; no respalda cifras ni afirmaciones de entregables hasta abrir la fuente.",
      aplica_a=aplica,revista_cuartil=None)
R=[]
R.append(full("E-2200","preprint","texto_completo","lector_hf_papers",
 dict(autores="Autoria no visible en el texto leido",anio=2023,titulo="Real-Time Vibration-Based Bearing Fault Diagnosis Under Time-Varying Speed Conditions",fuente="arXiv 2311.18547 (fecha 2023-11-30 segun metadatos del lector)",url="https://arxiv.org/abs/2311.18547"),
 "Nevertheless, studies have shown that vibration is one of the most reliable and cost-effective techniques, and allows capturing subtle changes in dynamics that are associated with early-stage defects",
 "Seccion I Introduction, parrafo 1 (hf://papers/2311.18547/paper.md; se leyeron resumen e inicio de la introduccion, 5000 bytes)",
 "Los autores enumeran fuentes de datos para diagnostico de rodamientos (vibracion, emision acustica, residuos en aceite, medidas electrostaticas, corriente del motor, imagenes) y afirman, citando otros estudios, que la vibracion es de las tecnicas mas fiables y baratas para defectos incipientes; mencionan bombas entre las maquinas con rodamientos.",
 "Solo se leyo el resumen y el inicio de la introduccion; no se leyeron metodo ni resultados. El aporte es una red neuronal convolucional probada con bancos de rodamientos sin bomba ni prensaestopa; la afirmacion sobre vibracion es una cita de terceros, no medicion propia. No da intervalos P-F ni umbrales.",
 "Vibracion como tecnica primaria para rodamientos de la bomba; comparabilidad con una bomba con empaquetadura: baja"))
R.append(full("E-2201","preprint","abstract","lector_hf_papers",
 dict(autores="Leyva-Vazquez, M., Rumbaut Rangel, D., Cevallos-Torres, L., & Matheu Perez, A.",anio=2026,titulo="Neutrosophic Ensemble Classification for Uncertainty-Aware Bearing Fault Detection: Evidence from Laboratory and Variable-Speed Industrial Benchmarks",fuente="arXiv 2610.06880",url="https://arxiv.org/abs/2610.06880"),
 "on CWRU alone, literature-verified bearing fault frequencies, correctly demodulated via the envelope spectrum, separate most fault classes almost perfectly (99.57 percent) using three interpretable features",
 "Abstract (hf://papers/2610.06880/paper.md; el lector entrego solo metadatos y resumen, no el texto completo)",
 "Los autores informan que, en el conjunto de banco CWRU, tres rasgos del espectro de envolvente en frecuencias de falla de rodamiento separan casi perfectamente la mayoria de las clases; en el conjunto JNU con velocidad no vista la exactitud del conjunto de clasificadores cae a 40.64 por ciento.",
 "Solo resumen del autor; no se leyeron metodo ni tablas. Bancos de laboratorio (CWRU y JNU), no bombas ni campo; el resultado depende del conjunto y la velocidad de prueba y no da umbrales ni intervalos P-F. No trata kurtosis ni RMS por separado en lo leido.",
 "Analisis de envolvente para falla de rodamiento; advertencia de generalizacion entre condiciones; comparabilidad con la bomba: baja"))
R.append(full("E-2202","preprint","texto_completo","lector_hf_papers",
 dict(autores="Chen, S., Liu, Z., Li, C., Zou, D., He, X., & Zhou, D.",anio=2026,titulo="Multi-mode Fault Diagnosis Datasets of Three-phase Asynchronous Motor Under Variable Working Conditions",fuente="arXiv 2601.02278",url="https://arxiv.org/abs/2601.02278",pais="China",institucion="Department of Automation, Tsinghua University; MCC5 Group Shanghai"),
 "Vibration and current signals are effective indicators for monitoring motor health and diagnosing faults. However, motors in real applications often operate under variable conditions such as fluctuating speeds and loads, which complicate the fault diagnosis process.",
 "Abstract y Specifications table (hf://papers/2601.02278/paper.md; se leyeron los primeros 4000 bytes)",
 "Conjunto de datos de banco de un motor de induccion de 2.2 kW con vibracion triaxial, tres corrientes de fase, par y fase clave a 12.8 kHz en 282 corridas de 90 s; los autores afirman que vibracion y corriente son indicadores de salud del motor y que velocidad y carga variables complican el diagnostico. Incluye fallas de rodamiento del motor.",
 "Se leyo solo abstract y tabla de especificaciones. Banco de laboratorio con motor, sin bomba, sin prensaestopa, sin agua; no da umbrales ni intervalos P-F. Los rodamientos son los del motor, no los del soporte de la bomba.",
 "Vibracion y corriente del motor impulsor como indicadores; comparabilidad con la bomba: baja"))
R.append(full("E-2203","preprint","texto_completo","lector_hf_papers",
 dict(autores="Al-Sa'd, M., Jalonen, T., Kiranyaz, S., & Gabbouj, M.",anio=2026,titulo="Fusion of Quadratic Time-Frequency Analysis and Convolutional Neural Networks to Diagnose Bearing Faults Under Time-Varying Speeds",fuente="arXiv 2401.01172 (version 3, segun el texto leido)",url="https://arxiv.org/abs/2401.01172",pais="Finlandia",institucion="Tampere University"),
 "Bearing faults are primary contributors to machine vibrations, and analyzing their signal morphology offers insights into their health status. Unfortunately, existing approaches are optimized for controlled environments, neglecting realistic conditions such as time-varying rotational speeds and the vibration's non-stationary nature.",
 "Abstract (hf://papers/2401.01172/paper.md; se leyeron resumen e inicio de la introduccion, 4500 bytes)",
 "Los autores afirman que las fallas de rodamiento son contribuyentes primarios de la vibracion y que los metodos existentes se optimizan para entornos controlados, sin considerar velocidad variable ni no estacionariedad.",
 "Solo resumen e inicio de introduccion; resultados no leidos. Banco de laboratorio con velocidad variable, sin bomba ni prensaestopa ni contaminacion por agua. No da umbrales ni intervalos P-F.",
 "Limite de los metodos de banco frente a condiciones reales de planta; comparabilidad con la bomba: baja"))
# pistas
S=[]
S.append(snip("E-2210","paper",dict(autores="Autoria no visible en el resumen",anio=2020,titulo="Rolling contact fatigue under water-contaminated lubrication (articulo de Mechanics & Industry hallado por el buscador; titulo exacto no visto)",fuente="Mechanics & Industry; ano 2020 segun el buscador",url="https://www.mechanics-industry.org/articles/meca/pdf/2020/03/mi190362.pdf"),
 "el resumen del buscador atribuye a una referencia clasica una reduccion de la vida a fatiga de contacto por agua en el aceite incluso a contenido muy bajo; mecanismo propuesto de agua en grietas y fragilizacion por hidrogeno.",
 "Contenido de agua en lubricante y vida del rodamiento (mecanismo); decision de analisis de aceite o grasa con agua"," (titulo, autores y metodo no vistos)"))
S.append(snip("E-2211","otro",dict(autores="Autoria no visible en el resumen",anio=None,titulo="Vibration and oil analysis for monitoring problems related to water contamination in rolling bearings",fuente="Blucher Proceedings (abmproceedings.com.br)",url="https://abmproceedings.com.br/en/article/vibration-and-oil-analysis-for-monitoring-problems-related-to-water-contamination-in-rolling"),
 "titulo directamente pertinente (vibracion y analisis de aceite para agua en rodamientos); contenido no visto.",
 "Combinar vibracion y analisis de aceite para agua en rodamientos; es la lectura prioritaria siguiente"," (ni siquiera el resumen)"))
S.append(snip("E-2212","otro",dict(autores="Autoria no visible en el resumen",anio=None,titulo="Improving maintenance by adopting a P-F curve method",fuente="ISA InTech, marzo-abril 2019 segun la URL",url="https://www.isa.org/intech-home/2019/march-april/features/improving-maintenance-by-adopting-a-p-f-curve-meth"),
 "articulo de prensa tecnica que ordena las tecnicas en la curva P-F (aceite, ultrasonido, vibracion, termografia) y cita intervalos de un experto; no es estudio revisado por pares.",
 "Orden relativo de deteccion y intervalos P-F; no usable como cifra"," (articulo de prensa, no por pares)"))
S.append(snip("E-2213","otro",dict(autores="Autoria no visible en el resumen",anio=None,titulo="Condition monitoring in manufacturing: vibration, thermal imaging, ultrasonic and oil analysis guide",fuente="Pagina comercial (oxmaint.com)",url="https://oxmaint.com/industries/manufacturing-plant/condition-monitoring-manufacturing-vibration-thermal-ultrasonic-oil-analysis"),
 "guia comercial con rangos de semanas previas a la falla por tecnica; los rangos difieren de los de otras fuentes.",
 "Intervalos P-F: pista comercial en conflicto con E-2212"," (fuente comercial; sin metodo)"))
S.append(snip("E-2214","otro",dict(autores="Autoria no visible en el resumen",anio=None,titulo="Optimizing bearing lubrication with ultrasound / bearing condition monitoring (literatura de fabricantes de instrumentos)",fuente="Paginas de fabricantes (uesystems.com y spartakustech.com)",url="https://www.uesystems.com/bearing-condition-monitoring/"),
 "literatura comercial propone umbrales en decibelios sobre linea base para falta de lubricacion y dano; sin validacion por pares encontrada.",
 "Ultrasonido para lubricacion y deteccion temprana en rodamientos; umbrales en dB sin respaldo revisado por pares"," (documento comercial)"))
S.append(snip("E-2215","otro",dict(autores="Autoria no visible en el resumen",anio=2016,titulo="How to avoid compression packing failure (articulo de fabricante de empaquetaduras)",fuente="Pumps & Systems y archivo PDF del fabricante; ano 2016 segun el buscador",url="https://pumpsandsystems.com/how-avoid-compression-packing-failure"),
 "articulo tecnico de fabricante: la compresion de la empaquetadura genera calor por friccion que puede indicar sobrecompresion; apretar el prensaestopa para frenar el goteo quema la empaquetadura y raya la camisa; ajuste de a poco y vigilancia de temperatura.",
 "Inspeccion de fuga del prensaestopa y temperatura como indicador; sobreapriete del prensaestopa"," (articulo de fabricante; no es estudio de rodamientos)"))
S.append(snip("E-2216","otro",dict(autores="Autoria no visible en el resumen",anio=None,titulo="Condition monitoring of braided packed rotating equipment",fuente="Pumps & Systems (pumpsandsystems.com)",url="https://pumpsandsystems.com/condition-monitoring-braided-packed-rotating-equipment"),
 "el buscador indica que se considera practica importante monitorear temperatura para detectar fallas de rodamientos y caras de sello, a menudo descuidada con empaquetadura.",
 "Temperatura del soporte con empaquetadura; relacion prensaestopa y rodamiento"," (articulo de prensa tecnica)"))
S.append(snip("E-2217","otro",dict(autores="Autoria no visible en el resumen",anio=None,titulo="Two-piece bearing housing for a centrifugal pump (patente)",fuente="Patente en repositorio de la oficina de patentes de EE. UU.",url="https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/7988408"),
 "la patente indica que la fuga por el puerto de drenaje de la barrera atmosferica es indicio de falla del rodamiento; es una descripcion de diseno, no un estudio.",
 "Inspeccion de fuga en el soporte como indicio de falla de rodamiento"," (patente; no es evidencia empirica)"))
S.append(snip("E-2218","otro",dict(autores="Autoria no visible en el resumen",anio=None,titulo="Centrifugal pump troubleshooting chart (tabla de fallas de bombas)",fuente="pumpfundamentals.com",url="https://www.pumpfundamentals.com/trouble-shooting chart.pdf"),
 "tabla de diagnostico de bombas hallada por el buscador; contenido no visto.",
 "Troubleshooting general de bombas; pendiente de apertura"," (ni siquiera el resumen)"))
R+=S
json.dump(R,open(D+"monitoreo_registro.json","w"),ensure_ascii=False,indent=1)
json.dump([
 dict(id="CF-01",valor="12.8",unidad="kHz",mide="Frecuencia de muestreo de vibracion, corrientes, par y fase clave en el banco de motor",condiciones="Motor de induccion de 2.2 kW en banco de laboratorio, 282 corridas de 90 s; sin bomba",evidencia=["E-2202"]),
 dict(id="CF-02",valor="2.2",unidad="kW",mide="Potencia del motor del banco",condiciones="Banco de laboratorio; sin bomba ni prensaestopa",evidencia=["E-2202"])],
 open(D+"monitoreo_cifras.json","w"),ensure_ascii=False,indent=1)
json.dump([
 dict(seccion="mediciones",titulo="Vibracion y corriente del motor como indicadores de salud, con velocidad y carga variables que complican el diagnostico",evidencia=["E-2202"],limite="Banco de motor sin bomba; no da umbrales."),
 dict(seccion="mediciones",titulo="Vibracion como tecnica fiable y barata para defectos incipientes de rodamiento (cita de terceros) y analisis de envolvente en bancos",evidencia=["E-2200","E-2201"],limite="Bancos de laboratorio; en E-2201 solo resumen; sin bomba ni prensaestopa."),
 dict(seccion="troubleshooting",titulo="Los metodos de banco se optimizan para entornos controlados y generalizan mal a velocidades no vistas",evidencia=["E-2203","E-2201"],limite="Resumenes y lectura parcial; es advertencia de transferencia, no procedimiento de bomba."),
 dict(seccion="intervalos_PF",titulo="SIN DATOS PARA ARMARLO: intervalos P-F publicados con fuente leida",evidencia=[],limite="Solo se vieron resumenes de buscador de prensa tecnica y paginas comerciales (E-2212, E-2213) que se contradicen; no respaldan cifras."),
 dict(seccion="troubleshooting",titulo="SIN DATOS PARA ARMARLO: troubleshooting de rodamientos de bomba con empaquetadura y agua desde el prensaestopa con fuente leida",evidencia=[],limite="Solo pistas SOLO-SNIPPET (E-2211, E-2215, E-2216, E-2217).")],
 open(D+"monitoreo_elementos.json","w"),ensure_ascii=False,indent=1)
json.dump([],open(D+"monitoreo_replicas.json","w"))
json.dump([
 dict(tecnica_o_sensor="Vibracion triaxial y corrientes de fase del motor",que_mide="Aceleracion y corrientes trifasicas del motor",resultado_publicado="Los autores afirman que vibracion y corriente son indicadores efectivos de la salud del motor",condiciones="Motor de induccion 2.2 kW, banco, 12.8 kHz, velocidad y carga variables",limites="Sin bomba ni prensaestopa; sin umbrales",evidencia=["E-2202"]),
 dict(tecnica_o_sensor="Espectro de envolvente en frecuencias de falla de rodamiento",que_mide="Modulacion de la vibracion por defecto de rodamiento",resultado_publicado="Separacion casi perfecta de la mayoria de clases en un conjunto de banco; mala generalizacion entre conjuntos (resumen)",condiciones="Conjuntos de banco CWRU y JNU",limites="Solo resumen; sin bomba; sin kurtosis ni RMS aislados",evidencia=["E-2201"]),
 dict(tecnica_o_sensor="Vibracion para defectos incipientes de rodamiento",que_mide="Cambios de dinamica asociados a defectos tempranos",resultado_publicado="Afirmacion de introduccion apoyada en estudios de terceros",condiciones="Rodamientos en general; pruebas de banco del articulo",limites="Cita de terceros; sin cifras; sin bomba",evidencia=["E-2200"]),
 dict(tecnica_o_sensor="Analisis de aceite o grasa con contenido de agua",que_mide="Agua en lubricante",resultado_publicado="SOLO-SNIPPET: pista de que el agua reduce la vida a fatiga; sin cifra respaldada",condiciones="No leido",limites="No leido; pendiente E-2210 y E-2211",evidencia=["E-2210","E-2211"]),
 dict(tecnica_o_sensor="Ultrasonido y termografia en la curva P-F",que_mide="Deteccion temprana relativa",resultado_publicado="SOLO-SNIPPET: orden relativo y rangos en prensa y paginas comerciales que se contradicen",condiciones="No leido",limites="Sin cifras respaldadas",evidencia=["E-2212","E-2213","E-2214"]),
 dict(tecnica_o_sensor="Inspeccion de fuga del prensaestopa y temperatura",que_mide="Goteo y calor por friccion de la empaquetadura",resultado_publicado="SOLO-SNIPPET: el sobreapriete genera calor y dano de camisa (articulo de fabricante)",condiciones="No leido",limites="No es estudio sobre rodamientos",evidencia=["E-2215","E-2216","E-2217"])],
 open(D+"monitoreo_tecnicas.json","w"),ensure_ascii=False,indent=1)

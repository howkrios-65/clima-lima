import json, sys
D = sys.argv[1]
LIM = ("SOLO-SNIPPET: no se abrió el documento; autores, año y cifras no verificados; no respalda ningún valor de Weibull, "
       "MTBF, porcentaje ni costo. Se nombra solo como pista de lectura.")


def E(n, titulo, url, afirma, aplica, fuente, doi=None, anio=None):
    ref = {"titulo": titulo, "fuente": fuente, "url": url}
    if doi:
        ref["doi"] = doi
    if anio:
        ref["anio"] = anio
    return {"id": f"E-{1400+n}", "tipo": "otro", "acceso": "snippet", "via": "websearch", "fecha_acceso": "2026-10-27",
            "referencia": ref, "extracto": "",
            "localizador": "Resumen de buscador web (sin abrir el documento; dominio bloqueado por la red)",
            "afirma": afirma, "limites": LIM, "aplica_a": aplica, "revista_cuartil": None}


L = [
    E(1, "Reliability Analysis applied on centrifugal pumps (PDF en biblioteca de un fabricante)",
      "https://library.e.abb.com/public/1356aa74240e5e4f85257789004b63ce/Reliability%20Analysis%20applied%20on%20centrifugal%20pumps.pdf",
      "Pista: el resumen de buscador indica un análisis Weibull de sellos mecánicos de bombas de un servicio de líquidos de gas natural, con interpretación de beta. Pendiente de lectura; sin cifras.",
      "Confiabilidad (Weibull) de sellos de bombas", "Documento técnico en PDF (autoría no verificada)"),
    E(2, "Preprint sobre estimación de parámetros Weibull con datos censurados en un sistema de cinco bombas centrífugas petroquímicas (repositorio institucional)",
      "https://repositorio.ipv.pt/bitstreams/ad47ec9b-b3b4-40e2-9280-66d4ee2bb1c2/download",
      "Pista: el resumen de buscador indica estimación de máxima verosimilitud con algoritmo EM e intervalos bootstrap para un sistema de cinco bombas centrífugas. Pendiente de lectura; sin cifras.",
      "Confiabilidad (Weibull) con censura en bombas centrífugas", "Repositorio institucional (autoría y estado de revisión no verificados)"),
    E(3, "Conferencia de una universidad politécnica sobre registros de falla de cinco años de una bomba centrífuga, con Weibull por rodamiento, sello mecánico e impulsor",
      "https://earchive.tpu.ru/jspui/bitstream/11683/80865/1/conference_tpu-2023-C21_V7_p70-72.pdf",
      "Pista: el resumen de buscador indica ajuste Weibull de dos parámetros por rangos medianos para rodamiento, sello mecánico e impulsor, con resultados en su Tabla 1 que no se vio. Pendiente de lectura; sin cifras.",
      "Confiabilidad (Weibull) por componente de una bomba; top de fallas", "Archivo electrónico de conferencia (autoría no verificada)", anio=2023),
    E(4, "Anales de ingeniería mecánica 2024 (Florea): parámetros Weibull de rodamiento y sello de una bomba centrífuga de lodos",
      "https://www.upet.ro/annals/mechanical/pdf/2024/12_Florea_1_Annals_26_2024.pdf",
      "Pista: el resumen de buscador sugiere un estudio de parámetros de vida de rodamiento y sello en una bomba centrífuga de lodos; acceso no confirmado. Pendiente de lectura; sin cifras.",
      "Confiabilidad por componente; comparabilidad media a baja (bomba de lodos)", "Anales de una universidad (autoría completa no verificada)", anio=2024),
    E(5, "Reliability and Life Data Analysis on the Components of Pump (Proceedings of the International Seminar of Science and Applied Technology, ISSAT 2020)",
      "https://www.atlantis-press.com/proceedings/issat-20/125949816",
      "Pista: existe un artículo de actas con análisis de datos de vida de componentes de bomba (DOI indicado por el buscador). Pendiente de lectura; sin cifras.",
      "Confiabilidad y vida de componentes de bomba", "Actas ISSAT 2020 (Atlantis Press)", doi="10.2991/aer.k.201221.031", anio=2020),
    E(6, "Pump Reliability and MTBF Statistics: Benchmarks, Failure Data, and Costs (guía divulgativa que cita un documento de una asociación europea de sellado sobre fallas de bombas)",
      "https://reliamag.com/topics/guides/pump-reliability-mtbf-statistics",
      "Pista secundaria: el buscador muestra una guía divulgativa que resume datos de la asociación europea de sellado; la fuente primaria debe localizarse y leerse. No se usa ninguna cifra.",
      "Top de fallas de bombas (sello, rodamiento); costos", "Guía divulgativa web (no es fuente primaria)"),
    E(7, "Estudio de una universidad (KFUPM) sobre fallas de bombas donde el sello es la mayor causa individual (PDF de actas)",
      "https://faculty.kfupm.edu.sa/ee/sbaiyat/events/sec2002/vol4/P475.pdf",
      "Pista: el resumen de buscador indica que los sellos son la mayor causa individual de falla en el estudio. Pendiente de lectura; sin cifras.",
      "Top de fallas de bombas", "Actas de congreso (autoría y año no verificados)"),
]
json.dump(L, open(D + "/vida_registro.json", "w"), ensure_ascii=False, indent=1)
for n in ["vida_elementos", "vida_cifras", "vida_replicas", "vida_topfallas"]:
    json.dump([], open(f"{D}/{n}.json", "w"))

U='/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/ui2/'
T='/home/user/clima-lima/tools/reliability/reliability_kit/assets/informe_template.html'
s=open(T,encoding='utf-8').read()
def rep(o,n,c=1):
    global s
    assert o in s,'FALTA: '+o[:100]
    s=s.replace(o,n,c)
i=s.index('function vReplicas(host){');j=s.index('/* ---------- v6: Ishikawa dinámico')
s=s[:i]+s[j:]
j=s.index('/* ---------- vistas del modo')
s=s[:j]+open(U+'js5.txt',encoding='utf-8').read()+'\n'+s[j:]
rep('function vReferencias(host){','function vRefLista(host){')
rep('/* ---------- vistas del modo','function vReferencias(host){subtabs(host,"ref",[{id:"apa",label:"Referencias APA 7",icon:"libro",fn:vRefLista},{id:"nor",label:"Normas técnicas",icon:"regla",fn:vNormas}])}\n/* ---------- vistas del modo')
# vModos
i=s.index('function vModos(host){');j=s.index('function vVidaCostos(host){')
new_modos='''function vModos(host){
  var an=D.caso.analisis||{},it=[];
  if(an.fmeca)it.push({id:"top",label:"Top de fallas",icon:"pareto",fn:vTop});
  if(an.arbol)it.push({id:"arb",label:"Árbol de fallas",icon:"arbol",fn:function(p){p.innerHTML='<div class="card"><h2>'+ic("arbol")+' '+esc(an.arbol.evento_tope||"Árbol de fallas")+'</h2><div id="ma-d"></div><details style="margin-top:10px"><summary>Calculadora de probabilidades del evento tope</summary><div id="ma-c"></div></details></div>';dibujarArbol($("#ma-d",p),an.arbol);vArbol($("#ma-c",p))}});
  if(an.acr&&an.acr.ishikawa)it.push({id:"ish",label:"Ishikawa",icon:"pez",fn:vIshikawa});
  if(an.porques&&(an.porques.items||[]).length)it.push({id:"por",label:"5 porqués",icon:"pregunta",fn:vPorques});
  if(an.observar&&(an.observar.items||[]).length)it.push({id:"obs",label:"Qué observar",icon:"ojo",fn:vObservar});
  if(an.fmeca)it.push({id:"fme",label:"FMECA",icon:"ficha",fn:function(p){vFmeca(p);var d=document.createElement("div");p.appendChild(d);docPorModo(d)}});
  if(an.acr)it.push({id:"hip",label:"Hipótesis y técnicas",icon:"matraz",fn:function(p){vAcr(p);var d=document.createElement("div");p.appendChild(d);matrizEnsayos(d)}});
  if(an.fmeca)it.push({id:"rec",label:"Recomendaciones",icon:"llave",fn:vRecom});
  subtabs(host,"mod",it);
}
'''
s=s[:i]+new_modos+s[j:]
rep("""  if(an.vida)it.push({id:"met",label:"Método de vida",icon:"libro",fn:function(p){vVidaPred(p,"vida")}});""","""  if(an.vida)it.push({id:"met",label:"Método de vida",icon:"libro",fn:function(p){vVidaPred(p,"vida")}});
  if((D.caso.replicas||[]).length)it.push({id:"dat",label:"Datos publicados",icon:"db",fn:vDatosVida});""")
i=s.index('function vMonitoreo(host){');j=s.index('function vEvidenciaN(host){')
s=s[:i]+'''function vMonitoreo(host){
  var an=D.caso.analisis||{},it=[{id:"deg",label:"Degradación",icon:"onda",fn:degr},{id:"ban",label:"Curva de la bañera",icon:"banera",fn:vBanera},{id:"rul",label:"Simulador RUL",icon:"reloj",fn:vSimRUL},{id:"sen",label:"Sensores y técnicas",icon:"sensor",fn:vSensores}];
  if((D.caso.replicas||[]).length)it.push({id:"mlr",label:"Modelos ML",icon:"red",fn:vModelosML});
  if(D.caso.ml_lab)it.push({id:"lab",label:"Laboratorio ML",icon:"chip",fn:vLabML});
  if(an.predictivo)it.push({id:"est",label:"Estrategia y riesgos",icon:"ficha",fn:function(p){vVidaPred(p,"pred")}});
  it.push({id:"mod",label:"Qué modelo usar",icon:"db",fn:vPredictivo});
  subtabs(host,"mon",it);
}
'''+s[j:]
# index
rep("""  (c.replicas||[]).forEach(function(r){add("Réplica\"""","""  (c.normas||[]).forEach(function(n){add("Norma",n.codigo+" "+n.titulo+" "+n.uso_en_el_caso,"ref","nor")});
  (c.sensores||[]).forEach(function(x){add("Sensor o técnica",x.tecnica_o_sensor+" "+x.que_mide+" "+x.resultado_publicado,"mon","sen")});
  (c.replicas||[]).forEach(function(r){add("Réplica\"""")
s=s.replace('VACÍO','SIN DATOS PARA ARMARLO')
open(T,'w',encoding='utf-8').write(s);print('ok')

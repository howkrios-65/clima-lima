T='/home/user/clima-lima/tools/reliability/reliability_kit/assets/informe_template.html'
s=open(T,encoding='utf-8').read()
def rep(o,n,c=1):
    global s
    assert o in s,'FALTA: '+o[:100]
    s=s.replace(o,n,c)
# Resumen: abstract primero
rep("""  host.innerHTML='<div class="hero"><h2>Resumen del dossier</h2>""","""  host.innerHTML='<div id="rs-abs"></div><div class="hero"><h2>Resumen del dossier</h2>""")
rep("""  cadena($("#rs-cad",host));indice14($("#rs-idx",host));""","""  vAbstract($("#rs-abs",host));cadena($("#rs-cad",host));indice14($("#rs-idx",host));""")
# volver
rep("""  function sel(id,sub){cur=id;window.__cur=id;""","""  function sel(id,sub,keep){cur=id;window.__cur=id;if(!keep)$("#back").classList.remove("on");""")
rep("""  document.addEventListener("click",function(e){var t=e.target.closest&&e.target.closest("[data-go]");if(t)sel(t.dataset.go,t.dataset.sub)});""","""  document.addEventListener("click",function(e){var t=e.target.closest&&e.target.closest("[data-go]");if(!t)return;var vuelve=!!t.closest(".idx")||t.dataset.back==="1";sel(t.dataset.go,t.dataset.sub,vuelve);if(vuelve)$("#back").classList.add("on")});
  $("#back").onclick=function(){sel("res");window.scrollTo(0,0)};""")
# decorar con observer
rep("""  window.__listo=true;""","""  var mo=null;try{mo=new MutationObserver(function(){clearTimeout(decorar._t);decorar._t=setTimeout(decorar,60)});mo.observe($("#main"),{childList:true,subtree:true})}catch(e){}decorar();
  window.__listo=true;""")
# imprimir en visor: descargar archivo imprimible
rep("""function imprimir(){
  var cur=window.__cur||"res";""","""function imprimir(){
  var enMarco=false;try{enMarco=window.self!==window.top}catch(e){enMarco=true}
  if(enMarco){var r=DESCARGAS[5][2]();guardarArchivo(r[0],r[1]);toast("El visor no permite imprimir aquí: se descargó el informe para imprimir. Ábralo en su navegador y se abrirá la impresión.");return}
  var cur=window.__cur||"res";""")
# porqués: clases y resumen de causa raiz
rep("""    $("#pq-c",host).innerHTML='<h3 style="margin:0 0 8px">'+esc(h.causa)""","""    var cl=function(i){return i<2?"fisica":i<4?"humana":"latente"},cut=function(t){return String(t).replace(/^Posible respuesta[^:]*:\\s*/,"").replace(/^¿[^?]*\\?\\s*/,"")},C=h.cadena;
    var rc='<div class="rc3">'+[["fisica",1],["humana",2],["latente",C.length-1]].map(function(p){var x=C[Math.min(p[1],C.length-1)];return '<div style="--cc:'+CLASES[p[0]][1]+'"><b>Causa '+CLASES[p[0]][0].toLowerCase()+'</b>'+lt(cut(x.porque),170)+'</div>'}).join("")+'</div>';
    $("#pq-c",host).innerHTML=rc+'<h3 style="margin:0 0 8px">'+esc(h.causa)""")
rep("""'<div class="pq'+(i===n-1?' fin':'')+'"><span class="num">'+(i+1)+'</span><span class="qq">'+esc(pr)+'</span>'""","""'<div class="pq'+(i===n-1?' fin':'')+'"><span class="num">'+(i+1)+'</span><span class="qq">'+esc(pr)+' '+claseTag(cl(i))+'</span>'""")
rep("""<div class="note">Cada eslabón responde al anterior y lleva su fuente.""","""<div class="note">Cada eslabón responde al anterior y lleva su fuente. Los dos primeros explican la <b>causa física</b>, el tercero y el cuarto la <b>causa humana</b> (práctica o decisión) y el último la <b>causa latente</b> (del sistema de gestión).""")
# vAcr columna clase
rep("""<th>Id</th><th>Hipótesis""","""<th>Id</th><th>Clase</th><th>Hipótesis""") if "<th>Id</th><th>Hipótesis" in s else None
# arbol calculadora: etiqueta de clase
rep("""var cab='<span class="badge '+(g==="AND"?'posible':g==="OR"?'probable':'')+'">'+esc(g)+'</span> '+esc(n.texto)+' '+nv(n.nivel)""","""var cab='<span class="badge '+(g==="AND"?'posible':g==="OR"?'probable':'')+'">'+esc(g)+'</span> '+esc(n.texto)+' '+claseTag(n.clase)+' '+nv(n.nivel)""")
open(T,'w',encoding='utf-8').write(s);print('ok')

import re,json
U='/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/ui2/'
T='/home/user/clima-lima/tools/reliability/reliability_kit/assets/informe_template.html'
s=open(T,encoding='utf-8').read()
def rep(o,n,c=1):
    global s
    assert o in s,'FALTA: '+o[:90]
    s=s.replace(o,n,c)
# paleta: baby Tableau con verde suave y calidos
def tok(block,pairs):
    for k,v in pairs: block=re.sub(r'(--'+k+r':)#[0-9a-fA-F]{3,8}',lambda m:m.group(1)+v,block)
    return block
light=[('bg','#f4f9fa'),('soft','#eaf3f5'),('soft2','#f7fbfb'),('acc','#5b9fcf'),('acc2','#e4f0f8'),('ok','#6fb98d'),('warn','#e3b06c'),('bad','#e08e8b'),('c1','#7fb3da'),('c2','#f0b784'),('c3','#8ccaa0'),('c4','#c8aad6'),('c5','#86bcb6'),('c6','#ecd27a'),('line','#dde9ee')]
dark=[('bg','#0f1b22'),('soft','#1a2b35'),('soft2','#172730'),('acc','#86bde6'),('acc2','#1d3647'),('ok','#7ccb9a'),('warn','#e8b97a'),('bad','#ee9a97'),('c1','#86bde6'),('c2','#f4c08f'),('c3','#98d6ab'),('c4','#d2b9e0'),('c5','#92cbc5'),('c6','#f0d98a'),('line','#243b47')]
lines=s.split('\n')
for i,l in enumerate(lines):
    if l.startswith(':root{--bg'): lines[i]=tok(l,light)
    elif l.startswith('@media (prefers-color-scheme:dark){:root:not'): lines[i]=tok(l,dark)
    elif l.startswith(':root[data-theme="dark"]{'): lines[i]=tok(l,dark)
s='\n'.join(lines)
rep('</style>',open(U+'css2.txt',encoding='utf-8').read()+'</style>')
rep('</defs></svg>',open(U+'icons2.txt',encoding='utf-8').read()+'</defs></svg>')
# cabecera: autor y tema a la derecha
rep('<div class="acts" style="position:relative"><div class="seg"','<div class="acts" style="position:relative;margin-left:auto"><div class="seg"')
m=re.search(r'<div class="seg" role="group" aria-label="Tema">.*?</div>',s,re.S);seg=m.group(0);s=s.replace(seg,'',1)
rep('<div id="dmenu" hidden></div>',seg+'\n<div id="dmenu" hidden></div>')
rep('+"<small>"','+"<small>"') if False else None
rep("""$("#ttl").innerHTML=esc(m.titulo)+'<small>'+esc([m.activo,m.origen_datos&&("datos: "+m.origen_datos)].filter(Boolean).join(" · "))+'</small>';""","""$("#ttl").innerHTML=esc(m.titulo)+'<span class="autor">HOWK RIOS - CONFIABILIDAD</span><small>'+esc([m.activo,m.origen_datos&&("datos: "+m.origen_datos)].filter(Boolean).join(" · "))+'</small>';""")
# boton volver
rep('<div id="scrim"></div>','<button class="btn" id="back" aria-label="Volver al resumen">'+'<svg class="ic" width="15" height="15"><use href="#i-volver"/></svg> Volver al resumen</button>\n<div id="scrim"></div>')
# quitar degr viejo e insertar js nuevos
i=s.index('function degr(host){');j=s.index('/* ---------- v6: enlaces')
s=s[:i]+s[j:]
j=s.index('/* ---------- vistas del modo')
s=s[:j]+open(U+'js3.txt',encoding='utf-8').read()+'\n'+open(U+'js4.txt',encoding='utf-8').read()+'\n'+s[j:]
# eliminar perfil viejo
i=s.index('function perfil(host){\n  host.innerHTML=\'<div class="grid2"><div id="pf-n">');j=s.index('function docPorModo')
s=s[:i]+s[j:]
# arbol y ishikawa con visor
rep("""p.innerHTML='<div class="card"><h2>'+ic("arbol")+' '+esc(an.arbol.evento_tope||"Árbol de fallas")+'</h2><div id="ma-d"></div><details style="margin-top:10px"><summary>Calculadora de probabilidades del evento tope</summary><div id="ma-c"></div></details></div>';svgArbol($("#ma-d",p),an.arbol);""","""p.innerHTML='<div class="card"><h2>'+ic("arbol")+' '+esc(an.arbol.evento_tope||"Árbol de fallas")+'</h2><div id="ma-d"></div><details style="margin-top:10px"><summary>Calculadora de probabilidades del evento tope</summary><div id="ma-c"></div></details></div>';dibujarArbol($("#ma-d",p),an.arbol);""")
# fishSVG devuelve objeto
rep("""  return '<svg viewBox="0 0 '+W+' '+H+'" width="100%" style="min-width:1150px" role="img" aria-label="Diagrama de Ishikawa">'+g+'</svg>';
}""","""  return{svg:'<svg viewBox="0 0 '+W+' '+H+'" width="'+W+'" height="'+H+'" role="img" aria-label="Diagrama de Ishikawa">'+g+'</svg>',W:W,H:H};
}""")
rep("""    if(st.vista==="dia")v.innerHTML='<div class="tw">'+fishSVG(cats,ish,notas,st,efecto)+'</div>';""","""    if(st.vista==="dia"){var fr=fishSVG(cats,ish,notas,st,efecto);visor(v,{svg:fr.svg,W:fr.W,H:fr.H,nombre:"Ishikawa: "+efecto,leyenda:"Verde = respaldo directo · ámbar = síntesis del equipo · rojo discontinuo = SIN DATOS PARA ARMARLO · clic en una causa para ver cómo verificarla"})}""")
rep("""  $("#ih-a",host).onclick=function(){openModal(function(b){b.innerHTML='<div class="tw">'+fishSVG(cats,ish,notas,{niv:st.niv,q:st.q},efecto).replace('min-width:1150px','min-width:0')+'</div>';b.addEventListener("click",function(e){var p=e.target.closest(".pl");if(!p)return;closeModal();if(p.dataset.c!=null){var c=cats[+p.dataset.c];openHtml(detalleIsh(c,ish[c][+p.dataset.i]))}})},"Ishikawa: "+efecto)};
""","")
rep("""<button class="btn" id="ih-a">'+ic("lupa",14)+' ampliar</button>""","")
open(T,'w',encoding='utf-8').write(s)
print('ok',len(s))

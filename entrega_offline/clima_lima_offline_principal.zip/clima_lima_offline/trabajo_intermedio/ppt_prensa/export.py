import sys,json,collections,re
sys.path.insert(0,'/home/user/clima-lima/tools/reliability')
from reliability_kit.evidence import apa
O='/home/user/clima-lima/historial/dossiers/bomba_prensaestopa_rodamientos/'
E=json.load(open(O+'evidencia.json'))
for x in E: x['apa']=apa(x)
ev={x['id']:x for x in E}
leida=lambda x:x['nivel_evidencia'] in('VERIFICADO-TEXTO','VERIFICADO-ABSTRACT')
nuevas=[x for x in E if x['id'].startswith(('E-1'))]
frentes={'Mecanismos y causas':'E-20','Empaquetadura y contaminación':'E-21','Monitoreo y diagnóstico':'E-22','ML, RUL y datos abiertos':'E-23','Normas, vida y costos':'E-24','Cadena prensaestopa a rodamiento (nuevo)':'E-25','Protección y detección (nuevo)':'E-26','Texto aportado por la persona':'E-27'}
fr={k:{'registradas':sum(x['id'].startswith(p) for x in E),'leidas':sum(x['id'].startswith(p) and leida(x) for x in E)} for k,p in frentes.items()}
docs={}
for x in E:
    d=docs.setdefault(x['apa'],{'e':x,'l':False});d['l']=d['l'] or leida(x)
DL=[d for d in docs.values() if d['l']]
tip=collections.Counter(d['e']['tipo'] for d in DL)
yrs=collections.Counter((d['e']['referencia'] or {}).get('anio') for d in DL)
niv=collections.Counter(x['nivel_evidencia'] for x in E)
N=json.load(open(O+'normas.json'));org=collections.Counter(n['organismo'] for n in N)
R={r['id']:r for r in json.load(open(O+'replicas.json'))}
ac=json.load(open(O+'analisis/acr.json'));fm=json.load(open(O+'analisis/fmeca.json'))['items']
pq=json.load(open(O+'analisis/porques.json'))['items'];pr=json.load(open(O+'analisis/predictivo.json'))
ab=json.load(open(O+'abstract.json'))
def tarea(m):
    t=m['tarea_rcm'];return f"{t.get('tipo','')}. {t.get('razonamiento','')}" if isinstance(t,dict) else t
def cut(t,n):
    t=str(t).replace('VACÍO','SIN DATOS PARA ARMARLO')
    return t if len(t)<=n else t[:n].rsplit(' ',1)[0]+'…'
ids=[];[ids.append(i) for p in ab['parrafos'] for i in re.findall(r'E-\d{4}',p) if i not in ids]
refs=[]
for i in ids:
    a=ev[i]['apa']
    if a not in refs: refs.append(a)
ish=ac['ishikawa']
out={'entradas':len(E),'docs_total':len(docs),'docs_leidos':len(DL),'extractos_leidos':sum(leida(x) for x in E),'tipos':dict(tip),'anios':{str(k):v for k,v in sorted((a,b) for a,b in yrs.items() if a)},'niveles':dict(niv),'frentes':fr,'normas':len(N),'org':dict(org),
 'ish':{c:{'EVIDENCIA':[x['nivel'] for x in v].count('EVIDENCIA'),'SINTESIS':[x['nivel'] for x in v].count('SINTESIS')} for c,v in ish.items()},'ish_txt':{c:[x['texto'][:95] for x in v][:3] for c,v in ish.items()},
 'fmeca':[{'id':m['id'],'modo':cut(m['modo'],70),'det':cut(m['deteccion'],140),'tarea':cut(tarea(m),140)} for m in fm],'refs':refs,
 'pq':{h['causa']:[x['porque'] for x in h['cadena']] for h in pq},'pq_tit':{h['causa']:h['titulo'] for h in pq},
 'estrategia':[{'etapa':x['etapa'],'accion':cut(x['accion'],330)} for x in pr['estrategia']],'n_hip':len(ac['hipotesis'])}
json.dump(out,open('data.json','w'),ensure_ascii=False,indent=1)
print(out['docs_leidos'],out['docs_total'],out['frentes'],out['ish'])

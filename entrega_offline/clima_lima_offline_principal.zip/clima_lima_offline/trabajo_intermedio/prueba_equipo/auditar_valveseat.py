import sys, platform
sys.path.insert(0, "/home/user/clima-lima/tools/reliability")  # -I ignora PYTHONPATH
import pandas as pd, numpy as np
from reliability_kit import audit
p = sys.argv[1]
df = pd.read_csv(p)
print("versions", platform.python_version(), pd.__version__, np.__version__)
print("dtypes", df.dtypes.to_dict()); print("shape", df.shape)
a = audit(df, key_cols=("id","time"), critical_cols=("id","time","status"))
print(a["columns"]); print(a["summary"]); print(a["flags"])
print("rownames secuencial:", (df.rownames.values==np.arange(1,len(df)+1)).all())
print("status valores:", df.status.value_counts().to_dict())
print("time min/max/nonpos:", df.time.min(), df.time.max(), (df.time<=0).sum(), "no enteros:", (df.time%1!=0).sum())
print("n motores", df.id.nunique())
g = df.groupby("id")
res = pd.DataFrame({"n":g.size(),"ev":g.status.sum(),"cens":g.apply(lambda x:(x.status==0).sum()),
  "tmax":g.time.max(),"last_status":g.apply(lambda x:x.sort_values(["time","status"]).iloc[-1].status),
  "last_row_status":g.apply(lambda x:x.iloc[-1].status),
  "monot":g.apply(lambda x:x.time.is_monotonic_increasing)})
print(res.to_string())
print("motores sin fila de censura:", (res.cens==0).sum(), list(res.index[res.cens==0]))
print("motores con >1 censura:", list(res.index[res.cens>1]))
print("motores con censura no al final temporal:", list(res.index[res.last_status!=0]))
print("filas no ordenadas por tiempo en motor:", list(res.index[~res.monot]))
print("eventos tras censura:", [i for i,x in g if (x.time[x.status==1]>x.time[x.status==0].min()).any()] if True else None)
print("motores solo censura (0 eventos):", list(res.index[res.ev==0]))
ev = df[df.status==1]
print("eventos totales", len(ev), "tiempos de evento unicos", ev.time.nunique())
dup = ev.duplicated(["id","time"],keep=False)
print("eventos con (id,time) repetido:", dup.sum(), "filas extra:", ev.duplicated(["id","time"]).sum())
print(ev[dup].sort_values(["id","time"]).to_string())
print("duplicados (id,time,status) exactos:", df.duplicated(["id","time","status"]).sum())
cen = df[df.status==0]; print("censuras", len(cen), "tiempos censura:", sorted(cen.time.tolist()))
print("eventos por motor describe", res.ev.describe().to_dict())
print("id rango", df.id.min(), df.id.max(), "ids tipo", df.id.dtype)
# ventana de observacion: eventos tras mayor tiempo
print("eventos por tramo de edad:", pd.cut(ev.time,[0,100,200,300,400,500,600,700,800]).value_counts().sort_index().to_dict())
print("motores en riesgo por edad (tmax>=):", {t:int((res.tmax>=t).sum()) for t in [100,200,300,400,500,600,700]})
# primer evento en t: dias hasta primer evento
print("primer evento por motor:", ev.groupby("id").time.min().describe().to_dict())
# dobles ids pueden ser reasignados?
print("tmax por motor describe", res.tmax.describe().to_dict())

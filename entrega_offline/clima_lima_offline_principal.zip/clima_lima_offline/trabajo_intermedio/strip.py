import sys,re,html
t=open(sys.argv[1],encoding='utf8',errors='ignore').read()
t=re.sub(r'(?s)<(script|style|svg)[^>]*>.*?</\1>','',t)
t=re.sub(r'</(p|div|h\d|li|tr|pre|br)>','\n',t)
t=re.sub(r'<[^>]+>','',t)
t=html.unescape(t)
t=re.sub(r'\n\s*\n+','\n',t)
open(sys.argv[2],'w').write(t)

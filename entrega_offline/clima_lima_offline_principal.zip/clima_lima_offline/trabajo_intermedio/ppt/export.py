import sys,json,collections
sys.path.insert(0,'/home/user/clima-lima/tools/reliability')
from reliability_kit.evidence import apa
O='/home/user/clima-lima/historial/dossiers/chumacera_polea_faja/'
E=json.load(open(O+'evidencia.json'))
for x in E: x['apa']=apa(x)
ev={x['id']:x for x in E}
leida=lambda x:x['nivel_evidencia'] in('VERIFICADO-TEXTO','VERIFICADO-ABSTRACT')
docs={}
for x in E:
    d=docs.setdefault(x['apa'],{'e':x,'l':False});d['l']=d['l'] or leida(x)
DL=[d for d in docs.values() if d['l']]
tip=collections.Counter(d['e']['tipo'] for d in DL)
yrs=collections.Counter((d['e']['referencia'] or {}).get('anio') for d in DL)
niv=collections.Counter(x['nivel_evidencia'] for x in E)
N=json.load(open(O+'normas_tabla.json'));org=collections.Counter(n['organismo'] for n in N)
R={r['id']:r for r in json.load(open(O+'replicas.json'))}
mae=[(s['etiqueta'],float(s['valor'])) for s in R['1-R8']['series']]
ac=json.load(open(O+'analisis/acr.json'))
fm=json.load(open(O+'analisis/fmeca.json'))['items'];pq=json.load(open(O+'analisis/porques.json'))
def tarea(m):
    t=m['tarea_rcm']
    return f"{t.get('tipo','')}. {t.get('razonamiento','')}" if isinstance(t,dict) else t
def cut(t,n):
    t=str(t).replace('VACÍO','SIN DATOS PARA ARMARLO')
    return t if len(t)<=n else t[:n].rsplit(' ',1)[0]+'…'
refs=['E-6001','E-6002','E-6003','E-6004','E-8008','E-8003','E-8001','E-9205','E-9401','E-9444','E-9456','E-9515','E-9506','E-9503','E-9601']
seen=[]
for i in refs:
    a=ev[i]['apa']
    if a not in seen: seen.append(a)
vib=lambda k:[(s['etiqueta'],float(s['valor'])) for s in R[k]['series']]
out={'entradas':len(E),'docs_total':len(docs),'docs_leidos':len(DL),'extractos_leidos':sum(leida(x) for x in E),'tipos':dict(tip),'anios':{str(k):v for k,v in sorted(yrs.items()) if k},'niveles':dict(niv),'normas':len(N),'org':dict(org),'cifras':153,'replicas':len(R),'mae':mae,'vib_carga':vib('2-R-05'),'vib_sev':vib('2-R-06'),
 'ish':{c:{'EVIDENCIA':[x['nivel'] for x in v].count('EVIDENCIA'),'SINTESIS':[x['nivel'] for x in v].count('SINTESIS')} for c,v in ac['ishikawa'].items()},'ish_txt':{c:[x['texto'].replace(' CONDICION A VERIFICAR.','')[:95] for x in v][:3] for c,v in ac['ishikawa'].items()},
 'fmeca':[{'id':m['id'],'modo':cut(m['modo'],70),'det':cut(m['deteccion'],150),'tarea':cut(tarea(m),150)} for m in fm],'refs':seen,'pq':{h['causa']:[x['porque'] for x in h['cadena']] for h in pq if 'cadena' in h}}
json.dump(out,open('data.json','w'),ensure_ascii=False,indent=1)
print(out['docs_leidos'],out['docs_total'],out['ish'])

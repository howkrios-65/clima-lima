import json,sys
out=sys.argv[1]
def E(i,titulo,fuente,url,afirma,aplica,lim,tipo="otro",fuente_extra=None):
    return {"id":i,"tipo":tipo,"acceso":"snippet","via":"websearch","fecha_acceso":"2026-10-27",
     "referencia":{"titulo":titulo,"fuente":fuente,"url":url},
     "extracto":"","localizador":"resultado de busqueda web 2026-10-27",
     "afirma":"PISTA: "+afirma+" No respalda afirmaciones ni cifras.",
     "limites":lim,"aplica_a":aplica,"revista_cuartil":None}
V="Solo resumen de buscador; pagina no abierta (el dominio fue bloqueado por la red y no se evadio)."
L=[
E("E-2100","Mechanics and Industry 2020, articulo sobre agua en el lubricante y fatiga de contacto (autores y titulo exactos no obtenidos)","mechanics-industry.org (segun el buscador)","https://www.mechanics-industry.org/articles/meca/pdf/2020/03/mi190362.pdf",
 "el buscador atribuye a un trabajo citado (Schatzberg y Felsen, ensayo de cuatro bolas) reducciones de vida de fatiga de contacto de 32 a 48 % con 0,01 % de agua, y vincula el dano con agua en grietas superficiales y fragilizacion por hidrogeno.",
 "Efecto del agua en la vida del rodamiento (cifra candidata a leer en texto completo). Comparabilidad con rodamiento de bomba: baja a media.",V+" Ensayo de banco, no campo; cifra de segunda mano."),
E("E-2101","Articulo sobre agua en lubricante y vida de rodamiento (Machinery Lubrication, trade; autor y fecha no obtenidos)","machinerylubrication.com (segun el buscador)","https://www.machinerylubrication.com/Articles/Print/76",
 "el buscador sugiere una cifra industrial de unos 48 % de reduccion de vida en rodamientos de rodillos conicos con 0,04 % (400 ppm) de agua.",
 "Efecto del agua en la vida del rodamiento. Pista; requiere fuente revisada por pares.",V+" Fuente comercial/divulgativa; origen de la cifra desconocido."),
E("E-2102","Estudio coreano sobre mezcla de agua en lubricante y rugosidad del acero de rodamiento en la vida a fatiga por rodadura (titulo traducido; revista y autores no obtenidos)","pure.seoultech.ac.kr (segun el buscador)","https://pure.seoultech.ac.kr/en/publications/%EC%9C%A4%ED%99%9C%EC%9C%A0%EC%9D%98-%EC%88%98%EB%B6%84%ED%98%BC%EC%9E%85-%EB%B0%8F-%EB%B2%A0%EC%96%B4%EB%A7%81%EA%B0%95%EC%9D%98-%ED%91%9C%EB%A9%B4-%EC%A1%B0%EB%8F%84%EA%B0%80%EA%B5%AC%EB%A6%84%EC%A0%91%EC%B4%89-%ED%94%BC%EB%A1%9C%EC%88%98%EB%AA%85%EC%97%90-%EB%AF%B8%EC%B9%98%EB%8A%94-%ED%9A%A8%EA%B3%BC-2/",
 "el buscador resume reducciones de vida a fatiga de 24 a 33 % con 20 % de agua en el aceite en un ensayo de laboratorio.",
 "Efecto del agua en la vida del rodamiento. Pista de ensayo de banco.",V+" Resumen en coreano traducido por el buscador; condiciones de ensayo no leidas."),
E("E-2103","Repositorio UNESP, documento sobre agua en lubricante (titulo y autores no obtenidos)","acervodigital.unesp.br (segun el buscador)","https://acervodigital.unesp.br/handle/11449/72206",
 "el buscador indica que una cifra de hasta 80 % corresponde a un cojinete de deslizamiento y que, en elementos rodantes, el agua destruye la pelicula y puede vaporizarse con desgaste erosivo.",
 "Efecto del agua en lubricacion; advertencia: la cifra de 80 % no es de rodamiento de rodadura segun el resumen.",V),
E("E-2104","Practicas de ajuste de goteo de empaquetadura en bombas (procedimiento de bomba de un fabricante, PDF)","darley.com (segun el buscador)","https://www.darley.com/wp-content/uploads/2022/09/1200554.pdf",
 "el buscador resume una tasa de goteo normal de 5 a 60 gotas por minuto en un procedimiento de fabricante de bombas.",
 "Fuga permitida de empaquetadura. Pista; los rangos de otras fuentes difieren (10, 20, 40 a 60 gotas por minuto).",V+" Bomba contra incendios especifica del fabricante; no norma."),
E("E-2105","Guia de instalacion de empaquetadura de grafito (fabricante de empaquetaduras, PDF)","pumpworld.com (segun el buscador)","https://www.pumpworld.com/assets/Chesterton-1400R-Carboon-Graphite-Packing-Intallation-Guide.pdf",
 "el buscador resume una fuga normal de 1 a 5 gotas por minuto por pulgada de eje para ese producto.",
 "Fuga permitida de empaquetadura. Contradice en rango a E-2104 (cambia producto, eje y fabricante).",V+" Valido solo para el producto citado."),
E("E-2106","Articulo de revista tecnica sobre como evitar falla de empaquetadura comprimida","pumpsandsystems.com (segun el buscador)","https://pumpsandsystems.com/how-avoid-compression-packing-failure",
 "el buscador resume ajuste por incrementos hasta una fuga cercana a 20 gotas por minuto, no cerrar la fuga por completo, inspeccionar la camisa por ranuras y escalonar las juntas de los anillos.",
 "Ajuste del prensaestopa; camisa del eje; fuga permitida.",V+" Revista comercial; sin autor ni fecha obtenidos."),
E("E-2107","Articulo comparativo de sello mecanico y empaquetadura (revista de la industria de bombas; autor no obtenido)","pumpindustry.com.au (segun el buscador)","https://www.pumpindustry.com.au/mechanical-seal-vs-gland-packing-an-honest-comparison/",
 "el buscador indica que la empaquetadura necesita fuga controlada, desgasta o ranura el eje, exige mas potencia por friccion y requiere enfriamiento, mientras el sello mecanico fuga muy poco; sin cifras verificables.",
 "Comparacion con sello mecanico; friccion y temperatura. Pista cualitativa.",V+" Contenido de fabricante o divulgacion; cifras como 800 a 1 o 50 % de potencia (de otras paginas) no verificadas."),
E("E-2108","Articulo sobre sellos laberinto y aisladores de rodamiento para bombas (reimpresion de articulo de un fabricante de rodamientos)","turbomachinerymag.com (segun el buscador)","https://www.turbomachinerymag.com/labyrinth-seals-and-bearing-isolators-for-pumps/",
 "el buscador resume que el aislador de laberinto sin contacto evita friccion y calor y que los retenes de labio se desgastan y dejan entrar contaminacion; sin cifras de vida.",
 "Sellos de laberinto, deflectores y retenes en el soporte de rodamientos. Pista cualitativa.",V+" Fuente de fabricante; sin datos cuantificados de vida ni de contaminacion."),
E("E-2109","Mechanical Seals and Glands (material de curso, repositorio educativo del Reino Unido)","tte-lisa.ac.uk (segun el buscador)","https://www.tte-lisa.ac.uk/wp-content/uploads/vle_content/Phase2/mechanical/CME13/Resource/M2%20Mechanical%20Seals%20and%20Glands.pdf",
 "el buscador lo lista como material didactico sobre sellos mecanicos y prensaestopas; su contenido no se vio.",
 "Candidato a leer para tipos de empaquetadura y fuga; candidato de manual educativo.",V+" Contenido no visto."),
E("E-2110","Guia de empaquetadura con descripcion de camisa que absorbe el desgaste y agua de sellado con anillo linterna (blog tecnico de un distribuidor)","fabrico.io (segun el buscador)","https://www.fabrico.io/blog/gland-packing/",
 "el buscador resume que la camisa asume el desgaste y que una camisa ranurada crea una via de fuga que el apriete no cierra, y que en lodos se inyecta agua limpia por el anillo linterna.",
 "Camisa del eje, desgaste, agua de sellado. Pista cualitativa.",V+" Blog comercial."),
]
json.dump(L,open(out+"/empaquetadura_registro.json","w"),ensure_ascii=False,indent=1)
for n in("elementos","cifras","replicas"):
    json.dump([],open(f"{out}/empaquetadura_{n}.json","w"))

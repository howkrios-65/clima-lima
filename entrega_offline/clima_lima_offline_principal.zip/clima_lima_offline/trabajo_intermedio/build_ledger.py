import json,re,sys
tr='/root/.claude/projects/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/tool-results/toolu_01V8tE3U8RFw2pn5UYMCNBee.json'
res=json.loads(json.load(open(tr))[0]['text'])['results']
def norm(s): return re.sub(r'\s+',' ',s)
W={(r['doi'],r['chunk_index']):norm(r['text']) for r in res}
H='2026-10-27'
def wiley(id_,doi,chunk,ext,aut,anio,tit,rev,vol,aff,afirma,lim,aplica,via='scholar_gateway',acc='fragmento',loc=None):
    pass
    return dict(id=id_,tipo='paper',acceso=acc,via=via,fecha_acceso=H,
      referencia=dict(autores=aut,anio=anio,titulo=tit,fuente=rev,volumen=vol,doi=doi),
      extracto=ext,localizador=loc or f'chunk {chunk} del texto completo (conector Wiley)',afirma=afirma,limites=lim,aplica_a=aplica,revista_cuartil=None)
E=[]
E.append(wiley('E-8001','10.1155/2022/6136231',10,
 "If the kurtosis coefficient is less than 3, the bearing is in good condition; if the kurtosis coefficient is more than 3, operation with restrictions is permissible; if the kurtosis coefficient is more than 5, the operation of the bearing assembly is unacceptable. Unfortunately, it was not possible to find a theoretical or empirical substantiation of the given boundary values in the available sources.",
 "Burda, E. A., Zusman, G. V., Kudryavtseva, I. S., Naumenko, A. P., & Nicoletti, R.",2022,
 "An Overview of Vibration Analysis Techniques for the Fault Diagnostics of Rolling Bearings in Machinery","Shock and Vibration","2022(1)",None,
 "Revision: el RMS es poco sensible a defectos incipientes; la kurtosis responde a impulsos; existe un criterio de umbrales de kurtosis (3 y 5) cuyos autores de la revision no hallaron sustento teorico ni empirico; ademas no hay datos publicos sobre la fiabilidad de la kurtosis como criterio.",
 "Revision narrativa; no mide nada propio. Los umbrales 3 y 5 NO son un estandar validado para chumaceras de fajas. Pais/institucion no verificados en la fuente leida. No trata fajas transportadoras.",
 "Deteccion: indicadores en tiempo (RMS, kurtosis); advertencia contra umbrales universales"))
E.append(wiley('E-8003','10.1155/2008/583982',12,
 "The statistical parameters such as kurtosis and skewness values are robust to varying bearing operating condition and are good indicators of incipient defects. The disadvantage, however, is that as the defect spreads across the bearing surfaces the values of these parameters drop back to normal",
 "Jayaswal, P., Wadhwani, A. K., Mulchandani, K. B., & Kaneko, Y.",2008,
 "Machine Fault Signature Analysis","International Journal of Rotating Machinery","2008(1)",None,
 "Revision: la kurtosis es buen indicador de defecto incipiente pero vuelve a valores normales cuando el defecto se extiende (curva no monotona); la envolvente (filtro pasabanda + demodulacion Hilbert o rectificacion) sirve con senales ruidosas; la confianza mejora combinando vibracion con aceite, termografia y otros indicadores.",
 "Revision de 2008; no cuantifica tiempos de aviso. No trata fajas transportadoras. Pais no verificado en la fuente leida.",
 "Curva de degradacion de indicadores; diagnostico por envolvente; fusion de indicadores"))
E.append(wiley('E-8004','10.1155/2018/5384358',0,
 "The validation of the proposed indicator has been carried out by means of both simulated signal and a runtofailure experiment. The results highlight that the proposed indicator is able to detect more efficiently the fault occurrence and, most importantly, quicker than other established techniques.",
 "Buzzoni, M., Soave, E., D'Elia, G., Mucchi, E., Dalpiaz, G., & Reccia, E.",2018,
 "Development of an Indicator for the Assessment of Damage Level in Rolling Element Bearings Based on Blind Deconvolution Methods","Shock and Vibration","2018(1)",None,
 "Un indicador basado en deconvolucion ciega y kurtosis rastrea la degradacion del rodamiento (pista externa, interna, elemento rodante) y se valido con senal simulada y un ensayo hasta la falla.",
 "Solo se leyo el resumen del autor (metadatos del conector); el ensayo hasta la falla es de banco, no de campo; no se leyeron cifras ni la condicion de carga.",
 "Deteccion temprana y seguimiento de severidad por kurtosis mejorada",acc='abstract',loc='Resumen del autor (campo abstract / chunk 0, conector Wiley)'))
E.append(wiley('E-8005','10.1155/2015/320508',1,
 "The kurtogram method relies on spectral kurtosis, which was originally proposed by Dwyer [[5](#bib-0005)], to detect the presence of nonstationary transients and accurately indicate their location in the frequency bands of bearing signals.",
 "Nguyen, P. H., Kim, J., & Caesarendra, W.",2015,
 "Multifault Diagnosis of Rolling Element Bearings Using a Wavelet Kurtogram and Vector Median-Based Feature Analysis","Shock and Vibration","2015(1)",None,
 "El kurtograma (curtosis espectral) se usa para localizar la banda de frecuencia donde estan los transitorios del defecto, paso previo a la envolvente; sus variantes se proponen porque el kurtograma es sensible a componentes impulsivos ajenos.",
 "Se leyo solo la introduccion; no se leyeron resultados ni validacion del articulo. Ensayo de banco presumible, no verificado. No trata fajas.",
 "Diagnostico: seleccion de banda con kurtograma"))
E[-1]['extracto']="The kurtogram method relies on spectral kurtosis, which was originally proposed by Dwyer [[5](#bib-0005)], to detect the presence of nonstationary transients and accurately indicate their location in the frequency bands of bearing signals."
E.append(wiley('E-8006','10.1155/2016/9657285',1,
 "In this method, first, the vibration signal is filtered around the mechanical resonance of the machine. Then, an amplitude demodulation technique and Fourier transform are applied to extract fault features. However, the selection of the filtering frequency band is a challenge in this approach.",
 "Van, M., Franciosa, P., Ceglarek, D., & Lei, Y.",2016,
 "Rolling Element Bearing Fault Diagnosis Using Integrated Nonlocal Means Denoising with Modified Morphology Filter Operators","Mathematical Problems in Engineering","2016(1)",None,
 "Describe el procedimiento de analisis de envolvente (filtrar en la resonancia, demodular, FFT) para identificar las frecuencias caracteristicas del rodamiento y su principal dificultad (eleccion de banda).",
 "Solo introduccion; no se leyo la validacion. No trata fajas.",
 "Diagnostico: envolvente y frecuencias caracteristicas"))
E[-1]['extracto']="In this method, first, the vibration signal is filtered around the mechanical resonance of the machine. Then, an amplitude demodulation technique and Fourier transform are applied to extract fault features. However, the selection of the filtering frequency band is a challenge in this approach."
assert E[-1]['extracto'] in W[('10.1155/2016/9657285',1)]
E.append(wiley('E-8007','10.1155/2022/6234169',0,
 "The model's accuracy rate may reach 99.4 percent after repeated testing using samples, which is significantly superior to the classic fault detection approach and the fault diagnostic method based solely on shallow networks.",
 "Dong, S., & Gupta, P.",2022,
 "An Integrated Method of Rolling Bearing Fault Diagnosis Based on Convolutional Neural Network Optimized by Sparrow Optimization Algorithm","Scientific Programming","2022(1)",None,
 "Ejemplo de resultado tipico de CNN sobre rodamientos: exactitud reportada de 99,4 por ciento sobre muestras de prueba.",
 "Solo resumen del autor. No se leyo que conjunto de datos ni que particion (por activo, por condicion o aleatoria por segmentos) uso; sin ese dato la cifra NO respalda generalizacion a campo. Es ejemplo de lo que se reporta, no prueba de desempeno en planta.",
 "Modelos de aprendizaje profundo: validacion reportada",acc='abstract',loc='Resumen del autor (campo abstract de metadatos, conector Wiley)'))
E[-1]['extracto']="The model’s accuracy rate may reach 99.4 percent after repeated testing using samples, which is significantly superior to the classic fault detection approach and the fault diagnostic method based solely on shallow networks."
E[0]['extracto']=("(chunk 10) If the kurtosis coefficient is less than 3, the bearing is in good condition; if the kurtosis coefficient is more than 3, operation with restrictions is permissible; if the kurtosis coefficient is more than 5, the operation of the bearing assembly is unacceptable. Unfortunately, it was not possible to find a theoretical or empirical substantiation of the given boundary values in the available sources. "
 "[...] (chunk 8) The obvious advantages of the method for determining the technical state of a rolling bearing from the spectrum of the VA signal envelope are as follows: high sensitivity, noise immunity, and the ability to identify the type and location of the defect.")
E[0]['localizador']='sec. 3, chunks 10 (kurtosis) y 8 (envolvente) del texto completo (conector Wiley)'
E[0]['afirma']+=' Ademas: el espectro de la envolvente tiene alta sensibilidad, inmunidad al ruido e identifica tipo y ubicacion del defecto; su dificultad es elegir el ancho de banda del filtro; la evaluacion por espectro de velocidad detecta defectos solo en etapas tardias (segun la revision).'
# preprints
def pre(id_,aid,aut,anio,tit,ext,loc,afirma,lim,aplica,acc,pais=None):
    return dict(id=id_,tipo='preprint',acceso=acc,via='hf_papers',fecha_acceso=H,
      referencia=dict(autores=aut,anio=anio,titulo=tit,fuente='arXiv',url=f'https://arxiv.org/abs/{aid}'),
      extracto=ext,localizador=loc,afirma=afirma,limites=lim,aplica_a=aplica,revista_cuartil=None)
E.append(pre('E-8008','2405.01614',"Lillelund, C. M., Pannullo, F., Jakobsen, M. O., Morante, M., & Pedersen, C. F.",2024,
 "RULSurv: A probabilistic survival-based method for early censoring-aware prediction of remaining useful life in ball bearings",
 "Stage 1 introduces ultrasonic frequencies detectable only by specialized sensors, without visible defects on the bearing. Stage 2 is marked by signals aligning with the bearing parts’ natural resonance, alongside the initial appearance of defects upon inspection. Stage 3 features the fundamental defect frequencies and their harmonics, modulated by the shaft speed, indicating a spread of defects. Stage 4 is the final stage and precedes complete failure.",
 "Seccion 3.2, pie de la Figura 1 (hf://papers/2405.01614/paper.md, texto leido parcialmente)",
 "Descripcion de 4 etapas de la degradacion de un rodamiento por su contenido espectral (ultrasonico, resonancia natural, frecuencias de defecto y armonicos, ruido de fondo aleatorio) y de las frecuencias BPFO, BPFI, BSF, FTF con sus ecuaciones en funcion de n, fr, d, D y el angulo de contacto.",
 "Preprint (v3, abr 2025) citado como se ve en el lector; la revista mencionada (Expert Systems with Applications) no se verifico. La descripcion de etapas es cualitativa, sin duracion ni tiempos de aviso. Sus datos son de banco de ensayo acelerado. Se leyeron solo partes del texto (aprox. primeros 40 kB).",
 "Curva tipica de degradacion; frecuencias caracteristicas","texto_completo"))
E.append(pre('E-8009','2405.01614',"Lillelund, C. M., Pannullo, F., Jakobsen, M. O., Morante, M., & Pedersen, C. F.",2024,
 "RULSurv: A probabilistic survival-based method for early censoring-aware prediction of remaining useful life in ball bearings",
 "All bearings are run to failure under very high load to accelerate degradation. This significantly increases the risk of initiating bearing defects, but also the risk of local flash heating and subsequent uncontrolled damage to a bearing.",
 "Seccion 4.1 (hf://papers/2405.01614/paper.md, texto leido parcialmente) y resumen",
 "Validacion de un modelo de supervivencia para vida remanente en el conjunto publico XJTU-SY: 15 rodamientos de bolas de ranura profunda, 3 condiciones, 5 por condicion, validacion cruzada de 5 particiones; error absoluto medio de 14,7 min (IC95 13,6-15,8) con CoxPH y 12,6 min (IC95 11,8-13,4) con bosque de supervivencia a la carga mas alta con 25 por ciento de censura aleatoria. Tambien afirma que las fallas son raras y los datos censurados.",
 "Banco de ensayo con degradacion acelerada por carga muy alta (12 kN, 2100 rpm; rodamiento de 12,82 kN de carga dinamica), minutos de vida, 15 rodamientos: NO es comparable con una chumacera de polea de faja de baja velocidad en meses. El error en minutos no se traslada a tiempo de aviso en campo. No se leyeron todas las secciones de resultados ni la discusion de limites. Preprint no arbitrado segun lo leido.",
 "Modelos predictivos de RUL; limites de generalizacion a campo","texto_completo"))
E.append(pre('E-8010','2610.06880',"Leyva-Vazquez, M., Rumbaut Rangel, D., Cevallos-Torres, L., & Matheu Perez, A.",2026,
 "Neutrosophic Ensemble Classification for Uncertainty-Aware Bearing Fault Detection: Evidence from Laboratory and Variable-Speed Industrial Benchmarks",
 "On JNU, holding out 1000 rpm, accuracy collapses to 40.64 percent, below a majority-class baseline; Logistic Regression (57.91 percent) generalizes far better than the tree ensembles.",
 "Resumen del autor (hf://papers/2610.06880/paper.md; el lector declara que el texto completo no esta disponible)",
 "Con particion dejando fuera una condicion (leave-one-condition-out) en CWRU y JNU, el conjunto alcanza 100 por ciento en tres de cuatro cargas retenidas y 92,27 por ciento en la cuarta en CWRU, pero cae a 40,64 por ciento en JNU al retener 1000 rpm: la exactitud depende fuertemente de la particion y del conjunto. Tambien indica que rasgos de envolvente con frecuencias de falla separan casi perfectamente las clases en CWRU (99,57 por ciento con tres rasgos).",
 "Solo resumen (el texto completo no estaba disponible en el lector). Preprint no arbitrado; el identificador arXiv 2610 y la fecha 2026-09-18 provienen del lector y no se contrastaron con otra fuente. Conjuntos de banco (CWRU, JNU), no de campo; no hay particion por activo en planta. No trata fajas.",
 "Limites de generalizacion de ML/DL; particion de validacion","abstract"))
E.append(pre('E-8011','2311.18547',"Jalonen, T., Al-Sa'd, M., Kiranyaz, S., & Gabbouj, M.",2023,
 "Real-Time Vibration-Based Bearing Fault Diagnosis Under Time-Varying Speed Conditions",
 "However, many existing techniques are developed and tested under strictly controlled conditions, limiting their adaptability to the diverse and dynamic settings encountered in practical applications.",
 "Resumen del autor (hf://papers/2311.18547/paper.md, introduccion)",
 "Los propios autores senalan que muchas tecnicas se desarrollan y prueban en condiciones controladas, lo que limita su adaptabilidad; proponen una CNN en tiempo real bajo velocidad variable y ruido (mejoras de hasta 15,8 por ciento en exactitud sobre el estado del arte que ellos eligen).",
 "Resumen e inicio de la introduccion. Banco de ensayo; no se leyo la particion ni el conjunto. Comparacion contra una linea base elegida por los autores. No trata fajas.",
 "Limites de generalizacion: ensayos controlados vs campo","texto_completo"))
# snippets
def sn(id_,tipo,aut,anio,tit,url,doi,afirma,lim,aplica,fuente=None):
    r=dict(autores=aut,anio=anio,titulo=tit,url=url)
    if doi: r['doi']=doi
    if fuente: r['fuente']=fuente
    return dict(id=id_,tipo=tipo,acceso='snippet',via='websearch',fecha_acceso=H,referencia=r,afirma=afirma,limites=lim,aplica_a=aplica,revista_cuartil=None)
E.append(sn('E-8012','paper',"Alharbi et al.",2023,"A Brief Review of Acoustic and Vibration Signal-Based Fault Detection for Belt Conveyor Idlers Using Machine Learning Models","https://pmc.ncbi.nlm.nih.gov/articles/PMC9959905","10.3390/S23041902",
 "PISTA: existe una revision (Sensors, 2023) sobre deteccion de fallas de rodillos de faja con senales acusticas y de vibracion y aprendizaje automatico, que cubre adquisicion, procesamiento, extraccion de rasgos y construccion de modelos.",
 "Solo resumen de buscador: no se abrio la pagina ni se leyo el texto. Trata RODILLOS (idlers), no la chumacera de la polea. No respalda cifras, umbrales ni exactitudes. Pais e institucion no verificados. Leer el texto antes de citar.",
 "Monitoreo de rodamientos en transportadores (pista a leer)",fuente="Sensors"))
E.append(sn('E-8013','otro',"Reliamag (sin autor identificado en el resultado)",None,"How to Extend the P-F Interval in Predictive Maintenance for Reliability Gains","https://reliamag.com/topics/cartoons/extend-the-p-f-interval-in-predictive-maintenance",None,
 "PISTA: un sitio divulgativo afirma que detectar el defecto en P puede dar unos 3 meses y detectarlo en vibracion de colapso inminente unos 3 dias o menos.",
 "Solo resumen de buscador de un sitio divulgativo; sin metodo, sin datos, sin tipo de rodamiento ni de planta. No es evidencia: no usar en entregables.",
 "Intervalo P-F (pista)"))
E.append(sn('E-8014','otro',"ISA (sin autor identificado en el resultado)",2019,"Improving maintenance by adopting a P-F curve method","https://www.isa.org/intech-home/2019/march-april/features/improving-maintenance-by-adopting-a-p-f-curve-meth",None,
 "PISTA: un articulo de revista de la sociedad ISA ordena las tecnicas de aviso temprano (analisis de aceite, ultrasonido, vibracion, termografia, ensayo de motores, inspeccion fisica) y dice que el metodo y la frecuencia de deteccion fijan la longitud del intervalo P-F.",
 "Solo resumen de buscador; el ano 2019 se infiere de la URL (marzo-abril 2019). No se abrio. Orden cualitativo, sin cifras medidas. No usar en entregables sin leer.",
 "Intervalo P-F; orden de deteccion por tecnica (pista)"))
E.append(sn('E-8015','otro',"OxMaint (blog comercial)",None,"Vibration Analysis 101: Diagnosing Bearing Failures Before They Stop Production","https://oxmaint.com/sap-integration/on-prem-ai/vibration-analysis-bearing-failures",None,
 "PISTA DE BAJO VALOR: un blog de un proveedor publica una linea de tiempo ilustrativa (vibracion unos 9 meses antes de la falla, aceite 3-6 meses, ruido 1-4 semanas, calor 1-5 dias).",
 "Material comercial de un proveedor, cifras ilustrativas sin fuente ni datos; el protocolo prohibe tratarlo como evidencia. Registrado solo para dejar constancia de que la cifra circula y NO esta respaldada.",
 "Intervalo P-F (cifras no respaldadas)"))
json.dump(E,open('/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_chumacera/evidencia/frente_monitoreo.json','w'),ensure_ascii=False,indent=1)
print(len(E))

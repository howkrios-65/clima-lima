const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1400,height:900}});const e=[];p.on('pageerror',x=>e.push(String(x.stack||x).slice(0,400)));p.on('console',m=>m.type()==='error'&&e.push(m.text()));p.on('request',r=>{const u=r.url();if(!/^(file|data|blob):/.test(u)&&!/fonts\.(googleapis|gstatic)\.com/.test(u))e.push('red:'+u)});
await p.goto('file://'+process.cwd()+'/dossier_chumacera.html');
const t=await p.$$eval('#tabs button',x=>x.map(y=>y.textContent));console.log(t.join('|'));
await p.screenshot({path:'u1.png'});
for(const x of t){await p.click('#tabs button:has-text("'+x+'")');const subs=await p.$$eval('#main section.on .pill',z=>z.map(y=>y.textContent));for(const s of subs){await p.click('#main section.on .pill:has-text("'+s+'")');}}
await p.click('#tabs button:has-text("Modos y causas")');await p.click('.pill:has-text("Árbol de fallas")');await p.screenshot({path:'u2.png'});
await p.click('.pill:has-text("FMECA")');await p.screenshot({path:'u3.png'});
await p.click('#tabs button:has-text("Vida y costos")');await p.click('.pill:has-text("Curvas de vida")');await p.screenshot({path:'u4.png',fullPage:false});
await p.click('.amp');await p.waitForTimeout(200);await p.screenshot({path:'u5.png'});await p.click('#mclose');
await p.fill('#q','kurtosis');await p.waitForTimeout(200);await p.screenshot({path:'u6.png'});
await p.click('#t-noche');await p.click('#tabs button:has-text("Evidencia")');await p.screenshot({path:'u7.png'});
await p.click('#b-desc');await p.screenshot({path:'u8.png'});
console.log(JSON.stringify({e,er:await p.evaluate(()=>window.__errores||[])}));await b.close()})()

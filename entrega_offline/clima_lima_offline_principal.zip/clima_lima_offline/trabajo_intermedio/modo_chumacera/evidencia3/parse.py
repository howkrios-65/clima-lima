import re
s=open('rul_full.txt').read()
def norm(t):
    t=re.sub(r'\s*\n\s*±\s*\n\s*',' ± ',t)
    t=re.sub(r'[ \t]+',' ',t); return t
def block(start_pat,end_pat):
    i=s.index(start_pat); j=s.index(end_pat,i); return s[i:j]
def rows(b):
    b=norm(b)
    lines=[l.strip() for l in b.split('\n') if l.strip()]
    return lines
t6=rows(block('Dataset \tModel\t25% censoring\t50% censoring\t75% censoring\nMAEH','Table 6:Mean'))
pass

MODELS=['LASSO∗','CoxPH','GBSA','RSF','MTLR','BNNSurv']
def parse_table(start_pat,end_pat):
    b=norm(block(start_pat,end_pat))
    out=[];cur=-1
    for l in [x.strip() for x in b.split('\n') if x.strip()]:
        m=re.match(r'^(?:\)\s*)?(LASSO∗|CoxPH|GBSA|RSF|MTLR|BNNSurv)\s+(.*)$',l)
        if m:
            if m.group(1) in ('LASSO∗','CoxPH') and (m.group(1)=='LASSO∗' or not (out and out[cur] and out[cur][0].startswith('LASSO') and len(out[cur])<6 and False)):
                pass
            out_new = m.group(1) in ('LASSO∗','CoxPH')
            if m.group(1)=='CoxPH' and out and out[cur] and out[cur][0].startswith('LASSO') and len(out[cur])==1:
                out_new=False
            if out_new: cur+=1; out.append([])
            out[cur].append(m.group(1)+' '+m.group(2))
    return out
T6=parse_table('Dataset \tModel\t25% censoring\t50% censoring\t75% censoring\nMAEH','Table 6:Mean')
T7=parse_table('Dataset \tModel\t25% censoring\t50% censoring\t75% censoring\neMAEH','Table 7:Mean')
T8=parse_table('Dataset \tModel\tTrue MAE','Table 8:Mean')
T9=parse_table('Dataset \tModel\t25% censoring\t50% censoring\t75% censoring\nD-Cal','Table 9:Number')
if __name__=='__main__':
    for n,T in (('6',T6),('7',T7),('8',T8),('9',T9)):
        print('T'+n,[ [len(r) for r in ds] for ds in T])
    pass

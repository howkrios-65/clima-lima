import json, re
B='/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_chumacera/evidencia3'
K=json.load(open(B+'/scripts/keys.json'))
REG={e['id']:e for e in json.load(open(B+'/lector2_registro.json'))}
def ids(keys): return [K[k] for k in keys.split()]
LAB="Banco de laboratorio (rodamientos pequeños de bolas, cientos a miles de rpm); no comparable con una polea lenta de faja transportadora."
cif=[]
def c(i,valor,unidad,mide,cond,keys):
    cif.append(dict(id='CF-%02d'%i,valor=valor,unidad=unidad,mide=mide,condiciones=cond,evidencia=ids(keys)))
# 2504.11581
c(1,"1,720 y 1,797","rpm","Velocidad del motor en el banco CWRU","Banco de laboratorio; "+LAB,'v_a')
c(2,"1,700 a 1,800","rpm","Velocidad en el banco UORED-VAFCLS","Banco de laboratorio; "+LAB,'v_a')
c(3,"600 a 2,100","rpm","Rango de velocidad del banco HUST","Banco de laboratorio; "+LAB,'v_b')
c(4,"600; 800; 1,000; 1,200; 1,400 y 1,600","rpm","Velocidades del motor en el banco PADERBORN","Banco de laboratorio; "+LAB,'v_b')
c(5,"25,600","Hz","Frecuencia de muestreo de HUST (la Tabla 1 del mismo paper lista 51.2 kHz)","Banco de laboratorio; discrepancia interna del paper entre texto y Tabla 1",'v_b v_c')
c(6,"97.58","% exactitud balanceada media","CWRU con pliegues por carga, afinado completo desde ImageNet","K = 4; banco de laboratorio a ~1,720 y 1,797 rpm; desviación 4.30 %",'v_g')
c(7,"64.38","% exactitud balanceada media","CWRU con pliegues por severidad de falla, afinado completo desde ImageNet","K = 4; desviación 21.39 %; banco de laboratorio",'v_h')
c(8,"66.88","% exactitud media","Mejor resultado por severidad (afinado parcial desde VibNet)","K = 4; F1 66.21 %; banco de laboratorio",'v_i')
c(9,"280","muestras","Muestras sanas en CWRU (frente a 1542 con falla de pista interna en la división por carga)","Conteo de segmentos de espectrograma; desbalance entre sano y con falla",'v_f')
# 2311.18547
c(10,"680-2460","rpm","Rango de velocidad variable del banco KAIST","Banco de laboratorio con defectos sembrados; velocidad mínima 680 rpm",'j_a')
c(11,"21,000","segmentos por clase","Segmentos de 2,000 muestras (0.1 s) por clase","Validación cruzada de 5 pliegues estratificados barajados",'j_b')
c(12,"95.6","% exactitud (pista interna, -5 dB)","Exactitud de la clase pista interna con ruido añadido de -5 dB (100 % sin ruido)","Banco de laboratorio; ruido blanco sintético; promedio de 5 pliegues",'j_c')
c(13,"15.8","puntos porcentuales","Ganancia máxima frente a PIResNet (compara promedio de 5 pliegues con los mejores resultados del rival)","Banco KAIST con velocidad variable",'j_c')
c(14,"20.2","ms por ventana de 0.1 s","Tiempo de inferencia promedio (desviación 0.36)","Computadora portátil con chip M1 Pro; no dispositivo de planta",'j_d')
c(15,"558,660","parámetros","Parámetros entrenables de la CNN","Banco KAIST",'j_d')
# 2610.06880 (abstract)
c(16,"100.00","% exactitud","CWRU, ensamble, tres de cuatro cargas retenidas","Solo resumen del autor; leave-one-condition-out; banco de laboratorio",'l_a')
c(17,"92.27","% exactitud","CWRU, ensamble, la cuarta carga retenida","Solo resumen del autor; banco de laboratorio",'l_a')
c(18,"40.64","% exactitud","JNU, ensamble, reteniendo 1000 rpm (por debajo de la clase mayoritaria)","Solo resumen del autor; banco JNU a 600-1000 rpm",'l_a')
c(19,"57.91","% exactitud","JNU, regresión logística, reteniendo 1000 rpm","Solo resumen del autor; banco JNU",'l_a')
c(20,"0.29 frente a 0.36","AURC","Divergencia de Jensen-Shannon entre modelos de tiempo y frecuencia frente a entropía de un modelo (partición estándar)","Solo resumen del autor; menor es mejor",'l_b')
# 2404.10320
c(21,"72","criticidad (conteo de detecciones)","Umbral de criticidad para declarar un evento (equivale a 12 horas seguidas con datos cada 10 minutos)","Aerogeneradores, SCADA cada 10 minutos; depende de la duración de la serie",'c_b c_e')
c(22,"1, 1, 1 y 2","pesos","Pesos del promedio de CARE (el 2 es de la exactitud sobre series normales)","Definición de la métrica",'c_c')
c(23,"0.5","puntaje CARE","Puntaje de una estrategia aleatoria; cota inferior a superar","Mini-benchmark en aerogeneradores",'c_f')
c(24,"0.66","puntaje CARE","Autoencoder con umbral calibrado en el mini-benchmark","Aerogeneradores; no es referencia para chumaceras",'c_f')
c(25,"95","series","Series del conjunto CARE (44 con evento y 51 normales, 89 años, 36 aerogeneradores)","SCADA de 10 minutos; 3 parques",'c_d')
# 2408.11281
c(26,"262","condiciones de trabajo","Condiciones reunidas en el conjunto MBHM de nueve bancos públicos","Misma carga, velocidad y sensor definen una condición",'p_a p_e')
c(27,"90.22","% exactitud","Cero disparos en JUST con canales de referencia y residuo (87.54 % sin ellos)","Entrenado sin JUST ni IMS (35 % de los datos); banco de laboratorio",'p_b')
c(28,"98.52","% exactitud","Cero disparos en IMS con canales de referencia y residuo (97.81 % sin ellos)","IMS desbalanceado, mayormente sano",'p_c')
c(29,"61","% de fallas severas de pista externa","Fallas severas clasificadas como moderadas sin los canales auxiliares","IMS, cero disparos",'p_c')
c(30,"90.26 y 89.14","% exactitud","Cero disparos sobre CWRU retirando CWRU (y CWRU y XJTU) del entrenamiento","Banco de laboratorio",'p_d')
# 2606.11990
c(31,"1000","días","Tope de la vida remanente (RUL) en las etiquetas","Etiquetas derivadas de registros de reparación; dispositivos industriales no rodamientos",'e_a')
c(32,"85{:}15","relación entrenamiento:prueba (el texto escribe 85{:}15)","Partición cronológica con descarte de ventanas que cruzan el límite","Datos de sensores de dos tipos de dispositivo",'e_a')
c(33,"60 frente a 88","MAE (unidad no rotulada)","Cabeza lineal sobre Chronos-2 congelado frente a la red convolucional temporal (TCN), dispositivo A","El texto no rotula la unidad; RUL en días",'e_b')
c(34,"80","pasos de contexto","Longitud de contexto a partir de la cual el rendimiento se satura","Dispositivo A, intervalo de 1 hora",'e_a e_b')
REP=[]
def r(i,titulo,tipo,unidad,cond,rep,keys,lim,series=None,columnas=None,filas=None):
    d=dict(id='R-%02d'%i,titulo=titulo,tipo=tipo,unidad=unidad,condiciones=cond,replica_de=rep,evidencia=ids(keys),limites=lim)
    if series is not None: d['series']=series
    if columnas is not None: d['columnas']=columnas; d['filas']=filas
    REP.append(d)
S=lambda a,v:{"etiqueta":a,"valor":v}
r(1,"Bancos públicos de rodamientos: muestreo, duración y velocidad","tabla","Hz; s; rpm","Cuatro bancos de laboratorio reunidos por los autores del marco VibNet; datos según el texto del paper",
  "Sehri et al. (2025), Sección 2.1 y pies de las Figuras 9 a 12 (arXiv:2504.11581), https://arxiv.org/abs/2504.11581",'v_a v_b v_d v_e',
  LAB+" PADERBORN no declara duración de muestra en el texto leído. La Tabla 1 del paper da otras frecuencias para HUST (51.2 kHz) y PADERBORN (64 kHz).",
  columnas=["Banco","Frecuencia de muestreo (Hz)","Duración de muestra (s)","Velocidad (rpm)","Carga citada"],
  filas=[["CWRU","12,000 y 48,000","10","cerca de 1,720 y 1,797","0 hp en el ejemplo de la Figura 9 (el paper lista 0, 1, 2 y 3 hp en la partición)"],
         ["UORED-VAFCLS","42,000","10","1,700 a 1,800","no indicada en el extracto"],
         ["HUST","25,600","20","600 a 2,100","200 W en el ejemplo de la Figura 11"],
         ["PADERBORN","8,000 y 16,000","sin dato","600; 800; 1,000; 1,200; 1,400 y 1,600","0.7 Nm y 10000 de fuerza radial a 900 rpm en el ejemplo de la Figura 12"]])
r(2,"Parámetros de preprocesamiento a espectrograma por banco","tabla","muestras; kHz","Segmentos de 0.25 s, 1600 puntos de FFT, 96 % de solape, banda de 0 a 10 kHz",
  "Sehri et al. (2025), Tabla 1 (arXiv:2504.11581), https://arxiv.org/abs/2504.11581",'v_c',
  "Las frecuencias de HUST y PADERBORN de esta tabla no coinciden con las del texto de la Sección 2.1 (25,600 Hz; 8,000 y 16,000 Hz). "+LAB,
  columnas=["Banco","Longitud de señal (muestras)","Longitud de ventana","Frecuencia de muestreo (kHz)"],
  filas=[["CWRU","12000","200","48 / 12"],["UORED-VAFCLS","10500","180","42"],["HUST","12800","200","51.2"],["PADERBORN","16000","180","64"]])
r(3,"Muestras por estado del rodamiento (totales)","tabla","segmentos","H sano, I pista interna, O pista externa, B bola; segmentos de espectrograma",
  "Sehri et al. (2025), Tabla 3, filas de totales (arXiv:2504.11581), https://arxiv.org/abs/2504.11581",'v_f',
  "Solo las filas de totales; los conteos por pliegue no se replican. "+LAB,
  columnas=["Banco / partición","H","I","O","B"],
  filas=[["CWRU por carga","280","1542","1540","1580"],["CWRU por severidad","280","1522","1540","1600"],["HUST","600","600","600","405"],["UORED-VAFCLS","800","200","200","200"],["PADERBORN","1918","1267","1907","0"]])
r(4,"Resultados de transferencia en CWRU: partición por carga y por severidad","tabla","% (media y desviación estándar entre 4 pliegues)","Exactitud balanceada y F1 macro; K = 4; DenseNet121 sobre espectrogramas",
  "Sehri et al. (2025), Tabla 4 (arXiv:2504.11581), https://arxiv.org/abs/2504.11581",'v_g v_h v_i v_j v_k',
  "La extracción del texto coloca la fila 'ImageNet parcial 90.04' bajo severidad; se asignó a carga según el texto de la Sección 4.3. Un solo banco, desviaciones de más de 20 puntos en severidad. "+LAB,
  columnas=["Partición","Método","Exactitud media","F1 medio","Desv. exactitud","Desv. F1"],
  filas=[["Carga","Afinado completo ImageNet","97.58","97.46","4.30","4.53"],["Carga","Afinado completo VibNet","97.39","97.32","3.79","3.94"],
         ["Carga","Desde cero","96.84","96.81","3.82","3.89"],["Carga","Afinado parcial VibNet","95.66","95.66","3.62","3.63"],
         ["Carga","Afinado parcial ImageNet","90.04","89.94","14.86","15.53"],
         ["Severidad","Afinado completo ImageNet","64.38","65.12","21.39","21.69"],["Severidad","Afinado completo VibNet","66.57","65.91","22.47","22.94"],
         ["Severidad","Desde cero","64.35","58.00","20.18","10.43"],["Severidad","Afinado parcial VibNet","66.88","66.21","21.38","21.69"],
         ["Severidad","Afinado parcial ImageNet","58.26","52.75","4.31","7.00"]])
r(5,"Exactitud balanceada media en CWRU con pliegues por carga","barras","% exactitud balanceada media (K = 4)","Partición por carga (0 a 3 hp); sin intervalos de confianza",
  "Sehri et al. (2025), Tabla 4, división por carga (arXiv:2504.11581), https://arxiv.org/abs/2504.11581",'v_g v_j',
  "Barras de medias; las desviaciones están en la tabla R-04, no son intervalos de confianza. "+LAB,
  series=[S("Afinado completo ImageNet","97.58"),S("Afinado completo VibNet","97.39"),S("Desde cero","96.84"),S("Afinado parcial VibNet","95.66"),S("Afinado parcial ImageNet","90.04")])
r(6,"Exactitud balanceada media en CWRU con pliegues por severidad de falla","barras","% exactitud balanceada media (K = 4)","Partición por severidad (0.007 a 0.028 pulgadas); desviaciones de ~21 puntos",
  "Sehri et al. (2025), Tabla 4, división por severidad (arXiv:2504.11581), https://arxiv.org/abs/2504.11581",'v_h v_i v_k',
  "Barras de medias; las desviaciones (hasta 22.47) están en la tabla R-04. "+LAB,
  series=[S("Afinado completo ImageNet","64.38"),S("Afinado completo VibNet","66.57"),S("Desde cero","64.35"),S("Afinado parcial VibNet","66.88"),S("Afinado parcial ImageNet","58.26")])
r(7,"Banco KAIST y protocolo de validación del diagnóstico con velocidad variable","tabla","según fila","Banco de laboratorio con defectos sembrados; 4 clases (Normal, Outer, Inner, Ball)",
  "Jalonen et al. (2023), Secciones II-A a II-C (arXiv:2311.18547), https://arxiv.org/abs/2311.18547",'j_a j_b',
  "Tabla armada con valores del texto; la Tabla I de resultados por SNR no figura en el texto recuperado. Pliegues barajados de las mismas grabaciones. "+LAB,
  columnas=["Parámetro","Valor"],
  filas=[["Velocidad del motor (rpm)","680-2460"],["Frecuencia de muestreo original (kHz)","25.6"],["Frecuencia tras reducción (kHz)","20"],
         ["Duración por clase (s)","2,100"],["Longitud de segmento (muestras)","2,000"],["Duración del segmento (s)","0.1"],
         ["Segmentos por clase","21,000"],["Muestras totales","84,000"],["Entrenamiento / prueba por pliegue","67,200 / 16,800"],
         ["Niveles de ruido añadido (dB)","20; 15; 10; 5; 0; -5"]])
r(8,"Exactitud de la clase pista interna: señal limpia y ruido de -5 dB","barras","% exactitud","Banco KAIST; promedio de 5 pliegues; ruido blanco gaussiano añadido",
  "Jalonen et al. (2023), Sección III-A (arXiv:2311.18547), https://arxiv.org/abs/2311.18547",'j_c',
  "Solo la clase pista interna; la Figura 3 y la Tabla I con las demás clases y niveles de SNR no se recuperaron: SIN DATOS PARA ARMARLAS. "+LAB,
  series=[S("Pista interna, señal limpia","100"),S("Pista interna, SNR de -5 dB","95.6")])
r(9,"Exactitud al retener una condición completa (CWRU y JNU)","barras","% exactitud","Leave-one-condition-out; CWRU por carga, JNU reteniendo 1000 rpm; solo datos del resumen del autor",
  "Leyva-Vazquez et al. (2026), resumen (arXiv:2610.06880), https://arxiv.org/abs/2610.06880",'l_a',
  "Solo resumen del autor (el lector no entregó texto completo); no hay tablas ni intervalos. Bancos de laboratorio. "+LAB,
  series=[S("CWRU, ensamble, tres cargas retenidas","100.00"),S("CWRU, ensamble, cuarta carga retenida","92.27"),S("JNU, ensamble, 1000 rpm retenido","40.64"),S("JNU, regresión logística, 1000 rpm retenido","57.91")])
r(10,"Componentes del puntaje CARE","tabla","según fila","Definición de la métrica por evento; datos de aerogeneradores con resolución de 10 minutos",
  "Gück et al. (2024), Sección 4.1 (arXiv:2404.10320), https://arxiv.org/abs/2404.10320",'c_a c_b c_c c_e',
  "La tabla resume el texto; las fórmulas se renderizan con símbolos no citables. Parámetros calibrados para series de 10 minutos de aerogeneradores.",
  columnas=["Componente","Qué mide","Métrica","Parámetro citado"],
  filas=[["Coverage","Detección de tantas anomalías correctas como sea posible","Fβ puntual en series con evento","β = 1/2"],
         ["Accuracy","Reconocimiento de comportamiento normal","Exactitud sobre series sin anomalías","—"],
         ["Reliability","Pocas alarmas falsas por evento","Fβ por evento; alarma si la criticidad máxima supera el umbral","72 (12 horas seguidas con datos cada 10 minutos)"],
         ["Earliness","Detección antes de que la falla sea crítica","Puntaje ponderado: peso 1 en la primera mitad del evento y decrece linealmente a 0 en la segunda","1 y 0"],
         ["CARE","Combinación","Promedio ponderado con pesos 1, 1, 1 y 2 (el 2 es de Accuracy); vale 0 si no hay detecciones","1, 1, 1 y 2"]])
r(11,"Composición del conjunto de datos CARE","tabla","conteo","Aerogeneradores; parque A en tierra, B y C marinos; SCADA de 10 minutos",
  "Gück et al. (2024), Sección 3.2, tabla de estadísticas (arXiv:2404.10320), https://arxiv.org/abs/2404.10320",'c_d',
  "No son datos de vibración ni de chumaceras. Las celdas '—' del total no se publican en el texto.",
  columnas=["Concepto","Parque A","Parque B","Parque C","Total"],
  filas=[["Turbinas","5","9","22","36"],["Series","22","15","58","95"],["Eventos de anomalía","11","6","27","44"],["Comportamiento normal","11","9","31","51"],["Variables","86","257","957","—"],["Sensores","54","63","238","—"]])
r(12,"Puntaje CARE del mini-benchmark","barras","puntaje CARE (0 a 1)","95 series de aerogeneradores; el bosque de aislamiento no se grafica porque su valor solo está en la Figura 3",
  "Gück et al. (2024), Sección 4.2.3, texto de la Figura 3 (arXiv:2404.10320), https://arxiv.org/abs/2404.10320",'c_f',
  "Solo cuatro de las cinco estrategias del paper tienen valor en el texto. No es referencia para chumaceras.",
  series=[S("Todo anomalía","0"),S("Todo normal","0"),S("Aleatorio","0.5"),S("Autoencoder con umbral calibrado","0.66")])
r(13,"Bancos de MBHM: muestreo, condiciones, fallas y tiempo","tabla","kHz; conteo; s","Diez filas de la Tabla 1 del paper (nueve bancos y el conjunto MBHM combinado)",
  "Peng et al. (2024), Tabla 1 (arXiv:2408.11281), https://arxiv.org/abs/2408.11281",'p_a',
  "Se omite la columna de marcas de texto. "+LAB,
  columnas=["Banco","Frecuencia de muestreo (kHz)","Condiciones de trabajo","Tipos de falla","Tiempo (s)"],
  filas=[["CWRU","12 / 48","12","10","3932"],["DIRG","51.2","102","7","7140"],["HIT","20","40","3","9648"],["IMS","20","16","7","46480"],["JNU","100","45","4","3600"],
         ["JUST","50","36","4","43986"],["MFPT","48.8 / 97.6","1","3","78"],["PU","64","4","5","7316"],["XJTU","25.6","6","10","13336"],["MBHM","12 a ~100","262","10","135516"]])
r(14,"Exactitud cero disparos en bancos no vistos","barras","% exactitud","Modelo entrenado sin el banco de prueba; con y sin canales de referencia sin falla y residuo",
  "Peng et al. (2024), Sección 5.3 (arXiv:2408.11281), https://arxiv.org/abs/2408.11281",'p_b p_c p_d',
  "Valores tomados del texto; las matrices de confusión no se recuperaron. IMS está desbalanceado. El método exige una señal de referencia sin falla de las mismas condiciones. "+LAB,
  series=[S("JUST, con canales de referencia y residuo","90.22"),S("JUST, sin esos canales","87.54"),S("IMS, con canales de referencia y residuo","98.52"),S("IMS, sin esos canales","97.81"),
          S("CWRU, entrenado sin CWRU","90.26"),S("CWRU, entrenado sin CWRU ni XJTU","89.14")])
r(15,"Error de pronóstico de vida remanente: cabeza lineal sobre Chronos-2 frente a TCN","barras","MAE (el texto no rotula la unidad; la RUL está en días)","Dispositivo A; ventana de contexto de 5 pasos; intervalo de 1 hora",
  "El-Ghoussani et al. (2026), Sección III-F (arXiv:2606.11990), https://arxiv.org/abs/2606.11990",'e_b',
  "Solo dos barras citadas en el texto; las tablas I y II completas no se recuperaron: SIN DATOS PARA ARMARLAS. Datos de equipos industriales, no de rodamientos.",
  series=[S("Chronos-2 congelado con cabeza lineal","60"),S("TCN","88")])
# --- verificacion de numeros literales
def tokens(s): return re.findall(r'\d[\d,\.]*\d|\d',s)
bad=0
def chk(label,text,evi):
    global bad
    pool=' '.join(REG[e]['extracto'] for e in evi)
    for t in tokens(text):
        if t not in pool:
            print('NUMERO NO LITERAL',label,repr(t)); bad+=1
for x in cif:
    chk(x['id'],x['valor'],x['evidencia'])
for x in REP:
    if 'series' in x:
        for s in x['series']: chk(x['id']+' '+s['etiqueta'],s['valor'],x['evidencia'])
    else:
        for f in x['filas']:
            for cell in f[1:] if x['id'] not in('R-01',) else f[1:]:
                chk(x['id']+' '+f[0],cell,x['evidencia'])
print('cifras',len(cif),'replicas',len(REP),'fallas',bad)
json.dump(cif,open(B+'/lector2_cifras.json','w'),ensure_ascii=False,indent=1)
json.dump(REP,open(B+'/lector2_replicas.json','w'),ensure_ascii=False,indent=1)

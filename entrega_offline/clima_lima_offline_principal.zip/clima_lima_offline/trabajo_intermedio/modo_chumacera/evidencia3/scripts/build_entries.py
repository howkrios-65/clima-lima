import re, json, sys
B='/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_chumacera/evidencia3'
T=B+'/txt/'
def norm(s):
    s=re.sub(r'<[^>]+>',' ',s)
    s=re.sub(r'\[([^\]]*)\]\([^)]*\)',r'\1',s)
    s=s.replace('_','').replace('*','')
    return re.sub(r'\s+',' ',s).strip()
SRC={
 'p11581':norm(open(T+'p11581_a.txt').read()),
 'p18547':norm(open(T+'p18547.txt').read()),
 'p10320':norm(open(T+'p10320.txt').read()),
 'p11281':norm(open(T+'p11281.txt').read()+'\n'+open(T+'p11281_b.txt').read()),
 'p06880':norm(open(T+'p06880.txt').read()),
 'p11990':norm(open(T+'p11990.txt').read()),
}
REFS={
 'p11581':dict(autores="Sehri, M., Varejão, I., Hua, Z., Bonella, V., Santos, A., Boldt, F. A., Dumond, P., & Varejão, F. M.",anio=2025,
   titulo="Towards a universal vibration analysis dataset: A framework for transfer learning in predictive maintenance and structural health monitoring",
   fuente="arXiv:2504.11581 (preprint)",url="https://arxiv.org/abs/2504.11581",pais="Canadá; Brasil (afiliaciones de los autores en el documento)",
   institucion="University of Ottawa; Universidade Federal do Espírito Santo; Instituto Federal do Espírito Santo (afiliaciones en el documento)"),
 'p18547':dict(autores="Jalonen, T., Al-Sa'd, M., Kiranyaz, S., & Gabbouj, M.",anio=2023,
   titulo="Real-time vibration-based bearing fault diagnosis under time-varying speed conditions",
   fuente="arXiv:2311.18547 (preprint; versión HTML v2)",url="https://arxiv.org/abs/2311.18547"),
 'p06880':dict(autores="Leyva-Vazquez, M., Rumbaut Rangel, D., Cevallos-Torres, L., & Matheu Perez, A.",anio=2026,
   titulo="Neutrosophic ensemble classification for uncertainty-aware bearing fault detection: Evidence from laboratory and variable-speed industrial benchmarks",
   fuente="arXiv:2610.06880 (preprint)",url="https://arxiv.org/abs/2610.06880"),
 'p10320':dict(autores="Gück, C., Roelofs, C. M. A., & Faulstich, S.",anio=2024,
   titulo="CARE to Compare: A real-world dataset for anomaly detection in wind turbine data",
   fuente="arXiv:2404.10320 (preprint; versión HTML v2)",url="https://arxiv.org/abs/2404.10320"),
 'p11281':dict(autores="Peng, H., Liu, J., Du, J., Gao, J., & Wang, W.",anio=2024,
   titulo="BearLLM: A prior knowledge-enhanced bearing health management framework with unified vibration signal representation",
   fuente="arXiv:2408.11281 (preprint; versión HTML v2)",url="https://arxiv.org/abs/2408.11281",
   institucion="Intelligent Detection and Equipment Department, Shenyang Institute of Automation (según metadatos del modelo vinculado en Hugging Face; no figura en el texto leído)"),
 'p11990':dict(autores="El-Ghoussani, A., De Vita, M., Naumann, R., & Belagiannis, V.",anio=2026,
   titulo="Time-series foundation model embeddings for remaining useful life estimation",
   fuente="arXiv:2606.11990 (preprint)",url="https://arxiv.org/abs/2606.11990",
   institucion="friedrich alexander university (organización 'unierlangen' en los metadatos de Hugging Face; no figura en el texto leído)"),
}
ENT=[]
def E(key,src,segs,loc,afirma,limites,aplica,acceso='texto_completo',sep=' ... '):
    ex=sep.join(segs)
    for s in segs:
        if norm(s) not in SRC[src]:
            print('FALLA VERBATIM',key,'|',s[:90]); 
    ref=dict(REFS[src])
    ref={k:v for k,v in ref.items() if v}
    ENT.append(dict(key=key,tipo='preprint',acceso=acceso,via='lector_hf_papers',fecha_acceso='2026-10-27',referencia=ref,
        extracto=ex,localizador=loc,afirma=afirma,limites=limites,aplica_a=aplica,revista_cuartil=None))
LAB="Banco de laboratorio con rodamientos pequeños de bolas a altas velocidades (cientos a miles de rpm), no una polea lenta de faja transportadora: sus cifras no son extrapolables a la chumacera de polea."
# ---------------- 2504.11581
E('v_a','p11581',[
 "The CWRU data consists of sampling frequencies of 12,000 and 48,000 Hz with a sample duration of 10 seconds, and speeds around 1,720 and 1,797 RPM",
 "The UORED-VAFCLS data consists of a sampling frequency of 42,000 Hz with a sample duration of 10 seconds, and speeds around 1,700 to 1,800 RPM",
 "The test rig consists of an electrical motor seen on the left-hand side of Figure 1, followed by a shaft with a coupling being tested and a dynamometer to control the different loads being applied."],
 "Sección 2.1.1 (CWRU) y 2.1.2 (UORED-VAFCLS), hf://papers/2504.11581/paper.md",
 "Parámetros de adquisición de dos bancos públicos de rodamientos: CWRU (12,000 y 48,000 Hz, 10 s, cerca de 1,720 y 1,797 rpm, carga aplicada con dinamómetro) y UORED-VAFCLS (42,000 Hz, 10 s, 1,700 a 1,800 rpm, carga y velocidad constantes).",
 LAB+" Los valores son los que declaran los autores del marco; no se verificaron contra los repositorios originales.",
 "Brecha de dominio entre bancos públicos (alta velocidad, rodamiento pequeño) y chumacera de polea de baja velocidad. Comparabilidad: baja.")
E('v_b','p11581',[
 "HUST data consists of a sampling frequency of 25,600 Hz with a sample duration of 20 seconds, and speeds ranging from 600 to 2,100 RPM",
 "offering data from ball bearings such as the 6204, 6205, 6206, 6207, and 6208",
 "The PADERBORN dataset includes vibration data recorded using two accelerometers with sampling rates of 8,000 and 16,000 Hz, covering motor speeds of 600, 800, 1,000, 1,200, 1,400, and 1,600 RPM",
 "deep groove ball bearings, cylindrical roller bearings, and tapered roller bearings"],
 "Secciones 2.1.3 (HUST) y 2.1.4 (PADERBORN), hf://papers/2504.11581/paper.md",
 "Parámetros de adquisición de HUST (25,600 Hz, 20 s, 600 a 2,100 rpm, rodamientos de bolas 6204 a 6208) y PADERBORN (8,000 y 16,000 Hz, velocidades de 600 a 1,600 rpm, bolas de ranura profunda, rodillos cilíndricos y rodillos cónicos).",
 LAB+" El texto da para PADERBORN 8,000 y 16,000 Hz, pero la Tabla 1 del mismo documento da 64 kHz; el documento no concilia ambos valores.",
 "Brecha de dominio entre bancos públicos y chumacera de polea de baja velocidad. Comparabilidad: baja.")
E('v_c','p11581',[
 "Dataset Signal length (samples) Window length Sampling freq. CWRU 12000 200 48 / 12 kHz UORED-VAFCLS 10500 180 42 kHz HUST 12800 200 51.2 kHz PADERBORN 16000 180 64 kHz",
 "Here, 0.25 s is used for all datasets.",
 "For each dataset there are 1600 Number of Fast Fourier Transform (NFFT) points, 96% overlap, and a frequency range of 0 to 10 kHz is used."],
 "Sección 3.3.1, Tabla 1 (celdas transcritas de la tabla HTML) y texto siguiente, hf://papers/2504.11581/paper.md",
 "Parámetros de preprocesamiento a espectrograma por banco: longitud de señal (12000, 10500, 12800 y 16000 muestras), longitud de ventana (200, 180, 200 y 180), segmentos de 0.25 s, 1600 puntos de FFT, 96 % de solape y banda de 0 a 10 kHz.",
 "La Tabla 1 lista 51.2 kHz para HUST y 64 kHz para PADERBORN, distinto de lo escrito en la Sección 2.1 (25,600 Hz; 8,000 y 16,000 Hz). Cálculo propio: 12800 muestras en 0.25 s equivalen a 51 200 Hz, así que la tabla parece reflejar la frecuencia efectiva usada; el documento no lo aclara. "+LAB,
 "Plantilla de preprocesamiento para estandarizar vibración de distintas frecuencias de muestreo. Comparabilidad: baja con el activo.")
E('v_d','p11581',[
 "Figure 13. Mitigation bias related to motor load severity",
 "Round 0 hp 1 hp 2 hp 3 hp 1 Fold 1 Fold 2 Fold 3 Fold 4",
 "Figure 14. Mitigation bias related to similarity of failure severity",
 "Round 0.007\" + H (0 hp) 0.014\" + H (1 hp) 0.021\" + H (2 hp) 0.028\" + H (3 hp)",
 "The results for K-fold cross-validation (K = 4)"],
 "Sección 3.4, Figuras 13 y 14 (celdas transcritas) y Sección 4.3, hf://papers/2504.11581/paper.md",
 "La evaluación en CWRU se hizo con 4 pliegues organizados de dos maneras: por carga del motor (0, 1, 2 y 3 hp) y por severidad de falla (0.007, 0.014, 0.021 y 0.028 pulgadas, más sano).",
 "Interpretación del investigador: las figuras muestran un pliegue por cada carga o severidad, lo que sugiere probar sobre una carga o severidad distinta a las de entrenamiento, pero el texto no lo declara con esa frase. "+LAB,
 "Evaluación de generalización entre condiciones (carga y severidad). Comparabilidad: baja con el activo, media como diseño de validación.")
E('v_e','p11581',[
 "Figure 11. TFR of the HUST dataset, using the B702 file as an example, showing that the 6207 bearing type has a ball fault and a 200W load is applied.",
 "N09\\_M07\\_F10\\_KI21\\_9 file, operating parameters are: 900 rpm, 0.7 Nm and 10000 radial force",
 "which has an inner race fault with a size of 0.007 inch under a 0 hp load"],
 "Pies de las Figuras 9, 11 y 12 de la Sección 3.3.1, hf://papers/2504.11581/paper.md",
 "Ejemplos de cargas de operación citados por los autores: 200 W en un archivo de HUST con rodamiento 6207 y falla de bola; 900 rpm, 0.7 Nm y 10000 de fuerza radial en un archivo de PADERBORN; 0 hp con falla de pista interna de 0.007 pulgadas en CWRU.",
 "Son ejemplos de pies de figura, no la lista completa de cargas de cada banco. El texto escribe 10000 de fuerza radial sin unidad; no se infiere. "+LAB,
 "Magnitud de carga en bancos públicos frente a cargas de una polea de faja. Comparabilidad: baja.")
E('v_f','p11581',[
 "Dataset Folds H I O B",
 "Total 280 1542 1540 1580",
 "Total 280 1522 1540 1600",
 "HUST N/A 600 600 600 405",
 "UORED-VAFCLS N/A 800 200 200 200",
 "PADERBORN N/A 1918 1267 1907 0",
 "where H, I, O and B represent healthy, inner race, outer race and ball faults, respectively"],
 "Sección 4.2, Tabla 3 (filas de totales transcritas), hf://papers/2504.11581/paper.md",
 "Conteo de muestras por estado del rodamiento (H sano, I pista interna, O pista externa, B bola): CWRU por carga 280/1542/1540/1580; CWRU por severidad 280/1522/1540/1600; HUST 600/600/600/405; UORED-VAFCLS 800/200/200/200; PADERBORN 1918/1267/1907/0 (sin bola). Los sanos son una fracción pequeña en CWRU.",
 "Conteos de segmentos de espectrograma tras el muestreo de los autores, no de máquinas ni de horas de operación. "+LAB,
 "Desbalance entre sano y con falla en bancos públicos. Comparabilidad: baja.")
E('v_g','p11581',[
 "For the CWRU Load Division, the full fine tuning method from ImageNet weights achieved a mean balanced accuracy of 97.58% and an macro F1 score of 97.46%, with standard deviations of 4.30% and 4.53%, respectively.",
 "In comparison, Full fine tuning from VibNet weights resulted in a slightly lower mean balanced accuracy of 97.39% and a macro F1 score of 97.32%, but with reduced standard deviations of 3.79% and 3.94%.",
 "Partial fine tuning on VibNet weights showed a mean balanced accuracy of 95.66% and a macro F1 score of 95.66%, while partial fine tuning on ImageNet weights resulted in significantly lower performance, with a mean accuracy of 90.04% and an F1 score of 89.94%."],
 "Sección 4.3, párrafo 2 (división por carga), hf://papers/2504.11581/paper.md",
 "En CWRU con pliegues por carga, el afinado completo desde pesos ImageNet logra 97.58 % de exactitud balanceada media (F1 macro 97.46 %), desde VibNet 97.39 % (97.32 %), el afinado parcial desde VibNet 95.66 % y desde ImageNet 90.04 % (89.94 %).",
 "Un solo banco (CWRU), K = 4, sin intervalos de confianza (solo desviaciones estándar entre pliegues). Rodamientos pequeños de bolas a ~1,720 y 1,797 rpm. "+LAB,
 "Generalización entre cargas en banco. Comparabilidad: baja.")
E('v_h','p11581',[
 "In the CWRU Severity Division, the full fine tuning method on ImageNet weights achieved a mean accuracy of 64.38% and an F1 score of 65.12%, with higher standard deviations of 21.39% and 21.69%.",
 "Full fine tuning on VibNet weightsimproved the mean accuracy to 66.57% and the F1 score to 65.91%, albeit with slightly higher standard deviations of 22.47% and 22.94%.",
 "The training from scratch model resulted in a mean accuracy of 64.35% and an F1 score of 58.00%, with a notable reduction in the standard deviation of the F1 score to 10.43%."],
 "Sección 4.3, párrafo 3 (división por severidad), hf://papers/2504.11581/paper.md",
 "En CWRU con pliegues por severidad de falla, la exactitud baja a 64.38 % (afinado completo desde ImageNet, desviación 21.39 %), 66.57 % (desde VibNet, desviación 22.47 %) y 64.35 % (desde cero, F1 58.00 %), frente a 97.58 % en la división por carga.",
 "Un solo banco y K = 4; las desviaciones de más de 20 puntos indican que el resultado depende mucho de qué pliegue se retiene. "+LAB,
 "Generalización a una severidad no vista; límite de los modelos entrenados en banco. Comparabilidad: baja.")
E('v_i','p11581',[
 "Partial fine tuning on VibNet weights showed the best performance in this division, with a mean accuracy of 66.88% and an F1 score of 66.21%, while Partial fine tuning on ImageNet weights had the lowest performance, with a mean accuracy of 58.26% and an F1 score of 52.75%.",
 "VibNet partial and full fine tuning respectively achieved the best and second-best results in the severity division, which is the more difficult diagnosis problem in the CWRU dataset."],
 "Sección 4.3, párrafo 3 (final), hf://papers/2504.11581/paper.md",
 "En la división por severidad, el mejor resultado es el afinado parcial desde VibNet (66.88 %; F1 66.21 %) y el peor el afinado parcial desde ImageNet (58.26 %; F1 52.75 %); los autores señalan que la severidad es el problema más difícil de CWRU.",
 "Preliminar, un banco, sin prueba de significancia; la diferencia entre mejor y segundo es de décimas frente a desviaciones de más de 20 puntos. "+LAB,
 "Generalización entre severidades. Comparabilidad: baja.")
E('v_j','p11581',[
 "Metric Method Mean (%) Std (%) Accuracy Score F1 Score Accuracy Score F1 Score",
 "Full Finetune ImageNet 97.58 97.46 4.30 4.53",
 "Full Finetune VibNet 97.39 97.32 3.79 3.94",
 "From Scratch 96.84 96.81 3.82 3.89",
 "Partial Finetune VibNet 95.66 95.66 3.62 3.63",
 "Partial Finetune ImageNet 90.04 89.94 14.86 15.53"],
 "Sección 4.3, Tabla 4, primer bloque (celdas transcritas), hf://papers/2504.11581/paper.md",
 "Tabla 4, división por carga de CWRU (exactitud media, F1 medio, desviación de ambos, en %): ImageNet completo 97.58/97.46/4.30/4.53; VibNet completo 97.39/97.32/3.79/3.94; desde cero 96.84/96.81/3.82/3.89; VibNet parcial 95.66/95.66/3.62/3.63; ImageNet parcial 90.04/89.94/14.86/15.53.",
 "La extracción del texto coloca la fila 'Partial Finetune ImageNet 90.04' bajo el rótulo de severidad; se asignó a la división por carga porque el texto de la Sección 4.3 lo dice así. Las desviaciones 14.86 y 15.53 provienen solo de esa fila. "+LAB,
 "Generalización entre cargas en banco. Comparabilidad: baja.")
E('v_k','p11581',[
 "Full Finetune ImageNet 64.38 65.12 21.39 21.69",
 "Full Finetune VibNet 66.57 65.91 22.47 22.94",
 "From Scratch 64.35 58.00 20.18 10.43",
 "Partial Finetune VibNet 66.88 66.21 21.38 21.69",
 "Partial Finetune ImageNet 58.26 52.75 4.31 7.00"],
 "Sección 4.3, Tabla 4, segundo bloque (celdas transcritas), hf://papers/2504.11581/paper.md",
 "Tabla 4, división por severidad de CWRU (exactitud media, F1 medio, desviación de ambos, en %): ImageNet completo 64.38/65.12/21.39/21.69; VibNet completo 66.57/65.91/22.47/22.94; desde cero 64.35/58.00/20.18/10.43; VibNet parcial 66.88/66.21/21.38/21.69; ImageNet parcial 58.26/52.75/4.31/7.00.",
 "Mismo banco y K = 4 que la fila anterior; las desviaciones de ~21 puntos hacen que las diferencias entre métodos sean menores que la variación entre pliegues. "+LAB,
 "Generalización a severidad no vista. Comparabilidad: baja.")
E('v_l','p11581',[
 "However, the CWRU dataset was not specifically designed with ML applications in mind, and care must be taken to avoid misleading results. For example, issues related to data with similar load conditions may affect the generalizability of models",
 "Another challenge is the significant amount of healthy data when compared to faulty data, since machines aren't meant to fail."],
 "Sección 2.1.1, párrafo 2, y Sección 1, párrafo 2, hf://papers/2504.11581/paper.md",
 "Los autores advierten que CWRU no se diseñó para aprendizaje automático, que cargas parecidas entre entrenamiento y prueba afectan la generalización y que los datos sanos abundan más que los con falla.",
 "Advertencia metodológica de los autores con referencias que no se leyeron. "+LAB,
 "Riesgo de resultados engañosos al validar con bancos. Comparabilidad: media como advertencia.")
# ---------------- 2311.18547
E('j_a','p18547',[
 "The motor was operated with time-varying speeds (680-2460 rpm) and the bearing in housing B was seeded with outer race, inner race, and bearing ball faults.",
 "The sampling frequency was set to 25.6 kHz and 2,100 seconds of vibration data were collected for each of the four classes.",
 "The vibration signals from the two sensors were first downsampled to 20 kHz"],
 "Sección II-A y II-B, hf://papers/2311.18547/paper.md",
 "Banco KAIST usado: motor con velocidad variable de 680 a 2460 rpm, defectos sembrados en pista externa, pista interna y bola, 25.6 kHz de muestreo, 2,100 s por clase, reducido a 20 kHz.",
 "Banco de laboratorio con defectos sembrados; la velocidad mínima es 680 rpm, por lo que el trabajo no cubre regímenes por debajo de ese valor. "+LAB,
 "Diagnóstico bajo velocidad variable; no sustenta desempeño a baja velocidad. Comparabilidad: baja.")
E('j_b','p18547',[
 "we corrupted the vibration waveforms with noise at the following SNR levels: 20 dB, 15 dB, 10 dB, 5 dB, 0 dB, and -5 dB",
 "corresponds to a segment length of 2,000 samples",
 "which yields a total of 21,000 segments",
 "we decided 10 Hz, or 0.1 seconds, is a suitable maximum rate of range",
 "First, we divided the 84,000 samples (four classes each having 21,000 segments) into five equally sized shuffled splits and maintained their class balance (stratified folds).",
 "each model was trained with 67,200 samples and tested with 16,800 samples"],
 "Secciones II-B y II-C, hf://papers/2311.18547/paper.md",
 "Segmentos sin solape de 2,000 muestras (0.1 s), 21,000 por clase, 84,000 en total; validación cruzada de 5 pliegues estratificados barajados (67,200 de entrenamiento y 16,800 de prueba); ruido blanco añadido a 20, 15, 10, 5, 0 y -5 dB.",
 "Interpretación del investigador: pliegues barajados de segmentos de las mismas grabaciones, sin retener una condición o grabación completa, por lo que no prueba generalización a otra máquina o régimen. Ruido blanco gaussiano sintético, no ruido de planta. "+LAB,
 "Protocolo de validación y robustez a ruido. Comparabilidad: baja.")
E('j_c','p18547',[
 "the Inner class is the easiest to predict as it had the least amount of accuracy drop; from 100% for clean signals to 95.6% for noisy signals at -5 dB SNR",
 "(up to a 3.6% point gain in average accuracy)",
 "the designed CNN outruns the PIResNet with a significant performance gain of up to 15.8% points. Nevertheless, our results are averaged over the five cross-validation splits while PIResNet results are drawn from the best-performing confusion matrices."],
 "Sección III-A, hf://papers/2311.18547/paper.md",
 "La clase pista interna conserva la exactitud (de 100 % sin ruido a 95.6 % con -5 dB); la CNN supera hasta 3.6 puntos de exactitud promedio y hasta 15.8 puntos en las matrices de confusión frente a PIResNet, comparando promedios de 5 pliegues contra los mejores resultados del otro método.",
 "La Tabla I y la Figura 3 con los valores por nivel de ruido no figuran en el texto recuperado (solo sus pies), por lo que no se pudo transcribir la exactitud de cada SNR. La ganancia de 15.8 puntos compara contra el mejor caso del método rival, según los propios autores. "+LAB,
 "Robustez de defecto en pista interna ante ruido. Comparabilidad: baja.")
E('j_d','p18547',[
 "The results indicate an average inference time of 20.2 ms with a 0.36 standard deviation. This corresponds to a processing time approximately five times less than the duration of data acquisition.",
 "In total, the model has 558,660 trainable parameters.",
 "The present work has some limitations; it is confined to fixed noise levels and to diagnosing isolated faults."],
 "Secciones II-C, III-B y IV, hf://papers/2311.18547/paper.md",
 "La CNN tiene 558,660 parámetros entrenables y 20.2 ms de inferencia promedio (desviación 0.36) por ventana de 0.1 s, unas cinco veces menos que el tiempo de adquisición; los autores reconocen que se limita a niveles fijos de ruido y a fallas aisladas.",
 "Tiempo medido en una computadora portátil con chip M1 Pro; no es un dispositivo de planta. "+LAB,
 "Viabilidad de cómputo en el borde. Comparabilidad: baja.")
# ---------------- 2610.06880 (abstract)
E('l_a','p06880',[
 "evaluated on two bearing benchmarks (CWRU and JNU, 600-1000 rpm) under a leave-one-condition-out protocol",
 "On CWRU, after correcting a file-to-class mapping error, the ensemble reaches 100.00 percent accuracy on three of four held-out loads (92.27 percent on the fourth)",
 "On JNU, holding out 1000 rpm, accuracy collapses to 40.64 percent, below a majority-class baseline; Logistic Regression (57.91 percent) generalizes far better than the tree ensembles."],
 "Resumen del autor (campo 'summary' de metadata.json y sección Abstract de paper.md de hf://papers/2610.06880; el lector solo devolvió metadatos y resumen, sin texto completo)",
 "Con retención de una condición (leave-one-condition-out), el ensamble llega a 100.00 % en tres de cuatro cargas retenidas de CWRU y 92.27 % en la cuarta, pero cae a 40.64 % en JNU al retener 1000 rpm, por debajo de una línea base de clase mayoritaria; la regresión logística llega a 57.91 %.",
 "Solo resumen (VERIFICADO-ABSTRACT): sin tablas ni protocolo; el texto completo no estaba disponible en Markdown. Bancos de laboratorio (CWRU, JNU a 600-1000 rpm). "+LAB,
 "Límite de generalización entre condiciones: el rendimiento depende de la partición. Comparabilidad: baja.",acceso='abstract')
E('l_b','p06880',[
 "(AURC 0.29 vs. 0.36 on the standard split; 0.54 vs. 0.73 under a harder single-condition reproduction)",
 "separate most fault classes almost perfectly (99.57 percent) using three interpretable features",
 "standalone Logistic Regression confidence outperforms the full decomposition, a boundary condition we report honestly"],
 "Resumen del autor (metadata.json y Abstract de hf://papers/2610.06880)",
 "Fusionar un modelo temporal y uno de frecuencia y medir su divergencia de Jensen-Shannon da menor AURC (0.29 frente a 0.36 en la partición estándar; 0.54 frente a 0.73 en una reproducción más difícil de una sola condición) que la entropía de un modelo; con frecuencias de falla demoduladas por envolvente en CWRU, tres rasgos separan las clases en 99.57 %.",
 "Solo resumen; el 99.57 % es solo en CWRU, sin retención de condición. "+LAB,
 "Incertidumbre del diagnóstico y rasgos basados en frecuencias de falla. Comparabilidad: baja.",acceso='abstract')
# ---------------- 2404.10320
E('c_a','p10320',[
 "The CARE-score focuses on four key aspects that a good AD model for predictive maintenance should excel in, which are:",
 "Coverage: Detection of as many correct anomalies as possible",
 "Accuracy: Recognition of normal behavior",
 "Reliability: Few false alarm events",
 "Earliness: Detection of anomalies before fault gets critical.",
 "The third sub-score assesses classification performance on aggregated events, by applying an eventwise classification measure."],
 "Sección 4.1, hf://papers/2404.10320/paper.md",
 "El puntaje CARE tiene cuatro componentes: Coverage (cobertura de anomalías correctas), Accuracy (reconocimiento de comportamiento normal), Reliability (pocas falsas alarmas por evento) y Earliness (detección antes de que la falla sea crítica).",
 "Datos de SCADA de aerogeneradores con resolución de 10 minutos, no vibración de chumaceras; solo la definición de la métrica es trasladable, no los valores. Los autores trabajan con la hipótesis de que el inicio de la anomalía está etiquetado.",
 "Métrica por evento y falsas alarmas para cualquier detector que se proponga para la chumacera. Comparabilidad: baja en el activo, media en metodología.")
E('c_b','p10320',[
 "In this case, a value of β=1 2",
 "is chosen to give more weight to precision than recall, thereby penalizing excessive false positives.",
 "which we set to 72. The idea behind this threshold is that in order to reach a criticality of 72 the algorithm must either detect at least 72 anomalies in a row, which equates to 12 hours of consecutive anomalies",
 "Setting the threshold at 72 was found to be the most appropriate for all 95 time series in this dataset and generally depends on the length of the time series and the use-case specific definitions of detected anomaly events.",
 "In the first half of the event, all detected anomalies are assigned a weight of 1. In the second half of the event, the weights decrease linearly to 0"],
 "Sección 4.1.1 (Coverage, Reliability y Earliness), hf://papers/2404.10320/paper.md",
 "Coverage usa Fβ con β = 1/2 (el texto renderiza 'β=1 2'; más adelante aparece como F 1 2) para penalizar falsos positivos; Reliability marca un evento como alarma si la criticidad máxima supera 72 (12 horas de detecciones seguidas con datos cada 10 minutos); Earliness pondera con 1 la primera mitad del evento y decrece linealmente a 0 en la segunda.",
 "El umbral 72 se calibró a series de 10 minutos y de 4 a 98 días de predicción; los autores dicen que depende de la duración de la serie y de la definición de evento. Otro intervalo de muestreo exige recalibrar. "+"Datos de aerogeneradores, no de chumaceras.",
 "Definición de métricas por evento para un detector de la chumacera. Comparabilidad: baja en el activo, media en metodología.")
E('c_c','p10320',[
 "where we choose ω 1=ω 2=ω 3=1",
 "and ω 4=2",
 "in order to weight the normal datasets to the same degree as datasets containing an anomaly event",
 "If no anomalies were detected at all, the CARE score will be 0.",
 "the predictions are worse than uniformly distributed random predictions"],
 "Sección 4.1.1 (CARE), ecuaciones 4 y 5, hf://papers/2404.10320/paper.md",
 "CARE es un promedio ponderado con pesos 1, 1, 1 y 2 (Coverage, Earliness, Reliability y Accuracy sobre series normales); vale 0 si no se detecta ninguna anomalía y se iguala a la exactitud sobre series normales cuando esta cae por debajo de 0.5 (peor que predicción aleatoria uniforme).",
 "El orden de los pesos (1 para Fβ promedio, WS promedio y EFβ; 2 para Acc promedio) sale de la ecuación 4 del texto; el umbral 0.5 de la ecuación 5 se renderiza con símbolos que no se pueden citar literalmente. "+"Datos de aerogeneradores, no de chumaceras.",
 "Definición del puntaje CARE y sus componentes. Comparabilidad: baja en el activo, media en metodología.")
E('c_d','p10320',[
 "The data consists of 95 datasets, containing 89 years of SCADA time series distributed across 36 different WTs from the three wind farms A, B and C.",
 "44 out the 95 datasets contain a labeled anomaly event and the other 51 datasets represent normal behavior",
 "Turbines 5 9 22 36",
 "Datasets 22 15 58 95",
 "Anomaly events 11 6 27 44",
 "Normal behavior 11 9 31 51",
 "Features 86 257 957-",
 "Sensors 54 63 238-"],
 "Sección 3.2 y tabla de estadísticas (celdas transcritas), hf://papers/2404.10320/paper.md",
 "El conjunto CARE reúne 95 series (89 años) de 36 aerogeneradores en 3 parques, con 44 eventos de anomalía etiquetados y 51 series de comportamiento normal; los parques A, B y C aportan 5, 9 y 22 turbinas y 86, 257 y 957 variables.",
 "Aerogeneradores (parque A en tierra, B y C marinos): operación y fallas distintas de una polea de faja; datos anonimizados y con marcas de tiempo desplazadas; el inicio de la anomalía en el parque A es una estimación de los autores.",
 "Tamaño y balance de un conjunto público con eventos etiquetados. Comparabilidad: baja.")
E('c_e','p10320',[
 "The datasets consist of SCADA time series data for each turbine, with a resolution of 10 minutes. Each dataset includes one year worth of data for training a model, as well as 4 to 98 days of prediction data.",
 "For each turbine fault the preceding 14 days were marked with the status-ID 4 (fault) and the 3 days after the fault timestamp were marked with the status-ID 3 (service mode).",
 "Every sub-dataset must contain at least one whole year worth of data, to be able to learn seasonality-related effects."],
 "Secciones 3.1 y 3.2, y 3.3 (parque A), hf://papers/2404.10320/paper.md",
 "Cada serie trae un año de entrenamiento y de 4 a 98 días de predicción con datos cada 10 minutos; en el parque A se marcaron 14 días antes de cada falla como estado de falla y 3 días después como servicio, para evitar contaminar el entrenamiento.",
 "Los 14 y 3 días son un criterio conservador de los autores para el parque A, sin información real de duración de la anomalía. Datos de aerogeneradores.",
 "Requisitos de datos para entrenar y evaluar detectores. Comparabilidad: baja.")
E('c_f','p10320',[
 "The strategy “random” gets the CARE-score of 0.5 and sets the lower bound to beat for good any anomaly detection algorithms.",
 "the trivial strategies “all anomaly” and “all normal” both get the score 0",
 "With a score of 0.66 the AE approach represents a good anomaly detector",
 "The isolation forest approach does not outperform that threshold since it is not able to recognize normal behavior appropriately with the chosen parameter configuration."],
 "Sección 4.2.3, hf://papers/2404.10320/paper.md",
 "En el mini-benchmark de CARE, 'todo anomalía' y 'todo normal' obtienen 0, la estrategia aleatoria 0.5 (cota inferior a superar), el bosque de aislamiento no supera 0.5 y el autoencoder con umbral calibrado llega a 0.66.",
 "Mini-benchmark ilustrativo de los autores con aerogeneradores; el valor del bosque de aislamiento figura solo en la Figura 3, no en el texto. 0.66 no es una referencia para chumaceras.",
 "Qué puntaje significa 'mejor que azar' en CARE. Comparabilidad: baja.")
# ---------------- 2408.11281
E('p_a','p11281',[
 "Dataset Sample Rate (kHz)Condi-tions∗Fault Types Time (s)Text",
 "CWRU 12 / 48 12 10 3932",
 "DIRG 51.2 102 7 7140",
 "HIT 20 40 3 9648",
 "IMS 20 16 7 46480",
 "JNU 100 45 4 3600",
 "JUST 50 36 4 43986",
 "MFPT 48.8 / 97.6 1 3 78",
 "PU 64 4 5 7316",
 "XJTU 25.6 6 10 13336",
 "MBHM 12 ~100 262 10 135516",
 "The same working conditions represent the same load, speed, and sensor."],
 "Sección 3, Tabla 1 (filas transcritas), hf://papers/2408.11281/paper.md",
 "Tabla 1 del paper: diez bancos con frecuencia de muestreo (kHz), número de condiciones de trabajo, tipos de falla y tiempo total (s); por ejemplo CWRU 12/48 kHz, 12 condiciones, 10 tipos, 3932 s; JNU 100 kHz, 45 condiciones; MBHM (conjunto combinado) 12 a ~100 kHz, 262 condiciones, 10 tipos, 135516 s.",
 "Las columnas se infieren de la cabecera y del pie del paper; las celdas se transcriben tal como salen en la extracción (sin la columna de marcas de texto). La condición de trabajo se define como misma carga, velocidad y sensor. "+LAB,
 "Diversidad de condiciones en bancos públicos. Comparabilidad: baja.")
E('p_b','p11281',[
 "We trained on the MBHM(w/o JUST&IMS) dataset, comprising only 35% of the MBHM training data, and performed zero-shot tests on the JUST and IMS datasets separately.",
 "On the JUST dataset, our method achieves an accuracy of 90.22% without any fine-tuning. In contrast, the method without fault-free and residual channels achieves an accuracy of only 87.54%."],
 "Sección 5.3, párrafo 3, hf://papers/2408.11281/paper.md",
 "Entrenando sin los bancos JUST e IMS (35 % de los datos de entrenamiento), la prueba sin ajuste adicional (cero disparos) en JUST da 90.22 % de exactitud con la señal de referencia sin falla y 87.54 % sin los canales de referencia y residuo.",
 "Prueba de transferencia entre bancos de laboratorio; el método exige una señal de referencia sin falla de las mismas condiciones de trabajo. "+LAB,
 "Generalización a un banco no visto con línea base sin falla. Comparabilidad: baja.")
E('p_c','p11281',[
 "Given that the IMS dataset is unbalanced (most samples are fault-free), the overall accuracy drops slightly from 98.52% to 97.81%.",
 "However, the method without two auxiliary channels tends to grossly underestimate the severity. For example, 61% of severe outer ring faults are classified as moderate, and 23% of moderate outer ring faults are identified as minor."],
 "Sección 5.3, párrafo 4, hf://papers/2408.11281/paper.md",
 "En IMS (muestras mayormente sanas), la exactitud cero disparos baja de 98.52 % a 97.81 % al quitar los canales de referencia y residuo, y sin ellos el 61 % de las fallas severas de pista externa se clasifican como moderadas y el 23 % de las moderadas como menores (se subestima la severidad).",
 "IMS está desbalanceado, así que la exactitud global refleja sobre todo muestras sanas. "+LAB,
 "Riesgo de subestimar severidad sin línea base sin falla. Comparabilidad: baja.")
E('p_d','p11281',[
 "we trained our model on the MBHM(w/o CWRU) and MBHM(w/o CWRU&XJTU) datasets, respectively. We then performed zero-shot testing on the commonly used CWRU dataset",
 "Our method achieves remarkable accuracies of 90.26% and 89.14% on the untrained CWRU dataset for each setting, respectively."],
 "Sección 5.3, párrafo 6, hf://papers/2408.11281/paper.md",
 "Retirando CWRU (y también XJTU) del entrenamiento, la exactitud cero disparos sobre CWRU es de 90.26 % y 89.14 %.",
 "Prueba entre bancos de laboratorio; sin intervalo de confianza. "+LAB,
 "Generalización a un banco no visto. Comparabilidad: baja.")
E('p_e','p11281',[
 "The MBHM contains 135,516 pairs of vibration signal segments and fault types, and 542,064 pairs of text cues and responses",
 "Our dataset contains 262 working conditions collected from nine publicly accessible datasets",
 "we empirically set n f=24000",
 "We addressed potential label leakage by dividing the 9 public datasets into a 7:2:1 ratio individualy.",
 "“(+108%)” represents a relative improvement from 48.01% to 100%"],
 "Secciones 3 y 4.1, 5.1 y pie de la Tabla 2, hf://papers/2408.11281/paper.md",
 "El conjunto MBHM reúne 135,516 segmentos de vibración con su falla, 262 condiciones de trabajo de nueve bancos públicos, n_f = 24000 componentes de frecuencia y una división 7:2:1 por banco; el pie de la Tabla 2 menciona una mejora relativa de 48.01 % a 100 % (+108 %) sin que el texto recuperado diga en qué método y banco.",
 "La Tabla 2 completa (exactitudes por método) no figura en el texto recuperado, solo su pie. "+LAB,
 "Escala y protocolo de un modelo único multicondición. Comparabilidad: baja.")
E('p_f','p11281',[
 "However, it relies on comparisons via fault-free signals under the same working conditions, which suggests that it cannot handle bearing health management tasks without prior fault-free knowledge.",
 "At the same time, signal comparison requires the same working conditions, so it cannot be applied to devices such as industrial robotic arms, whose working conditions (e.g., speed, load) vary over time"],
 "Apéndice E, 'Limitation and Future Works', hf://papers/2408.11281/paper.md (segundo tramo)",
 "Los autores reconocen que el método necesita una señal sin falla de las mismas condiciones de trabajo (capturada tras la aceptación o el mantenimiento) y no sirve para equipos cuyas condiciones (velocidad, carga) varían en el tiempo.",
 "Limitación declarada por los autores; no se evaluó con una máquina de planta.",
 "Línea base por activo: sin registro sano de la chumacera no se puede aplicar. Comparabilidad: media como idea de línea base.")
# ---------------- 2606.11990
E('e_a','p11990',[
 "We express y_{t} in days and cap such that y_{t}\\leftarrow\\min(y_{t},y_{\\max}), with y_{\\max}=1000 days.",
 "In addition to sensor measurements, we utilize maintenance logs containing the set of failure timestamps",
 "The context window length L is set to 5 in the following experiments.",
 "We select split points to achieve an 85{:}15 ratio. Crucially, we discard any window [t,...,T] that overlaps the boundary between splits."],
 "Secciones II-A y III-A, hf://papers/2606.11990/paper.md",
 "La vida remanente (RUL) se construye con los registros de reparación como tiempo al siguiente fallo, en días y con tope de 1000 días; la partición es cronológica 85:15 y se descartan ventanas que cruzan el límite; el contexto base es L = 5.",
 "Datos de sensores de equipos industriales de otro tipo (dos tipos de dispositivo), no rodamientos ni vibración; las tablas I y II con los errores por método no figuran en el texto recuperado. Comparabilidad baja con el activo.",
 "Protocolo de validación y construcción de etiquetas con registros de falla. Comparabilidad: baja.")
E('e_b','p11990',[
 "outperforming standard baselines—including non-sequential regressors—by up to 5\\times",
 "expanding the context window to 80 steps dramatically improves performance by reducing MAE by 2\\times compared to a short 5-step context",
 "The performance of our approach improves significantly as L increases, with the most substantial gains observed up to L=80. Beyond this point, performance saturates.",
 "even a linear head on top of frozen Chronos-2 embeddings achieves a significant improvement (MAE 60 vs. 88)"],
 "Secciones I, III-E y III-F, hf://papers/2606.11990/paper.md",
 "Con un modelo base de series de tiempo congelado y una cabeza ligera, el error baja hasta 5 veces frente a modelos de referencia; pasar de contexto 5 a 80 pasos reduce el MAE a la mitad y más allá de 80 se satura; en el dispositivo A, una cabeza lineal da MAE 60 frente a 88 de la red convolucional temporal (TCN).",
 "La unidad del MAE no está rotulada en el texto (la RUL se expresa en días). Las tablas I y II, que darían los errores de cada método, no se recuperaron: SIN DATOS PARA ARMARLAS. Datos de equipos de telecomunicaciones, sin validación en rodamientos.",
 "Pronóstico de vida remanente con registros de falla. Comparabilidad: baja.")
for i,e in enumerate(ENT): e['id']='E-%d'%(9450+i)
KEY={e['key']:e['id'] for e in ENT}
out=[{k:v for k,v in e.items() if k!='key'} for e in ENT]
for e,o in zip(ENT,out):
    L=len(o['extracto'])
    if L>800: print('LARGO',e['key'],L)
json.dump(out,open(B+'/lector2_registro.json','w'),ensure_ascii=False,indent=1)
json.dump(KEY,open(B+'/scripts/keys.json','w'))
print(len(out),'entradas',KEY)

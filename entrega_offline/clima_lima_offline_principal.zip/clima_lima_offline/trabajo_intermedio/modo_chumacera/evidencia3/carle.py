import re
P1=open('p1.txt').read(); Q0=open('q0.txt').read()
def clean_row(line):
    line=line.replace('\\\\,','\\,')
    toks=line.split(' ')
    out=[]
    for t in toks:
        if '\\,' in t:
            v=t.replace('\\,','')
            # pop previous tokens whose concatenation == v
            acc='';k=0
            while out and acc!=v and len(acc)<len(v):
                acc=out.pop()+acc; k+=1
            assert acc==v,(acc,v,line)
            out.append(v)
        else: out.append(t)
    return out
def parse(text,start,end,models):
    i=text.index(start); j=text.index(end,i); b=text[i:j]
    res={}  # (bearing)->{model:[vals]}
    cur=None
    for l in b.split('\n'):
        l=l.strip()
        m=re.match(r'^(Bearing \d+) (.*)$',l)
        if m: cur=m.group(1); l=m.group(2)
        mm=re.match(r'^(CARLE|CARL|CALE|CRLE|CNN-LSTM|CABiLSTM|MSIDIN) (.*)$',l)
        if not mm or cur is None: continue
        name=mm.group(1); rest=mm.group(2).replace('–––','').strip()
        toks=clean_row(rest)
        # dedupe immediate duplicates if too many
        if len(toks)>9:
            d=[]
            for t in toks:
                if d and d[-1]==t and '.' in t: continue
                d.append(t)
            toks=d
        res.setdefault(cur,{})[name]=toks
    return res
T4=parse(Q0,'Table 4: Comparison with SOTA (XJTU-SY)','Table 5: Comparison','')
T1=parse(P1,'Table 1: Ablation experiment (XJTU-SY)','Table 2: Ablation','')
T5=parse(Q0,'Table 5: Comparison with SOTA (PRONOSTIA)','### 4.8','')
T2=parse(P1,'Table 2: Ablation experiment (PRONOSTIA)','### 4.5','')
if __name__=='__main__':
    for n,T in (('T4',T4),('T1',T1),('T5',T5),('T2',T2)):
        print(n)
        for b,d in T.items():
            for m,v in d.items(): print(' ',b,m,len(v),' '.join(v))

import json,re,sys
sys.path.insert(0,'.')
import parse as P, carle as C
REG=json.load(open('lector1_registro.json'))
OLD={e['id']:e for e in json.load(open('/home/user/clima-lima/historial/dossiers/chumacera_polea_faja/evidencia.json'))}
EX={e['id']:e['extracto'] for e in REG}; EX['E-9205']=OLD['E-9205']['extracto']
ids=json.load(open('ids.json'))
def find(ctx,must=None):
    r=[i for i,x in EX.items() if ctx in x and (i.startswith('E-94') or i=='E-9205')]
    assert r,ctx; return r
def ev_of(ctxs): 
    out=[]
    for c in ctxs:
        for i in find(c):
            if i not in out: out.append(i)
    return out
LIM_B="Ensayo acelerado de banco XJTU-SY (rodamientos de bolas LDK UER204, cargas de 10 a 12 kN, 2100 a 2400 rpm) con censura simulada; minutos del banco, no vida de una chumacera de polea; no transferible en valor absoluto."
LIM_CA="Ensayo acelerado de banco (XJTU-SY/PRONOSTIA) con RUL normalizada; error adimensional, no minutos; no transferible a una chumacera de polea."
cif=[];rep=[]
def cifra(v,u,mide,cond,ctx,extra=()):
    ev=ev_of([ctx]+list(extra)); 
    assert any(v in EX[i] for i in ev),(v,ctx)
    cif.append(dict(id='C%d'%(len(cif)+1),valor=v,unidad=u,mide=mide,condiciones=cond,evidencia=ev))
CO="XJTU-SY, condicion C1 (12.0 kN, 2100 rpm), 25 % de censura aleatoria, validacion cruzada de 5 particiones, RULSurv (arXiv 2405.01614)"
cifra("14.7","min","MAE de CoxPH (tiempo a la falla)",CO,"14.7 minutes (95% CI",["CoxPH 14.7 ± 1.1"])
cifra("13.6-15.8","min","IC 95 % del MAE de CoxPH",CO,"14.7 minutes (95% CI")
cifra("12.6","min","MAE de Random Survival Forests",CO,"12.6 minutes (95% CI",["RSF 12.6 ± 0.8"])
cifra("11.8-13.4","min","IC 95 % del MAE de Random Survival Forests",CO,"12.6 minutes (95% CI")
cifra("18.5","min","MAE de LASSO (sin soporte de censura)",CO,"18.5 minutes (95% CI",["LASSO∗ 18.5 ± 1.1"])
cifra("17.4-19.6","min","IC 95 % del MAE de LASSO",CO,"18.5 minutes (95% CI")
cifra("0.7586","adimensional","CRA medio de RULSurv sobre los 5 rodamientos de C1","XJTU-SY, carga mas alta (C1), inspeccion al inicio del registro","0.7586")
for v,mide in (("2100","Velocidad de giro, C1"),("2250","Velocidad de giro, C2"),("2400","Velocidad de giro, C3")):
    cifra(v,"rpm",mide,"Banco XJTU-SY segun RULSurv, Tabla 2","Rotating speed [rpm]")
for v,mide in (("12.0","Carga radial, C1"),("11.0","Carga radial, C2"),("10.0","Carga radial, C3")):
    cifra(v,"kN",mide,"Banco XJTU-SY segun RULSurv, Tabla 2","Rotating speed [rpm]")
for v,mide in (("9.6","L10h calculada, C1"),("11.7","L10h calculada, C2"),("14.6","L10h calculada, C3")):
    cifra(v,"h",mide,"Banco XJTU-SY segun RULSurv, Tabla 2","Rotating speed [rpm]")
cifra("15","rodamientos","Total de rodamientos de bolas ensayados","XJTU-SY: 3 condiciones x 5 rodamientos (LDK UER204)","15 deep grove ball bearings")
cifra("12.82","kN","Capacidad de carga dinamica del rodamiento LDK UER204","RULSurv, Tabla 3","Load rating (dynamic) 12.82 kN")
cifra("25.6","kHz","Frecuencia de muestreo de vibracion","32,768 muestras (1.28 s) cada 1 minuto","25.6 kHz")
cifra("635","muestras","Tamano del conjunto supervisado C1","Tras promedio movil, d = 12 caracteristicas","N = 635")
cifra("1586","muestras","Tamano del conjunto supervisado C2","d = 12","N = 1586")
cifra("4930","muestras","Tamano del conjunto supervisado C3","d = 12","N = 4930")
cifra("42.6","%","Diferencia media entre el evento detectado y el fin de registro, carga alta (C1)","Detector KL, Tabla 5 y seccion 5.3","42.6%")
cifra("48.7","%","Diferencia media evento-fin de registro, carga media (C2)","Detector KL","42.6%")
cifra("56.9","%","Diferencia media evento-fin de registro, carga baja (C3)","Detector KL","42.6%")
cifra("2537","min","Mayor fin de registro (rodamiento 3_1, C3)","Tabla 5","Bearing 3_1 1014 2537")
cifra("41","min","Menor fin de registro de C2 (rodamiento 2_4)","Tabla 5","Bearing 2_4 17 41")
cifra("51","min","Fin de registro del rodamiento 1_5 (C1)","Tabla 5","Bearing 1_5 36 51")
cifra("600","s","Duracion de la ventana del detector de eventos","Algoritmo KL, seccion 4.3","T = 600 seconds")
cifra("98.8","min","MAEH de RSF, DC3 (carga baja), 25 % de censura","Tabla 6; media de 5 particiones (desviacion estandar 7.3)","RSF 98.8 ± 7.3")
cifra("31.5","min","MAE verdadero de RSF, DC2, 25 % de censura","Tabla 8; desviacion estandar 2.0","RSF 31.5 ± 2.0")
cifra("105.3","min","MAE verdadero de RSF, DC3, 25 % de censura","Tabla 8; desviacion estandar 6.2","RSF 105.3 ± 6.2")
cifra("183.7","min","MAE verdadero de CoxPH, DC3, 25 % de censura","Tabla 8; desviacion estandar 6.2","CoxPH 183.7 ± 6.2")
cifra("0.2803","RUL normalizada","MAE de CARLE entrenado en PRONOSTIA y probado en XJTU-SY con alineacion CORAL","CARLE (arXiv 2510.17846), seccion 4.6","MAE of 0.2803")
cifra("0.2919","RUL normalizada","MAE de CARLE sin alineacion de dominio","CARLE, seccion 4.6","MAE of 0.2919")
cifra("0.04087","RUL normalizada","MAE de CARLE, XJTU-SY rodamiento 3, 35 Hz y 12 kN (condicion de entrenamiento)","CARLE, Tabla 4","Bearing 3 CARLE 0.00220 0.04087")
cifra("0.15631","RUL normalizada","MAE de CARLE, XJTU-SY rodamiento 3, 40 Hz y 10 kN (condicion no vista)","CARLE, Tabla 4","Bearing 3 CARLE 0.00220 0.04087")
# ------------- replicas
def num_ok(strings,evs):
    pool=' '.join(re.sub(r'\s+',' ',EX[i]) for i in evs)
    for s in strings:
        assert s in pool,('CELDA FUERA DE EXTRACTO',s,evs)
def R(titulo,tipo,unidad,cond,rep_de,evs,lim,series=None,columnas=None,filas=None):
    d=dict(id='R%d'%(len(rep)+1),titulo=titulo,tipo=tipo,unidad=unidad,condiciones=cond,replica_de=rep_de,evidencia=evs,limites=lim)
    chk=[]
    if series is not None:
        d['series']=series
        for s in series: chk.append(s['valor']); chk+=s.get('ic',[])
    else:
        d['columnas']=columnas; d['filas']=filas
        for f in filas:
            for c in f[1:] if False else f: chk.append(c)
    # numeric tokens check: every numeric token of every cell
    toks=[]
    for c in chk:
        for t in re.findall(r'[-+]?\d[\d.,/]*\d|\d',c): toks.append(t)
    if series is not None: num_ok(chk,evs)
    else:
        pool=' '.join(re.sub(r'\s+',' ',EX[i]) for i in evs)
        for t in toks: assert t in pool,('TOKEN',t,titulo)
    rep.append(d)
R("MAE del tiempo a la falla con IC 95 %, banco XJTU-SY, C1, 25 % de censura","barras_ic","min",CO,"Resumen (abstract) de RULSurv",["E-9205"],LIM_B,
  series=[dict(etiqueta="CoxPH",valor="14.7",ic=["13.6","15.8"]),dict(etiqueta="Random Survival Forests",valor="12.6",ic=["11.8","13.4"]),dict(etiqueta="LASSO (sin censura)",valor="18.5",ic=["17.4","19.6"])])
# Tabla 2
R("Condiciones de operacion del banco XJTU-SY","tabla","",
  "15 rodamientos de bolas LDK UER204, 5 por condicion","Tabla 2 de RULSurv",["E-9401"],LIM_B,
  columnas=["Condicion","L10h [h]","Fuerza radial [kN]","Velocidad [rpm]","Rodamientos"],
  filas=[["C1","9.6","12.0","2100","Bearing 1_1 to 1_5"],["C2","11.7","11.0","2250","Bearing 2_1 to 2_5"],["C3","14.6","10.0","2400","Bearing 3_1 to 3_5"]])
R("Propiedades del rodamiento LDK UER204","tabla","","Tabla 3 de RULSurv","Tabla 3 de RULSurv",["E-9402"],LIM_B,
  columnas=["Propiedad","Valor"],filas=[["Outer race diameter","39.80 mm"],["Inner race diameter","29.30 mm"],["Bearing mean diameter","34.55 mm"],["Ball diameter","7.92 mm"],["Number of balls","8"],["Load rating (static)","6.65 kN"],["Load rating (dynamic)","12.82 kN"]])
# Tabla 5
rows5=[]
txt=EX['E-9403']+'\n'+EX['E-9404']
for ln in txt.split('\n'):
    m=re.search(r'Bearing (\d_\d) (\d+) (\d+) (-\d+) ([\d.]+)',ln)
    if m: rows5.append([('C'+m.group(1)[0]),'Bearing '+m.group(1)]+list(m.groups()[1:]))
assert len(rows5)==15
R("Tiempo de evento detectado frente al fin de registro por rodamiento","tabla","min","Detector KL de RULSurv; t_i = evento detectado, L = fin de registro","Tabla 5 de RULSurv",["E-9403","E-9404"],LIM_B,
  columnas=["Condicion","Rodamiento","t_i [min]","L [min]","Diferencia [min]","Diferencia [%]"],filas=rows5)
DSN=[('C1 (carga alta)','C1'),('C2 (carga media)','C2'),('C3 (carga baja)','C3')]
def table_rows(T,k):
    out=[]
    for r in T[k]:
        r=re.sub(r'^DC\d \(\w+\) \(N = \d+, d = 12\) ','',r); out.append(r)
    return out
ev8=["E-9423","E-9424","E-9425"]; ev6=[ids['t6'][0:2],ids['t6'][2:4],ids['t6'][4:6]]; ev7=[ids['t7'][0:1],ids['t7'][1:3],ids['t7'][3:5]]
cond_c={'C1':'12.0 kN, 2100 rpm','C2':'11.0 kN, 2250 rpm','C3':'10.0 kN, 2400 rpm'}
for k,(lab,c) in enumerate(DSN):
    rows=[]
    for r in P.T8[k]:
        m=re.match(r'^(\S+) (.*)$',r); cells=re.findall(r'[\d.]+ ± [\d.]+(?: \([-+][\d.]+\))?',m.group(2)); assert len(cells)==3
        rows.append([m.group(1)]+cells)
    R("MAE verdadero por modelo y nivel de censura, %s"%lab,"tabla","min","XJTU-SY %s (%s); media ± desviacion estandar de 5 particiones; entre parentesis variacion relativa %% frente a LASSO"%(c,cond_c[c]),"Tabla 8 de RULSurv",[ev8[k]],LIM_B,
      columnas=["Modelo","25 % de censura","50 % de censura","75 % de censura"],filas=rows)
for k,(lab,c) in enumerate(DSN):
    # barras 25 %
    ser=[]
    for r in P.T8[k]:
        m=re.match(r'^(\S+) ([\d.]+) ± ([\d.]+)',r); ser.append(dict(etiqueta=m.group(1).replace('∗',' (sin censura)'),valor=m.group(2)))
    R("MAE verdadero con 25 %% de censura, %s"%lab,"barras","min","XJTU-SY %s (%s); 25 %% de censura simulada; media de 5 particiones (desviaciones estandar en la Tabla 8, no son IC)"%(c,cond_c[c]),"Tabla 8 de RULSurv (columna 25 %)",[ev8[k]],LIM_B,series=ser)
hdr=["Modelo"]+["%s %s"%(p,m) for p in ("25 %","50 %","75 %") for m in ("MAEH","MAEM","MAEPO")]
hdr7=["Modelo"]+["%s %s"%(p,m) for p in ("25 %","50 %","75 %") for m in ("eMAEH","eMAEM","eMAEPO")]
for T,evs,h,nm,tt in ((P.T6,ev6,hdr,"Tabla 6","Error absoluto medio (MAEH, MAEM, MAEPO) bajo censura"),(P.T7,ev7,hdr7,"Tabla 7","Diferencia eMAE respecto del MAE verdadero")):
    for k,(lab,c) in enumerate(DSN):
        rows=[]
        for r in table_rows(T,k):
            m=re.match(r'^(\S+) (.*)$',r); cells=re.findall(r'[\d.]+ ± [\d.]+(?: \([-+][\d.]+\))?',m.group(2)); assert len(cells)==9,r
            rows.append([m.group(1)]+cells)
        R("%s, %s"%(tt,lab),"tabla","min","XJTU-SY %s (%s); media ± desviacion estandar de 5 particiones; entre parentesis variacion relativa %% frente a CoxPH"%(c,cond_c[c]),nm+" de RULSurv",evs[k],LIM_B,columnas=h,filas=rows)
# Tabla 9
rows=[]
for k,(lab,c) in enumerate(DSN):
    for r in P.T9[k]:
        t=r.split(' '); assert len(t)==7,r
        rows.append([c,t[0]]+t[1:])
R("Calibracion D y C (particiones calibradas de 5)","tabla","particiones de 5","XJTU-SY; calibrada si p > 0.05; C-Cal solo aplica a BNNSurv ('-' = no aplica)","Tabla 9 de RULSurv",["E-9426"],LIM_B,
  columnas=["Condicion","Modelo","25 % D-Cal","25 % C-Cal","50 % D-Cal","50 % C-Cal","75 % D-Cal","75 % C-Cal"],filas=rows)
# Tabla 10: from extracts
rows=[]
for i in ids['t10']:
    for ln in EX[i].split('\n'):
        m=re.search(r'Bearing (\d_\d) (.*)$',ln); v=m.group(2).split(' '); assert len(v)==6
        rows.append(['Bearing '+m.group(1)]+v)
R("CRA por rodamiento: RVM, DBN, PF, EKF, Hybrid y RULSurv","tabla","CRA (adimensional; 1 = exacto)","XJTU-SY; RULSurv con inspeccion en T_k = 1; los demas metodos tomados de la referencia [64] del articulo","Tabla 10 de RULSurv",ids['t10'],LIM_B,
  columnas=["Rodamiento","RVM","DBN","PF","EKF","Hybrid","RULSurv"],filas=rows)
# CARLE
def carle_rows(T,b,models):
    return [[m]+C.cleaned(T,b,m) if False else [m]+T[b][m] for m in models]
cols9=["Modelo","35Hz12kN MSE","35Hz12kN MAE","35Hz12kN Score","37.5Hz11kN MSE","37.5Hz11kN MAE","37.5Hz11kN Score","40Hz10kN MSE","40Hz10kN MAE","40Hz10kN Score"]
R("CARLE frente a CNN-LSTM, CABiLSTM y MSIDIN, rodamiento 3, XJTU-SY","tabla","RUL normalizada (MSE, MAE) y Score","Entrenado en 35 Hz y 12 kN; 37.5 Hz y 11 kN y 40 Hz y 10 kN son condiciones no vistas","Tabla 4 de CARLE (rodamiento 3)",[ids['c4'][2]],LIM_CA,
  columnas=cols9,filas=carle_rows(C.T4,'Bearing 3',['CARLE','CNN-LSTM','CABiLSTM','MSIDIN']))
R("Ablacion de CARLE, rodamiento 3, XJTU-SY","tabla","RUL normalizada (MSE, MAE) y Score","Variantes: CARL sin ensamble, CALE sin conexiones residuales, CRLE sin atencion multicabeza","Tabla 1 de CARLE (rodamiento 3)",[ev_of(["Bearing 3 CARLE 0.00220 0.04087 130.0166"])[0]],LIM_CA,
  columnas=cols9,filas=carle_rows(C.T1,'Bearing 3',['CARLE','CARL','CALE','CRLE']))
R("CARLE entre dominios (PRONOSTIA a XJTU-SY): MAE","barras","RUL normalizada","Con y sin alineacion de caracteristicas CORAL","Seccion 4.6 y Tabla 3 de CARLE (valores del texto)",[ids['c_cross']],LIM_CA,
  series=[dict(etiqueta="Con CORAL",valor="0.2803"),dict(etiqueta="Sin alinear",valor="0.2919")])
json.dump(cif,open('lector1_cifras.json','w'),ensure_ascii=False,indent=1)
json.dump(rep,open('lector1_replicas.json','w'),ensure_ascii=False,indent=1)
print(len(cif),len(rep))

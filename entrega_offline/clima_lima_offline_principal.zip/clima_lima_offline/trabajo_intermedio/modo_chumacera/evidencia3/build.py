import re, json, unicodedata, sys
sys.path.insert(0,'/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_chumacera/evidencia3')
import parse as P, carle as C
RUL=open('rul_full.txt').read()+open('q1.txt').read()
CAR=C.P1+C.Q0
def sq(t):
    t=unicodedata.normalize('NFKC',t)
    return re.sub(r'[\s​⁢]+','',t)
RULQ=sq(RUL); CARQ=sq(CAR)
def lit(ex,src):
    for piece in ex.split(' ... '):
        for line in piece.split('\n'):
            Q=(RULQ if src=='R' else CARQ)
            if sq(line) in Q: continue
            assert src=='C' and re.match(r'^(Bearing \d )?(CARLE|CARL|CALE|CRLE|CNN-LSTM|CABiLSTM|MSIDIN) ',line),('NO LITERAL',line[:120])
            for tk in line.split(' ')[1:]:
                if re.match(r'^\d',tk) or tk=='Bearing': pass
            for tk in re.sub(r'^(Bearing \d )?\S+ ','',line).split(' '):
                assert sq(tk) in Q,('TOKEN NO LITERAL',tk,line[:80])
    return ex
HOY='2026-10-27'
REF_R=dict(autores="Lillelund, C. M., Pannullo, F., Jakobsen, M. O., Morante, M., & Pedersen, C. F.",anio=2025,
 titulo="RULSurv: A probabilistic survival-based method for early censoring-aware prediction of remaining useful life in ball bearings",
 fuente="arXiv 2405.01614 (version publicada: Expert Systems with Applications, segun la cabecera del preprint)",
 url="https://arxiv.org/abs/2405.01614",pais="Dinamarca",institucion="Department of Electrical and Computer Engineering, Aarhus University")
REF_C=dict(autores="Razzaq, W., & Zhao, Y.-B.",anio=2025,
 titulo="CARLE: A Hybrid Deep-Shallow Learning Framework for Robust and Explainable RUL Estimation of Rolling Element Bearings",
 fuente="arXiv:2510.17846",url="https://arxiv.org/abs/2510.17846",pais="China",
 institucion="School of Automation, University of Science and Technology of China")
LIM_R=("Ensayo acelerado de banco (XJTU-SY: 15 rodamientos de bolas LDK UER204, 5 por condicion, cargas radiales de 10 a 12 kN, 2100 a 2400 rpm) con censura simulada al azar sobre datos completos; "
 "no es dato de campo ni de una chumacera de polea de faja; los valores absolutos (minutos) no son transferibles. Extracto con espacios y simbolos matematicos del HTML normalizados (NFKC).")
LIM_C=("Ensayo acelerado de banco (XJTU-SY y PRONOSTIA), error sobre etiquetas de RUL normalizadas, no minutos; no es dato de campo ni de una chumacera de polea. "
 "Extracto con espacios finos y duplicados de la conversion HTML eliminados. Leido hasta el inicio del Apendice A.2 (el resto no se leyo).")
ENT=[]; nid=[9401]
def add(src,ex,loc,afirma,aplica,limites_extra='',tipo='preprint'):
    ex=lit(ex,src); assert len(ex)<=800,(loc,len(ex))
    e=dict(id='E-%d'%nid[0],tipo=tipo,acceso='texto_completo',via='lector_hf_papers',fecha_acceso=HOY,
      referencia=dict(REF_R if src=='R' else REF_C),extracto=ex,localizador=loc+(' (hf://papers/2405.01614/paper.md)' if src=='R' else ' (hf://papers/2510.17846/paper.md)'),
      afirma=afirma,limites=(LIM_R if src=='R' else LIM_C)+((' '+limites_extra) if limites_extra else ''),aplica_a=aplica,revista_cuartil=None,nivel_evidencia='VERIFICADO-TEXTO')
    ENT.append(e); nid[0]+=1; return e['id']
AP_R="Pronostico de vida remanente (RUL) de rodamientos con censura; comparabilidad con la chumacera de polea: baja."
AP_C="Pronostico de RUL de rodamientos con aprendizaje profundo; comparabilidad con la chumacera de polea: baja."
ids={}
# ---- RULSurv estaticas
ids['t2']=add('R',"Operating condition L10h [h] Radial force [kN] Rotating speed [rpm] Bearing dataset\nC1 9.6 12.0 2100 Bearing 1_1 to 1_5\nC2 11.7 11.0 2250 Bearing 2_1 to 2_5\nC3 14.6 10.0 2400 Bearing 3_1 to 3_5\n ... The dataset contains measurements of 15 deep grove ball bearings of type LDK UER204 with a dynamic load rating of 12.82 kN.",
 "Seccion 4.1 y Tabla 2","Condiciones de operacion del banco XJTU-SY segun RULSurv: C1 12.0 kN y 2100 rpm (L10h 9.6), C2 11.0 kN y 2250 rpm (11.7), C3 10.0 kN y 2400 rpm (14.6); 15 rodamientos de bolas LDK UER204, 5 por condicion.",AP_R)
ids['t3']=add('R',"Outer race diameter 39.80 mm Inner race diameter 29.30 mm\nBearing mean diameter 34.55 mm Ball diameter 7.92 mm\nNumber of balls 8 Contact angle 0 °\nLoad rating (static) 6.65 kN Load rating (dynamic) 12.82 kN\n ... The sampling frequency is 25.6 kHz, and 32,768 samples (i.e., 1.28 seconds of data) are recorded every 1 minute.",
 "Seccion 4.1, Tabla 3 y texto de muestreo","Propiedades del rodamiento LDK UER204 (8 bolas, diametro medio 34.55 mm, bola 7.92 mm, capacidad dinamica 12.82 kN) y muestreo de vibracion (25.6 kHz; 32,768 muestras de 1.28 s cada 1 minuto).",AP_R)
ids['t5a']=add('R',"C1 (high) Bearing 1_1 77 122 -45 36.9\nBearing 1_2 89 160 -71 44.4\nBearing 1_3 62 157 -95 60.5\nBearing 1_4 70 121 -51 42.1\nBearing 1_5 36 51 -15 29.4\nC2 (medium) Bearing 2_1 245 490 -245 50.0\nBearing 2_2 77 160 -83 51.9\nBearing 2_3 316 532 -216 40.6\nBearing 2_4 17 41 -24 58.5\nBearing 2_5 193 338 -145 42.9",
 "Tabla 5 (condiciones C1 y C2; columnas: tiempo de evento detectado t_i [min], fin de vida L [min], diferencia [min], diferencia [%])","Tiempo de evento detectado por el algoritmo KL frente al fin de registro (L) en minutos, condiciones C1 (L entre 51 y 160 min) y C2 (L entre 41 y 532 min).",AP_R)
ids['t5b']=add('R',"C3 (low) Bearing 3_1 1014 2537 -1523 60.0\nBearing 3_2 612 2495 -1883 75.5\nBearing 3_3 206 370 -164 44.3\nBearing 3_4 514 1514 -1000 66.1\nBearing 3_5 69 113 -44 38.9\n ... The average differences between the end of the recording and the estimated time of failure are 42.6%, 48.7%, and 56.9% for the high, medium and low operating conditions, respectively. All events are detected before the end of the recording.",
 "Seccion 5.3 y Tabla 5 (condicion C3; mismas columnas)","Condicion C3: fin de registro entre 113 y 2537 min; diferencia media evento-fin de vida de 42.6 %, 48.7 % y 56.9 % para carga alta, media y baja; todos los eventos se detectan antes del fin de registro.",AP_R)
ids['cens']=add('R',"Because the XJTU-SY dataset only includes complete observations, i.e., the failure time is always known, we introduce random and independent censoring by a fixed percentage ... we selected 25%, 50%, and 75%, resulting in three censored data sets with the respective level of censoring. ... we calculate the time of censoring ... as a random number between one and the observed event time",
 "Seccion 4.5","Definicion de censura usada: censura derecha aleatoria e independiente, simulada sobre datos completos, con 25, 50 y 75 % de las muestras; el tiempo de censura es un numero aleatorio entre uno y el tiempo de evento observado.",AP_R,"La censura es sintetica: la base solo tiene fallas observadas; no representa suspensiones reales de una flota.")
ids['prep']=add('R',"For bearings under high load (C1), we use w = 2 and l = −1. For medium load (C2), we use w = 4 and l = −3. For the light load (C3), we use w = 6 and l = −5. ... This produces three supervised learning datasets, DC1 (N = 635, d = 12), DC2 (N = 1586, d = 12) and DC3 (N = 4930, d = 12), where N is the number of samples and d is the number of features.",
 "Seccion 4.4","Preprocesamiento: promedio movil (ventana w, rezago l) por condicion; tres conjuntos supervisados de N = 635, 1586 y 4930 muestras con d = 12 caracteristicas de dominio del tiempo.",AP_R)
ids['cv']=add('R',"we arrange a stratified 5-fold cross-validation procedure, ensuring that event times and censoring levels remain consistent across all folds. For each fold, we apply z-score data normalization to all features and compute the event horizon on the training set. ... If the respective model requires a validation set for early stopping, we allocate 30% of the training set for this purpose. ... For the baseline CoxPH model, we set the convergence criterion to 10−9 and a maximum of 100 iterations for all conditions.",
 "Seccion 5.1","Validacion cruzada estratificada de 5 particiones, normalizacion z-score, 30 % del entrenamiento para validacion cuando hace falta; CoxPH con criterio de convergencia 10-9 y maximo de 100 iteraciones.",AP_R)
ids['hp1']=add('R',"For the GBSA and RSF models, aligned with the three operating conditions, we set the number of estimators to {100, 200, 400}, the minimum number of samples needed to split to {5, 10, 20}, the minimum number of samples in a leaf node to {3, 5, 10} and a maximum depth of {3, 5, 10}. For the MTLR model, we use batch sizes of {32, 64, 128}, hidden sizes of {16, 32, 64}, a fixed dropout rate of 0.25",
 "Seccion 5.1 (hiperparametros, parte 1)","Hiperparametros de GBSA y RSF (estimadores 100/200/400; division minima 5/10/20; hoja minima 3/5/10; profundidad 3/5/10, uno por condicion) y de MTLR (lote 32/64/128; capas ocultas 16/32/64; abandono 0.25).",AP_R)
ids['hp2']=add('R',"a learning rate of 8 × 10−5 using the Adam optimizer ... a penalty term of 0.01, and 5000 training epochs ... For the BNNSurv model, we use batch and network sizes identical to MTLR, but with a learning rate of 0.001 using Adam and 100 epochs of training. ... In this work, we adopt the BNNSurv model using MCD inference and set a dropout rate of 25%.",
 "Seccion 5.1 y 4.6 (hiperparametros, parte 2)","MTLR: tasa de aprendizaje 8 x 10-5, penalizacion 0.01, 5000 epocas; BNNSurv: tasa 0.001, 100 epocas, abandono de Monte Carlo de 25 %.",AP_R)
ids['evp']=add('R',"the algorithm segments the observed timeseries into W window frames, each with a constant duration of T = 600 seconds. ... We recommend setting this parameter to η = 5 ... For this experiment, we set λKL = {1.5, 1.75, 2} for the high, medium, and low operating conditions, respectively.",
 "Seccion 4.3","Parametros del detector de eventos por divergencia KL: ventanas de 600 s, eta = 5, lambda_KL = 1.5, 1.75 y 2 para carga alta, media y baja.",AP_R,"Los umbrales se calibran con el fin de vida L conocido del banco; en planta los autores recomiendan usar L10.")
ids['cra']=add('R',"Moreover, our approach achieves a mean cumulative relative accuracy (CRA) of 0.7586 over 5 bearings under the highest load, which improves over several state-of-the-art baselines.",
 "Abstract (segunda parte)","CRA medio de 0.7586 sobre los 5 rodamientos de la carga mas alta (C1); complementa las cifras de MAE con IC 95 % del resumen (registro E-9205).",AP_R)
# ---- packing helper
def pack(rows,label,maxlen=790):
    chunks=[];cur=[]
    for r in rows:
        trial='\n'.join(cur+[r])
        if len(trial)>maxlen and cur: chunks.append(cur);cur=[r]
        else: cur.append(r)
    chunks.append(cur); return chunks
DS=[("DC1 (high) (N = 635, d = 12)",'C1'),("DC2 (medium) (N = 1586, d = 12)",'C2'),("DC3 (low) (N = 4930, d = 12)",'C3')]
tab_ids={}
def table_entries(key,T,tnum,cols,afirma_t,withlabel=True):
    tab_ids[key]=[]
    for k,(lab,c) in enumerate(DS):
        rows=list(T[k]); rows[0]=lab+' '+rows[0]
        for part in pack(rows,lab):
            first=part[0].split(' ')[-1] if False else None
            names=[re.match(r'^(?:DC\d \(\w+\) \(N = \d+, d = 12\) )?(\S+)',r).group(1) for r in part]
            i=add('R','\n'.join(part),"Tabla %s, condicion %s, modelos %s. Columnas: %s"%(tnum,c,', '.join(names),cols),
              "%s Condicion %s (%s), modelos %s."%(afirma_t,c,lab,', '.join(names)),AP_R)
            tab_ids[key].append(i)
table_entries('t6',P.T6,'6',"por nivel de censura 25 %, 50 %, 75 %: MAEH, MAEM, MAEPO (minutos, media +- desviacion estandar de 5 particiones; entre parentesis variacion relativa % frente a CoxPH)","Error absoluto medio (MAEH, MAEM, MAEPO) bajo censura.")
table_entries('t7',P.T7,'7',"por nivel de censura 25 %, 50 %, 75 %: eMAEH, eMAEM, eMAEPO (minutos, media +- desviacion estandar; entre parentesis variacion relativa % frente a CoxPH)","Diferencia (eMAE) entre el MAE verdadero y el MAE con censura.")
table_entries('t8',P.T8,'8',"MAE verdadero con censura 25 %, 50 %, 75 % (minutos, media +- desviacion estandar de 5 particiones; entre parentesis variacion relativa % frente a LASSO)","MAE verdadero (test sin censura) por modelo.")
# Tabla 9
rows9=[]
for k,(lab,c) in enumerate(DS):
    rr=list(P.T9[k]); rr[0]=lab+' '+rr[0]; rows9+=rr
ex9='\n'.join(rows9)
ids['t9']=add('R',ex9,"Tabla 9 (columnas por censura 25 %, 50 %, 75 %: D-Cal, C-Cal; particiones calibradas de 5)","Calibracion D (distribucion) y C (cobertura) como particiones aprobadas de 5; MTLR es el unico que pasa D-calibracion en todas las condiciones y censuras.",AP_R,"El texto del articulo dice que BNNSurv pasa 4 de 5 particiones en D-calibracion bajo carga alta; la tabla muestra 3/5 (25 %), 5/5 (50 %) y 4/5 (75 %).")
# Tabla 10
src10=RUL[RUL.index('Operating\ncondition\n \t\nBearing'):RUL.index('Table 10:Cumulative')] if 'Operating\ncondition\n \t\nBearing' in RUL else None
t10=re.findall(r'Bearing (\d_\d)\t([^\n]*)\n',RUL[RUL.index('RVM (SL)'):RUL.index('Table 10:Cumulative')])
T10={}
for b,v in t10:
    T10[b]=v.split('\t'); assert len(T10[b])==6,(b,v)
assert len(T10)==15
tab10=[]
for c,bs in (('C1 (high)',['1_%d'%i for i in range(1,6)]),('C2 (medium)',['2_%d'%i for i in range(1,6)]),('C3 (low)',['3_%d'%i for i in range(1,6)])):
    rows=['Bearing %s %s'%(b,' '.join(T10[b])) for b in bs]; rows[0]=c.split()[0]+' '+c.split()[1]+' '+rows[0]
    i=add('R','\n'.join(rows),"Tabla 10, condicion %s (columnas: RVM, DBN, PF, EKF, Hybrid, RULSurv; CRA)"%c,"CRA por rodamiento de RVM, DBN, PF, EKF, el modelo Hybrid y RULSurv en la condicion %s."%c,AP_R,"Las cifras de los otros metodos se reportan como en la referencia [64] del articulo (no reproducidas por los autores); RULSurv usa inspeccion en T_k = 1 (inicio del registro).")
    tab10.append(i)
ids['t10']=tab10
# narrativas RULSurv
ids['n1']=add('R',"Generally, we see lower MAE under high load, where the event horizon is shorter, the bearings deteriorate faster, and the event times are much more consistent ... compared to medium and low load. ... In general, the RSF model has the lowest MAE in operating conditions and in censoring levels ... However, the main trend is that censoring generally decreases predictive accuracy",
 "Seccion 5.4","Interpretacion de los autores de la Tabla 6: menor MAE con carga alta (horizonte corto, deterioro rapido); RSF con menor MAE en general; mas censura reduce la exactitud.",AP_R)
ids['n2']=add('R',"In this case, the true MAE is calculated by removing the censoring from the test set, i.e., decensoring it, and keeping the censoring in the training set. ... we trained a linear model with an ℓ1 regularization term (LASSO) on uncensored observations only ... disregarding the censored data leads to poorer predictive accuracy (i.e., MAE), when comparing LASSO with the censoring-aware models, across the majority of datasets and censoring levels.",
 "Seccion 5.4","Definicion del MAE verdadero (test sin censura, entrenamiento con censura) y del modelo de referencia LASSO (solo observaciones no censuradas); ignorar los datos censurados empeora el MAE en la mayoria de casos.",AP_R)
ids['n3']=add('R',"the bearings in the XJTU-SY dataset fail at entirely different times, even for the same operating conditions. This points to other factors – e.g., temperature, lubrication, and previous wear having a significant influence on the lifetime. ... The XJTU-SY dataset only comes with five bearings per operating condition and they have all been subjected to accelerated degradation, which substantially shortens their lifespan compared to actual industrial bearings.",
 "Secciones 5.3 y 6.4","Los autores indican que los rodamientos del mismo banco fallan en tiempos muy distintos y atribuyen la dispersion a temperatura, lubricacion y desgaste previo; reconocen que la degradacion acelerada acorta la vida frente a rodamientos industriales.",AP_R,"La atribucion a temperatura, lubricacion y desgaste previo es interpretacion de los autores, no medida en el ensayo.")
ids['n4']=add('R',"the vibration patterns observed in the XJTU-SY dataset are the result of excessive load on the bearings, preventing proper lubrication and leading to immediate surface damage and rapid degradation of the raceway. Although the proposed method performed well on the XJTU-SY dataset, which features bearings that undergo accelerated degradation, industrial settings often present a different challenge, where degradation is less apparent and wear develops gradually over time.",
 "Seccion 6.2","Limite declarado por los autores: la carga excesiva del banco impide la lubricacion adecuada y causa dano superficial rapido; en planta el desgaste es gradual y el metodo debe recalibrarse.",AP_R)
ids['n5']=add('R',"Since none of the methods studied provided their source code, it was not possible to reproduce the results, so the CRA is reported as in [64]. For the proposed method, we set the inspection time Tk = 1, i.e., at the beginning of the recording, and take a single sample the X-axis.",
 "Seccion 5.7","Los CRA de RVM, DBN, PF, EKF e Hybrid de la Tabla 10 no fueron reproducidos por los autores; RULSurv predice desde el inicio del registro (T_k = 1) con una sola muestra del eje X.",AP_R)
last_rul=nid[0]-1
# ---- CARLE
ids['c_xjtu']=add('C',"The dataset includes run-to-failure vibration data from 15 rolling element bearings obtained through accelerated degradation experiments under three distinct operational conditions: 1200 rpm (35 Hz) with a 12 kN radial load, 2250 rpm (37.5 Hz) with an 11 kN radial load, and 2400 rpm (40 Hz) with a 10 kN radial load.",
 "Seccion 4.1 (XJTU-SY)","CARLE describe XJTU-SY como 15 rodamientos en ensayo acelerado con tres condiciones: 35 Hz y 12 kN, 37.5 Hz y 11 kN, 40 Hz y 10 kN.",AP_C,"Contradiccion entre fuentes: CARLE da 1200 rpm para la condicion de 35 Hz, mientras RULSurv (E-9401 y siguientes) da 2100 rpm; 35 Hz equivale a 2100 rpm, asi que 1200 rpm parece un error de CARLE (inferencia del lector, no declarada por los autores).")
def rowstr(T,b,m): return '%s %s'%(m,' '.join(T[b][m]))
c4=[]
for b in ['Bearing %d'%i for i in range(1,6)]:
    rows=[('%s '%b if j==0 else '')+rowstr(C.T4,b,m) for j,m in enumerate(['CARLE','CNN-LSTM','CABiLSTM','MSIDIN'])]
    i=add('C','\n'.join(rows),"Tabla 4, %s (XJTU-SY; columnas 35Hz12kN, 37.5Hz11kN, 40Hz10kN: MSE, MAE, Score)"%b,"Comparacion de CARLE con CNN-LSTM, CABiLSTM y MSIDIN en el %s de XJTU-SY: MSE, MAE y Score en las tres condiciones (entrenamiento en 35Hz12kN; las otras dos son condiciones no vistas)."%b.lower(),AP_C,"MSE y MAE sobre RUL normalizada; Score segun la ecuacion 16 del articulo. El texto de la seccion 4.7 y la tabla difieren en algunos valores del rodamiento 3 (p. ej. MSE 0.03805 en texto y 0.03085 en tabla para 40Hz10kN).")
    c4.append(i)
ids['c4']=c4
c1=[]
for bs in (['Bearing 1','Bearing 2'],['Bearing 3','Bearing 4'],['Bearing 5']):
    rows=[]
    for b in bs:
        for j,m in enumerate(['CARLE','CARL','CALE','CRLE']): rows.append(('%s '%b if j==0 else '')+rowstr(C.T1,b,m))
    i=add('C','\n'.join(rows),"Tabla 1, %s (ablacion XJTU-SY; columnas 35Hz12kN, 37.5Hz11kN, 40Hz10kN: MSE, MAE, Score)"%' y '.join(bs),"Ablacion de CARLE (CARL sin ensamble, CALE sin conexiones residuales, CRLE sin atencion multicabeza) en %s de XJTU-SY."%' y '.join(x.lower() for x in bs),AP_C,"El Score de CARLE en el rodamiento 3 en 35Hz12kN es 130.0166 en la Tabla 1 y 199.6124 en la Tabla 4 (mismos MSE y MAE); el articulo no lo explica.")
    c1.append(i)
ids['c1']=c1
ids['c_cross']=add('C',"the CORAL-aligned model achieved an MSE of 0.0961, MAE of 0.2803, and Score of 297.3991, whereas the non-aligned model achieved an MSE of 0.1049, MAE of 0.2919, and Score of 321.70.",
 "Seccion 4.6 (texto; el cuerpo de la Tabla 3 no se recupero en la conversion)","Validacion entre dominios (entrenado en PRONOSTIA, probado en XJTU-SY): con alineacion CORAL MSE 0.0961, MAE 0.2803, Score 297.3991; sin alinear MSE 0.1049, MAE 0.2919, Score 321.70.",AP_C,"Los autores concluyen que la generalizacion entre bancos sigue siendo limitada (error remanente alto).")
c5=[]
for T,tn,key in ((C.T5,'5','Comparacion PRONOSTIA'),(C.T2,'2','Ablacion PRONOSTIA')):
    models=['CARLE','CNN-LSTM','CABiLSTM','MSIDIN'] if tn=='5' else ['CARLE','CARL','CALE','CRLE']
    rows=[]
    for b in ['Bearing 1','Bearing 2','Bearing 3']:
        for j,m in enumerate(models): rows.append(('%s '%b if j==0 else '')+rowstr(T,b,m))
    # pack
    for part in pack(rows,'',790):
        i=add('C','\n'.join(part),"Tabla %s (PRONOSTIA; columnas 100Hz4kN, 100Hz4.2kN, 100Hz5kN: MSE, MAE, Score), filas %s a %s"%(tn,part[0].split(' ')[0] if part[0].startswith('Bearing') else part[0].split(' ')[0],part[-1].split(' ')[0]),
          "%s: MSE, MAE y Score por modelo en rodamientos 1 a 3 de PRONOSTIA (parcial)."%key,AP_C,"Solo se registran los rodamientos 1 a 3 (rodamientos 4 a 7 de la tabla no cubiertos por el presupuesto de identificadores).")
        c5.append(i)
ids['c5']=c5
ids['c_xai']=add('C',"both the XJTU-SY and PRONOSTIA models rely heavily on ... a measure of signal variability. This finding aligns with the physics of bearing failure, where increased variability often signals instability caused by defects such as looseness, contamination, or misalignment. ... SHAP analysis ... confirms these findings",
 "Seccion 4.8","Segun LIME y SHAP aplicados por los autores, el modelo CARLE depende sobre todo de la desviacion estandar de la senal (variabilidad); los autores la relacionan con defectos como holgura, contaminacion o desalineacion.",AP_C,"La relacion con holgura, contaminacion o desalineacion es interpretacion de los autores; el ensayo no induce esas fallas por separado.")
print('ultimo id',nid[0]-1)
json.dump(ENT,open('lector1_registro.json','w'),ensure_ascii=False,indent=1)
json.dump(dict(ids,**tab_ids),open('ids.json','w'))
print(json.dumps(ids))

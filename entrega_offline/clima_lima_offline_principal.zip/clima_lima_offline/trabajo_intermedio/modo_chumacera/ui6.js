const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1500,height:950}});const e=[];p.on('pageerror',x=>e.push(String(x.stack||x).slice(0,400)));p.on('console',m=>m.type()==='error'&&e.push(m.text()));p.on('request',r=>{const u=r.url();if(!/^(file|data|blob):/.test(u)&&!/fonts\.(googleapis|gstatic)\.com/.test(u))e.push('red:'+u)});
await p.goto('file://'+process.cwd()+'/dossier_chumacera.html');
const t=await p.$$eval('#tabs button',x=>x.map(y=>y.textContent));console.log(t.join('|'));
await p.screenshot({path:'v1.png'});
for(const x of t){await p.click('#tabs button:has-text("'+x+'")');const subs=await p.$$eval('#main section.on .pill',z=>z.map(y=>y.textContent));for(const s of subs){await p.click('#main section.on .pill:has-text("'+s+'")');}}
await p.click('#tabs button:has-text("Modos y causas")');await p.click('.pill:has-text("Ishikawa")');await p.waitForTimeout(200);await p.screenshot({path:'v2.png',fullPage:true});
await p.click('.pl[data-c="0"][data-i="0"]');await p.waitForTimeout(300);await p.screenshot({path:'v3.png'});
const open1=await p.evaluate(()=>document.querySelector('#drawer').classList.contains('on'));
await p.mouse.click(100,400);await p.waitForTimeout(300);
const open2=await p.evaluate(()=>document.querySelector('#drawer').classList.contains('on'));
console.log('drawer abre/cierra afuera',open1,open2);
await p.click('.seg button[data-v="tar"]');await p.screenshot({path:'v4.png',fullPage:true});
await p.click('.pill:has-text("5 porqués")');await p.screenshot({path:'v5.png',fullPage:true});
await p.click('.pill:has-text("Qué observar")');await p.screenshot({path:'v6.png',fullPage:true});
await p.click('#tabs button:has-text("Referencias")');await p.screenshot({path:'v7.png',fullPage:true});
const links=await p.$$eval('#v-ref a.ext, #v-ref a.lnkb',a=>a.length);console.log('enlaces',links);
await p.click('#tabs button:has-text("Evidencia")');await p.screenshot({path:'v8.png',fullPage:true});
await p.click('.pill:has-text("Réplicas y cifras")');await p.screenshot({path:'v9.png',fullPage:true});
await p.click('#tabs button:has-text("Resumen")');await p.screenshot({path:'v10.png',fullPage:true});
await p.click('#tabs button:has-text("Vacíos y plan")');await p.click('.pill:has-text("Equipo de agentes")');await p.screenshot({path:'v11.png',fullPage:true});
console.log(JSON.stringify({e,er:await p.evaluate(()=>window.__errores||[])}));await b.close()})()

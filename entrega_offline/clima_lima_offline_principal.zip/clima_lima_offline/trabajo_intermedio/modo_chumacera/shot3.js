const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1500,height:950}});const e=[];p.on('pageerror',x=>e.push(String(x.stack||x).slice(0,300)));p.on('console',m=>m.type()==='error'&&e.push(m.text()));
await p.goto('file://'+process.cwd()+'/dossier_chumacera.html');
const t=await p.$$eval('#tabs button',x=>x.map(y=>y.textContent));
for(const x of t){await p.click('#tabs button:has-text("'+x+'")');const subs=await p.$$eval('#main section.on .pill',z=>z.map(y=>y.textContent));for(const s of subs){await p.click('#main section.on .pill:has-text("'+s+'")');await p.waitForTimeout(80)}}
await p.click('#tabs button:has-text("Monitoreo y ML")');
for(const [n,l] of [['m1','Curva de la bañera'],['m2','Simulador RUL'],['m3','Sensores y técnicas'],['m4','Modelos ML'],['m5','Laboratorio ML']]){await p.click('.pill:has-text("'+l+'")');await p.waitForTimeout(250);await p.screenshot({path:n+'.png'})}
await p.click('#tabs button:has-text("Modos y causas")');await p.click('.pill:has-text("Top de fallas")');await p.screenshot({path:'m6.png'});
await p.click('.pill:has-text("Recomendaciones")');await p.screenshot({path:'m7.png'});
await p.click('#tabs button:has-text("Referencias")');await p.click('.pill:has-text("Normas técnicas")');await p.screenshot({path:'m8.png'});
await p.click('#tabs button:has-text("Resumen")');await p.screenshot({path:'m9.png'});
await p.click('.idx button >> nth=3');await p.waitForTimeout(300);console.log('back visible',await p.evaluate(()=>document.querySelector('#back').classList.contains('on')));await p.screenshot({path:'m10.png'});
console.log(JSON.stringify({e,er:await p.evaluate(()=>window.__errores||[])}));await b.close()})()

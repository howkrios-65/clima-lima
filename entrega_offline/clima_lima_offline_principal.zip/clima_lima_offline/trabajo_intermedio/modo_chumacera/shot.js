const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1500,height:950}});
await p.goto('file://'+process.cwd()+'/dossier_chumacera.html');
await p.click('#tabs button:has-text("Modos y causas")');await p.click('.pill:has-text("Ishikawa")');await p.click('#ih-a');await p.waitForTimeout(300);await p.screenshot({path:'w1.png'});await p.click('#mclose');
await p.click('.pill:has-text("5 porqués")');await p.screenshot({path:'w2.png'});
await p.click('#tabs button:has-text("Referencias")');await p.screenshot({path:'w3.png'});
await p.click('#tabs button:has-text("Evidencia")');await p.screenshot({path:'w4.png'});
await p.click('.pill:has-text("Réplicas y cifras")');await p.waitForTimeout(200);await p.screenshot({path:'w5.png'});
await p.click('#tabs button:has-text("Resumen")');await p.screenshot({path:'w6.png',fullPage:false});
await b.close()})()

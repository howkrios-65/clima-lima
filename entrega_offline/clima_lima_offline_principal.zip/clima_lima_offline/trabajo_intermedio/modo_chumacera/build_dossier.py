import json, sys, datetime as dt
sys.path.insert(0, '/home/user/clima-lima/tools/reliability')
from reliability_kit import Ledger, dossier, apa
from reliability_kit import report_html as rh
BASE = '/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_chumacera/'
L = Ledger(); omit = []
import re
GEN = [(r'SKF|Timken', 'fabricante de rodamientos'), (r'OxMaint', 'proveedor de software'), (r'Reliamag', 'revista divulgativa'), (r'Transmin', 'fabricante de poleas'),
       (r'Rock Products', 'revista comercial'), (r'\bCR4\b', 'foro técnico'), (r'Tecsup', 'instituto técnico'), (r'tesis\.pucp\.edu\.pe', 'el repositorio de la universidad'), (r'PUCP', 'universidad'), (r'ReliabilityWeb', 'sitio divulgativo'),
       (r'Tranter', 'instructor'), (r'\bSAS\b', 'software estadístico')]
NEUTRAL = {'E-8527', 'E-8528', 'E-8529', 'E-8013', 'E-8015', 'E-6006', 'E-6007', 'E-6008', 'E-8521', 'E-8524', 'E-7007', 'E-8530', 'E-6009', 'E-8014'}
def neutral(o):
    if isinstance(o, str):
        for p, g in GEN: o = re.sub(p, g, o)
        return o
    if isinstance(o, list): return [neutral(x) for x in o]
    if isinstance(o, dict): return {k: neutral(v) for k, v in o.items()}
    return o
SEEN = set()
for f in ('evidencia/frente_modos', 'evidencia/frente_datos', 'evidencia/frente_monitoreo', 'evidencia/frente_normas', 'evidencia2/frente_vida', 'evidencia2/frente_monitoreo2', 'evidencia2/frente_lubricacion', 'evidencia3/lector1_registro', 'evidencia3/lector2_registro', 'evidencia4/lectorA_registro', 'evidencia4/lectorB_registro', 'evidencia4/normas_registro'):
    for e in json.load(open(BASE + f + '.json')):
        k_ = (e.get('extracto') or '').strip()
        if k_ and k_ in SEEN:
            omit.append((e['id'], 'extracto duplicado')); continue
        if k_: SEEN.add(k_)
        if e['id'] in NEUTRAL:
            e = neutral(e)
            if e.get('referencia', {}).get('url'): e['referencia']['url'] = None
            e['limites'] += ' Nombre y enlace del sitio omitidos por la política de neutralidad.'
        if e['id'] in ('E-9301', 'E-9305', 'E-9307') and e.get('referencia'): e['referencia']['anio'] = 2025
        if e['id'] in ('E-9101', 'E-9205'): e['limites'] = e['limites'].replace('Banco acelerado', 'Banco de ensayo') + ' El carácter acelerado del ensayo no está verificado en el texto leído.'
        if e['id'] in ('E-8008', 'E-8009', 'E-8011') and e.get('acceso') == 'texto_completo': e['acceso'] = 'fragmento'
        try: L.add(e)
        except Exception as ex: omit.append((e['id'], str(ex)[:80]))
print('omitidas:', omit)
def el(t, titulo, ids, limite=""): return {"tipo": t, "titulo": titulo, "evidencia": ids, "limite": limite}
V = "Sin hallazgo con respaldo leído para este modo de falla en las vías disponibles"
S = {
 "mediciones": {"elementos": [
   el("afirmacion", "Análisis de envolvente: se filtra en una resonancia, se demodula y se buscan las frecuencias BPFO, BPFI, BSF y FTF según la geometría del rodamiento", ["E-8006", "E-8008", "E-8001"], "Fuentes de introducción y revisión; datos de banco, no de poleas de faja"),
   el("afirmacion", "La kurtosis es buen indicador de defectos incipientes pero vuelve a valores normales cuando el defecto se extiende (curva no monótona). Una revisión no halló sustento teórico ni empírico de los umbrales 3 y 5 en las fuentes que consultó", ["E-8003", "E-8001"], "Revisiones narrativas; ausencia de hallazgo en sus fuentes, no prueba de inexistencia; no hay tiempos de aviso"),
   el("afirmacion", "Un rodamiento sano muestra solo frecuencias ligadas al eje, como el desbalance o la desalineación; las anomalías operacionales aparecen mínimamente en la superficie de los elementos rodantes y, con frecuencia, se energizan muchos armónicos al pasar sobre ellas", ["E-9305", "E-9307"], "Descripción cualitativa de un preprint de banco; sin amplitudes ni umbrales"),
   el("afirmacion", "Degradación en cuatro etapas espectrales (ultrasónica, resonancia natural, frecuencias de defecto y armónicos, ruido de fondo aleatorio), descritas de forma cualitativa y sin duración", ["E-8008"], "Preprint de banco")],
   "nota": "Temperatura, ultrasonido y aceite o grasa: sin curvas leídas (VACÍO parcial)."},
 "fenomenos": {"elementos": [
   el("afirmacion", "En condiciones convencionales (ISO 281:2007, edición no verificada) la causa de falla es la fatiga de contacto con descascarado subsuperficial; fuera de ellas intervienen carga excesiva, desalineación, ajustes apretados, falla de lubricante, desgaste, corrosión y fretting", ["E-6002"], "Rodamientos de bolas en ciclos muy altos; no es un estudio de transportadores"),
   el("afirmacion", "El autor atribuye el 90 % de las fallas prematuras de rodamientos de bolas de bombas a corrosión causada por contaminación, mala manipulación antes y durante la instalación, falla del lubricante o sobrecalentamiento por ajustes inadecuados en alojamientos o ejes", ["E-6004"], "Resumen de 1988; bombas, no transportadores; sin base de datos ni n"),
   el("afirmacion", "Un preprint señala que las fallas y defectos suelen inducirse por desgaste por contaminación, mala lubricación y montaje incorrecto, entre otros", ["E-9301"], "Introducción que cita otras referencias no leídas; sin cifras")],
   "nota": "Mecanismos propios de la chumacera de polea (flexión del eje, sellos en polvo, calentamiento del soporte): VACÍO."},
 "top_fallas": {"elementos": [
   el("afirmacion", "Cita secundaria: más del 50 % de las fallas de banda transportadora se deben a rodillos (idlers) en mal funcionamiento; daño de rodillos por lubricación impropia, contaminación y desalineación", ["E-6001"], "Introducción que cita a otros; rodillos, no chumaceras de poleas; sin base de datos, tamaño ni año; la fuente primaria (E-6009) no se leyó"),
   el("afirmacion", "Cita secundaria: se estima que entre 40 y 50 % de las fallas de maquinaria se atribuyen a rodamientos", ["E-9102"], "Cifra tomada de otra referencia no leída; maquinaria rotativa en general, no transportadores; sin base de datos, n ni año")],
   "nota": "Ranking de componentes y modos con base de datos, n y año: VACÍO."},
 "fmeca": {"elementos": [
   el("afirmacion", "Causas mencionadas en la literatura leída para el daño de rodamientos (insumo candidato de causas del FMECA; nivel POSIBLE por analogía, sin datos de polea): carga excesiva, desalineación, ajustes, lubricación, desgaste, corrosión, fretting, contaminación y sobrecalentamiento", ["E-6002", "E-6004"], "Respaldo: introducción de un artículo sobre fatiga de ciclos muy altos en bolas y un resumen divulgativo de bombas; efectos, severidad, ocurrencia y detección no se puntúan sin un experto del activo")],
   "nota": "Escalas S-O-D: VACÍO (requieren experto y datos del activo)."},
 "confiabilidad": {"elementos": [
   el("afirmacion", "La vida nominal básica es el valor de vida que se espera que el 90 % de una población de rodamientos alcance o supere, en condiciones de operación convencionales", ["E-6003"], "Contexto de aerogeneradores; no entrega horas para poleas"),
   el("afirmacion", "Las observaciones censuradas son frecuentes dada la rareza de las fallas en rodamientos de bolas, y pocos estudios abordan sus consecuencias", ["E-9101"], "Introducción de un preprint de banco; apoyada en referencias no leídas"),
   el("afirmacion", "Existen conjuntos abiertos de rodamientos de laboratorio: Paderborn (17 rodamientos; número de fallas y censura no verificados) y un subconjunto de 2 ensayos de UNSW; ninguno es de faja ni de campo", ["E-7001", "E-7003"], "Con 2 fallas Weibull es inviable. Solo sirven como contraste metodológico")],
   "nota": "Parámetros Weibull publicados verificados y datos de campo de chumaceras de polea: VACÍO. No se ajusta ningún Weibull."},
 "punto_optimo": {"elementos": [], "vacio": "Sin costos de falla y de reemplazo aportados por la persona, y sin fuente leída del modelo en el registro: no se calcula ninguna edad óptima."},
 "lcc": {"elementos": [], "vacio": "Sin costos aportados y sin fuente de datos de costo: no se calcula LCC."},
 "vida_util": {"elementos": [
   el("afirmacion", "La vida nominal es una vida de fatiga bajo condiciones convencionales; la edición de la norma de vida nominal no está verificada", ["E-6003"], "Contexto de aerogeneradores")],
   "nota": "Vida de diseño de poleas en fuente leída: VACÍO. Existen pistas comerciales sin abrir (E-6006, E-6007) que no respaldan cifras."},
 "ibr": {"elementos": [], "vacio": "API RP 580 y 581 solo se vieron como resúmenes de buscador (E-8513, E-8514); a criterio del equipo, no verificado, son para equipos de proceso. No se leyó ninguna fuente de IBR aplicable a la chumacera."},
 "ml": {"elementos": [
   el("afirmacion", "En un preprint, al retener la condición de 1000 rpm en el conjunto JNU la exactitud colapsa a 40,64 %, por debajo de la clase mayoritaria; la regresión logística (57,91 %) generaliza mejor que los conjuntos de árboles. La exactitud depende de la partición; no hay datos de campo", ["E-8010"], "Solo resumen de un preprint sin texto completo; el identificador arXiv debe verificarse; conjuntos de banco"),
   el("afirmacion", "Un banco público de rodamientos (CWRU) no fue diseñado para aprendizaje automático y hay que evitar resultados engañosos; en los dos bancos descritos en ese preprint (HUST y CWRU) las velocidades van de 600 a 2100 rpm", ["E-9203", "E-9204"], "Descripción de datasets en un marco propuesto; el documento no lista velocidades menores, pero la velocidad de una polea lenta de faja no consta en la fuente: comparación VACÍO"),
   el("afirmacion", "La adaptación de dominio pierde exactitud cuando las categorías de falla de origen y destino no coinciden", ["E-9209"], "Descripción de la literatura hecha por los autores de un método; resultados autoinformados en bancos"),
   el("afirmacion", "Un preprint evita la fuga temporal con una partición cronológica: entrenamiento con ventanas hasta un instante y prueba posterior", ["E-9210"], "Equipos de telecomunicaciones, no rodamientos; validación dentro de la misma flota"),
   el("afirmacion", "Existe un conjunto de datos reales de operación de aerogeneradores (89 años de datos, 44 ventanas etiquetadas de anomalías) con un puntaje que combina detección, comportamiento normal, falsas alarmas y anticipación", ["E-9201"], "Datos SCADA, no vibración ni rodamientos de poleas"),
   el("afirmacion", "En un banco de ensayo para vida remanente, todos los rodamientos se llevan a falla bajo carga muy alta para acelerar la degradación, lo que aumenta el riesgo de calentamiento local y daño incontrolado. Implicación del equipo: esa vida no representa la de una chumacera lenta de faja", ["E-8009"], "Preprint no arbitrado, leído parcialmente; las métricas de error no se citan porque no figuran en el extracto registrado"),
   el("afirmacion", "Los propios autores señalan que muchas técnicas se prueban en condiciones controladas, lo que limita su adaptabilidad", ["E-8011"], "Solo resumen e inicio")],
   "nota": "Estudios de campo con partición por activo: VACÍO."},
 "acr": {"elementos": [
   el("afirmacion", "Causas mencionadas (nivel POSIBLE, por analogía): lubricación inadecuada, contaminación y desalineación en rodillos, e instalación, ajustes y lubricación en bombas", ["E-6001", "E-6004"], "Ninguna es específica de chumaceras de polea; sin datos del activo")]},
 "troubleshooting": {"elementos": [
   el("afirmacion", "El kurtograma se basa en la curtosis espectral para detectar transitorios no estacionarios y ubicarlos en bandas de frecuencia de la señal del rodamiento", ["E-8005"], "Solo introducción")],
   "nota": "Criterios de alarma de vibración para poleas, fusión de técnicas y tiempo de aviso (P-F): VACÍO."},
 "mpd_normas": {"elementos": [], "vacio": "Ninguna norma se leyó: las 15 candidatas (ISO 281, 15243, 20816-3, 13373, 18436-2, 5048, DIN 22101, ISO 113, CEMA 7, API 580 y 581, SAE JA1011) están solo como resúmenes de buscador y se listan aparte como pistas con estado NO-VERIFICADO."},
}
cit = sorted({i for s in S.values() for e in s['elementos'] for i in e['evidencia']})
S["referencias"] = {"elementos": [el("referencia", "Fuentes realmente usadas en este dossier", cit)]}
D = {"modo_falla": "chumacera de polea de faja transportadora", "secciones": S}
S["ml"]["elementos"] += [
  el("afirmacion", "Un autoencoder convolucional con micrófono, entrenado solo con sonido normal, obtuvo AUC de 0,875 en una cepilladora industrial frente a 0,518 del bosque de aislamiento; en la máquina de rodamientos de un desafío de detección acústica el AUC fue de 65,92 % con un autoencoder simple", ["E-9515", "E-9506"], "Cepilladora y banco de laboratorio: no son una polea de faja; sin intervalos de confianza"),
  el("afirmacion", "La ampliación de datos con un modelo de difusión elevó la exactitud de una CNN en CWRU de 78,665 % a 94,033 % y la de una RNN-LSTM de 56,262 % a 88,642 %", ["E-9503"], "Clasificación en banco, no vida remanente; resultados de un solo conjunto leído")]
S["confiabilidad"]["elementos"] += [
  el("afirmacion", "Una distribución con forma de bañera baja, tiene un valle plano y vuelve a subir; la familia Weibull puede dar riesgo decreciente, constante o creciente según su parámetro de forma", ["E-9601", "E-9602", "E-9603"], "Definición estadística de un artículo ajeno al mantenimiento; no da parámetros de rodamientos ni de poleas")]
S["mpd_normas"]["nota"] = "Se identificaron 43 normas y guías solo en resúmenes de buscador (SOLO-SNIPPET): ver la pestaña Referencias, Normas técnicas. Ninguna se verificó en la página oficial."
val = dossier.validar_dossier(D, L)
print(val)
assert not val['errores'], val['errores']
json.dump(D, open(BASE + 'dossier.json', 'w'), ensure_ascii=False, indent=1)
# ---------- informe ----------
titulos = {s[0]: s[1] for s in dossier.SECCIONES}
hall = []; k = 0
for sid, s in S.items():
    if sid == 'referencias': continue
    for e in s['elementos']:
        k += 1; hall.append({"id": f"H{k}", "texto": f"[{titulos[sid]}] {e['titulo']}. Límite: {e['limite']}", "evidencia": e['evidencia']})
vac = [f"{titulos[sid]}: {x['vacio']}" for sid, x in S.items() if x.get('vacio')] + [f"{titulos[sid]}: {x['nota']}" for sid, x in S.items() if x.get('nota')]
vac += ["Ninguna fuente específica de chumaceras de poleas de faja se leyó; todo el respaldo es de rodamientos en general, bombas, rodillos o bancos de laboratorio.",
        "El conector de texto completo agotó su cuota (reinicio 2026-11-01); las consultas en español y portugués no fueron sistemáticas. Pistas por abrir: E-6005 (eje y carcasa de poleas), E-8521, E-8522 (chumaceras de transportadores, comparabilidad alta por confirmar) y E-8523.",
        "Acceso bloqueado, según la prueba de este entorno, a los repositorios de universidades, ISO, IEC, API, SAE, CEMA, DTIC y arXiv directo; Scopus, ScienceDirect, Springer, IEEE, Crossref y OpenAlex figuraban bloqueados en la medición anterior del entorno. La cobertura por país (Chile, Perú, Australia, EEUU, México, Brasil, Finlandia, Reino Unido, Suiza, Alemania, Canadá) es VACÍO.",
        "Videos, LinkedIn y Scribd: solo pistas, ninguna transcripción leída. Cuartiles de revista sin verificar."]
fr = lambda ids: [[i, L.get(i)['referencia'].get('titulo', '')[:80], L.nivel_de(i)] for i in ids]
NORMA_NUM = {'E-8501': 'ISO 281', 'E-8502': 'ISO 15243', 'E-8503': 'ISO 20816-1', 'E-8504': 'ISO 20816-3', 'E-8505': 'ISO 13373-1', 'E-8506': 'ISO 13373-2', 'E-8507': 'ISO 13373-3',
             'E-8508': 'ISO 18436-2', 'E-8509': 'ISO 5048', 'E-8510': 'DIN 22101', 'E-8511': 'ISO 113', 'E-8512': 'CEMA Standard 7', 'E-8513': 'API RP 580', 'E-8514': 'API RP 581', 'E-8515': 'SAE JA1011'}
EN_REG = {'E-8501', 'E-8503', 'E-8504', 'E-8508', 'E-8513', 'E-8514', 'E-8515'}
normas_ids = [i for i in NORMA_NUM if i in L.entradas]
filas_n = [[i, NORMA_NUM[i], "en el registro del repositorio" if i in EN_REG else "no está en el registro: se propone como NO-VERIFICADO", L.nivel_de(i)] for i in normas_ids]
datos_ok = [i for i in ('E-7001', 'E-7003') if i in L.entradas]
pistas_d = [i for i in ('E-7002', 'E-7004', 'E-7005', 'E-7006') if i in L.entradas]
tablas = [
 {"titulo": "Conjuntos abiertos de rodamientos de laboratorio verificados (ninguno de faja ni de campo)", "evidencia": datos_ok,
  "columnas": ["Id", "Fuente", "Nivel de evidencia"], "filas": fr(datos_ok),
  "nota": "Con 2 fallas o con vida de banco acelerado, un Weibull no describe la chumacera de una polea."},
 {"titulo": "Pistas de conjuntos de datos por abrir (no son evidencia)", "evidencia": [],
  "columnas": ["Id", "Fuente", "Nivel de evidencia"], "filas": fr(pistas_d),
  "nota": "Identificación del espejo de E-7002 leída; sus cifras son solo resumen de buscador. Licencias no verificadas."},
 {"titulo": "Normas candidatas (pistas; ninguna leída; edición no verificada)", "evidencia": [],
  "columnas": ["Id", "Norma", "Estado en el registro", "Nivel de evidencia"], "filas": filas_n,
  "nota": "ISO 20816-1 y 13373-1, -2 y -3 figuran entre las 15 candidatas del texto original; no citar ediciones ni cláusulas hasta abrir el texto en el publicador."},
]
cnt = L.resumen()['por_nivel']
caso = {"meta": {"titulo": "Dossier del modo de falla: chumacera de polea de faja transportadora", "activo": "Chumacera (rodamiento y soporte) de polea de faja transportadora",
                 "origen_datos": "literatura leída por el equipo; sin datos de planta", "n_fallas": 0},
        "resumen": {"kpis": [{"label": "entradas en el registro (incluye pistas)", "valor": str(len(L.entradas)), "evidencia": [cit[0]]},
                             {"label": "secciones con evidencia leída (sin contar Referencias)", "valor": f"{val['cobertura']['con_evidencia'] - 1} de 13", "evidencia": [cit[0]]},
                             {"label": "secciones VACÍO declarado", "valor": str(val['cobertura']['vacias']), "evidencia": [cit[0]]}],
                    "hallazgos": hall},
        "tablas": tablas, "vacios": vac,
        "supuestos": ["Los datos del caso de ejemplo anterior son ilustrativos y no se usaron.", "Las referencias de la pestaña Evidencia están en APA y solo incluyen lo realmente registrado. E-8008 y E-8009 son extractos del mismo preprint."],
        "preguntas": ["¿Habilita los dominios académicos y de normas en la configuración de red del entorno? Sin eso la mayoría de secciones seguirá en VACÍO.",
                      "¿Dispone de historial propio de la chumacera (fechas de instalación y reemplazo, horas, causa)? Permitiría Weibull y punto óptimo con datos reales.",
                      "¿Aporta costos de falla y de reemplazo para calcular el punto óptimo y el LCC?",
                      "¿Autoriza guardar este dossier en el historial del repositorio (si es compartido) o solo en local?"],
        "historial": [{"version": "v1", "fecha": dt.date.today().isoformat(), "cambio": "Primer dossier del modo de falla", "baseline": "VACÍO: sin datos de falla del activo"}],
        "recurrencia": {"detectada": False, "texto": "Sin casos reales en el historial."},
        "busqueda": {"frentes": ["mecanismo y modos", "monitoreo y ML", "datos de vida", "normas y fuentes formales"], "validacion_dossier": val['cobertura']}}
caso["dossier"] = {"orden": [x[0] for x in dossier.SECCIONES], "titulos": titulos, "frentes": {x[0]: x[2] for x in dossier.SECCIONES}, "secciones": S}
caso["simulador"] = True
AN = BASE + 'analisis/'
J = lambda n: json.load(open(AN + n + '.json', encoding='utf-8'))
fm = J('fmeca')
for it in fm['items']:
    t = it.get('tarea_rcm')
    if isinstance(t, dict):
        it['tarea_rcm'] = f"{t.get('tipo','')} (consecuencia: {t.get('consecuencia_a_confirmar','')}). {t.get('razonamiento','')}"
lc = J('lcc')
for e in lc['elementos']:
    if e.get('fuente_del_dato'): e['nota'] = (e.get('nota') or '') + ' Dato: ' + str(e['fuente_del_dato'])

# ---- correcciones de la verificación independiente ----
def _ev(it, add): 
    it['nota'] = ((it.get('nota') or '') + ' ' + add).strip()
A_ = J('acr'); AR = J('arbol'); VI = J('vida'); PR = J('predictivo')
for h in A_['hipotesis']:
    if h['id'] in ('H5', 'H6', 'H9'): h['nivel'] = 'SINTESIS'; _ev(h, 'Respaldo de rodamientos generales y bombas; transferido por analogía a poleas (criterio del equipo).')
for cat, lst in A_['ishikawa'].items():
    for it in lst:
        if it.get('nivel') == 'EVIDENCIA' and any(k in it['texto'] for k in ('Ajustes', 'manipulación', 'Corrosión')): it['nivel'] = 'SINTESIS'
for n in AR['nodos']:
    if n['id'] == 'N3':
        n['nivel'] = 'SINTESIS'; n['evidencia'] = ['E-6002', 'E-6001', 'E-6004']
        n['texto'] = 'Causas fuera de condiciones convencionales (marco del equipo): las que listan las fuentes leídas (carga excesiva, desalineación, ajustes apretados, falla de lubricante, desgaste, corrosión, fretting) más contaminación e instalación citadas en otras fuentes.'
    if n['id'] == 'N14': n['texto'] = 'Umbrales de kurtosis 3 y 5 sin sustento hallado, o modelos de diagnóstico que no generalizan del banco al campo.'
    if n['id'] == 'N16': _ev(n, 'Actúa como habilitador de las causas físicas, no como alternativa independiente.')
    if n['id'] == 'N0': _ev(n, 'La detección falla solo respecto de la consecuencia; si no hay programa de monitoreo, esta rama no existe.')
for it in fm['items']:
    if it['id'] == 'FM3': it['mecanismo'] = 'Corrosión del rodamiento causada por contaminación, una de las cuatro causas que el autor de un resumen sobre bombas lista (E-6004); la contaminación también aparece como causa de daño de rodillos de transportador (E-6001).'
    if it['id'] in ('FM3', 'FM4'): _ev(it, 'Que el rediseño sea más eficaz que la detección es criterio del equipo, sin fuente.')
for e in lc['elementos']:
    if e['id'] in ('C1', 'C6', 'C7', 'C8'): e['nota'] = 'Estructura estándar de costos del equipo; los ids citados solo contextualizan el modo de falla y no son premisa de este costo. Debe ser validado por un experto.'
for f in lc['formulas']:
    if 'LCC' in f['nombre'] or 'ciclo' in f['nombre'].lower(): f['nota'] = 'Antes de usarla, unificar la definición de Cf (reposición, instalación, indisponibilidad por falla) con la de C(T) y separar C7 en parada por falla y parada preventiva para no contar dos veces; el índice del VPN debe coincidir con el número de flujos.'
    f['nivel'] = 'SINTESIS'
lc['vacios'].append('Definición de Cf y de C7 pendiente de unificar entre la fórmula LCC y la de reemplazo por edad (posible doble conteo de la parada por falla).')
for h in VI['hallazgos']:
    if h['id'] in ('V3', 'V9', 'V10'): h['nivel'] = 'SINTESIS'; _ev(h, 'Mezcla hechos de las fuentes con inferencias del equipo: que L10 solo cubre fatiga y que el banco no representa una polea lenta de faja son criterios del equipo; la exactitud entre condiciones de banco no mide transferencia a campo.')
    if h['id'] == 'V2': h['texto'] += ' (ISO/TS 16281: no está en el registro de normas; NO-VERIFICADO, edición no verificada.)'
    if h['id'] == 'V5': h['texto'] = 'Las cifras de L10 de práctica comercial solo existen como pistas de buscador sin abrir (E-6006, E-6007) y no se usan como valores.'
    if h['id'] == 'V12': h['texto'] = 'Los parámetros Weibull publicados que aparecen como pistas de buscador (E-7007 a E-7009) NO se usan: no se leyeron. Un β asumido (Weibayes) solo sería admisible como supuesto explícito, rotulado y con análisis de sensibilidad, nunca como resultado.'
    if h['id'] == 'V11': h['texto'] = h['texto'].replace('la fuente primaria', 'la fuente primaria probable (sin leer)')
VI['vacios'] = [x.replace('148 aprobadas', 'las pruebas del kit') for x in VI['vacios']]
for lst in (VI.get('metodo_recomendado', []), PR.get('estrategia', []), PR.get('riesgos_de_validacion', [])):
    for it in lst: it.setdefault('nivel', 'SINTESIS')
for h in PR['hallazgos']:
    if h['id'] == 'P1': h['texto'] = h['texto'].replace('es la técnica con respaldo', 'es la técnica que las revisiones narrativas describen, sin validación en fajas,')
    if h['id'] == 'P2': h['nivel'] = 'SINTESIS'; _ev(h, 'Las ecuaciones no figuran en el extracto registrado: verificar en la fuente.')
for coll in (A_['hipotesis'], AR['nodos'], PR['hallazgos'], PR['estrategia']):
    for it in coll:
        if 'E-8010' in it.get('evidencia', []): _ev(it, 'E-8010 es un preprint 2026 de identificador no contrastado.')
OUT_ = '/home/user/clima-lima/historial/dossiers/chumacera_polea_faja/'
# ---- Ishikawa v2, 5 porqués, qué observar ----
ISH = J('ishikawa2')
A_['ishikawa'] = {c: [x for x in v if x] for c, v in ISH.items()}
A_['ishikawa_notas'] = {
 "Mano de obra": "SIN DATOS PARA ARMARLO (parcial). Datos que faltan: rol de turnos y dotación, matriz de competencias y formación, procedimiento vigente de montaje y de engrase, registros de intervenciones y análisis humano previo.",
 "Medio ambiente": "SIN DATOS PARA ARMARLO (parcial). Datos que faltan: concentración de polvo y humedad, temperatura ambiente y del soporte, tipo de material transportado, frecuencia de lavado, clima local y estado de la estructura de apoyo."}
PQ = J('porques'); OB = J('observar')
def _pref(d, pre):
    for x in d: x['id'] = pre + str(x['id'])
    return d
CIF = []; REP = []
for pre, d, f in (('1-', 'evidencia3/', 'lector1'), ('2-', 'evidencia3/', 'lector2'), ('A-', 'evidencia4/', 'lectorA'), ('B-', 'evidencia4/', 'lectorB')):
    CIF += _pref(json.load(open(BASE + d + f + '_cifras.json')), pre); REP += _pref(json.load(open(BASE + d + f + '_replicas.json')), pre)
caso["normas"] = json.load(open(BASE + 'evidencia4/normas_tabla.json')); caso["normas_sin_datos"] = json.load(open(BASE + 'evidencia4/normas_sin_datos.json'))
caso["sensores"] = json.load(open(BASE + 'evidencia4/lectorA_tecnicas.json')); caso["topfallas"] = json.load(open(BASE + 'evidencia4/lectorB_topfallas.json'))
caso["ml_lab"] = json.load(open(OUT_ + 'ml_lab.json'))
# ---- correcciones del verificador (ronda v6) ----
def _nota(it, t): it['nota'] = ((it.get('nota') or '') + ' ' + t).strip()
IS = A_['ishikawa']
IS['Medición'][1]['nivel'] = 'SINTESIS'; _nota(IS['Medición'][1], 'La frase sobre RMS y velocidad no figura en el extracto de E-8001; es razonamiento del equipo.')
IS['Medición'][2]['texto'] = 'Umbrales de kurtosis 3 y 5 sin sustento hallado; los umbrales fijos describen pocos tipos de falla.'
IS['Medición'][2]['verificar'] = (IS['Medición'][2].get('verificar') or '') + ' Verificar si los umbrales del activo se calibraron con fallas propias.'
IS['Medición'][3]['evidencia'] = list(dict.fromkeys(IS['Medición'][3]['evidencia'] + ['E-9450', 'E-9451']))
IS['Medición'][4]['texto'] = 'Modelos y reglas de diagnóstico validados en banco, sin evidencia de que generalicen al campo.'
IS['Medición'][5]['evidencia'] = ['E-8003', 'E-9479']
IS['Mano de obra'][1]['mecanismo'] = IS['Mano de obra'][1]['mecanismo'].replace('es la dificultad principal', 'es un reto')
IS['Medio ambiente'][2]['mecanismo'] = IS['Medio ambiente'][2]['mecanismo'].replace('el sobrecalentamiento está ligado a falla de lubricante y ajustes (E-6004)', 'E-6004 liga el sobrecalentamiento a los ajustes; la falla de lubricante es otra causa de su lista')
IS['Material'][2]['nivel'] = 'SINTESIS'; _nota(IS['Material'][2], 'La relación de la vida con (C/F) elevado a un exponente y el descascarado subsuperficial están en el resumen de la fuente, no en el extracto; criterio del equipo.')
_nota(IS['Máquina'][1], 'Solo es respaldo directo que la desalineación figura como causa de daño; carga localizada y desgaste asimétrico son razonamiento del equipo.')
for c in ('Máquina',):
    for k in (3, 4, 5): _nota(IS[c][k], 'Los términos del mecanismo van más allá del texto de la fuente; son razonamiento del equipo.')
_nota(IS['Método'][1], 'Términos del mecanismo: razonamiento del equipo.')
_nota(IS['Método'][2], 'La vida modificada por viscosidad y contaminación consta en el resumen de E-6003, no en su extracto.')
quit_ = {'Mano de obra': 3, 'Método': 3, 'Medio ambiente': 3}
for c, k in quit_.items():
    it = IS[c].pop(k)
    A_['ishikawa_notas'][c] = (A_['ishikawa_notas'].get(c, '') + (' ' if c in A_['ishikawa_notas'] else '') + 'SIN DATOS PARA ARMARLO (sin fuente): ' + it['texto'].replace(' CONDICION A VERIFICAR.', '') + ' Queda como pregunta a verificar en terreno.').strip()
# porqués: todo condicional y de síntesis
REESC = {('H1', 0): '¿Por qué podría fallar la chumacera? Si esta hipótesis se cumpliera, el rodamiento acumularía daño en las superficies de rodadura hasta perder el giro.',
         ('H2', 0): '¿Por qué podría fallar la chumacera? Si esta hipótesis se cumpliera, sería por corrosión y desgaste de pistas y elementos rodantes asociados a contaminación.',
         ('H3', 0): '¿Por qué podría fallar la chumacera? Si esta hipótesis se cumpliera, la carga se concentraría en parte de las pistas con desgaste y daño asimétrico, consecuencia de la desalineación.'}
for h in PQ:
    for i, x in enumerate(h['cadena']):
        x['nivel'] = 'SINTESIS'
        if (h['causa'], i) in REESC: x['porque'] = REESC[(h['causa'], i)]
        elif i:
            t = x['porque']; q = t.find('?')
            x['porque'] = t[:q + 1] + ' Posible respuesta, a verificar con registros del activo: ' + t[q + 1:].strip()
# qué observar
for k in (1, 3, 10, 13, 14, 17, 21, 25, 29):
    it = OB['items'][k - 1]; it['nivel'] = 'SINTESIS'
    if k == 1: it['evidencia'] = [e for e in it['evidencia'] if e != 'E-8003'] or ['E-6004']
    if k == 25: it['sintoma'] = 'RMS o velocidad global poco sensibles al defecto incipiente'
    it['medicion'] = it['medicion'] + ' (síntoma y medición: razonamiento del equipo; las fuentes citadas respaldan el contexto, no el síntoma exacto)'
# ---- clases de causa (física, humana, latente) ----
CLN = {'N2': 'fisica', 'N4': 'fisica', 'N5': 'fisica', 'N6': 'fisica', 'N7': 'fisica', 'N8': 'fisica', 'N10': 'fisica', 'N9': 'humana', 'N13': 'humana', 'N14': 'humana',
       'N15': 'latente', 'N16': 'latente', 'N17': 'latente', 'N18': 'latente', 'N3': 'fisica', 'N1': 'fisica', 'N12': 'humana'}
for n in AR['nodos']:
    if n['id'] in CLN: n['clase'] = CLN[n['id']]
CLH = {'H1': 'fisica', 'H2': 'fisica', 'H3': 'fisica', 'H4': 'fisica', 'H5': 'fisica', 'H6': 'humana', 'H7': 'fisica', 'H8': 'humana', 'H9': 'fisica'}
for h in A_['hipotesis']: h['clase'] = CLH.get(h['id'], '')
ABS = json.load(open(BASE + 'abstract.json', encoding='utf-8'))
for p_ in ABS['parrafos']:
    for i_ in re.findall(r'E-\d{4}', p_):
        assert i_ in L.entradas and L.puede_afirmar([i_], 'VERIFICADO-ABSTRACT')[0], 'abstract cita fuente insuficiente: ' + i_
caso["abstract"] = ABS
caso["cifras"] = CIF; caso["replicas"] = REP
RI = {r['id']: r for r in REP}; CI = {c['id']: c for c in CIF}
for i in ('1-R19', '1-R20'): RI[i]['limites'] += ' El Score de 35 Hz y 12 kN difiere entre las Tablas 1 y 4 con los mismos MSE y MAE; el artículo no lo explica.'
RI['1-R17']['condiciones'] = RI['1-R17']['condiciones'].replace('calibrada si p > 0.05; ', '') ; RI['1-R17']['limites'] += ' El texto del artículo da 4 de 5 particiones en BNNSurv C1 con 25 % de censura y la tabla 3 de 5; se usa la tabla. El umbral de la prueba no consta en el extracto.'
RI['2-R-15']['condiciones'] = RI['2-R-15']['condiciones'].replace('; intervalo de 1 hora', '') + '; el contexto de 5 pasos es un supuesto del lector, no consta que las cifras correspondan a él'; RI['2-R-15']['limites'] = RI['2-R-15']['limites'].replace('ARMARLAS', 'ARMARLO')
CI['2-CF-34']['condiciones'] = CI['2-CF-34']['condiciones'].replace(', intervalo de 1 hora', '')
CI['2-CF-20']['mide'] = 'AURC de la fusión por divergencia de Jensen-Shannon de los modelos de tiempo y frecuencia, frente a la entropía de un modelo (partición estándar)'
RI['2-R-03']['limites'] += ' La asignación de las filas de totales a carga y severidad sigue el orden del texto; es interpretación del lector.'
RI['2-R-13']['limites'] += ' El paper cuenta condiciones por carga, velocidad y sensor, distinto de las tres condiciones de carga y velocidad de otro paper.'

caso["trazabilidad"] = json.load(open(BASE + 'trazabilidad.json', encoding='utf-8'))
caso["ranking"] = []
caso["analisis"] = {"porques": {"items": PQ}, "observar": OB, "fmeca": fm, "arbol": AR, "acr": A_, "lcc": lc, "vida": VI, "predictivo": PR, "herramientas": True}
# ---- correcciones del verificador, ronda 2 ----
def _item(lst, ini):
    for x in lst:
        if x['texto'].startswith(ini): return x
rms = _item(A_['ishikawa']['Medición'], 'RMS y espectro'); rms['nivel'] = 'SINTESIS'; _nota(rms, 'La frase sobre RMS y velocidad no está en el extracto de E-8001 (solo en su resumen): razonamiento del equipo.')
ku = _item(A_['ishikawa']['Medición'], 'Kurtosis usada'); ku['nivel'] = 'EVIDENCIA'; ku['nota'] = (ku.get('nota') or '').replace('La frase sobre RMS y velocidad no figura en el extracto de E-8001; es razonamiento del equipo.', '').strip()
for x in A_['ishikawa']['Medición']:
    if x['texto'].startswith('Vigilancia sin integrar'): x['mecanismo'] = x['mecanismo'].replace('(E-9209)', '(E-9479)')
for cat in A_['ishikawa'].values():
    for x in cat:
        if 'E-8003' in x['evidencia'] and 'combin' in (x.get('mecanismo') or '').lower(): _nota(x, 'La combinación de técnicas consta en el resumen de E-8003, no en su extracto.')
for h in A_['hipotesis']:
    if h['id'] == 'H7': h['nivel'] = 'SINTESIS'; _nota(h, 'La causa de falla en condiciones convencionales consta en el resumen de E-6002, no en su extracto.')
for m in fm['items']:
    if m['id'] == 'FM1': m['nivel'] = 'SINTESIS'
for h in PR['hallazgos']:
    if h['id'] == 'P1': h['nivel'] = 'SINTESIS'; _nota(h, 'La sensibilidad por etapa consta en resúmenes de las fuentes, no en sus extractos.')
for h in PQ:
    if h['causa'] == 'H1':
        _nota(h['cadena'][3], 'La dependencia de la vida modificada con la viscosidad y la contaminación consta en el resumen de E-6003, no en su extracto.') if False else None
        h['cadena'][3]['porque'] += ' (La dependencia de la vida modificada con la viscosidad y la contaminación consta en el resumen de E-6003, no en su extracto.)'
ABS = caso['abstract']; P_ = ABS['parrafos']
P_[1] = P_[1].replace('por lo que no cubre esas causas', 'por lo que, a juicio del equipo, no cubre esas causas').replace('una cadena de cinco porqués que va de la causa física', 'tres cadenas de cinco porqués (H1 a H3) que van de la causa física')
P_[3] = ('Pronóstico y aprendizaje automático. En un banco de ensayo de 15 rodamientos {E-9401}, en la condición de carga más alta y con 25 % de censura aleatoria, un método de supervivencia alcanzó un error absoluto medio de 14,7 minutos (IC 95 %: 13,6 a 15,8) con CoxPH y de 12,6 minutos (11,8 a 13,4) con bosques de supervivencia aleatorios, frente a 18,5 minutos con LASSO {E-9205}; otro marco de aprendizaje profundo obtuvo un MAE normalizado de 0,2803 con alineación de dominio y de 0,2919 sin ella {E-9444}. En diagnóstico, una misma red alcanzó 97,58 % de exactitud balanceada con pliegues por carga {E-9456} y 64,38 % con pliegues por severidad {E-9457}: el resultado depende de cómo se parte el conjunto. Con acústica, un autoencoder convolucional con transformador logró AUC de 0,875 en una cepilladora industrial {E-9515}; en la máquina «bearing» de un desafío de laboratorio, un autoencoder simple obtuvo AUC de 65,92 % en el dominio fuente y de 55,75 % en el objetivo {E-9506}, valores que no son comparables entre sí. La ampliación de datos con difusión elevó la exactitud de una CNN en CWRU de 78,665 % a 94,033 % {E-9503}.')
P_[4] = P_[4].replace('Todos los resultados provienen de bancos de ensayo o de otros activos, con velocidades desde 600 rpm {E-9451}; ninguno mide una polea lenta de faja', 'Los resultados leídos provienen de bancos de ensayo o de otros activos; los bancos de vibración leídos listan velocidades desde 600 rpm {E-9451} y ninguno de los documentos leídos mide una polea lenta de faja')
ABS['parrafos'] = P_
for t in caso['sensores']:
    if t['tecnica_o_sensor'].startswith('Sobremuestreo'): t['resultado_publicado'] = 'Segun el analisis de 86 envios de 23 equipos, las claves fueron el remuestreo, las muestras sinteticas y los modelos preentrenados grandes; el texto no da la magnitud por tecnica'
    if t['tecnica_o_sensor'].startswith('CNN ligera'): t['condiciones'] = 'CWRU; datos enviados por puerto serie desde un PC, sin sensor inalambrico en el ensayo'
for n_ in caso['normas']:
    n_['relaciones'] = ('Segun el resumen de buscador: ' + n_['relaciones']) if n_.get('relaciones') else ''
    n_['edicion_vista'] = str(n_.get('edicion_vista') or 'no verificada') + ' (segun resumen; edicion no verificada)'
    if n_['codigo'] == 'ISO 13379-1': n_['relaciones'] = 'Contradice el registro del repositorio (edicion 2012); sin resolver hasta abrir la pagina oficial'
caso["evaluar"] = [["Ultrasonido y alta frecuencia (sobre 10 kHz)", "Un preprint (no contrastado en su fuente primaria) describe que el defecto excita frecuencias propias desde unos 10 kHz, y la etapa ultrasónica solo se ve con sensores especializados", ["E-9307", "E-8008"], "Alcance y costo del sensor en una polea lenta; umbrales"],
 ["Envolvente y kurtosis", "La envolvente tiene alta sensibilidad (E-8001); la kurtosis detecta el defecto incipiente pero vuelve a lo normal al extenderse el daño", ["E-8003", "E-8001"], "Umbrales sustentados; calibración con fallas del propio activo"],
 ["Aceite o grasa, temperatura y termografía combinados con vibración", "Combinar técnicas mejora la confianza del diagnóstico (según el resumen de E-8003, no su extracto)", ["E-8003"], "Qué etapa detecta cada una y con qué anticipación"],
 ["Sensado acústico por micrófono", "Un autoencoder convolucional con micrófono logró AUC de 0,875 en una cepilladora industrial; en la máquina «bearing» de un desafío de laboratorio, un autoencoder simple dio AUC de 65,92 % (fuente) y 55,75 % (objetivo): no son comparables", ["E-9515", "E-9506"], "Ningún resultado en poleas de faja ni en ambiente minero"],
 ["Diagnóstico embebido en microcontrolador", "Una CNN pequeña corrió en un microcontrolador con exactitud publicada en CWRU; en el ensayo no hubo sensor inalámbrico (los datos llegaron desde un PC)", ["E-9520"], "Alcance, consumo y vida de batería en terreno"]]
caso["ml_lab"]["refs"] = ["E-9506", "E-9515", "E-9503"]
caso["topfallas_pendiente"] = "Fuentes con conteos por componente de transportadores que aún no se pudieron leer (están como pistas): una revisión de fallas de rodamientos de rodillos, una tesis sobre rodamientos de rodillos locos en minas y un conjunto de datos de averías de transportadores en minas subterráneas. Con acceso a esos textos se armaría el top real."
caso = json.loads(json.dumps(caso, ensure_ascii=False).replace('VACÍO', 'SIN DATOS PARA ARMARLO'))
r = rh.construir_informe(caso, L, BASE + 'dossier_chumacera.html')
import shutil
OUT = '/home/user/clima-lima/historial/dossiers/chumacera_polea_faja/'
shutil.copy(BASE + 'dossier_chumacera.html', OUT + 'informe.html'); shutil.copy(BASE + 'dossier.json', OUT + 'dossier.json'); L.to_json(OUT + 'evidencia.json')
json.dump({"modo_falla": D['modo_falla'], "fecha": dt.date.today().isoformat(), "version": 1, "secciones_con_evidencia": val['cobertura']['con_evidencia'], "secciones_vacias": val['vacios'],
           "entradas_registro": len(L.entradas), "nota": "Pistas SOLO-SNIPPET no respaldan afirmaciones; ver evidencia.json"}, open(OUT + 'meta.json', 'w'), ensure_ascii=False, indent=1)
print(len(r['ajustes']), [ (a['donde'],a['tipo']) for a in r['ajustes']][:20], len(L.entradas), cnt)
for a in r['ajustes']:
    if a['tipo'] == 'eliminado_por_gate': print(json.dumps(a, ensure_ascii=False)[:400])
for n, o in (('acr', A_), ('porques', PQ), ('observar', OB)): json.dump(o, open(OUT + 'analisis/' + n + '.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
json.dump(CIF, open(OUT + 'cifras.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1); json.dump(REP, open(OUT + 'replicas.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

json.dump(ABS, open(OUT + 'abstract.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
for n_, o_ in (('normas_tabla', caso['normas']), ('lectorA_tecnicas', caso['sensores']), ('lectorB_topfallas', caso['topfallas'])): json.dump(o_, open(OUT + n_ + '.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

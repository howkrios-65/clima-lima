import json,sys
f,out=sys.argv[1],sys.argv[2]
d=json.load(open(f))
open(out,'w').write(d['results'][0]['result']['content'])

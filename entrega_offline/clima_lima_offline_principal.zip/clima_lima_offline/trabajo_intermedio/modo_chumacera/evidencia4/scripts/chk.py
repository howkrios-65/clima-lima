import json,re,sys
S="/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_chumacera/evidencia4/"
E=json.load(open(S+"lectorA_registro.json"))
src={"2312.07981":S+"txt/2312.07981.txt","2401.01172":S+"txt/2401.01172.txt"}
import glob
cord=open(S+"txt/2609.39784_b.txt").read()
def norm(t):
    t=re.sub(r"<sup>.*?</sup>","",t); t=re.sub(r"\[\[?(\d+)\]?\]\([^)]*\)","",t); t=re.sub(r"\[(\d+)\]","",t)
    t=re.sub(r"\\\s|\\mathrm|\{|\}|\*|_","",t)
    return re.sub(r"\s+"," ",t)
for e in E:
    k=e["referencia"]["url"].split("/")[-1]
    if k in src: txt=norm(open(src[k]).read())
    elif k=="2609.39784": txt=norm(cord)
    else: continue
    for frag in re.split(r" \.\.\. ",e["extracto"]):
        f=norm(frag)
        if f not in txt: print("NO LITERAL",e["id"],f[:90])

import json,sys
D='/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_chumacera/evidencia4/'
sys.path.insert(0,'/home/user/clima-lima/tools/reliability')
from reliability_kit.evidence import Ledger
from reliability_kit.replicas import validar_cifras, validar_replicas
RAW=json.load(open(D+'paderborn_raw.json'))
reg=json.load(open(D+'lectorB_registro.json'))
L=Ledger()
for e in reg:
    e=dict(e)
    if e.get('extracto') is None: e.pop('extracto'); e.pop('localizador')
    L.add(e)
TAB={'B01':'E-9605','B02':'E-9605','B03':'E-9605','B04':'E-9605','B05':'E-9606','B06':'E-9606','B07':'E-9606','B08':'E-9606','B09':'E-9607','B10':'E-9607','B11':'E-9607','B12':'E-9607','B13':'E-9608','B14':'E-9608','B15':'E-9608','B16':'E-9609','B17':'E-9609'}
CP="Paderborn LDM, ensayo de banco de rodamientos de bolas con carga y velocidad variables (conjunto run-to-failure publicado; reempaquetado en Hugging Face por Nounours777)"
LP="Ensayo de banco; el README no declara criterio de fin de ensayo ni hora de falla; el intervalo entre marcas de tiempo es el del log de condiciones, no una vida declarada; no es dato de campo ni de una chumacera de polea."
cif=[]
n=[0]
def c(valor,unidad,mide,cond,ev):
    n[0]+=1; cif.append(dict(id='C%d'%n[0],valor=valor,unidad=unidad,mide=mide,condiciones=cond,evidencia=ev))
c("1","","valor de kappa de la familia APGW que corresponde a la distribucion Weibull","Articulo estadistico de metodos (Burke, Jones y Noufaily, arXiv:1901.03212), Tabla 2; sin datos de ningun equipo",["E-9603"])
for b,(r,a,z) in RAW.items():
    c(str(r),"registros","registros de vibracion (campo records de meta.json) del rodamiento "+b,CP+"; rodamiento "+b,[TAB[b]])
c("128000","Hz","frecuencia de muestreo de la vibracion, rodamiento B01",CP+"; meta.json de B01",["E-9611"])
c("204800","muestras","muestras por registro de vibracion, rodamiento B01",CP+"; meta.json de B01",["E-9611"])
c("10.0","g/V","factor de conversion g por voltio (g_per_volt), rodamiento B01",CP+"; meta.json de B01",["E-9611"])
c("2500","N","carga estatica fijada (setStatLoad) en la primera fila del log de B01 y B06",CP+"; primera fila del log de condiciones",["E-9610"])
c("750","rpm","velocidad fijada (setSpeed) en la primera fila del log de B01 y B06",CP+"; primera fila del log de condiciones",["E-9610"])
UC="Subconjunto en Hugging Face (alidi) del conjunto run-to-failure de UNSW; ensayos 1 y 3, aceleracion horizontal; defecto sembrado tipo BPFO"
c("80","ejemplos","ejemplos de la particion test1",UC,["E-9612"])
c("79","ejemplos","ejemplos de la particion test3",UC,["E-9612"])
c("51200","Hz","frecuencia de muestreo",UC,["E-9612"])
c("6.0","Hz","velocidad de giro",UC,["E-9612"])
c("10.5","kN","carga radial",UC,["E-9612"])
c("1.0","mm","tamano de defecto (uno de los dos ensayos)",UC,["E-9612"])
c("0.5","mm","tamano de defecto (el otro ensayo)",UC,["E-9612"])
CC="Conjunto de diagnostico de motor asincrono de 2.2 kW con fallas sembradas (Chen et al., arXiv:2601.02278); no contiene tiempos hasta la falla"
c("282","corridas","corridas de ensayo del conjunto",CC,["E-9613"])
c("90","s","duracion de cada corrida",CC,["E-9613"])
c("24","tipos","tipos de falla del conjunto",CC,["E-9613"])
c("12.8","kHz","frecuencia de muestreo",CC,["E-9613"])
c("2.2","kW","potencia del motor del banco",CC,["E-9613"])
LB="Articulo estadistico de metodos (Burke, Jones y Noufaily, arXiv:1901.03212) con ejemplos medicos; solo respalda definiciones de forma del riesgo, no tasas de falla de ningun equipo."
rep=[]
rep.append(dict(id='R1',titulo="Formas de la funcion de riesgo de la familia PGW segun gamma y kappa*gamma (definicion de la forma down-then-up o banera)",tipo='tabla',unidad='',condiciones="Familia de distribuciones PGW; definicion matematica, no datos de campo",replica_de="Tabla 1 de Burke, Jones y Noufaily (arXiv:1901.03212)",evidencia=['E-9602'],limites=LB,
 columnas=["gamma","kappa*gamma","forma del riesgo"],filas=[["1","1","constant"],["<=1","<=1","decreasing"],["<=1",">=1","down-then-up"],[">=1","<=1","up-then-down"],[">=1",">=1","increasing"]]))
rep.append(dict(id='R2',titulo="Casos kappa=1 (Weibull) y kappa=2 de la familia APGW: formas posibles del riesgo",tipo='tabla',unidad='',condiciones="Familia APGW; definicion matematica, no datos de campo",replica_de="Tabla 2 de Burke, Jones y Noufaily (arXiv:1901.03212), filas kappa=1 y kappa=2",evidencia=['E-9603'],limites=LB,
 columnas=["kappa","H_A","formas del riesgo","distribucion"],filas=[["1","t^gamma","decreasing, constant, increasing","Weibull (gamma = 1 da la exponencial)"],["2","t^gamma + (1/6) t^(2 gamma)","decreasing, down-then-up, increasing","gamma = 1 da riesgo lineal"]]))
filas=[[b,str(r),a,z] for b,(r,a,z) in RAW.items()]
rep.append(dict(id='R3',titulo="Paderborn LDM: registros de vibracion y primera y ultima marca de tiempo del log, por rodamiento (B01 a B17)",tipo='tabla',unidad='',condiciones=CP,replica_de="Campo records de meta.json y filas primera y ultima de <B>_operatingConditions.csv de cada rodamiento",evidencia=['E-9605','E-9606','E-9607','E-9608','E-9609'],limites=LP,
 columnas=["Rodamiento","Registros","Primera marca de tiempo","Ultima marca de tiempo"],filas=filas))
rep.append(dict(id='R4',titulo="Paderborn LDM: registros de vibracion por rodamiento",tipo='barras',unidad='registros',condiciones=CP,replica_de="Campo records de meta.json de cada rodamiento",evidencia=['E-9605','E-9606','E-9607','E-9608','E-9609'],limites=LP+" El numero de registros es un indicador del tamano del ensayo, no de la vida.",
 series=[dict(etiqueta=b,valor=str(r)) for b,(r,a,z) in RAW.items()]))
rep.append(dict(id='R5',titulo="Paderborn LDM: primera fila del log de condiciones (carga dinamica y estatica fijadas, velocidad fijada)",tipo='tabla',unidad='N y rpm',condiciones=CP+"; solo 5 de 17 rodamientos leidos",replica_de="Primera fila de <B>_operatingConditions.csv de B01, B06, B11, B14 y B17",evidencia=['E-9610'],limites=LP+" Es una muestra del log, no la condicion nominal.",
 columnas=["Rodamiento","setDynLoad [N]","setStatLoad [N]","setSpeed [rpm]"],filas=[["B01","0","2500","750"],["B06","0","2500","750"],["B11","1000","3000","2477.66842367181"],["B14","801.589453034805","2500","2700"],["B17","1500","2405.79193707562","2700"]]))
rep.append(dict(id='R6',titulo="Subconjunto UNSW run-to-failure (alidi): ejemplos por particion",tipo='tabla',unidad='ejemplos',condiciones=UC,replica_de="Tarjeta del conjunto, bloque dataset_info",evidencia=['E-9612'],limites="Subconjunto de terceros con defecto sembrado; la tarjeta no da tiempos de falla; no es dato de campo.",
 columnas=["Particion","Ejemplos"],filas=[["test1","80"],["test3","79"]]))
okc,errc=validar_cifras(cif,L); okr,errr=validar_replicas(rep,L)
print('cifras',len(okc),'/',len(cif),'errores',errc); print('replicas',len(okr),'/',len(rep),'errores',errr)
assert not errc and not errr
json.dump(cif,open(D+'lectorB_cifras.json','w'),ensure_ascii=False,indent=1)
json.dump(rep,open(D+'lectorB_replicas.json','w'),ensure_ascii=False,indent=1)
top=[
 dict(componente_o_modo="Dano de rodamiento (entre las fallas comunes de un motor asincrono)",medida="enumeracion cualitativa, sin frecuencia ni porcentaje",valor="Common failures include inter-turn short circuits in stator windings, broken rotor bars, bearing damage, air gap eccentricity, and rotor imbalance",base_de_datos_o_poblacion="Motor asincrono trifasico en empresas industriales y mineras (texto de contexto de un articulo de datos, sin muestra)",anio=2026,condiciones="Afirmacion de la introduccion del articulo, con referencias de los autores; no es un conteo",limites="Cualitativa; sin conteos ni porcentajes; motor de 2.2 kW, no chumacera de polea de faja",evidencia=["E-9614"]),
 dict(componente_o_modo="Dano simultaneo de pista interna y pista externa de rodamiento",medida="frecuencia relativa (cualitativa)",valor="rare",base_de_datos_o_poblacion="'field data' no identificado por los autores",anio=2026,condiciones="Frase de justificacion del diseno experimental; los autores no dan fuente ni cifra en esa frase",limites="Cualitativa y sin cita en la frase; no es un conteo; texto en ingles 'rare'",evidencia=["E-9614"]),
]
json.dump(top,open(D+'lectorB_topfallas.json','w'),ensure_ascii=False,indent=1)

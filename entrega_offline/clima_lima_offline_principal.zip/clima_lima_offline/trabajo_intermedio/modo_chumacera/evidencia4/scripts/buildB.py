import re, json, sys, unicodedata
D='/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_chumacera/evidencia4/'
sys.path.insert(0,'/home/user/clima-lima/tools/reliability')
HOY='2026-10-27'
def norm(t):
    t=re.sub(r'<[^>]+>',' ',t)
    t=unicodedata.normalize('NFKC',t)
    return re.sub(r'\s+',' ',t).strip()
BUR=open(D+'txt/1901.03212_p1.txt').read()
BURN=norm(BUR)
def bsl(a,b,incl=True):
    i=BURN.index(a); j=BURN.index(b,i)+(len(b) if incl else 0); return BURN[i:j]
# ---------- Burke
def ref_burke():
    return dict(autores="Burke, K., Jones, M. C., & Noufaily, A.",anio=2019,
      titulo="A flexible parametric modelling framework for survival analysis",fuente="arXiv:1901.03212",
      url="https://arxiv.org/abs/1901.03212",pais="Irlanda y Reino Unido",
      institucion="University of Limerick; Open University; University of Warwick")
LIMB=("Articulo estadistico de metodos (distribuciones de supervivencia); sus ejemplos son de medicina (cancer de pulmon, melanoma), no de rodamientos ni de transportadores; "
 "solo respalda definiciones de forma de la funcion de riesgo, no tasas de falla de ningun equipo. Leido hasta el byte 77205 del preprint (resto no leido). Extracto: etiquetas HTML/LaTeX aplanadas y espacios normalizados (NFKC).")
ENT=[]
def add(id_,tipo,acceso,via,ref,ex,loc,afirma,lim,aplica):
    assert len(ex)<=800,(id_,len(ex))
    ENT.append(dict(id=id_,tipo=tipo,acceso=acceso,via=via,fecha_acceso=HOY,referencia=ref,extracto=ex,localizador=loc,afirma=afirma,limites=lim,aplica_a=aplica,revista_cuartil=None,nivel_evidencia=None))
p1=bsl("namely, constant, increasing, decreasing, up-then-down or down-then-up (and no others), are available","are available")
p2=bsl("Here, we use the simple descriptive terms","which also encompass monotone hazards.")
add('E-9601','preprint','fragmento','lector_hf_papers',ref_burke(),p1+" ... "+p2,
 "Seccion 1 (Introduccion), hf://papers/1901.03212/paper.md",
 "Definicion textual de la forma de banera: 'bathtub-shaped' es 'down-then-up' (riesgo que baja y luego sube) con un valle plano; las formas de riesgo disponibles en la familia son constante, creciente, decreciente, up-then-down y down-then-up.",
 LIMB,"Curva de la banera (definicion de forma del riesgo); sin datos de rodamientos; comparabilidad con la chumacera: no aplica (definicion).")
t1=bsl("Table 1: Shapes of PGW hazard functions","not both equal at once")
t1=t1.replace('\\gamma','gamma').replace('\\kappa','kappa').replace('\\leq','<=').replace('\\geq','>=') if False else t1
add('E-9602','preprint','fragmento','lector_hf_papers',ref_burke(),t1,
 "Seccion 2, Tabla 1 (formas de la funcion de riesgo PGW)",
 "Tabla 1: la forma del riesgo depende de gamma y kappa*gamma: constante si ambos son 1; decreciente si ambos <=1; down-then-up si gamma<=1 y kappa*gamma>=1; up-then-down si gamma>=1 y kappa*gamma<=1; creciente si ambos >=1 (convencion: no ambos iguales a la vez).",
 LIMB,"Curva de la banera: condicion matematica de la forma down-then-up; no son datos de campo.")
T2=bsl("Table 2: Special and limiting cases of APGW distributions","</table>".replace('</table>','others encompassed'))
rows=re.findall(r'<tr>(.*?)</tr>',BUR[BUR.index('Table 2: Special'):BUR.index('Table 2: Special')+2500],re.S)
rn=[norm(r) for r in rows]
hdr=rn[0]; r1=[r for r in rn if 'Weibull' in r and 't^\\gamma' in r and r.startswith('1 ')][0]
r2=[r for r in rn if r.startswith('2 ')][0]
assert all(x in BURN for x in (hdr,r1,r2))
add('E-9603','preprint','fragmento','lector_hf_papers',ref_burke(),hdr+" ... "+r1+" ... "+r2,
 "Seccion 2, Tabla 2 (casos especiales de la familia APGW)",
 "Tabla 2: con kappa=1 la familia es la Weibull y su riesgo puede ser decreciente, constante o creciente (gamma=1 da la exponencial); con kappa=2 el riesgo puede ser decreciente, down-then-up o creciente.",
 LIMB,"Weibull: forma del riesgo segun gamma (el parametro de forma de la Weibull); sin valores numericos de ningun equipo.")
# ---------- Paderborn
README=("Repack of *Run-to-failure data set of ball bearings subjected to time-varying load and speed conditions* (O. K. Aimiyekagbon, Paderborn University, Zenodo, DOI [10.5281/zenodo.10805042](https://doi.org/10.5281/zenodo.10805042), CC BY 4.0). Nothing is resampled or filtered: each accelerometer value is the integer `code` of the data logger's grid ... "
 "Bearings: B01, B02, B03, B04, B05, B06, B07, B08, B09, B10, B11, B12, B13, B14, B15, B16, B17 ... Row k of `vibration.npy` is row k of `<B>_operatingConditions.csv`.")
REF_P=dict(autores="Nounours777 (reempaquetado); Aimiyekagbon, O. K. (datos originales)",anio=2026,
 titulo="Paderborn LDM run-to-failure bearings, lossless int16 repack (Run-to-failure data set of ball bearings subjected to time-varying load and speed conditions)",
 fuente="Hugging Face Datasets, hf://datasets/Nounours777/Paderborn-bearing; datos originales en Zenodo DOI 10.5281/zenodo.10805042, licencia CC BY 4.0, segun el README del reempaquetado",
 url="https://huggingface.co/datasets/Nounours777/Paderborn-bearing",pais="Alemania",institucion="Paderborn University (datos originales, segun el README)")
LIMP=("Repositorio de datos de terceros (reempaquetado de un usuario de Hugging Face; el anio 2026 es el de creacion del repo, el de los datos originales no figura en el README). "
 "Ensayo de banco de rodamientos de bolas con carga y velocidad variables; el README no declara el criterio de fin de ensayo ni la hora de falla, y los registros de ensayo (.pdf) no se pudieron leer; "
 "no es dato de campo ni de una chumacera de polea.")
add('E-9604','repositorio','texto_completo','lector_hf_datasets',REF_P,README,"README.md del repositorio (hf://datasets/Nounours777/Paderborn-bearing/README.md)",
 "Identificacion de un conjunto publico de rodamientos de bolas ensayados hasta la falla con carga y velocidad variables: 17 rodamientos B01 a B17, datos originales de Paderborn University (Zenodo, CC BY 4.0), con vibracion y archivos de condiciones de operacion.",
 LIMP,"Conjunto publico de vida de rodamientos (run-to-failure); comparabilidad con la chumacera: baja (banco, rodamiento de bolas).")
RAW={ # primeras/ultimas marcas y registros transcritos de las lecturas
 'B01':(377,'19-Oct-2021 08:46:54','19-Oct-2021 10:59:32'),
 'B02':(1116,'25-Oct-2021 08:59:35','25-Oct-2021 14:36:36'),
 'B03':(614,'05-Nov-2021 15:10:43','05-Nov-2021 18:23:40'),
 'B04':(1114,'17-Nov-2021 12:45:09','17-Nov-2021 18:26:58'),
 'B05':(572,'22-Nov-2021 11:06:32','22-Nov-2021 13:59:49'),
 'B06':(12965,'25-Nov-2021 09:53:21','28-Nov-2021 04:20:35'),
 'B07':(6393,'31-Jan-2022 12:36:13','03-Feb-2022 08:14:36'),
 'B08':(1827,'04-Feb-2022 14:43:30','05-Feb-2022 01:20:58'),
 'B09':(1813,'18-Feb-2022 15:51:44','19-Feb-2022 03:59:44'),
 'B10':(3224,'04-Mar-2022 14:21:51','05-Mar-2022 09:21:36'),
 'B11':(1953,'17-Aug-2022 09:26:32','17-Aug-2022 18:17:01'),
 'B12':(767,'24-Aug-2022 08:49:23','24-Aug-2022 11:22:23'),
 'B13':(19417,'09-Sep-2022 12:21:13','12-Sep-2022 05:56:26'),
 'B14':(12317,'23-Sep-2022 12:43:11','30-Sep-2022 20:29:52'),
 'B15':(22567,'14-Oct-2022 14:53:44','17-Oct-2022 18:54:10'),
 'B16':(5891,'28-Oct-2022 09:53:01','29-Oct-2022 05:35:43'),
 'B17':(2733,'04-Nov-2022 09:02:50','05-Nov-2022 01:28:31')}
json.dump(RAW,open(D+'paderborn_raw.json','w'),indent=1)
LIMP2=LIMP+(" Extracto compuesto con tres fragmentos por rodamiento: campo \"records\" de meta.json, primera y ultima marca de tiempo de la columna Time de <B>_operatingConditions.csv; "
 "la diferencia entre marcas es el intervalo registrado en ese log, no una vida declarada por la fuente.")
def tabla(ids_b,eid,loc):
    parts=[]
    for b in ids_b:
        r,a,z=RAW[b]; parts.append(f'"bearing": "{b}", "records": {r} ... {a} ... {z}')
    ex=" ... ".join(parts)
    add(eid,'repositorio','fragmento','lector_hf_datasets',dict(REF_P),ex,loc,
     "Para cada rodamiento listado: numero de registros de vibracion (campo records) y primera y ultima marca de tiempo del log de condiciones de operacion del ensayo.",LIMP2,
     "Tabla de tiempos del ensayo de rodamientos B01 a B17 (conjunto run-to-failure); comparabilidad con la chumacera: baja.")
tabla(['B01','B02','B03','B04'],'E-9605',"data/B01..B04: meta.json (campo records), primera y ultima fila de <B>_operatingConditions.csv")
tabla(['B05','B06','B07','B08'],'E-9606',"data/B05..B08: meta.json (campo records), primera y ultima fila de <B>_operatingConditions.csv")
tabla(['B09','B10','B11','B12'],'E-9607',"data/B09..B12: meta.json (campo records), primera y ultima fila de <B>_operatingConditions.csv")
tabla(['B13','B14','B15'],'E-9608',"data/B13..B15: meta.json (campo records), primera y ultima fila de <B>_operatingConditions.csv")
tabla(['B16','B17'],'E-9609',"data/B16..B17: meta.json (campo records), primera y ultima fila de <B>_operatingConditions.csv")
# especificacion B01 + condiciones primeras filas
HDR="Time,setDynLoad / N,peak_dynLoad / N,setStatLoad / N,meanAbs_statLoad / N,setSpeed / rpm,meanAbs_speed / rpm"
FIRST={'B01':'19-Oct-2021 08:46:54,0,10.3965994159118,2500,2544.03715298923,750,753.116231066696',
 'B06':'25-Nov-2021 09:53:21,0,70.7608130532961,2500,2481.17486318798,750,750.639690467653',
 'B11':'17-Aug-2022 09:26:32,1000,1025.219682,3000,3003.28071162316,2477.66842367181,2480.38539988227',
 'B14':'23-Sep-2022 12:43:11,801.589453034805,803.74339775,2500,2567.72816912792,2700,2697.67236161405',
 'B17':'04-Nov-2022 09:02:50,1500,1506.35781675,2405.79193707562,2459.27725923936,2700,2697.73077609031'}
def pipe(s): return s.replace(',',' | ')
ex=pipe(HDR)+" ... "+" ... ".join(f"{b}: "+pipe(r) for b,r in FIRST.items())
add('E-9610','repositorio','fragmento','lector_hf_datasets',dict(REF_P),ex,
 "Cabecera y primera fila de data/B01, B06, B11, B14 y B17 /<B>_operatingConditions.csv",
 "Primera fila del log de condiciones: B01 y B06 con carga dinamica fijada 0, carga estatica fijada 2500 y velocidad fijada 750 rpm; B11 con 1000, 3000 y 2477.66842367181 rpm; B14 con 801.589453034805, 2500 y 2700 rpm; B17 con 1500, 2405.79193707562 y 2700 rpm (las cargas estan en N).",
 LIMP+" Solo se leyo la primera fila de 5 de los 17 rodamientos; es una muestra del log, no la condicion nominal declarada. En el extracto las comas del CSV se sustituyen por ' | ' para legibilidad.",
 "Condiciones de carga y velocidad del ensayo de Paderborn; comparabilidad con la chumacera: baja.")
M01='"bearing": "B01", "records": 377, "samples_per_record": 204800, "sampling_rate_hz": 128000, "channels": [ "accHorizRear_A", "accHorizFrontal_C" ], "dtype": "int16" ... "g_per_volt": 10.0'
add('E-9611','repositorio','fragmento','lector_hf_datasets',dict(REF_P),M01,"data/B01/meta.json (primeros 1500 bytes)",
 "Especificacion de la adquisicion en B01: 377 registros de 204800 muestras cada uno a 128000 Hz, dos canales de aceleracion (accHorizRear_A y accHorizFrontal_C), factor de 10.0 g por voltio.",
 LIMP+" Solo se leyo meta.json de B01 en detalle; los demas rodamientos pueden diferir en registros.",
 "Adquisicion de vibracion del conjunto Paderborn; comparabilidad con la chumacera: baja.")
# ---------- UNSW (alidi)
REF_U=dict(autores="alidi (subconjunto en Hugging Face); datos originales de UNSW",anio=2025,
 titulo="Bearing run-to-failure dataset of UNSW - test 1 & 3 - horizontal acceleration",
 fuente="Hugging Face Datasets, hf://datasets/alidi/bearing-run2failure-unsw; fuente original DOI 10.17632/h4df4mgrfb.3, licencia CC BY 4.0, segun la tarjeta del conjunto",
 url="https://huggingface.co/datasets/alidi/bearing-run2failure-unsw",pais="Australia",institucion="UNSW (datos originales, segun la tarjeta)")
exU=("This dataset is a subset of the bearing run-to-failure dataset of UNSW : - Horizontal acceleration (accH) measurements - Test 1 and Test 3 from the original dataset - Sampling frequency: 51200 Hz "
 "- Each sample contains signal data, signal length, sampling frequency, speed (6.0 Hz), radial load (10.5 kN), defect size (1.0 and 0.5 mm), and defect type (BPFO) ... "
 "- name: test1 num_bytes: 393220800 num_examples: 80 - name: test3 num_bytes: 388305540 num_examples: 79")
add('E-9612','repositorio','texto_completo','lector_hf_datasets',REF_U,exU,"README.md de hf://datasets/alidi/bearing-run2failure-unsw",
 "Tarjeta de un subconjunto del conjunto run-to-failure de UNSW: ensayos 1 y 3, aceleracion horizontal a 51200 Hz, velocidad 6.0 Hz, carga radial 10.5 kN, defectos de 1.0 y 0.5 mm tipo BPFO; 80 ejemplos en test1 y 79 en test3.",
 "Subconjunto de terceros con defecto sembrado (BPFO) y dos ensayos; la tarjeta no da tiempos de falla ni numero de rodamientos; anio 2025 tomado de la fecha de creacion del repo en el buscador de Hugging Face; no es dato de campo.",
 "Conjunto publico de vida de rodamientos (UNSW); comparabilidad con la chumacera: baja.")
# ---------- Chen et al. (Data in Brief, arXiv 2601.02278)
REF_C=dict(autores="Chen, S., Liu, Z., Li, C., Zou, D., He, X., & Zhou, D.",anio=2026,
 titulo="Multi-mode Fault Diagnosis Datasets of Three-phase Asynchronous Motor Under Variable Working Conditions",
 fuente="arXiv:2601.02278 (articulo de datos; el texto declara los requisitos de Data in Brief); datos en Mendeley Data DOI 10.17632/6s3dggj9mw.1",
 url="https://arxiv.org/abs/2601.02278",pais="China",institucion="MCC5 Group Shanghai; Tsinghua University; Zhengzhou University; Southeast University")
exC1=("Eight-channel synchronous vibration-current-torque-keyphase data were recorded from a 2.2 kW three-phase induction motor under variable speed/load profiles at 12.8 kHz. "
 "Controlled single and compound faults were physically introduced and measured over 282 runs (90 s each), saved as CSV files. ... "
 "The dataset includes 24 fault types, encompassing healthy state, rotor imbalance, bending, broken bars, stator winding short circuits (low and high severity), voltage unbalance, static and dynamic eccentricity, bearing faults (inner, outer, ball, and compound), and mechanical-electrical compound faults.")
LIMC=("Conjunto de DIAGNOSTICO con fallas sembradas en laboratorio (rodamientos SKF 6205 con muescas laser): no contiene tiempos hasta la falla ni historial de vida; motor de 2.2 kW, no una chumacera de polea. "
 "Extracto con el guion largo de 'vibration-current-torque-keyphase' normalizado a guion simple.")
add('E-9613','preprint','texto_completo','lector_hf_papers',REF_C,exC1,"Tabla de especificaciones y seccion Data description, hf://papers/2601.02278/paper.md",
 "Conjunto publico de motor asincrono de 2.2 kW con 24 tipos de falla (entre ellos fallas de rodamiento de pista interna, externa y bola) en 282 corridas de 90 s a 12.8 kHz.",
 LIMC,"Conjunto publico de diagnostico (no de vida); util solo para descartar su uso como datos de tiempo hasta la falla.")
exC2=("Common failures include inter-turn short circuits in stator windings, broken rotor bars, bearing damage, air gap eccentricity, and rotor imbalance ... "
 "The dataset is limited to single-point raceway faults, as field data indicates simultaneous damage to both inner and outer races is rare. ... "
 "the dataset is limited to single-point bearing faults and does not include distributed or progressive fault patterns that may occur in long-term service.")
add('E-9614','preprint','texto_completo','lector_hf_papers',REF_C,exC2,"Seccion Background, seccion Experimental design y seccion Limitations, hf://papers/2601.02278/paper.md",
 "Los autores enumeran el dano de rodamiento entre las fallas comunes de un motor asincrono (sin dar frecuencias) y afirman, sin cifras ni cita en esa frase, que el dano simultaneo de pista interna y externa es raro en datos de campo; declaran que su conjunto no incluye fallas progresivas de servicio prolongado.",
 LIMC+" Las frases sobre fallas comunes y sobre dano simultaneo son cualitativas, sin conteos ni porcentajes.",
 "Modos de falla de rodamientos de motor (cualitativo); comparabilidad con la chumacera: baja.")
# ---------- pistas no leidas
def lead(id_,tipo,ref,afirma,lim,aplica):
    ENT.append(dict(id=id_,tipo=tipo,acceso='solo_referencia',via='websearch',fecha_acceso=HOY,referencia=ref,extracto='',localizador='',afirma=afirma,limites=lim,aplica_a=aplica,revista_cuartil=None,nivel_evidencia=None))
NOLEI="No se leyo su texto: el acceso a ese servidor fue rechazado por la politica de red (CONNECT 403); autores y anio provienen del resumen del buscador y no estan verificados. No respalda ninguna cifra."
lead('E-9620','paper',dict(autores="Vasic, Stojanovic y Blagojevic (segun el buscador)",anio=2020,titulo="Failure analysis of idler roller bearings in belt conveyors",fuente="Engineering Failure Analysis (segun el buscador)",url="https://dspace.unic.kg.ac.rs/items/31cae612-9d62-4441-b5e4-b2f4ea074010",pais="Serbia",institucion="Universidad de Kragujevac (repositorio SCIDAR)"),
 "Pista: existe un estudio con titulo 'Failure analysis of idler roller bearings in belt conveyors' en el repositorio de la Universidad de Kragujevac; el buscador lo describe como analisis de cien rodamientos de rodillos locos extraidos de un transportador.",NOLEI,"Estadistica de dano de rodamientos de rodillos de transportador (b); leer despues.")
lead('E-9621','tesis',dict(autores="O'Farrell, P.",anio=2022,titulo="Premature failure analysis of single row deep groove bearings from idler rollers used on mine sites",fuente="Tesis, Macquarie University (figshare)",url="https://figshare.mq.edu.au/articles/thesis/Premature_failure_analysis_of_single_row_deep_groove_bearings_from_idler_rollers_used_on_mine_sites/19428020",pais="Australia",institucion="Macquarie University"),
 "Pista: tesis de Macquarie University sobre falla prematura de rodamientos de bolas de ranura profunda de rodillos locos en minas; el titulo y el autor constan en el enlace, el anio es la fecha de publicacion del registro.",NOLEI,"Fallas de rodamientos de rodillos de faja en mina (b); leer despues.")
lead('E-9622','repositorio',dict(autores="Sur, A. (segun el buscador)",anio=2025,titulo="Predictive Reliability Modelling and Maintenance Optimization of Belt Conveyor Systems in Underground Coal Mines",fuente="Mendeley Data (segun el buscador)",url="https://data.mendeley.com/datasets/r4769kdjbg/1",pais=None,institucion=None),
 "Pista: conjunto de datos en Mendeley Data con registros de averias de transportadores de banda de minas de carbon subterraneas (tiempo antes de la falla, frecuencia, duracion de reparacion) segun el buscador.",NOLEI,"Estadistica y Weibull de componentes de transportador (a, b); leer primero.")
lead('E-9623','paper',dict(autores="Hart (segun el buscador)",anio=2024,titulo="Independent competing risks in common shape-parameter Weibull systems, with application to rolling bearing service life",fuente="IEEE Transactions on Reliability (segun el buscador); manuscrito en Strathprints",url="https://strathprints.strath.ac.uk/90545",pais="Reino Unido",institucion="University of Strathclyde (repositorio Strathprints)"),
 "Pista: articulo con ese titulo en el repositorio de la Universidad de Strathclyde sobre vida de servicio de rodamientos con Weibull de forma comun a partir de datos de falla de campo, segun el buscador.",NOLEI,"Weibull de rodamientos con datos de campo (a); leer primero.")
lead('E-9624','otro',dict(autores="No identificado",anio=None,titulo="Failure rate, bathtub curve and reliability of components and systems",fuente="Registro invenio.itam.cas.cz (segun el buscador)",url="https://invenio.itam.cas.cz/record/3525",pais="Republica Checa",institucion=None),
 "Pista: registro del Instituto de Mecanica Teorica y Aplicada (Republica Checa) con ese titulo sobre curva de la banera; autor y anio no verificados.",NOLEI,"Curva de la banera en componentes (a).")
lead('E-9625','otro',dict(autores="Nelson (1990) segun la documentacion de SAS",anio=1990,titulo="Datos de vida de rodamientos con carga acelerada reproducidos en la documentacion de SAS (procedimiento RELIABILITY)",fuente="support.sas.com, ejemplo del procedimiento RELIABILITY",url="https://support.sas.com/documentation/cdl/en/qcug/65562/HTML/default/qcug_reliability_gettingstarted06.htm",pais=None,institucion=None),
 "Pista: la documentacion de SAS reproduce una tabla de vida de rodamientos ensayados a cuatro cargas, citada a Nelson (1990, p. 305).",NOLEI,"Tabla publica de tiempos hasta la falla de rodamientos (d); leer primero.")

# ---------- escribir y validar
from reliability_kit.evidence import Ledger, validar_entrada
import datetime as dt
L=Ledger()
for e in ENT:
    e2=dict(e)
    if not e2['extracto']: e2.pop('extracto'); e2.pop('localizador')
    L.add(e2)
reg=[L.entradas[e['id']] for e in ENT]
for r in reg:
    if 'extracto' not in r: r['extracto']=None; r['localizador']=None
json.dump(reg,open(D+'lectorB_registro.json','w'),ensure_ascii=False,indent=1)
print('Ledger OK',len(reg),'avisos',{k:v for k,v in L.avisos.items() if v})
json.dump(RAW,open(D+'paderborn_raw.json','w'))

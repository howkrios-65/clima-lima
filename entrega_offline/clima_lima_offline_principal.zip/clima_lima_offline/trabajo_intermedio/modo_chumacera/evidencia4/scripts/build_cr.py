import json
S="/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_chumacera/evidencia4/"
C=[];n=[0]
def c(valor,unidad,mide,cond,ev):
    n[0]+=1; C.append(dict(id="C%d"%n[0],valor=valor,unidad=unidad,mide=mide,condiciones=cond,evidencia=ev))
TS="Banco CWRU, 50 muestras por condicion de entrenamiento, epoca 100, TSDM arXiv 2312.07981"
for v,m in [("78.665","exactitud de CNN sin ampliar datos"),("94.033","exactitud de CNN ampliada con TSDM"),("56.262","exactitud de RNN-LSTM sin ampliar datos"),("88.642","exactitud de RNN-LSTM ampliada con TSDM"),("60.557","exactitud del transformador TST sin ampliar datos"),("72.192","exactitud del transformador TST ampliada con TSDM"),("32.380","mejora maxima de exactitud con TSDM (RNN-LSTM, primer banco)")]:
    c(v,"%",m,TS,["E-9503"] if v!="32.380" else ["E-9501","E-9503"])
c("18.355","%","mejora maxima de exactitud con TSDM (segundo banco; tabla no leida)","Resumen de arXiv 2312.07981; el conjunto no se leyo en el cuerpo",["E-9501"])
c("9.298","%","mejora maxima de exactitud con TSDM (tercer banco; tabla no leida)","Resumen de arXiv 2312.07981; el conjunto no se leyo en el cuerpo",["E-9501"])
c("50","muestras","muestras de entrenamiento por condicion (pocos datos de falla)","CWRU, arXiv 2312.07981",["E-9502"])
c("200","muestras","total de muestras de entrenamiento pequeno","CWRU, 4 condiciones, arXiv 2312.07981",["E-9502"])
c("1200","muestras","total de muestras de prueba","CWRU, 4 condiciones x 300, arXiv 2312.07981",["E-9502"])
DC="DCASE 2023 T2, maquina 'bearing' de laboratorio, entrenamiento solo con sonido normal, promedio de 5 corridas, arXiv 2305.07828"
for v,m in [("65.92","AUC fuente, autoencoder simple"),("55.75","AUC objetivo, autoencoder simple"),("50.42","pAUC, autoencoder simple"),("65.16","AUC fuente, Mahalanobis selectivo"),("55.28","AUC objetivo, Mahalanobis selectivo"),("51.37","pAUC, Mahalanobis selectivo")]:
    c(v,"%",m,DC,["E-9506"])
c("990","clips","clips normales del dominio fuente para entrenar (por seccion)","DCASE 2023 T2, arXiv 2305.07828",["E-9505"])
c("10","clips","clips normales del dominio objetivo para entrenar (por seccion)","DCASE 2023 T2, arXiv 2305.07828",["E-9505"])
c("86","envios","envios recibidos en el reto","DCASE 2023 T2, arXiv 2305.07828",["E-9504"])
c("23","equipos","equipos participantes","DCASE 2023 T2, arXiv 2305.07828",["E-9504"])
FS="DCASE2022 T2 con requisito first-shot, maquina 'bearing', promedio de 3 semillas, arXiv 2303.00455"
for v,m,e in [("0.7479","AUC fuente del autoencoder base","E-9510"),("0.5621","AUC objetivo del autoencoder base","E-9510"),("0.7195","AUC fuente de Mahalanobis selectivo","E-9510"),("0.6280","AUC objetivo de Mahalanobis selectivo","E-9510"),("0.7190","AUC fuente del primer lugar DCASE2022 (conjunto masivo)","E-9510"),("0.6827","AUC objetivo del primer lugar DCASE2022 (conjunto masivo)","E-9510")]:
    c(v,"adimensional",m,FS,[e])
PL="Sonido de cepilladora de madera en aserradero real, microfono ICP 377A21 a 20 kHz, evaluacion con 105 anomalias, arXiv 2501.04819"
for v,m in [("0.518","AUC del bosque de aislamiento"),("0.520","AUC de la linea base DCASE"),("0.683","AUC de la SVM de una clase"),("0.798","AUC del CAE publicado"),("0.846","AUC del Skip-CAE"),("0.875","AUC del Skip-CAE-Transformer")]:
    c(v,"adimensional",m,PL,["E-9515"])
c("105","anomalias","anomalias en el conjunto de evaluacion","cepilladora real, arXiv 2501.04819",["E-9514"])
c("7,562","grabaciones","grabaciones de 10 s del conjunto","cepilladora real, arXiv 2501.04819",["E-9514"])
c("20","kHz","frecuencia de muestreo del microfono","cepilladora real, arXiv 2501.04819",["E-9514"])
c("21","h","duracion aproximada de las grabaciones","cepilladora real, arXiv 2501.04819",["E-9514"])
TF="Banco KAIST, velocidad variable, 5-fold, TF-CNN arXiv 2401.01172"
c("2.2","puntos porcentuales","ventaja en exactitud de TF-CNN frente a PIResNet con senal limpia",TF,["E-9518"])
c("1.6","puntos porcentuales","ventaja en exactitud de TF-CNN frente a T-CNN con senal limpia",TF,["E-9518"])
c("19","%","ventaja aproximada frente a PIResNet con ruido de -5 dB",TF,["E-9518"])
c("15","%","ventaja aproximada frente a T-CNN con ruido de -5 dB",TF,["E-9518"])
c("1,200","RPM","velocidad por debajo de la cual se concentran los errores de clasificacion",TF,["E-9519"])
c("70","%","parte de los errores de la clase normal que ocurren por debajo de 1,200 RPM",TF,["E-9519"])
c("25.6","kHz","frecuencia de muestreo de los acelerometros del banco",TF,["E-9517"])
c("35","min","datos por clase del banco",TF,["E-9517"])
ST="Banco CWRU, 10 clases, 1797 rpm, 12 kHz, CNN en STM32H743VI, arXiv 2304.09100"
c("98.9","%","exactitud de la CNN optimizada",ST,["E-9520"])
c("19","ms","tiempo de cada diagnostico en el microcontrolador",ST,["E-9520"])
c("142.15","KB","memoria FLASH del modelo",ST,["E-9521"])
c("11.32","KB","memoria RAM del modelo",ST,["E-9521"])
c("36,390","parametros","parametros del modelo optimizado",ST,["E-9521"])
c("0.9890","adimensional","mejor exactitud del modelo optimizado",ST,["E-9521"])
CO="Preentrenamiento CORD con XJTU-SY y otros conjuntos, RUL normalizada, arXiv 2609.39784"
c("13.9","%","reduccion del error de ciclo de vida (5 vecinos) en rodamientos por preentrenamiento multidominio",CO,["E-9523"])
c(".1463","RMSE (RUL normalizada)","RMSE desde cero en turbofan U11 con 10 % de etiquetas (no es rodamiento)","N-CMAPSS U11, 400 actualizaciones, arXiv 2609.39784",["E-9525"])
c(".1374","RMSE (RUL normalizada)","RMSE preentrenado en turbofan U11 con 10 % de etiquetas (no es rodamiento)","N-CMAPSS U11, 400 actualizaciones, arXiv 2609.39784",["E-9525"])
json.dump(C,open(S+"lectorA_cifras.json","w"),ensure_ascii=False,indent=1)

R=[]
LIMB="Datos de banco o de laboratorio; no es una chumacera de polea de faja ni dato de campo; valores no transferibles."
R.append(dict(id="R1",titulo="Exactitud de prueba en CWRU con pocos datos: modelos con y sin ampliacion de datos",tipo="tabla",unidad="%",condiciones=TS,replica_de="Tabla 6 de arXiv 2312.07981",evidencia=["E-9503"],limites=LIMB+" Clasificacion de falla, no RUL.",
 columnas=["Modelo","Sin ampliar","VQ-VAE","TimeGAN","Diffwave","TSDM","Mejora TSDM"],
 filas=[["CNN","78.665","79.708","80.375","81.330","94.033","15.368"],["RNN-LSTM","56.262","60.917","60.967","62.683","88.642","32.380"],["TST","60.557","61.038","61.333","62.330","72.192","11.635"]]))
R.append(dict(id="R2",titulo="AUC y pAUC de la maquina 'bearing' con linea base no supervisada (DCASE 2023 T2)",tipo="tabla",unidad="%",condiciones=DC,replica_de="Tablas 1 y 2 de arXiv 2305.07828 (fila bearing)",evidencia=["E-9506"],limites=LIMB+" Sonido de laboratorio mezclado con ruido; AUC cercano a 50 % es casi azar.",
 columnas=["Modo","AUC fuente [%]","AUC objetivo [%]","pAUC [%]"],
 filas=[["Autoencoder simple","65.92","55.75","50.42"],["Mahalanobis selectivo","65.16","55.28","51.37"]]))
R.append(dict(id="R3",titulo="AUC y pAUC de la maquina 'bearing' en DCASE2022 T2 con detectores first-shot",tipo="tabla",unidad="adimensional",condiciones=FS,replica_de="Tabla I (columna bearing) de arXiv 2303.00455",evidencia=["E-9510"],limites=LIMB,
 columnas=["Sistema","AUC fuente","AUC objetivo","pAUC"],
 filas=[["Autoencoder first-shot","0.7479","0.5621","0.5474"],["Mahalanobis selectivo","0.7195","0.6280","0.5763"],["Linea base DCASE2022 AE","0.7271","0.5384","0.5563"],["Linea base DCASE2022 MobileNetV2","0.6067","0.5460","0.5091"],["Primer lugar DCASE2022 (conjunto masivo)","0.7190","0.6827","0.6885"]]))
R.append(dict(id="R4",titulo="AUC de detectores de anomalias acusticos en una cepilladora de madera real",tipo="barras",unidad="adimensional",condiciones=PL,replica_de="Seccion V-A de arXiv 2501.04819 (Fig. 3)",evidencia=["E-9515"],limites="Sonido de una cepilladora de aserradero, no de una chumacera de faja; un solo conjunto de evaluacion de dos dias sin intervalos.",
 series=[dict(etiqueta="Bosque de aislamiento",valor="0.518"),dict(etiqueta="Linea base DCASE",valor="0.520"),dict(etiqueta="SVM de una clase",valor="0.683"),dict(etiqueta="CAE publicado (Duman et al.)",valor="0.798"),dict(etiqueta="Skip-CAE",valor="0.846"),dict(etiqueta="Skip-CAE-Transformer",valor="0.875")]))
R.append(dict(id="R5",titulo="AUC y pAUC por tipo de anomalia en la cepilladora",tipo="tabla",unidad="adimensional",condiciones=PL,replica_de="Tabla II de arXiv 2501.04819",evidencia=["E-9516"],limites="Sonido de una cepilladora de aserradero, no de una chumacera de faja; pocas anomalias por tipo.",
 columnas=["Modelo","Roto AUC","Roto pAUC","Atascado AUC","Atascado pAUC","Grueso o desigual AUC","Grueso o desigual pAUC"],
 filas=[["Skip-CAE-Transformer","0.743","0.677","0.778","0.744","0.921","0.807"],["Skip-CAE","0.777","0.618","0.723","0.729","0.900","0.820"],["CAE de Duman et al.","0.757","0.644","0.639","0.676","0.864","0.742"],["OneClassSVM","0.558","0.509","0.707","0.519","0.681","0.515"],["Linea base DCASE","0.441","0.474","0.620","0.480","0.484","0.476"],["Isolation Forest","0.437","0.474","0.613","0.474","0.485","0.474"]]))
R.append(dict(id="R6",titulo="Comparacion de cuatro CNN para diagnostico de rodamientos en CWRU",tipo="tabla",unidad="adimensional",condiciones=ST,replica_de="Tabla IV de arXiv 2304.09100",evidencia=["E-9521"],limites=LIMB+" Clasificacion de 10 clases con datos enviados desde un PC por puerto serie.",
 columnas=["Modelo","Parametros","Entrenamiento por ronda [s]","Mejor exactitud"],
 filas=[["Modelo base","55,690","2.2","0.9528"],["Modelo Tanh","55,690","2.2","0.9765"],["Modelo ReduceLR","55,690","2.3","0.9477"],["Modelo optimizado","36,390","2.0","0.9890"]]))
R.append(dict(id="R7",titulo="Recursos del modelo CNN en el microcontrolador STM32H743VI",tipo="tabla",unidad="",condiciones=ST,replica_de="Tabla III de arXiv 2304.09100",evidencia=["E-9521"],limites=LIMB,
 columnas=["Indice","Valor"],filas=[["MACC","1238380"],["FLASH [KB]","142.15"],["RAM [KB]","11.32"]]))
json.dump(R,open(S+"lectorA_replicas.json","w"),ensure_ascii=False,indent=1)
print(len(C),len(R))

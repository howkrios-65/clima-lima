const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1500,height:950}});const e=[];p.on('pageerror',x=>e.push(String(x.stack||x).slice(0,300)));
await p.goto('file://'+process.cwd()+'/dossier_chumacera.html');
await p.screenshot({path:'x0.png'});
await p.click('#tabs button:has-text("Modos y causas")');await p.waitForTimeout(300);await p.screenshot({path:'x1.png'});
await p.click('.pill:has-text("Ishikawa")');await p.waitForTimeout(400);await p.screenshot({path:'x2.png'});
await p.click('.pl[data-c="0"][data-i="0"]');await p.waitForTimeout(300);console.log('drawer',await p.evaluate(()=>document.querySelector('#drawer').classList.contains('on')));
await p.mouse.click(60,500);
await p.click('.pill:has-text("5 porqués")');await p.screenshot({path:'x3.png'});
await p.click('#tabs button:has-text("Evidencia")');await p.click('.pill:has-text("Perfil")');await p.waitForTimeout(300);await p.screenshot({path:'x4.png',fullPage:true});
await p.click('#tabs button:has-text("Monitoreo y ML")');await p.screenshot({path:'x5.png'});
console.log(JSON.stringify({e,er:await p.evaluate(()=>window.__errores||[])}));await b.close()})()

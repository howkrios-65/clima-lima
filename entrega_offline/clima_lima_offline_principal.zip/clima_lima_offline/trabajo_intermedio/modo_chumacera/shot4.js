const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1500,height:1000}});
await p.goto('file://'+process.cwd()+'/dossier_chumacera.html');await p.waitForTimeout(300);
await p.screenshot({path:'n1.png'});await p.evaluate(()=>window.scrollTo(0,1100));await p.waitForTimeout(150);await p.screenshot({path:'n2.png'});
await p.click('#t-noche');await p.evaluate(()=>window.scrollTo(0,0));await p.screenshot({path:'n3.png'});
await b.close()})()

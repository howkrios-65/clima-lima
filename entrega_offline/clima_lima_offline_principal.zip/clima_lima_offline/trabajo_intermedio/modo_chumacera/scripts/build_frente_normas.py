import sys
sys.path.insert(0, "/home/user/clima-lima/tools/reliability")
from reliability_kit.evidence import Ledger, apa
OUT = "/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/modo_chumacera/evidencia/frente_normas.json"
F = "2026-10-27"
rows = []
n = [8500]
def add(**k):
    n[0] += 1
    e = dict(id=f"E-{n[0]}", fecha_acceso=F, revista_cuartil=None, **k)
    rows.append(e)

def norma(nombre, titulo, anio, url, afirma, limites, aplica, reg, via="websearch"):
    add(tipo="norma", acceso="snippet", via=via, referencia=dict(titulo=titulo, anio=anio, autores=nombre, url=url),
        afirma=afirma, limites=limites, aplica_a=aplica, estado_registro=reg)

L = "Solo resumen de buscador/listado de terceros; no se abrió la norma ni sus cláusulas; no respalda texto, fórmulas ni valores; estado y edición por confirmar en el publicador."
norma("ISO 281", "Rolling bearings - Dynamic load ratings and rating life", 2007,
 "https://www.iso.org/es/contents/data/standard/09/45/94537.html",
 "Segun listados de terceros (BSI, tiendas nacionales) la edicion publicada vigente es la de 2007, con la 3.a edicion en etapa de borrador (DIS/FDIS) y una enmienda en votacion; define vida nominal basica (90 % de confiabilidad) y vida nominal modificada.",
 L + " La fecha de publicacion de la ed. 3 no se encontro.", "Vida nominal L10 / L10m del rodamiento de la chumacera (mecanismo: fatiga por contacto).",
 "En registro: SOLO-SNIPPET (ed. 2007). Se mantiene; ed. 3 en DIS/FDIS sin publicar segun snippet.")
norma("ISO 15243", "Rolling bearings - Damage and failures - Terms, characteristics and causes", 2017,
 "https://www.iso.org/standard/59619.html",
 "Segun snippets, la ed. 2017 (2.a) figura vigente y confirmada en 2022 y reemplaza a la ed. 2004 (retirada); clasifica modos de dano en servicio de rodamientos de acero estandar. Un listado aislado la muestra retirada: conflicto entre fuentes. Hay un borrador de 3.a ed.",
 L + " Conflicto de estado entre listados (uno indica retirada).", "Clasificacion de modos de falla del rodamiento (fatiga, desgaste, corrosion, danos electricos, etc.) para el dossier.",
 "NO esta en registro: proponer agregar como NO-VERIFICADO (snippet con conflicto de estado).")
norma("ISO 20816-1", "Mechanical vibration - Measurement and evaluation of machine vibration - Part 1: General guidelines", 2016,
 "https://www.iso.org/standard/63180.html",
 "Segun snippet, 1.a ed. nov. 2016, confirmada en 2021, con borrador de revision (DIS) en curso; fija condiciones y procedimientos generales de medicion y evaluacion de vibracion de maquinas completas.",
 L, "Criterio general de severidad de vibracion en caja/soporte de chumacera.", "En registro: SOLO-SNIPPET (ed. 2016). Se mantiene; revision en DIS.")
norma("ISO 20816-3", "Mechanical vibration - Measurement and evaluation of machine vibration - Part 3: Industrial machinery with a power rating above 15 kW and operating speeds between 120 r/min and 30 000 r/min", 2022,
 "https://store.uni.com/api/ext/uni-api/version/preview/UNI1612069_EEN",
 "Segun snippets (SIS, ANSI, UNI), la ed. 2022 reemplaza a ISO 10816-3:2009 (+Amd 1:2017) e ISO 7919-3, que figuran retiradas; rango 120 a 30 000 r/min y potencia mayor a 15 kW; conserva zonas A/B/C/D segun fuentes de proveedor.",
 L + " Los limites de zona no se leyeron en la norma; las fuentes de proveedor no sustituyen el texto. Una polea de faja puede estar fuera del rango de velocidad (120 r/min) o de la clase de maquina: aplicabilidad por verificar.",
 "Severidad de vibracion; verificar si aplica a poleas de baja velocidad.", "En registro: SOLO-SNIPPET (ed. 2022). Se mantiene; retiro de ISO 10816-3 solo por snippet.")
norma("ISO 13373-1", "Condition monitoring and diagnostics of machines - Vibration condition monitoring - Part 1: General procedures", 2002,
 "https://www.iso.org/standard/21110.html",
 "Segun snippet, la ed. 2002 fue revisada y confirmada en 2024; guia general para medir y recoger datos de vibracion (transductores, ubicacion, monitoreo continuo y periodico).",
 L, "Practica de medicion de vibracion en chumacera (sensor, posicion, periodicidad).", "NO esta en registro (solo 13372/13374/13379/13381): proponer NO-VERIFICADO.")
norma("ISO 13373-2", "Condition monitoring and diagnostics of machines - Vibration condition monitoring - Part 2: Processing, analysis and presentation of vibration data", 2016,
 "https://www.iso.org/standard/68128.html",
 "Segun snippet, la 2.a ed. 2016 fue confirmada en 2021; trata procesamiento, analisis y presentacion en dominios del tiempo y la frecuencia.",
 L, "Metodo de procesado (envolvente/espectro) para rodamientos de baja velocidad.", "NO esta en registro: proponer NO-VERIFICADO.")
norma("ISO 13373-3", "Condition monitoring and diagnostics of machines - Vibration condition monitoring - Part 3: Guidelines for vibration diagnosis", 2015,
 "https://infostore.saiglobal.com/en-us/Standards/ISO-13373-3-2015-605507_SAIG_ISO_ISO_1387510/",
 "Segun un revendedor, la ed. 2015 es la ultima; no se vio la pagina de ISO.",
 L + " Solo revendedor.", "Guia de diagnostico por vibracion de falla de rodamiento.", "NO esta en registro: proponer NO-VERIFICADO.")
norma("ISO 18436-2", "Condition monitoring and diagnostics of machines - Requirements for qualification and assessment of personnel - Part 2: Vibration condition monitoring and diagnostics", 2014,
 "https://www.evs.ee/en/iso-18436-2-2014",
 "Segun snippets, la ed. 2014 figura vigente, con revision (ISO/CD) en desarrollo segun un organismo nacional; fija requisitos de formacion y examen de analistas de vibracion en cuatro categorias.",
 L, "Competencia del analista que diagnostica la chumacera.", "En registro: SOLO-SNIPPET (ed. 2014; registro dice nueva ed. en FDIS, el snippet de hoy dice CD: discrepancia por resolver).")
norma("ISO 5048", "Continuous mechanical handling equipment - Belt conveyors with carrying idlers - Calculation of operating power and tensile forces", 1989,
 "https://www.iso.org/standard/11069.html",
 "Segun snippets, la ed. 1989 (2.a) figura vigente y confirmada en 2026; la de 1979 esta retirada; calcula potencia en la polea motriz y tensiones de banda.",
 L, "Cargas en poleas (tensiones de banda) como dato de entrada de la vida de rodamiento; no trata el rodamiento.", "NO esta en registro: proponer NO-VERIFICADO.")
norma("DIN 22101", "Continuous conveyors - Belt conveyors for loose bulk materials - Basis for calculation and dimensioning", 2011,
 "https://dinmedia.de/en/standard/din-22101/145598666",
 "Segun snippets, la edicion vigente es DIN 22101:2011-12 (ed. 2002 reemplazada) con un borrador de revision en curso.",
 L + " Solo en aleman segun listado.", "Diseno de transportador: base de calculo de cargas de polea.", "NO esta en registro: proponer NO-VERIFICADO.")
norma("ISO 113", "Rolling bearings - Plummer block housings - Boundary dimensions", 2010,
 "https://ccn-scc.ca/standardsdb/standards/8149993",
 "Segun snippets, la ed. 2010 figura vigente y confirmada (fecha de confirmacion reportada: 2026, sin leer la pagina) y reemplaza a la de 1999; da dimensiones de contorno de soportes (chumaceras) de 2 y 4 pernos.",
 L, "Define el soporte (carcasa), no su resistencia ni modos de falla.", "NO esta en registro: proponer NO-VERIFICADO.")
norma("CEMA Standard 7 (capitulo de poleas)", "CEMA Standard 7 - capitulo sobre poleas (titulo exacto no leido)", None,
 "https://cemanet.org/wp-content/uploads/2019/06/EC-2019-Conveyor-Idler-Committee-Meeting-Agenda-Set.pdf",
 "Segun un resumen de buscador de un documento de comite, el capitulo de poleas usa las tasas de vida de ISO 281:2007; la edicion de Standard 7 no se pudo identificar.",
 L + " Edicion y titulo desconocidos; el snippet es de un acta de comite, no de la norma.", "Practica de la industria para vida de rodamiento de polea.", "NO esta en registro: proponer NO-VERIFICADO.")
norma("API RP 580", "Risk-Based Inspection (elementos de un programa RBI)", 2023,
 "https://eshop.normservis.sk/norma/apirp-580-ed-4-1.8.2023.html",
 "Segun un listado de tienda, 4.a ed. fechada agosto 2023 con Addendum 1 (2025). Confirma el conflicto del registro entre 3.a (2019) y 4.a ed.",
 L + " Solo tienda, no API. RBI de API se pensó para equipos estaticos/presurizados de proceso; su aplicabilidad a una chumacera de faja es una analogia metodologica, no un requisito.", "Uso metodologico de IBR (probabilidad x consecuencia) para priorizar inspeccion.", "En registro: SOLO-SNIPPET con conflicto de edicion; el nuevo snippet apoya 4.a ed. 2023 + Add. 2025.")
norma("API RP 581", "Risk-Based Inspection Methodology", 2025,
 "https://oviss.jp/view/item/000000001157",
 "Segun un listado de tienda, 4.a ed. fechada 2025; un articulo de prensa tecnica sugiere retiro progresivo del metodo semicuantitativo (solo titulo y extracto visto).",
 L + " El alcance del retiro del metodo semicuantitativo no se leyó.", "Metodologia cuantitativa de IBR; analogia, no aplica directamente a rodamientos.", "En registro: SOLO-SNIPPET (4.a ed. 2025). Se mantiene.")
norma("SAE JA1011", "Evaluation Criteria for Reliability-Centered Maintenance (RCM) Processes", 2024,
 "https://www.dinmedia.de/en/standard/sae-ja-1011/386132170",
 "Segun snippets (DIN Media, BSI), la edicion vigente seria SAE JA1011 de 2024-11-06; la de 2009 figura historica en ANSI. Resuelve la edicion pendiente del registro solo a nivel snippet.",
 L + " Las siete preguntas descritas por un proveedor no se verificaron contra la norma.", "Marco RCM para seleccionar tareas (condicion, restauracion, sustitucion) de la chumacera.", "En registro: NO-VERIFICADO sin edicion. Subir a SOLO-SNIPPET con ed. 2024 (hallazgo de hoy).")
add(tipo="reporte_tecnico", acceso="snippet", via="websearch",
    referencia=dict(autores="Nowlan, F. S., & Heap, H. F.", anio=1978, titulo="Reliability-Centered Maintenance", fuente="Informe DTIC ADA066579", url="https://apps.dtic.mil/sti/html/tr/ADA066579/index.html", pais="EEUU"),
    afirma="Segun el registro DTIC visto en snippet, es el informe de 1978 que sirve de origen del RCM (programa de mantenimiento preventivo para equipo complejo).",
    limites="Solo extracto de buscador; no se leyo el informe; los porcentajes de patrones de falla que circulan (p. ej. 11 %) no se contrastaron con la tabla original y no deben citarse. Dominio DTIC bloqueado en este entorno.",
    aplica_a="Origen y logica de seleccion de tareas por patron de falla (rodamientos: tipicamente falla sin edad fija: hipotesis a verificar en el texto).", estado_registro="En registro: SOLO-SNIPPET.")

# Literatura
add(tipo="paper", acceso="snippet", via="websearch",
    referencia=dict(autores="Randall, R. B., & Antoni, J.", anio=2011, titulo="Rolling element bearing diagnostics - A tutorial",
                    fuente="Mechanical Systems and Signal Processing", volumen="25(2)", paginas="485-520", doi="10.1016/j.ymssp.2010.07.017"),
    afirma="Referencia bibliografica confirmada por listas de referencias en snippets de buscador (autores, revista, volumen, paginas, DOI); descrito por un tercero como el tutorial principal de diagnostico de rodamientos.",
    limites="No se leyo el articulo ni su resumen; no respalda ninguna afirmacion tecnica; el DOI no se pudo resolver (doi.org bloqueado); cuartil no verificable.",
    aplica_a="Metodo de diagnostico por envolvente/demodulacion para falla de rodamiento (pista a leer).", comparabilidad="por evaluar", tipo_estudio="revision/tutorial")
pre = [
 ("2311.18547","Jalonen, T., Al-Sa'd, M., Kiranyaz, S., & Gabbouj, M.",2023,"Real-Time Vibration-Based Bearing Fault Diagnosis Under Time-Varying Speed Conditions",
  "Abstract de autores (leido en el lector de preprints): CNN en tiempo real para diagnosticar fallas de rodamiento (pista interna, externa, bolas) con ruido y velocidad variable; reporta ganancias de precision de hasta 15,8 % frente a su referencia.",
  "Abstract_ del preprint, sin revision por pares confirmada; banco de laboratorio, no polea de faja ni baja velocidad; aprendizaje profundo, no una norma de aceptacion; 15,8 % es cifra del autor en su banco.",
  "Alcance de la deteccion por vibracion con velocidad variable.","Abstract: 'it achieves substantial accuracy gains of up to 15.8%'","Abstract"),
 ("2510.17846","Razzaq, W., & Zhao, Y.-B.",2025,"CARLE: A Hybrid Deep-Shallow Learning Framework for Robust and Explainable RUL Estimation of Rolling Element Bearings",
  "Abstract de autores: marco hibrido para estimar la vida util remanente de rodamientos, evaluado en los conjuntos XJTU-SY y PRONOSTIA; la introduccion cita que 40 a 50 % de las fallas de maquinaria se atribuyen a rodamientos (cifra tomada de su ref. 1, sin verificar).",
  "Preprint sin revision por pares confirmada; datos de bancos de ensayo acelerado; la cifra 40 a 50 % es cita secundaria de la introduccion (no se leyo su fuente) y no debe usarse como dato de planta.",
  "Pronostico (RUL) de rodamiento: limites de comparabilidad con una polea de baja velocidad.","Abstract: 'We assessed the effectiveness of the proposed framework via the XJTU-SY and PRONOSTIA bearing datasets.'","Abstract"),
 ("2610.06880","Leyva-Vazquez, M., Rumbaut Rangel, D., Cevallos-Torres, L., & Matheu Perez, A.",2026,"Neutrosophic Ensemble Classification for Uncertainty-Aware Bearing Fault Detection: Evidence from Laboratory and Variable-Speed Industrial Benchmarks",
  "Abstract de autores: con los bancos CWRU y JNU, el clasificador alcanza 100 % en tres de cuatro cargas de CWRU, pero cae a 40,64 % al retener 1000 rpm en JNU, por debajo de la clase mayoritaria; el espectro de envolvente separa casi perfecto (99,57 %) en CWRU.",
  "Preprint de 2026-09; el HF solo dio resumen y metadatos (texto completo no disponible); bancos de laboratorio; el contraste CWRU vs JNU ilustra que la precision de laboratorio no se transfiere.",
  "Advertencia de generalizacion de modelos de diagnostico de rodamientos.","Abstract: 'On JNU, holding out 1000 rpm, accuracy collapses to 40.64 percent, below a majority-class baseline'","Abstract"),
]
for pid, au, an, ti, af, li, ap, ex, loc in pre:
    add(tipo="preprint", acceso="abstract", via="hf_papers",
        referencia=dict(autores=au, anio=an, titulo=ti, fuente=f"arXiv:{pid}", url=f"https://arxiv.org/abs/{pid}"),
        afirma=af, limites=li, aplica_a=ap, extracto=ex.split(": ",1)[1].strip("'"), localizador=f"hf://papers/{pid}/ (abstract)", comparabilidad="baja", tipo_estudio="experimental/computacional (banco de laboratorio)")

def otro(titulo, anio, url, afirma, limites, aplica, acceso="snippet", pais=None, autores=None, via="websearch", tipo="otro", comp="por evaluar"):
    ref = dict(titulo=titulo, url=url)
    if anio: ref["anio"] = anio
    if pais: ref["pais"] = pais
    if autores: ref["autores"] = autores
    add(tipo=tipo, acceso=acceso, via=via, referencia=ref, afirma=afirma, limites=limites, aplica_a=aplica, comparabilidad=comp)

otro("Tesis PUCP sobre analisis de falla de eje de polea motriz de faja transportadora (titulo exacto no visto)", 2026,
 "https://tesis.pucp.edu.pe/bitstreams/643c557f-74dd-40d4-bdbb-04301343b1d6/download",
 "Segun el snippet, tesis de la PUCP (Lima) que analiza la fractura de un eje de polea motriz de faja transportadora con ensayos de laboratorio; no usa vibraciones.",
 "Solo extracto de buscador; titulo, autor y año tomados del comentario del buscador sin abrir el PDF; es falla del eje, no del rodamiento ni de la chumacera; tesis.pucp.edu.pe bloqueado en este entorno.",
 "Comparable en equipo (polea de faja) pero otro componente: pista.", pais="Peru")
otro("Aplicabilidade do conceito triplice barreira em mancais de transportadores de correia", 2017,
 "https://abmproceedings.com.br/en/article/download-pdf/aplicabilidade-do-conceito-triplice-barreira-em-mancais-de-transportadores-de-correia",
 "Segun el snippet, congreso ABM: contaminacion por particulas en mancais de transportadores de correia, con analisis de causa raiz en rodamientos autocompensadores; la combinacion de sello triple y vibracion habria subido el tiempo entre fallas de unos 10 a unos 30 meses.",
 "Solo extracto de buscador; titulo tomado del enlace; cifras 10 y 30 meses del snippet, sin n ni condiciones; caso de una operacion, no generalizable; congreso, no revista; no citar la cifra.",
 "Contaminacion como causa raiz y contramedida (sellado) en chumacera de transportador: pista de alta comparabilidad por leer.", pais="Brasil", comp="alta (por confirmar)")
otro("Dissertacao UFPA: desenvolvimento de sistema de diagnostico con vibracao en roletes de bancada de transportador de correia (titulo exacto no visto)", None,
 "https://www.repositorio.ufpa.br/bitstream/2011/16511/1/Dissertacao_DesenvolvimentoSistemaDiagnostico.pdf",
 "Segun el snippet, dissertacao de la UFPA: vibracion recogida en roletes de una bancada de transportador, con wavelet y arbol de decision; cita defectos de rodamiento y desgaste como modos de falla comunes.",
 "Solo extracto de buscador; año y autor desconocidos; bancada de laboratorio en rodillos, no polea con chumacera; repositorio UFPA no probado en el mapa.",
 "Diagnostico de rodamiento en transportador, en banco: comparabilidad media-baja.", pais="Brasil", comp="media-baja")
otro("Metodologia para detectar fallas en rodamientos mediante frecuencias forzantes (revista Tecsup, titulo exacto no visto)", 2022,
 "https://revista.tecsup.edu.pe/index.php/Imasi/article/download/52/52",
 "Segun el snippet, articulo de Tecsup (Peru, 2022) con una metodologia de deteccion de fallas de rodamiento por frecuencias forzantes en equipos rotativos.",
 "Solo extracto de buscador; sin autor ni titulo exacto; no se abrio.", "Metodo basico de frecuencias de falla de rodamiento: pista.", pais="Peru")
otro("A Review of Rolling Element Bearing Vibration 'Detection, Diagnosis and Prognosis' (informe DTIC ADA291123)", None,
 "https://apps.dtic.mil/sti/html/tr/ADA291123/index.html",
 "Segun el snippet, informe de revision sobre cinematica, vida, medicion de vibracion, procesado de señal y pronostico de rodamientos.",
 "Solo extracto de buscador; autores y año no vistos; DTIC bloqueado en este entorno.", "Revision de base del diagnostico por vibracion: pista a leer.", pais="EEUU")
otro("Vibration Based Condition Monitoring in Rotating Machineries (NPTEL, modulo 4, IIT)", None,
 "https://archive.nptel.ac.in/content/storage2/courses/112103024/module15/lec2/1.html",
 "Segun el snippet, clase abierta de NPTEL con frecuencias generadas por defectos de rodamientos y mencion de que la tecnica mas comun es medir la vibracion en el rodamiento a intervalos regulares.",
 "Solo extracto de buscador (no es transcripcion leida); sin autor/año; India fuera de la prioridad geografica.", "Material didactico de base: pista.", pais="India")
otro("SKF: Bearing damage and failure analysis (guia, PDF)", None,
 "https://cdn.skfmediahub.skf.com/api/public/093168a92d25cc46/pdf_preview_medium/093168a92d25cc46_pdf_preview_medium.pdf",
 "Segun el snippet, existe una guia de fabricante sobre dano y analisis de falla de rodamientos; solo se vio el indice.",
 "Fabricante; solo indice visto; sin año; no respalda causas ni porcentajes.", "Guia de causas de falla del rodamiento: leer completa.", autores="SKF")
otro("Timken: Bearing damage analysis with lubrication reference guide (5892)", None,
 "https://timken.com/resources/5892-bearing-damage-analysis-with-lubrication-reference-guide",
 "Segun el snippet, guia de fabricante con advertencias de alineacion y de no operar sobre cierta temperatura (121 C segun el buscador).",
 "Fabricante; extracto de buscador; la cifra de temperatura no se verifico y es de un tipo de rodamiento concreto.", "Guia de causas de falla y lubricacion: leer completa.", autores="Timken")
otro("Serie de video de bearing failure y vibracion (ReliabilityWeb, Tranter, partes 1 a 3)", None,
 "https://reliabilityweb.com/videos/article/bearing_fault_detection_p1",
 "Pista: serie de video sobre fallas de rodamiento; una pagina asociada mostraba porcentajes de causas (fatiga, lubricacion, contaminacion) en un listado desordenado.",
 "Video/pagina comercial: pista, jamas respaldo de cifras; no se vio transcripcion; los porcentajes del snippet no se usan.", "Solo pista.", acceso="solo_referencia", comp="baja")
otro("Perfil de LinkedIn devuelto por busqueda sobre chumaceras (sin contenido leido)", None,
 "https://www.linkedin.com/ (perfil omitido por privacidad)",
 "Pista de busqueda; no se leyo nada.", "LinkedIn: solo pista; no se accede ni se extrae; no respalda nada.", "Ninguna.", acceso="solo_referencia", comp="baja")

l = Ledger(rows)
l.to_json(OUT)
print(l.resumen())
for e in l.entradas.values():
    print(e["id"], e["nivel_evidencia"], "|", apa(e)[:150])
print({k:v for k,v in l.avisos.items() if v})

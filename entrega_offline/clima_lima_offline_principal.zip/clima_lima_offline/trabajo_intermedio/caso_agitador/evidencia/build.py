import json,re
base='/root/.claude/projects/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/tool-results/'
chunks={}
for f in ['6218','6347','6200','6240']:
    d=json.load(open(base+f'mcp-Wiley_Scholar_Gateway-search_wiley_fulltext-179307259{f}.txt'))
    for r in d['results']:
        chunks[r['id']]=r['text']
J="Journal of Healthcare Risk Management"
# (chunk, start, end, autores, anio, titulo, revista, vol, pag, loc, afirma, limites, aplica, tipo_estudio, comp)
S=[
("10.1002/jhrm.21198_0003","If we want uniformity","their results will be different.","Latino, R. J.",2015,"How is the effectiveness of root cause analysis measured in healthcare?",J,"35(2)","21-30","sección STANDARDIZING EFFECTIVE RCAs, fragmento 0003",
 "Un autor de opinión sostiene que si distintos analistas usan 5 porqués, Ishikawa o árbol lógico sus resultados serán diferentes; es decir, las técnicas no son intercambiables ni producen por defecto la misma causa. Es indicio contra suponer independencia o equivalencia entre técnicas.",
 "Artículo de opinión de salud (hospitales), no estudio empírico; no mide la convergencia entre técnicas ni su validez. El resto del pasaje (críticas a 5 porqués e Ishikawa) no se cita aquí.","M-ACR","opinión/revisión","baja"),
("10.1002/hfm.20902_0007","Third, it is unclear why","as a standalone tool.","McIlroy, R. C., Plant, K. L., & Stanton, N. A.",2021,"Intuition, the Accimap, and the question \"why?\" Identifying and classifying higher-order factors in road safety",  "Human Factors and Ergonomics in Manufacturing & Service Industries","31(5)","546-558","sección INTRODUCTION, fragmento 0007",
 "Critica de los 5 porqués: el número de porqués no tiene justificación, el método fuerza a explorar una sola trayectoria causal y los autores no recomiendan usarlo como herramienta única, solo combinado con otros enfoques (p. ej. Accimap).",
 "Seguridad vial y enfoque sociotécnico; argumento conceptual de los autores, no un ensayo comparativo de eficacia.","M-ACR","artículo conceptual","baja"),
("10.1002/qre.3224_0006","It is critical to remember","(p. 112)","Barsalou, M.",2022,"Criteria for the prioritization of hypotheses in root cause analysis","Quality and Reliability Engineering International","39(1)","132-142","sección LITERATURE REVIEW, fragmento 0006",
 "Revisión de literatura: un diagrama de Ishikawa no identifica una causa raíz, solo presenta causas posibles; tratarlo como actividad diagnóstica puede descarrilar la solución de problemas. Las hipótesis deben retenerse o rechazarse con evidencia.",
 "Cita a otros autores dentro de una revisión (calidad/manufactura); no es un ensayo de eficacia del diagrama. Lo dicho sobre 5 porqués en fragmentos vecinos no se cita aquí.","M-ACR","revisión","media"),
("10.1002/qre.1435_0008","However, these techniques have limited success","in RCA.","Reid, I., & Smyth-Renshaw, J.",2012,"Exploring the Fundamentals of Root Cause Analysis: Are We Asking the Right Questions in Defining the Problem?","Quality and Reliability Engineering International","28(5)","535-545","sección The focus on process improvement, fragmento 0008",
 "Lluvia de ideas, causa-efecto (Ishikawa) y 5 porqués son las herramientas más usadas pero tienen éxito limitado para captar la psicología humana en el ACR; el artículo argumenta que preguntar 'por qué' introduce variación y que el 5W+1H es insuficiente para hallar la causa raíz.",
 "Estudio conceptual con ejemplos de gestión de calidad/Six Sigma; la cita sobre el éxito limitado atribuye la observación a otros autores; no es medición de eficacia.","M-ACR","artículo conceptual","baja"),
("10.1002/acm2.14623_0009","Practitioners often oversimplified accident causation","a pitfall known as","Wong, L. M., & Pawlicki, T.",2025,"A review of accident models and incident analysis techniques","Journal of Applied Clinical Medical Physics","26(3)",None,"sección INCIDENT ANALYSIS TECHNIQUES, fragmento 0009",
 "Revisión (oncología radioterápica): en la práctica del ACR se tiende a buscar una sola causa o pocos factores ('root cause seduction'), y los análisis suelen detenerse en el error humano sin hallar factores subyacentes; el ACR sofisticado exige línea de tiempo, fallas activas y condiciones latentes.",
 "Contexto de salud, no industrial; revisión narrativa. El extracto corta antes del nombre del error; el nombre completo figura en el pasaje leído.","M-ACR","revisión","baja"),
("10.1002/tqem.21401_0017","However, it does rely on professional judgment","under investigation.","Guerin, T. F.",2015,"An Investigation Into the Root Cause of a Spill From Procuring and Handling of Lubricants","Environmental Quality Management","24(4)","23-50","sección Comparing the RCA Method With the \"5 Why\" Analysis, fragmento 0017",
 "Caso industrial (derrame de lubricantes): el 5 porqués es una versión rápida y de pocos recursos del ACR que depende del juicio profesional; el ACR con Ishikawa y equipo de expertos da mayor confianza en las causas pero cuesta más.",
 "Un solo caso de derrame, comparación cualitativa del propio autor; no mide validez de ninguna técnica.","M-ACR","caso","media"),
("10.1002/jhrm.21454_0001","traditional RCA methods generally assume","single root cause.","Wiegmann, D. A., Wood, L. J., Solomon, D. B., & Shappell, S. A.",2020,"Implementing a human factors approach to RCA2: Tools, processes and strategies",J,"41(1)","31-46","sección INTRODUCTION, fragmento 0001",
 "Los autores sostienen que el ACR tradicional presupone fallas encadenadas linealmente y trazables a una sola causa raíz (hallada con la serie de cinco porqués), supuesto no válido cuando el origen es un error humano en un sistema acoplado.",
 "Ámbito hospitalario y error humano; afirmación de los autores con citas de otros, sin datos propios sobre equipos mecánicos.","M-ACR","artículo conceptual","baja"),
("10.1002/rhc3.12281_0009","These difficulties typically become more difficult over time","linear narratives of how an event occurred","Meyer, C. O.",2023,"Can one \"prove\" that a harmful event was preventable? Conceptualizing and addressing epistemic puzzles in post-incident reviews","Risk, Hazards & Crisis in Public Policy","15(3)","374-392","sección THREE TYPES OF EPISTEMIC PUZZLES IN PIR, fragmento 0009",
 "El sesgo retrospectivo distorsiona la reconstrucción de hechos y favorece narrativas lineales en vez de contingentes; afecta también la búsqueda de evidencia del investigador (palabras clave basadas en lo que ya se sabe). Parte de la literatura lo considera inevitable.",
 "Investigaciones post-incidente de política pública y seguridad nacional, no de ingeniería de planta; análisis conceptual.","M-ACR","artículo conceptual","baja"),
("10.1002/prs.70071_0011","Incident investigations that require competing hypotheses","simplistic frontline blame.","Perez, J. T.",2026,"Logical fallacy and cognitive bias vulnerabilities inherent to process safety management","Process Safety Progress",None,None,"sección MITIGATION STRATEGIES, fragmento 0011",
 "En gestión de seguridad de procesos, exigir hipótesis en competencia en las investigaciones de incidentes reduce los sesgos de confirmación y retrospectivo; otras mitigaciones del mismo pasaje: desafío independiente en puntos de decisión y documentación explícita de supuestos.",
 "Propuesta de mitigación de un artículo de análisis (industria de procesos); no se presentan datos de eficacia en el fragmento leído.","M-ACR","artículo conceptual","media"),
("10.1002/acp.70258_0003","Once investigators develop an initial theory of causation","as supporting it","MacLean, C. L., & Schael, B.",2026,"Investigating Workplace Investigators: Bias Mitigation With Fact-Checking","Applied Cognitive Psychology","40(4)",None,"sección Introduction, fragmento 0003",
 "Una vez que el investigador forma una teoría inicial, el sesgo de confirmación lo lleva a buscar información que la apoye, subestimar la que la contradice e interpretar lo ambiguo a su favor; la información en investigaciones laborales suele ser ambigua e incompleta.",
 "Solo se leyó la introducción; el efecto de la intervención de verificación de hechos (resultados) no se leyó. Investigadores laborales y estudiantes, no ingenieros de confiabilidad.","M-ACR","experimental (introducción)","baja"),
("10.1002/prs.12579_0005","a 2004 metaanalysis of 95 studies","across a range of settings","Hutchinson, B., Dekker, S., & Rae, A.",2024,"How audits fail according to accident investigations: A counterfactual logic analysis","Process Safety Progress","43(3)","441-454","sección BACKGROUND, fragmento 0005",
 "Cita un metaanálisis de 2004 (95 estudios) con efectos de sesgo retrospectivo de bajos a moderados sobre los juicios posteriores, y describe la postura de que las investigaciones 'construyen' causas seleccionando fragmentos (cherry-picking). Matiza que el sesgo existe pero con magnitud acotada.",
 "Referencia de segunda mano a un metaanálisis no leído; contexto de accidentes y auditorías. No cuantifica el efecto en ACR de equipos.","M-ACR","revisión","media"),
("10.1002/acp.2350040405_0000","industrial accidents are the endresults of long chains of events","hidden for a long time.","Wagenaar, W. A., Hudson, P. T., & Reason, J. T.",1990,"Cognitive failures and accidents","Applied Cognitive Psychology","4(4)","273-294","Abstract",
 "Los accidentes industriales son el resultado de cadenas largas que arrancan en decisiones gerenciales que crean fallas latentes; la prevención es más eficaz dirigida a las decisiones de gestión que a los actos inseguros.",
 "Solo el resumen del autor; trabajo de 1990 de enfoque cognitivo, sin datos de planta propios.","M-ACR","artículo conceptual","media"),
("10.1002/sres.2618_0004","Latent conditions may not combine with active failures","years of existence.","Jing, L., Bai, Q., Guo, W., Feng, Y., Liu, L., & Zhang, Y.",2019,"Contributory factors interactions model: A new systems-based accident model","Systems Research and Behavioral Science","37(2)","255-276","sección SWISS CHEESE MODEL, HFACS, AND THEIR LIMITATIONS, fragmento 0004",
 "En el modelo del queso suizo las condiciones latentes (decisiones de alto nivel, supervisión, condiciones previas) pueden permanecer años antes de combinarse con fallas activas y atravesar las capas de defensa.",
 "Descripción de un modelo conceptual en un artículo que propone otro modelo; no evidencia empírica de la prevalencia de causas latentes.","M-ACR","revisión","media"),
("10.1111/risa.70084_0021","explains an accident as the result of the alignment of holes","layers of defenses, barriers, and safeguards","Igarashi, T., & Marais, K.",2025,"Cartography of Accident Causation Models: Remapping the Modeling Landscape","Risk Analysis","45(10)","3176-3200","sección Review of Individual Models, fragmento 0021",
 "Revisión de modelos: el queso suizo explica el accidente como alineación de agujeros en capas de defensas, barreras y salvaguardas; el modelo dominó se critica por simplificar en exceso y no describir accidentes organizacionales.",
 "Revisión de modelos teóricos; no valida el modelo frente a datos de accidentes industriales.","M-ACR","revisión","media"),
("10.1002/prs.12359_0001","Organizational failure remains within the organization","active failure of field workers.","Yang, J., & Kwon, Y.",2022,"Human factor analysis and classification system for the oil, gas, and process industry","Process Safety Progress","41(4)","728-737","sección INTRODUCTION, fragmento 0001",
 "En la industria de procesos las fallas organizacionales permanecen como condición latente largo tiempo y provocan fallas activas de los operarios; el queso suizo identifica factores pero no da detalle de los factores contribuyentes, lo que motivó HFACS para petróleo, gas y proceso.",
 "Introducción de un artículo que desarrolla una taxonomía; la afirmación sobre la limitación del queso suizo viene de referencias que citan los autores.","M-ACR","revisión","alta"),
("10.1002/prs.12002_0002","Sequential and epidemiological accident models do not fully capture","complex sociotechnical systems.","Yousefi, A., Rodriguez Hernandez, M., & Lopez Peña, V.",2018,"Systemic accident analysis models: A comparison study between AcciMap, FRAM, and STAMP","Process Safety Progress","38(2)",None,"sección INTRODUCTION, fragmento 0002",
 "Los modelos secuenciales y epidemiológicos (cadena de eventos, queso suizo) no capturan la dinámica ni las interacciones no lineales de sistemas sociotécnicos complejos; los modelos sistémicos (AcciMap, FRAM, STAMP) desplazan el foco hacia factores organizacionales.",
 "Introducción de un estudio comparativo de modelos; no reporta tasas de acierto de ninguna técnica.","M-ACR","revisión","alta"),
]
out=[];n=5001
for (cid,s,e,au,an,ti,rev,vol,pag,loc,af,li,ap,te,cp) in S:
    t=chunks[cid]; t=t.replace('‐','-')
    i=t.find(s); j=t.find(e,i)
    assert i>=0 and j>=0,(cid,s,e)
    ex=t[i:j+len(e)]
    assert len(ex)<=800,(cid,len(ex))
    acc='abstract' if loc=='Abstract' else 'fragmento'
    out.append({"id":f"E-{n}","tipo":"paper","acceso":acc,"via":"wiley_scholar_gateway","fecha_acceso":"2026-10-27",
      "referencia":{"autores":au,"anio":an,"titulo":ti,"fuente":rev,"volumen":vol,"paginas":pag,"doi":cid.rsplit('_',1)[0]},
      "extracto":ex,"localizador":loc,"afirma":af,"limites":li,"aplica_a":[ap],"tipo_estudio":te,"comparabilidad":cp,"revista_cuartil":None}); n+=1
out.append({"id":f"E-{n}","tipo":"paper","acceso":"snippet","via":"websearch","fecha_acceso":"2026-10-27",
 "referencia":{"autores":"Card, A. J.","anio":2017,"titulo":"The problem with '5 whys'","fuente":"BMJ Quality & Safety","volumen":"26(8)","paginas":"671-677","doi":"10.1136/bmjqs-2016-005849"},
 "afirma":"Pista, no evidencia: según resúmenes de buscador, el artículo critica el 5 porqués (profundidad arbitraria, deducción sin observación, simplifica problemas complejos) y dice que su popularidad no se apoya en evidencia de eficacia.",
 "limites":"Solo resumen de buscador y resúmenes secundarios; no se abrió el texto. Debe verificarse antes de citarlo en un entregable; contexto de salud.","aplica_a":["M-ACR"],"tipo_estudio":"artículo conceptual","comparabilidad":"baja","revista_cuartil":None})
json.dump(out,open('frente_E.json','w'),ensure_ascii=False,indent=1)

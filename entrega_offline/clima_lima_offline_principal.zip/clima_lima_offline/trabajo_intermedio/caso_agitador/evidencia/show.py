import json,sys,glob
base='/root/.claude/projects/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/tool-results/'
fs=['6218','6347','6200','6240']
ids=sys.argv[1].split(',')
a0=int(sys.argv[2]); a1=int(sys.argv[3])
for f in fs:
    d=json.load(open(base+f'mcp-Wiley_Scholar_Gateway-search_wiley_fulltext-179307259{f}.txt'))
    for r in d['results']:
        if r['id'] in ids:
            a=r['metadata']['additionalMetadata']
            print('#####',r['id'],f,a.get('journalTitle'),a.get('volume'),a.get('issue'),a.get('pageRange'),a.get('articleNumber'))
            print(r['text'][a0:a1]); print()

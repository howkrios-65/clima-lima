import json,re,sys
T="/root/.claude/projects/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/tool-results/mcp-Wiley_Scholar_Gateway-search_wiley_fulltext-%s.txt"
Q={"visc":"1793072601831","sand":"1793072601521","oil":"1793072602119","water":"1793072649576","part":"1793072649605"}
def chunk(q,cid):
    d=json.load(open(T%Q[q]))
    return [r for r in d["results"] if r["id"]==cid][0]["text"]
norm=lambda s:re.sub(r"\s+"," ",s)
FA="2026-10-27"
E=[]
def add(n,q,cid,autores,anio,titulo,fuente,vol,pag,doi,ex,loc,afirma,lim,ap,comp,est,acceso="fragmento"):
    assert norm(ex) in norm(chunk(q,cid)),(n,"extracto no literal")
    ref={"autores":autores,"anio":anio,"titulo":titulo,"fuente":fuente,"volumen":vol,"doi":doi}
    if pag: ref["paginas"]=pag
    E.append({"id":f"E-{2000+n}","tipo":"paper","acceso":acceso,"via":"wiley_scholar_gateway","fecha_acceso":FA,
      "referencia":ref,"extracto":ex,"localizador":loc,"afirma":afirma,"limites":lim,"aplica_a":ap,
      "comparabilidad":comp,"tipo_estudio":est,"revista_cuartil":None})
add(1,"visc","10.1002/tt.3020110105_0000","Michaelis, K., Hoehn, B., & Oster, P.",2006,
 "Influence of lubricant on gear failures — test methods and application to gearboxes in practice","Tribotest","11(1)","43-56","10.1002/tt.3020110105",
 "Base oil type, oil viscosity, and additive type and content have a strong influence on typical gear failures.",
 "Conector Wiley Scholar Gateway, pasaje 10.1002/tt.3020110105_0000 (sección Abstract)",
 "Segun el resumen de los autores, el tipo de aceite base, la viscosidad y el tipo y contenido de aditivo influyen fuertemente en las fallas tipicas de engranajes; la influencia del lubricante solo se evalua de forma adecuada en bancos de engranajes (FZG) y no con ensayos simples de banco.",
 "Solo se leyo el resumen (pasaje del conector); no cuantifica el efecto de una viscosidad insuficiente ni de mezclar grados. No trata agua ni particulas. Es una revision de metodos de ensayo (FZG), no un caso de planta.",
 ["H-LUB"],"media","revision de metodos de ensayo",acceso="abstract")
add(2,"visc","10.1111/ffe.12867_0001","Terrin, A., & Meneghetti, G.",2018,
 "A comparison of rolling contact fatigue behaviour of 17NiCrMo6-4 case-hardened disc specimens and gears","Fatigue & Fracture of Engineering Materials & Structures","41(11)","2321-2337","10.1111/ffe.12867",
 "Micropitting is particularly common in carburized gears with poor lubricating conditions.",
 "Conector Wiley Scholar Gateway, pasaje 10.1111/ffe.12867_0001 (sección Introduction)",
 "En su introduccion los autores indican que el micropitting es comun en engranajes cementados con mala lubricacion y que el macropitting puede originarse en los crateres del micropitting; ademas, el deterioro del acabado superficial por micropicado aumenta la tasa de desgaste.",
 "Es texto de introduccion (antecedente), no un resultado del estudio; el estudio compara probetas de disco con engranajes de un acero 17NiCrMo6-4 y no varia viscosidad, mezcla ni agua. No hay datos del piñon conico ni de la raiz del diente.",
 ["H-LUB"],"media","antecedente en un estudio experimental")
add(3,"visc","10.1111/ffe.13150_0001","Prajapati, D. K., & Tiwari, M.",2019,
 "Experimental investigation on evolution of surface damage and topography parameters during rolling contact fatigue tests","Fatigue & Fracture of Engineering Materials & Structures","43(2)","355-370","10.1111/ffe.13150",
 "the thickness of lubricant film is getting thinner leading to severe asperitytoasperity contacts. Because of severe asperity contacts, an incidence of micropitting is observed in high power density (power throughput/weight) machines.",
 "Conector Wiley Scholar Gateway, pasaje 10.1111/ffe.13150_0001 (sección Introduction)",
 "Los autores plantean que una pelicula de lubricante mas delgada produce contacto severo entre asperezas y que de ahi se observa micropitting; ademas describen que la severidad del micropitting crece con el numero de ciclos.",
 "Texto de introduccion; el ensayo es de fatiga por rodadura en maquina de discos, con variacion de la relacion deslizamiento-rodadura, no engranajes ni cambios de viscosidad o contaminacion. No cuantifica el efecto de la viscosidad.",
 ["H-LUB"],"media","experimental (discos); afirmacion citada de introduccion")
add(4,"visc","10.1002/ls.70006_0010","Zhang, S., Yan, M., Yang, C., Wang, Q., & Li, H.",2025,
 "Contact Fatigue of Carbon Steel Gear Under Different Lubrication Conditions","Lubrication Science","37(7)","431-441","10.1002/ls.70006",
 "The ratio of the pitting area to the working surface area under large quantity lubrication condition and insufficient lubrication condition is 0.99% and 0.05% respectively.",
 "Conector Wiley Scholar Gateway, pasaje 10.1002/ls.70006_0010 (sección Discussion)",
 "En engranajes FZG de acero al carbono AISI 1045, la lubricacion abundante dio mas area picada (0,99 %) que la insuficiente (0,05 %); con lubricacion minima el desgaste fue la forma de falla principal y no el picado.",
 "Varia la CANTIDAD de aceite, no la viscosidad ni la mezcla ni el agua. Acero al carbono AISI 1045 (no cementado), engranajes de ensayo cilindricos tipo A. Tres engranajes por condicion. Sus conclusiones son opuestas a la intuicion de que menos lubricante da mas picado: no son transferibles a un piñon cementado.",
 ["H-LUB"],"baja","experimental (banco FZG)")
add(5,"sand","10.1002/ls.1378_0004","Boucherit, H., Bou?Saïd, B., & Lahmar, M.",2017,
 "The effect solid particle lubricant contamination on the dynamic behavior of compliant journal bearings","Lubrication Science","29(7)","425-439","10.1002/ls.1378",
 "The highest wear is observed at the tooth root because at this level we find the greatest sliding and the great flexion rigidity.",
 "Conector Wiley Scholar Gateway, pasaje 10.1002/ls.1378_0004 (sección Introduction, revision de literatura)",
 "Citando a otros autores (Sari; Bouchireb y Sari), el articulo resume que particulas de arena en el aceite causan desgaste notable de engranajes en los primeros ciclos, con el mayor desgaste en la raiz del diente, y que la vibracion del engranaje se acelera por las particulas solidas.",
 "Es una cita secundaria dentro de un articulo teorico sobre cojinetes de deslizamiento; los estudios primarios sobre engranajes NO se leyeron y no estan registrados. El estudio propio es una simulacion de cojinetes, no de engranajes. No trata fatiga a flexion ni cementado.",
 ["H-CONT"],"baja","revision de literatura dentro de un estudio teorico; cita secundaria")
add(6,"oil","10.1155/2015/597841_0010","Baron, P., Kočiško, M., Dobránsky, J., Pollák, M., Cmorej, T., & Bandyopadhyay, A.",2015,
 "Research and Correlation of Diagnostic Methods for Assessment of the State of Oil Filling in Cycloid Gearbox","Advances in Materials Science and Engineering","2015","","10.1155/2015/597841",
 "Induction method in this case does not guarantee the correct quantification of measured Fe particles concentrations (wear particles from contact surfaces).",
 "Conector Wiley Scholar Gateway, pasaje 10.1155/2015/597841_0010 (sección 5. Conclusion)",
 "En reductores cicloidales de un manipulador, el metodo de induccion/magnetico para hierro no es suficientemente sensible a particulas menores de 5 micras ni a particulas no magneticas (oxidos de hierro, compuestos con aditivos), y la medicion de hierro difiere fundamentalmente segun el metodo; los autores recomiendan fluorescencia de rayos X.",
 "Reductor cicloidal de manipulador en rodaje (primeras 600 h), 5 pares, aceites sinteticos PAO y PG; no es un reductor conico de agitador ni aceite mineral con EP. El contenido de hierro se correlaciona con el juego cinematico, no con fatiga de raiz. El umbral de 5 micras proviene del texto de las conclusiones (la unidad se perdio en la extraccion del conector).",
 ["H-MON"],"media","experimental en banco/planta pequena; acceso abierto")
add(7,"oil","10.1002/ls.1650_0011","Ranjan, R., Kumar, S., Ghosh, S. K., & Kumar, M.",2023,
 "Experimental and statistical analysis of wear on gear material","Lubrication Science","35(6)","438-448","10.1002/ls.1650",
 "Wear debris analysis was the most effective tool for the assessment of RULL among FTIR, pinondisc and wear debris analysis.",
 "Conector Wiley Scholar Gateway, pasaje 10.1002/ls.1650_0011 (sección CONCLUSIONS)",
 "En un reductor de 11 kW de una colada continua, el analisis de residuos de desgaste fue la herramienta mas eficaz para estimar la vida util remanente del aceite entre FTIR, pin-sobre-disco y analisis de residuos; ademas, el resumen indica que oxidacion, sulfatacion, hollin y contenido de agua aumentan con el tiempo y reducen esa vida.",
 "Un solo reductor y una serie temporal de muestras; la vida util de aceite obtenida (dias) no es transferible a otro aceite o servicio. No evalua viscosidad ni codigo de limpieza, ni relaciona los parametros con fractura de dientes. 'Mas eficaz' se refiere a la estimacion de vida del aceite, no a deteccion temprana de falla del engranaje.",
 ["H-MON","H-CONT"],"media","experimental con un caso industrial")
add(8,"oil","10.1002/we.1521_0006","Feng, Y., Qiu, Y., Crabtree, C. J., Long, H., & Tavner, P. J.",2012,
 "Monitoring wind turbine gearboxes","Wind Energy","16(5)","728-740","10.1002/we.1521",
 "However, detailed interpretation of oil particle data is tricky, and there are some practical difficulties in selecting suitable sampling size of particle.",
 "Conector Wiley Scholar Gateway, pasaje 10.1002/we.1521_0006 (sección REVIEW OF METHODS FOR MONITORING WT GEARBOXES)",
 "Una revision de monitoreo de cajas de aerogeneradores indica que los contadores de particulas ferrosas y no ferrosas dan informacion util para diagnosticar fallas en rodillos, jaulas o engranajes, pero que la interpretacion detallada de los datos de particulas es dificil y hay problemas practicos para elegir el tamano de muestra.",
 "Revision sobre cajas de aerogeneradores con contador de residuos en linea (no analisis de laboratorio de muestras puntuales). No da umbrales ni sensibilidad/especificidad para ningun parametro.",
 ["H-MON"],"media","revision")
add(9,"oil","10.1002/we.1746_0001","Zhu, J., Yoon, J. M., He, D., & Bechhoefer, E.",2014,
 "Online particle-contaminated lubrication oil condition monitoring and remaining useful life prediction for wind turbines","Wind Energy","18(6)","1131-1149","10.1002/we.1746",
 "For particle contamination, these parameters include viscosity, particle counting, dielectric constant (DC), magnetic susceptibility and so on.",
 "Conector Wiley Scholar Gateway, pasaje 10.1002/we.1746_0001 (sección Introduction)",
 "Los autores describen la contaminacion por particulas, el agua y la oxidacion como tres rasgos basicos de degradacion del aceite, y listan viscosidad, conteo de particulas, constante dielectrica y susceptibilidad magnetica como parametros de desempeno para la contaminacion por particulas; indican que una alta concentracion de hollin puede aumentar la viscosidad del lubricante.",
 "Texto de introduccion; el estudio es de sensores en linea para aerogeneradores. Las cifras que da (p. ej. mas del 80 % del desgaste por particulas, alerta 10 veces antes que la vibracion) son citas de otros autores y NO se registran como hallazgos. La mencion de dioxido de silicio se refiere al hollin y al polvo externo segun el texto; no es evidencia sobre silice mineral en un reductor de planta.",
 ["H-MON","H-CONT"],"media","antecedente en un estudio de sensores en linea")
add(10,"oil","10.1002/we.1512_0008","Dempsey, P. J., & Sheng, S.",2012,
 "Investigation of data fusion applied to health monitoring of wind turbine drivetrain components","Wind Energy","16(4)","479-489","10.1002/we.1512",
 "However, it is hard for oil debris monitoring technique to tell exactly where the damage is located without further particle elemental analysis. For both techniques, extensive data is needed to define accurate thresholds so that reliable diagnostics can be reached.",
 "Conector Wiley Scholar Gateway, pasaje 10.1002/we.1512_0008 (sección OIL-DEBRIS ANALYSIS)",
 "En una caja de engranajes de ensayo con dano, el conteo de residuos ferrosos en linea dio tasas de generacion mucho mayores que con la caja sana (maximo de 11 particulas en 4 h como linea base), pero no localiza el dano sin analisis elemental, y tanto vibracion como residuos requieren muchos datos para fijar umbrales.",
 "Una caja de ensayo con dano inducido, sensor de residuos ferrosos mayores de 350 micras (valor del texto, unidad perdida en la extraccion); los autores no pudieron verificar que los residuos vinieran solo de los engranajes danados. No es comparable a muestreo periodico de laboratorio.",
 ["H-MON"],"media","experimental en banco de ensayo")
add(11,"water","10.1002/ls.1494_0001","Kürten, D., Khader, I., & Kailer, A.",2020,
 "Tribochemical degradation of vacuum-stable lubricants: A comparative study between multialkylated cyclopentane and perfluoropolyether in a vacuum ball-on-disc and full-bearing tests","Lubrication Science","32(4)","183-191","10.1002/ls.1494",
 "Water contamination in lubricants, on the other hand, was reported to significantly reduce bearings life.",
 "Conector Wiley Scholar Gateway, pasaje 10.1002/ls.1494_0001 (sección INTRODUCTION)",
 "Los autores resumen, citando a otros, que el hidrogeno en aceros de rodadura (cojinetes y engranajes) se asocia a fragilizacion y a fallas tempranas por grietas blancas, y que el agua en el lubricante reduce de forma significativa la vida de los cojinetes y, junto con residuos metalicos frescos (cobre, hierro), acelera la oxidacion del aceite.",
 "Es introduccion de un estudio con lubricantes para vacio en bola-sobre-disco y cojinetes completos: las afirmaciones sobre el agua son citas de terceros, no resultados propios, y se refieren a cojinetes. No se leyeron las fuentes primarias. No cuantifica contenido de agua ni vida en engranajes.",
 ["H-CONT","H-LUB"],"baja","antecedente citado de segunda mano")
add(12,"water","10.1002/sia.4853_0001","Nedelcu, I., Piras, E., Rossi, A., & Pasaribu, H. R.",2012,
 "XPS analysis on the influence of water on the evolution of zinc dialkyldithiophosphate-derived reaction layer in lubricated rolling contacts","Surface and Interface Analysis","44(8)","1219-1224","10.1002/sia.4853",
 "There is a consensus that low amounts or even no water in lubricating oil is desirable for optimal bearing performance to be achieved.",
 "Conector Wiley Scholar Gateway, pasaje 10.1002/sia.4853_0001 (sección Introduction)",
 "Los autores indican que hay consenso en que el aceite debe tener poca o ninguna agua para el mejor desempeno de cojinetes, que el agua dispersa puede interactuar con los aditivos y degradarlos, y citan que aditivos EP/AW de azufre-fosforo pueden reducir la vida a fatiga de cojinetes en un factor de 4,5 respecto al aceite base solo por su reactividad quimica.",
 "Texto de introduccion con citas de terceros (no se leyeron las fuentes primarias); el estudio propio es de analisis de superficie (XPS) de la capa de reaccion del aditivo ZDDP en contactos de rodadura acero-acero con 0,5 a 2 % de agua. Se refiere a cojinetes, no a engranajes conicos ni a mezclas de grados.",
 ["H-CONT","H-LUB"],"baja","antecedente citado; estudio de quimica de superficie")
add(13,"water","10.1002/jsl.3000060103_0000","Sullivan, J. L., & Middleton, M. R.",1989,
 "The mechanisms governing crack and pit formation in steel in rolling sliding contact in aqueous lubricants","Journal of Synthetic Lubrication","6(1)","17-30","10.1002/jsl.3000060103",
 "It has been shown that pitting life depends on the relative magnitude of fluid film thickness and the lubrication regime in which the system is operated. A minimum in pitting life is shown to occur in the mixedelastohydrodynamic region.",
 "Conector Wiley Scholar Gateway, pasaje 10.1002/jsl.3000060103_0000 (sección Abstract)",
 "Segun el resumen, la vida al picado de superficies de acero en rodadura-deslizamiento con fluidos acuosos depende de la relacion entre el espesor de pelicula y la rugosidad (regimen de lubricacion), con un minimo de vida en la region elastohidrodinamica mixta.",
 "Solo resumen (abstract). Fluidos resistentes al fuego de agua-glicol (fluidos acuosos), NO aceite mineral con agua contaminante ni gear oil; articulo de 1989. Apoya la dependencia del picado con el regimen de pelicula, no el efecto de un porcentaje de agua en aceite de engranajes.",
 ["H-LUB","H-CONT"],"baja","experimental (rodadura-deslizamiento)",acceso="abstract")
add(14,"water","10.1002/ls.1453_0000","Cen, H., Morina, A., & Neville, A.",2019,
 "Effect of base oil polarity on the micropitting behaviour in rolling-sliding contacts","Lubrication Science","31(4)","113-126","10.1002/ls.1453",
 "The asperity contact stress was also considered to be a main factor to promote the formation of micropits, thus this contact fatigue phenomenon can be retarded by the increase of lambda ratio or reduce of surface roughness.",
 "Conector Wiley Scholar Gateway, pasaje 10.1002/ls.1453_0000 (sección INTRODUCTION)",
 "En la introduccion se recoge que el micropitting aumenta con la tension de contacto entre asperezas y puede retardarse aumentando la relacion lambda (espesor de pelicula sobre rugosidad) o reduciendo la rugosidad; el resumen del estudio indica que el aceite base polar (ester) dio mas desgaste y menos microhoyuelos que el no polar (PAO) con los mismos aditivos.",
 "Maquina de micropitting de tres puntos con probetas de rodadura-deslizamiento, no engranajes. La relacion lambda es un concepto de la introduccion (cita de terceros); el estudio no mide viscosidad ni mezcla de grados ni agua. Los resultados dependen del par base-aditivo, no son generalizables a un ISO 320 con EP.",
 ["H-LUB"],"media","experimental (banco de micropitting) con antecedente citado")
json.dump(E,open("/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/caso_agitador/evidencia/frente_B.json","w"),ensure_ascii=False,indent=1)
print(len(E))

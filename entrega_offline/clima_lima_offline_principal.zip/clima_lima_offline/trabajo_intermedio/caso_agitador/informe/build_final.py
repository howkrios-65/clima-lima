import json, sys, re, datetime as dt
sys.path.insert(0, '/home/user/clima-lima/tools/reliability')
from reliability_kit import Ledger
from reliability_kit import report_html as rh
SP = '/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/'
L = Ledger(); DUP = []; frente = {}
for f in 'ABCDE':
    for e in json.load(open(SP + f'caso_agitador/evidencia/frente_{f}.json')):
        try: L.add(e); frente[e['id']] = f
        except Exception as ex:
            if 'ya está registrado' in str(ex): DUP.append(e['id'])
            else: raise
NOM = {'A': 'Mecanismo de falla del piñón cónico cementado', 'B': 'Lubricante y contaminación', 'C': 'Cargas de choque y arranque',
       'D': 'Monitoreo de condición y detección', 'E': 'Metodología de causa raíz'}
hall = []; k = 0
for f in 'ABCDE':
    ids = [i for i in L.entradas if frente[i] == f and L.nivel_de(i) in ('VERIFICADO-TEXTO', 'VERIFICADO-ABSTRACT')][:3]
    for i in ids:
        e = L.get(i); k += 1
        hall.append({"id": f"H{k}", "texto": f"[{NOM[f]}] {e['afirma']} Límites: {e['limites']}", "evidencia": [i]})
agentes = []
for p in sorted(__import__('pathlib').Path('/home/user/clima-lima/.claude/agents').glob('reliability-*.md')):
    t = p.read_text(encoding='utf-8'); d = re.search(r"description: (.*)", t).group(1); tools = re.search(r"tools: (.*)", t).group(1)
    tools = re.sub(r"Agent\([^)]*\)", "Agent(...)", tools)
    agentes.append([p.stem, d.split('. ')[0][:170], tools[:90]])
caso = {
 "meta": {"titulo": "Investigación y sistema de agentes de confiabilidad: biblioteca de evidencia", "activo": "Sin caso: los datos de ejemplo del usuario son ilustrativos y no se usan",
          "origen_datos": "literatura leída por el equipo; ningún dato de planta", "n_fallas": 0},
 "resumen": {"kpis": [{"label": "fuentes leídas y registradas", "valor": str(len(L.entradas)), "evidencia": [next(iter(L.entradas))]},
                      {"label": "agentes del equipo", "valor": str(len(agentes) )}, {"label": "duplicados omitidos", "valor": str(len(DUP))}],
             "hallazgos": hall},
 "tablas": [
  {"titulo": "Equipo de agentes (descripción del propio sistema, no afirmación científica)", "columnas": ["Agente", "Función", "Herramientas"], "filas": agentes, "evidencia": []},
  {"titulo": "Acceso medido a fuentes en este entorno", "columnas": ["Vía", "Estado", "Qué entrega"],
   "filas": [["Conector de texto completo (Wiley)", "Funciona; cuota gratuita casi agotada", "Fragmentos de texto de artículos"],
             ["Lector de preprints (Hugging Face)", "Funciona", "Texto de preprints por identificador"],
             ["Búsqueda web", "Funciona", "Solo resúmenes de buscador (snippet)"],
             ["Scopus, ScienceDirect, Springer, IEEE, Google Scholar, Crossref, OpenAlex", "Bloqueado por la red", "Nada"],
             ["Repositorios de universidades (MIT, Harvard, Mines, Stanford, universidades del Perú y de los países priorizados)", "Bloqueado por la red", "Nada"],
             ["Scribd, LinkedIn, YouTube", "No accesible", "Nada; serían solo pistas"]], "evidencia": []},
  {"titulo": "Prioridad geográfica indicada", "columnas": ["País", "Estado de cobertura"],
   "filas": [[c, "VACÍO declarado: repositorios no accesibles desde este entorno"] for c in ["Chile", "Perú", "Australia", "Estados Unidos", "México", "Brasil", "Finlandia", "Reino Unido", "Suiza", "Alemania", "Canadá"]], "evidencia": []}],
 "vacios": ["Ningún modo de falla nuevo se investigó todavía: el dossier se activa con /modo-de-falla.",
            "Las fuentes aquí listadas se leyeron para un caso de ejemplo (piñón cónico cementado de agitador); su comparabilidad con otro componente debe evaluarse.",
            "Sin acceso a Scopus, repositorios universitarios, Scribd, LinkedIn ni YouTube: la cobertura por país y universidad es VACÍO.",
            "Los cuartiles de revista no se verificaron.", "Sin datos de planta: no hay Weibull, línea base ni recurrencia que mostrar."],
 "supuestos": ["Los datos de ejemplo del usuario son ilustrativos y se excluyeron de este informe."],
 "preguntas": ["¿Habilita los dominios académicos en la configuración de red del entorno? Con eso los investigadores podrían leer tesis, libros y repositorios.",
               "¿Qué primer modo de falla investigamos (por ejemplo, chumacera de polea de faja transportadora)?",
               "Si el repositorio es compartido, ¿autoriza guardar casos en él, o se mantienen solo locales?"],
 "historial": [{"version": "v1", "fecha": dt.date.today().isoformat(), "cambio": "Biblioteca inicial de evidencia y catálogo de agentes", "baseline": "No aplica: sin datos de falla"}],
 "recurrencia": {"detectada": False, "texto": "Sin casos reales en el historial."},
}
r = rh.construir_informe(caso, L, SP + 'caso_agitador/informe/informe_final.html')
print(r['ajustes'], r['resumen_evidencia']['total'], len(agentes))

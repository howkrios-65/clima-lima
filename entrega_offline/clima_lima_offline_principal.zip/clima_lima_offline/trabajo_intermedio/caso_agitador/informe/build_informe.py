import json, sys, datetime as dt
sys.path.insert(0, '/home/user/clima-lima/tools/reliability')
import numpy as np
from reliability_kit import Ledger, signals
from reliability_kit import report_html as rh

SP = '/tmp/claude-0/-home-user-clima-lima/5d78240e-f4f2-5b7a-9ab4-8fd5b0b1815f/scratchpad/'
D = json.load(open(SP + 'caso_usuario_DATA.json'))
HOY = dt.date.today().isoformat()

# ---------- registro: literatura (frentes A-E) + datos aportados ----------
L = Ledger(); DUP = []
for f in 'ABCDE':
    for e in json.load(open(SP + f'caso_agitador/evidencia/frente_{f}.json')):
        try:
            L.add(e)
        except Exception as ex:
            if 'ya está registrado' in str(ex):
                DUP.append(e['id'])
            else:
                raise
print('duplicados omitidos (misma fuente leída por dos frentes):', DUP)

def usuario(i, titulo, afirma, limites):
    L.add({"id": f"E-{i}", "tipo": "dato_usuario", "fecha_acceso": HOY, "referencia": {"titulo": titulo},
           "afirma": afirma, "limites": limites})

LIM = "Aportado por el usuario en un informe HTML; no se verificó contra el sistema de origen y no se sabe si es real o ilustrativo."
usuario(9001, "Series en línea de vibración y temperatura (120 días, un punto)", "Velocidad RMS, envolvente y temperatura de carcasa diarias del punto R1H.", LIM)
usuario(9002, "Series de proceso (120 días)", "Densidad de pulpa, tonelaje, corriente promedio y pico, horas y número de arranques diarios.", LIM)
usuario(9003, "Cinco informes de análisis de aceite", "Agua, viscosidad, hierro, índice PQ, silicio, ISO 4406 y TAN en cinco fechas.", LIM)
usuario(9004, "Registro de 47 órdenes de trabajo", "Órdenes de mantenimiento preventivo, predictivo y correctivo del periodo, con estado y comentarios.", LIM)
usuario(9005, "Bitácora de 23 eventos", "Eventos de operación, mantenimiento y predictivo del 1 jun al 30 sep, incluida la inspección posterior a la falla.", LIM)
usuario(9006, "Rutas de vibración y termografía", "20 registros de vibración offline y 25 de termografía, con diagnósticos del analista.", LIM)
usuario(9007, "Afirmaciones del informe original sin soporte adjunto", "Aislamiento del motor 2,4 GΩ y giro libre; comparación con otros cinco agitadores; inexistencia de procedimiento de desembancado.", LIM + " No se recibieron las mediciones ni los documentos.")

# ---------- cálculos con el kit ----------
o, p = D['online'], D['proc']
vel = np.array(o['vel_rms_mm_s'], float); env = np.array(o['acel_envolvente_gE'], float)
dens = np.array(p['densidad_pulpa_pct_sol'], float); ia = np.array(p['corriente_prom_A'], float)
fechas = o['fecha']; fi = fechas.index('2026-09-28')
det = signals.deteccion_retrospectiva(fechas, vel, 30, 3.0, indice_falla=fi, persistencia=3)
rho = signals.spearman_bootstrap(dens, ia, seed=1)
i_byp = fechas.index('2026-08-27')
i12 = fechas.index('2026-08-12')
cmp_ia = signals.comparar_periodos(ia[:i12], ia[i12:i_byp], seed=1)
cmp_byp = signals.comparar_periodos(ia[i12:i_byp], ia[i_byp:i_byp + 30], seed=1)
rho_a = signals.spearman_bootstrap(dens[:i12], ia[:i12], seed=1); rho_d = signals.spearman_bootstrap(dens[i12:], ia[i12:], seed=1)
mk = signals.mann_kendall(vel[:fi])

# ---------- caso ----------
ac = D['aceite']
red = lambda a, b: round((b - a) / a * 100)
n_abiertas = [o for o in D['ot'] if o['estado'] != 'Cerrada']
def tipo_ev(b):
    f, a, t = b['fecha_hora'], b['area'], b['evento']
    if f.startswith('2026-09-28 03:40') or f.startswith('2026-09-28 07:30'): return 'hito'
    if a in ('Predictivo', 'Lubricación'): return 'medicion'
    if f.startswith('2026-09-30') or 'Relleno' in t or 'respirador estándar' in t: return 'accion'
    return 'bitacora'
linea = []
for b in D['bit']:
    ev = ['E-9005'] + (['E-9003'] if b['area'] == 'Lubricación' else []) + (['E-9006'] if b['area'] == 'Predictivo' else [])
    linea.append({"fecha": b['fecha_hora'], "tipo": tipo_ev(b), "titulo": f"{b['area']}", "detalle": b['evento'].replace("Zona Norte", "zona de mineral arcilloso"), "evidencia": ev})
for a in ac:
    linea.append({"fecha": a['fecha_muestra'] + " 00:00", "tipo": "medicion", "titulo": "Muestra de aceite",
                  "detalle": f"agua {a['agua_ppm']} ppm · viscosidad {a['visc_40C_cSt']} cSt · Fe {a['Fe_ppm']} ppm · PQ {a['PQ_index']} · {a['ISO4406']}", "evidencia": ["E-9003"]})
for oo in n_abiertas:
    linea.append({"fecha": oo['fecha_creacion'] + " 00:00", "tipo": "ot", "titulo": f"OT {oo['OT']} · {oo['estado']}",
                  "detalle": oo['descripcion'], "evidencia": ["E-9004"]})

def serie(id_, titulo, unidad, fechas_, vals, ev):
    return {"id": id_, "titulo": titulo, "unidad": unidad, "base_n": 30, "k": 3, "persistencia": 3, "evidencia": ev,
            "puntos": [[f, round(float(v), 3)] for f, v in zip(fechas_, vals)]}
series = [
    serie("vel", "Velocidad de vibración RMS, punto R1H (en línea)", "mm/s", o['fecha'], o['vel_rms_mm_s'], ["E-9001"]),
    serie("env", "Aceleración de envolvente, punto R1H", "gE", o['fecha'], o['acel_envolvente_gE'], ["E-9001"]),
    serie("tc", "Temperatura de carcasa", "°C", o['fecha'], o['temp_carcasa_C'], ["E-9001"]),
    serie("den", "Densidad de pulpa", "% sólidos", p['fecha'], p['densidad_pulpa_pct_sol'], ["E-9002"]),
    serie("cor", "Corriente promedio del motor", "A", p['fecha'], p['corriente_prom_A'], ["E-9002"]),
    serie("arr", "Arranques por día", "n", p['fecha'], p['n_arranques'], ["E-9002"]),
]

tablas = [
    {"titulo": "Análisis de aceite del reductor (5 muestras)", "evidencia": ["E-9003"],
     "columnas": ["Muestra", "Viscosidad 40 °C (cSt)", "Agua (ppm)", "Fe (ppm)", "PQ", "Si (ppm)", "ISO 4406", "TAN", "Condición según el laboratorio"],
     "filas": [[a['fecha_muestra'], a['visc_40C_cSt'], a['agua_ppm'], a['Fe_ppm'], a['PQ_index'], a['Si_ppm'], a['ISO4406'], a['TAN_mgKOH_g'], a['condicion']] for a in ac],
     "nota": f"Variación primera a última muestra: viscosidad {red(ac[0]['visc_40C_cSt'], ac[-1]['visc_40C_cSt'])} %, agua ×{ac[-1]['agua_ppm']/ac[0]['agua_ppm']:.1f}, Fe ×{ac[-1]['Fe_ppm']/ac[0]['Fe_ppm']:.1f}. La última muestra es posterior a la falla."},
    {"titulo": "Órdenes y avisos sin cierre antes de la falla", "evidencia": ["E-9004"],
     "columnas": ["OT", "Creada", "Tipo", "Descripción", "Estado", "Comentario"],
     "filas": [[o_['OT'], o_['fecha_creacion'], o_['tipo'], o_['descripcion'], o_['estado'], o_['comentario']] for o_ in n_abiertas],
     "nota": f"{len(n_abiertas)} registros no cerrados al 28-sep (conteo directo de los datos aportados)."},
]

pf = lambda f: signals.primer_cruce  # (no se usa)
hall = [
    {"id": "H1", "texto": f"En la vibración en línea (R1H), con línea base de los primeros 30 días (mediana {det['linea_base']['mediana']:.2f} mm/s, sigma robusta {det['linea_base']['sigma']:.2f}), la serie cruza 3 sigma con persistencia de 3 días el {det['fecha_alarma_umbral']} ({det['dias_antelacion_umbral']} días antes del evento) y el CUSUM alarma el {det['fecha_alarma_cusum']} ({det['dias_antelacion_cusum']} días antes). Es una detección retrospectiva con un solo evento: no estima falsas alarmas ni valida un umbral. El informe original habla de 54 días con otro criterio.", "evidencia": ["E-9001"]},
    {"id": "H2", "texto": f"El aceite muestra agua de {ac[0]['agua_ppm']} a {ac[-1]['agua_ppm']} ppm, viscosidad de {ac[0]['visc_40C_cSt']} a {ac[-1]['visc_40C_cSt']} cSt ({red(ac[0]['visc_40C_cSt'], ac[-1]['visc_40C_cSt'])} %) y hierro de {ac[0]['Fe_ppm']} a {ac[-1]['Fe_ppm']} ppm; la última muestra es posterior a la falla. Es degradación observada, no prueba por sí sola que causó la fractura.", "evidencia": ["E-9003"]},
    {"id": "H3", "texto": f"Densidad de pulpa y corriente promedio se asocian en toda la serie (Spearman {rho['rho']:.2f}, n = {rho['n']}), pero eso refleja sobre todo que ambas saltan el 12-ago. Dentro de cada régimen la asociación es menor: {rho_a['rho']:.2f} antes (IC [{rho_a['ic'][0]:.2f}; {rho_a['ic'][1]:.2f}], n = {rho_a['n']}) y {rho_d['rho']:.2f} después (IC [{rho_d['ic'][0]:.2f}; {rho_d['ic'][1]:.2f}], n = {rho_d['n']}). Los intervalos son optimistas porque las series diarias están autocorrelacionadas; asociación no es causa.", "evidencia": ["E-9002"]},
    {"id": "H4", "texto": f"La corriente promedio sube de una mediana de {cmp_ia['mediana_antes']:.1f} A a {cmp_ia['mediana_despues']:.1f} A el 12-ago (desplazamiento de Hodges-Lehmann {cmp_ia['desplazamiento_hl']:.1f} A), el mismo día en que la densidad sube de 44,9 a 50,2 % sólidos. Después del bypass del 27-ago no hay escalón adicional ({cmp_byp['mediana_antes']:.1f} A frente a {cmp_byp['mediana_despues']:.1f} A en 30 días; IC de la diferencia [{cmp_byp['ic_dif_medianas'][0]:.1f}; {cmp_byp['ic_dif_medianas'][1]:.1f}]). El aumento de corriente coincide con la densidad, no con el bypass; la corriente promedio de régimen tampoco captura el pico de arranque.", "evidencia": ["E-9002", "E-9005"]},
    {"id": "H5", "texto": f"{len(n_abiertas)} registros de mantenimiento no estaban cerrados al 28-sep (4 de seguimiento predictivo en backlog o programados, 2 correctivos en espera de repuesto, 1 cambio de aceite postergado y 1 aviso sin orden), incluida la recomendación de boroscopía del 2-sep y el cambio de aceite postergado dos veces.", "evidencia": ["E-9004", "E-9005"]},
    {"id": "H6", "texto": "La literatura leída respalda los eslabones por separado: del micropitting al macropicado en engranajes cementados (E-1002) y de la fatiga de contacto a la fractura por flexión en cónicos grandes cementados (E-1001, E-1011). No se halló estudio que una micropitting con fractura por flexión en un cónico, ni sobre mezcla ISO 220 en ISO 320 con EP, ni sobre agua o sílice en cónicos cementados.", "evidencia": ["E-1001", "E-1002", "E-1011"]},
    {"id": "H7", "texto": "En cajas de aerogenerador se midió carga de impacto en los dientes durante inversiones de par por pérdida de red (E-3002, E-3003); extrapolarlo al arranque directo de un agitador no está medido. Una introducción de simulación señala que con el agitador detenido y sólidos asentados el impulsor inferior soporta fuerza significativa (E-3014, sin resultados leídos). No se halló medición de arranque directo con tanque embancado ni comparación frente a arrancador suave en este conector.", "evidencia": ["E-3002", "E-3003", "E-3014"]},
    {"id": "H8", "texto": "Según la correspondencia del informe original, RC1 y RC2 convergen en 8 de 8 técnicas, RC3 en 7 de 8 y RC4 en 5 de 8, pero casi todas se alimentan de las mismas cinco fuentes de información (bitácora, órdenes, aceite, vibración y proceso), y Kepner-Tregoe depende de datos no recibidos. La literatura leída critica usar los 5 porqués como herramienta única; no mide si combinar técnicas mejora la validez.", "evidencia": ["E-5002"]},
]
kpis = [
    {"label": "días entre primera alarma (3 sigma) y evento, retrospectivo", "valor": str(det['dias_antelacion_umbral']), "evidencia": ["E-9001"]},
    {"label": "agua en aceite, última muestra (ppm)", "valor": str(ac[-1]['agua_ppm']), "evidencia": ["E-9003"]},
    {"label": "variación de viscosidad a 40 °C", "valor": f"{red(ac[0]['visc_40C_cSt'], ac[-1]['visc_40C_cSt'])} %", "evidencia": ["E-9003"]},
    {"label": "Spearman densidad–corriente", "valor": f"{rho['rho']:.2f}", "evidencia": ["E-9002"]},
    {"label": "arranques el día de la falla", "valor": str(p['n_arranques'][fi]), "evidencia": ["E-9002", "E-9005"]},
    {"label": "registros de mantenimiento sin cerrar al 28-sep", "valor": str(len(n_abiertas)), "evidencia": ["E-9004"]},
]
hip = [
    {"id": "HIP1", "titulo": "Agua en el aceite y caída de viscosidad, según los informes de laboratorio aportados (datos no verificados; su papel causal es HIP3). Mezcla de grados: solo 'posible' según el laboratorio y rellenos de 14 L; el −21 % de viscosidad es mayor que lo que explicaría ese relleno", "tipo": "física", "estado": "confirmada",
     "apoyo_caso": ["E-9003", "E-9005"], "apoyo_literatura": ["E-1006", "E-1010"], "contradice": ["E-1005"]},
    {"id": "HIP2", "titulo": "Impacto por rearranques directos con el tanque embancado (3 arranques registrados el 28-sep; no hay torque medido; hubo 13 arranques directos previos desde el 27-ago sin falla)", "tipo": "física", "estado": "probable",
     "apoyo_caso": ["E-9002", "E-9005"], "apoyo_literatura": ["E-3002", "E-3003", "E-3013"], "contradice": []},
    {"id": "HIP3", "titulo": "Fatiga a flexión en la raíz iniciada por picado y/o micropitting (solo se documenta picado en la corona; sin fractografía ni metalurgia en lo recibido)", "tipo": "física", "estado": "probable",
     "apoyo_caso": ["E-9005", "E-9006", "E-9003"], "apoyo_literatura": ["E-1001", "E-1002", "E-1011", "E-1013"], "contradice": []},
    {"id": "HIP4", "titulo": "Aumento de la corriente promedio por mayor densidad sin gestión del cambio (no hay corriente nominal ni torque: sobrecarga no demostrada)", "tipo": "física/latente", "estado": "posible",
     "apoyo_caso": ["E-9002", "E-9005"], "apoyo_literatura": [], "contradice": []},
    {"id": "HIP5", "titulo": "Recomendaciones predictivas sin cierre (bucle abierto)", "tipo": "latente", "estado": "confirmada",
     "apoyo_caso": ["E-9004", "E-9005"], "apoyo_literatura": [], "contradice": []},
    {"id": "HIP6", "titulo": "Defecto de material del piñón (el informe original lo descarta por desgaste progresivo, lo que no lo excluye; falta ensayo)", "tipo": "física", "estado": "posible",
     "apoyo_caso": [], "apoyo_literatura": [], "contradice": ["E-9003"]},
    {"id": "HIP7", "titulo": "Error de montaje o alineamiento (sin ensayo; el informe original lo descarta por falta de intervención interna)", "tipo": "física", "estado": "posible",
     "apoyo_caso": [], "apoyo_literatura": [], "contradice": ["E-9005"]},
    {"id": "HIP8", "titulo": "Falla eléctrica del motor (el informe original cita aislamiento 2,4 GΩ y giro libre, sin mediciones adjuntas; la bitácora es consistente pero no la excluye)", "tipo": "eléctrica", "estado": "posible",
     "apoyo_caso": ["E-9005", "E-9004"], "apoyo_literatura": [], "contradice": []},
]
ALL = ["bitacora", "ot", "aceite", "vibracion", "proceso"]
tec = [
    {"id": "TL", "nombre": "Línea de tiempo", "raices": ["RC1", "RC2", "RC3", "RC4"], "insumos": ALL, "evidencia": [],
     "hallazgo": "Ordena los hechos con fecha y fuente. Base de las demás técnicas, por eso no aporta independencia.", "pasos": [x.replace("4 alertas", "5 alertas") for x in D['metodos'][0]['pasos']]},
    {"id": "5P", "nombre": "5 porqués", "raices": ["RC1", "RC2", "RC3"], "insumos": ["bitacora", "ot", "aceite"], "evidencia": ["E-5002", "E-5004", "E-5006"],
     "hallazgo": "Dos ramas (lubricación y sobrecarga). La literatura critica su profundidad arbitraria y su cadena causal única.", "pasos": [x.replace("Agua 2 900 ppm", "Agua 2 310 ppm antes de la falla") for x in D['metodos'][1]['pasos']]},
    {"id": "ISH", "nombre": "Ishikawa 6M", "raices": ["RC1", "RC2", "RC3", "RC4"], "insumos": ALL, "evidencia": ["E-5001", "E-5003"],
     "hallazgo": "Organiza causas posibles; por sí solo no identifica la causa raíz. Cada causa necesita evidencia propia.", "pasos": [x.replace("rearme de protección 3 veces", "rearme de protección antes del 3.er arranque") for x in D['metodos'][2]['pasos']]},
    {"id": "PRO", "nombre": "Árbol lógico", "raices": ["RC1", "RC2", "RC3", "RC4"], "insumos": ["aceite", "vibracion", "proceso", "bitacora"], "evidencia": [],
     "hallazgo": "Cada hipótesis física exige una prueba. Aquí no hay fractografía ni metalurgia: las hipótesis de material y montaje quedan abiertas, no descartadas.", "pasos": ["Pasos del informe original, no verificados: material y montaje descartados sin ensayo; aquí quedan como posibles"]},
    {"id": "FTA", "nombre": "Árbol de fallas", "raices": ["RC1", "RC2", "RC3"], "insumos": ["bitacora", "ot", "aceite"], "evidencia": [],
     "hallazgo": "Puerta AND entre resistencia reducida, carga excesiva y detección fallida (según el informe original). No se cuantificó: no hay tasas de falla de cada rama.", "pasos": D['metodos'][4]['pasos']},
    {"id": "KT", "nombre": "Kepner-Tregoe", "raices": ["RC1", "RC2"], "insumos": ["informe_original"], "evidencia": [],
     "hallazgo": "Depende de datos de otros cinco agitadores que no se recibieron (E-9007). Sin esos datos es una hipótesis, no un hallazgo.", "pasos": ["Pasos del informe original, no verificados: dependen de datos de otros cinco agitadores no recibidos"]},
    {"id": "BAR", "nombre": "Análisis de barreras", "raices": ["RC1", "RC2", "RC3", "RC4"], "insumos": ["vibracion", "aceite", "ot", "bitacora"], "evidencia": ["E-5014", "E-5016"],
     "hallazgo": "La barrera técnica de monitoreo detectó; fallaron las organizacionales. El modelo del queso suizo es marco conceptual, sin validación empírica en planta en lo leído.", "pasos": D['metodos'][6]['pasos']},
    {"id": "APO", "nombre": "Apollo (causa-efecto)", "raices": ["RC1", "RC2", "RC3", "RC4"], "insumos": ["bitacora", "ot", "aceite", "vibracion"], "evidencia": [],
     "hallazgo": "Muestra que eliminar solo el arranque directo no habría bastado si el piñón ya estaba dañado (no hay inspección previa que lo confirme).", "pasos": D['metodos'][7]['pasos']},
]
raices = [
    {"id": "RC1", "titulo": "Lubricación sin control de contaminación ni de grado", "descripcion": "Respirador sin desecante tras el 2-jul, rellenos con otro grado el 27-jul y el 17-ago, cambio de aceite postergado dos veces.", "evidencia": ["E-9003", "E-9004", "E-9005"]},
    {"id": "RC2", "titulo": "Cambios de proceso y arranque sin gestión del cambio", "descripcion": "Densidad objetivo a 50 % el 12-ago, bypass a arranque directo el 27-ago, solicitud de subir la alarma de corriente el 5-sep.", "evidencia": ["E-9002", "E-9005"]},
    {"id": "RC3", "titulo": "Recomendaciones predictivas sin cierre", "descripcion": "Registros de seguimiento en backlog; alarma en línea a un buzón genérico sin acuse.", "evidencia": ["E-9004", "E-9005"]},
    {"id": "RC4", "titulo": "Sin procedimiento de rearranque tras corte", "descripcion": "La bitácora muestra tres arranques sin desembancado. La inexistencia del procedimiento se afirma en el informe original y no está documentada (E-9007).", "evidencia": ["E-9005", "E-9007"]},
]
plan = [{"id": c['id'], "accion": c['a'], "tipo": c['tipo'], "causa": c['rc'], "responsable": c['r'], "fecha": c['f'] + " (propuesta original, a reprogramar)", "verificacion": c['kpi'] + " (umbral propuesto, sin fuente)",
         "evidencia": ["E-9005"] if c['rc'] != 'RC1' else ["E-9003", "E-9005"]} for c in D['capa']]

caso = {
    "meta": {"titulo": "ACR del piñón cónico de un reductor de agitador: dientes barridos", "activo": "Reductor RED-AG-301, agitador TK-301",
             "fecha_evento": "2026-09-28", "origen_datos": "aportado por el usuario (real o ilustrativo, por confirmar)", "n_fallas": 1},
    "resumen": {"kpis": kpis, "hallazgos": hall},
    "linea_tiempo": linea, "series": series, "tablas": tablas, "hipotesis": hip, "tecnicas": tec, "raices": raices, "plan": plan,
    "vida": None,
    "vacios": [
        "Un solo evento: no se puede ajustar Weibull, estimar recurrencia ni fijar una línea base de la familia de falla.",
        "No hay torque ni corriente instantánea de arranque medidos: no se puede cuantificar el impacto del rearranque.",
        "No hay fractografía, metalurgia, dureza ni profundidad de capa cementada en lo recibido: material y montaje no están descartados.",
        "En el conector Wiley (único con texto completo disponible) no se halló estudio sobre mezcla ISO 220 en ISO 320 con EP, agua o sílice en cónicos cementados con cifras, arranque directo frente a arrancador suave con carga sedimentada, ni rearranques repetidos. No se consultaron otras bases, literatura de fabricantes de lubricantes ni normas.",
        "No se halló estudio empírico sobre si combinar técnicas de ACR mejora la validez. Kepner-Tregoe y Apollo no se buscaron específicamente.",
        "Casi toda la evidencia científica leída proviene de cajas de aerogenerador, bancos de ensayo de engranajes cilíndricos y salud/seguridad de procesos; la comparabilidad con un cónico cementado de agitador es baja o media.",
        "Los cuartiles de revista no se pudieron verificar (el sitio de rankings está bloqueado en este entorno).",
        "Acceso bloqueado por la red a Scopus, ScienceDirect, Springer, IEEE, Google Scholar y repositorios universitarios; el conector de texto completo tiene cuota limitada.",
        "Los costos, los 'agentes', los debates y los puntajes del informe original son narrativa sin fuente y no se usaron.",
    ],
    "supuestos": [
        "La línea base de vibración son los primeros 30 días (el informe original indica que junio era normal); umbral de 3 sigma robusta y persistencia de 3 días son ajustables en la pestaña Señales.",
        "Las series diarias se tomaron tal como se recibieron, sin corregir huecos ni cambios de sensor.",
        "Las 'causas raíz' RC1 a RC4 y la correspondencia técnica por causa son las del informe original; aquí se muestran con las fuentes de información que cada técnica usa, que es una síntesis del equipo.",
    ],
    "preguntas": [
        "¿Los datos adjuntos son reales o ilustrativos? De eso depende todo lo demás.",
        "¿Existen fotos, fractografía o ensayos metalúrgicos del piñón y la corona?",
        "¿Hay registro de corriente o torque durante los tres arranques de la madrugada del 28-sep?",
        "¿Hay historial de los otros agitadores del mismo tipo para construir una línea base de la familia?",
        "¿Puede guardarse este caso en el historial del equipo, y en el repositorio o solo localmente?",
    ],
    "historial": [{"version": "v1", "fecha": HOY, "cambio": "Primer registro del caso con 1 evento", "baseline": "VACÍO: un solo evento no permite ajustar una distribución"}],
    "recurrencia": {"detectada": False, "texto": "Sin casos previos en el historial: no se puede afirmar recurrencia ni actualizar una línea base."},
    "busqueda": {"frentes": ["A mecanismo de falla del piñón", "B lubricante y contaminación", "C cargas de choque y arranque", "D monitoreo de condición", "E metodología de ACR"],
                 "fuentes_en_registro": len(L.entradas), "duplicados_omitidos": DUP},
}

# ---------- memoria de casos (fuera del repositorio) ----------
from reliability_kit import CaseStore, familia_de
store = CaseStore(SP + 'caso_agitador/historial')
reg = {"id": "ACR-2026-014", "titulo": caso['meta']['titulo'], "activo_clase": "reductor de agitador, engranaje cónico", "modo_falla": "rotura de dientes del piñón",
       "unidad": "RED-AG-301", "fecha_falla": "2026-09-28", "mecanismos": ["micropitting", "fatiga a flexión", "contaminación del lubricante", "impacto de arranque"],
       "causas_raiz": [{"id": r["id"], "titulo": r["titulo"]} for r in raices]}
try:
    store.registrar_caso(reg)
except Exception as ex:
    print('registro:', ex)
print('recurrencia:', store.buscar_recurrencia(reg))
try:
    print('linea base:', store.actualizar_linea_base(familia_de(reg), 'primer caso'))
except Exception as ex:
    print('linea base:', type(ex).__name__, ex)

res = rh.construir_informe(caso, L, SP + 'caso_agitador/informe/informe_acr.html')
print('ajustes:'); [print(' -', a['donde'], a['tipo'], a.get('a', ''), '|', a['detalle'][:100]) for a in res['ajustes']]
print(res['resumen_evidencia']); print({r: v['n'] for r, v in res['convergencia']['por_raiz'].items()}, {r: v['fuentes_distintas'] for r, v in res['convergencia']['por_raiz'].items()})

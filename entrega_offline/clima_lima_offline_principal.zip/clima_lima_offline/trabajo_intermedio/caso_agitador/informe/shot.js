const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1200,height:900}});const errs=[];
p.on('pageerror',e=>errs.push(String(e)));p.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
p.on('request',r=>{if(!/^(file|data):/.test(r.url()))errs.push('red:'+r.url())});
await p.goto('file://'+process.argv[2]);
const tabs=await p.$$eval('#tabs button',x=>x.map(y=>y.textContent));console.log(tabs.join(' | '));
for(const t of tabs){await p.click('#tabs button:has-text("'+t+'")');const id=await p.$eval('#tabs button[aria-selected=true]',e=>e.dataset.id);await p.screenshot({path:'s_'+id+'.png',fullPage:false});}
await p.click('#tabs button:has-text("Señales")');await p.hover('#sg0 svg',{position:{x:500,y:80}});await p.screenshot({path:'s_sen2.png'});
console.log(await p.textContent('#v-vid'));
console.log(JSON.stringify({errs,er:await p.evaluate(()=>window.__errores||[])}));await b.close()})();
